The shortcut can be placed in any location. 
The .ps1 must be placed in c:\temp unless location in shortcut changed.
Toolbox will be downloaded fresh upon each execution. 