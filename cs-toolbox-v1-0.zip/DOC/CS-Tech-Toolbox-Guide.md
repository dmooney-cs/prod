# 🧰 CS Tech Toolbox – User Guide

This toolbox includes a collection of modular PowerShell scripts designed to assist with validation, diagnostics, agent maintenance, and network analysis on ConnectSecure-managed systems.

## 🔹 Launcher Menu Overview
Each launcher option loads a tool with specific collection or diagnostic capabilities:

### [1] Validation Tool A
- Scans Microsoft Office installations (Word, Excel, Outlook, etc.) from the registry.
- Detects installed system drivers with version information.
- Identifies all local and roaming profiles and audits apps per user.
- Collects browser extension data from Chrome, Edge, and Firefox.
- Exports all data to CSV in the standard export folder.

### [2] Validation Tool B
- Gathers installed hotfixes using Get-HotFix, WMIC, and osquery methods.
- Cross-validates patch records between different tools.
- Includes a VC++ Runtime Dependency Scanner for analyzing .DLL/.EXE libraries.
- Outputs structured data for patch compliance review.
- Supports ZIP + Email and cleanup operations.

### [3] Validation Tool C
- Uses osquery to extract Chrome/Edge extension details with user association.
- Scans for SSL/TLS cipher suites using Nmap against local services.
- Automatically installs required dependencies like Npcap if needed.
- Exports cipher test results and extension data to timestamped CSVs.
- Provides ZIP/email and cleanup support for exported reports.

### [4] Agent Maintenance
- Detects ConnectSecure Agent service and check-in status.
- Offers to restart services or clear pending job queues.
- Allows enabling/disabling SMBv2 and required firewall rules.
- Exports agent status or action results to CSV format.

### [5] Agent Install Tool
- Checks whether the ConnectSecure Agent is already installed.
- Prompts for uninstall before reinstallation if needed.
- Downloads latest agent version from live API endpoint.
- Installs using user-supplied Company ID, Tenant ID, and Key.
- Logs all actions and exports transcript and summary report.

### [6] Network Tools
- Runs TLS 1.0 cipher scan over RDP port (3389) using Nmap.
- Performs full Nmap SSL cipher enumeration on user-defined targets.
- Validates SMB 1.0/2.0/3.0 registry settings on the system.
- Exports detailed scan results to CSV or TXT format.

### [7] Active Directory Tools
- Queries AD users, groups, OUs, computers, and GPOs via native PowerShell.
- Outputs structured objects with metadata for export.
- Designed for auditing domain environments and documenting AD health.
- Fully standalone and includes ZIP/email + cleanup utilities.
.

## 📘 Full List of Shared Functions
Descriptions below illustrate purpose, behavior, and outcomes:

### `Ensure-ExportFolder`
Checks if `C:\Script-Export` exists and creates it if missing. Ensures a valid path for all exported files.

### `Export-Data`
Standardizes CSV output. Includes hostname and timestamp in filename. Displays confirmation and export path on screen.

### `Get-ExportPath`
Returns the absolute path to `C:\Script-Export`, ensuring consistency for other operations.

### `Pause-Script`
Displays a prompt asking the user to press ENTER before continuing. Used to pause between major steps.

### `Run-CleanupExportFolder`
Scans `C:\Script-Export` for generated output files (ZIPs, CSVs, logs). Prompts user for confirmation before deleting. Useful for resetting between tool runs.

### `Run-ZipAndEmailResults`
Zips all output in the export folder. Attempts to launch Outlook with the ZIP file attached. If Outlook is unavailable, it falls back to a `mailto:` link with prefilled subject and body. Also includes logic to prompt user if agent logs should be included in a nested ZIP structure.

### `Show-FolderContents`
Lists the files in a specified folder with sizes and names. Helps verify ZIP content before emailing.

### `Show-Header`
Prints a styled header box at the top of each function section for consistent visual separation.

### `Write-ExportPath`
Prints the export path in bright green formatting to highlight where results were saved.
