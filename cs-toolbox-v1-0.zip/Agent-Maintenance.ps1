
function Show-AgentMaintenanceMenu {
    Clear-Host
    Write-Host ""
    Write-Host "============================================="
    Write-Host "     Agent Maintenance Menu"
    Write-Host "============================================="
    Write-Host ""
    Write-Host " [1] Check Agent Services"
    Write-Host " [2] Clear Pending Jobs"
    Write-Host " [3] Set SMB Compatibility"
    Write-Host " [4] Check SMB Status"
    Write-Host ""
    Write-Host " [Q] Quit to Main Menu"
    Write-Host ""
}
do {
    Show-AgentMaintenanceMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Write-Host "Running: Check Agent Services..." }
        '2' { Write-Host "Running: Clear Pending Jobs..." }
        '3' { Write-Host "Running: Set SMB Compatibility..." }
        '4' { Write-Host "Running: Check SMB Status..." }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
Pause-Script
