# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – AD Validation Tool                    ║
# ║ Version: AD.2 | 2025-07-21                                  ║
# ║ Includes: AD Users, Groups, Computers, OUs, ZIP + Cleanup   ║
# ╚═════════════════════════════════════════════════════════════╝

irm https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/Functions-Common.ps1 | iex
Ensure-ExportFolder

function Run-ADUsers {
    Show-Header "Active Directory Users"
    if (-not (Get-Command Get-ADUser -ErrorAction SilentlyContinue)) {
        Write-Host "Active Directory module not available." -ForegroundColor Red
        Pause-Script; return
    }

    try {
        $users = Get-ADUser -Filter * -Properties DisplayName, EmailAddress, Enabled, LastLogonDate, Department |
            Select-Object SamAccountName, DisplayName, EmailAddress, Enabled, LastLogonDate, Department
        Export-Data -Object $users -BaseName "AD_Users"
    } catch {
        Write-Host "Failed to query AD users." -ForegroundColor Red
    }
    Pause-Script
}

function Run-ADGroups {
    Show-Header "Active Directory Groups"
    if (-not (Get-Command Get-ADGroup -ErrorAction SilentlyContinue)) {
        Write-Host "Active Directory module not available." -ForegroundColor Red
        Pause-Script; return
    }

    try {
        $groups = Get-ADGroup -Filter * -Properties Description, GroupScope |
            Select-Object Name, GroupScope, Description
        Export-Data -Object $groups -BaseName "AD_Groups"
    } catch {
        Write-Host "Failed to query AD groups." -ForegroundColor Red
    }
    Pause-Script
}

function Run-ADComputers {
    Show-Header "Active Directory Computers"
    if (-not (Get-Command Get-ADComputer -ErrorAction SilentlyContinue)) {
        Write-Host "Active Directory module not available." -ForegroundColor Red
        Pause-Script; return
    }

    try {
        $computers = Get-ADComputer -Filter * -Properties IPv4Address, OperatingSystem, LastLogonDate |
            Select-Object Name, IPv4Address, OperatingSystem, LastLogonDate
        Export-Data -Object $computers -BaseName "AD_Computers"
    } catch {
        Write-Host "Failed to query AD computers." -ForegroundColor Red
    }
    Pause-Script
}

function Run-ADOUs {
    Show-Header "Active Directory Organizational Units"
    if (-not (Get-Command Get-ADOrganizationalUnit -ErrorAction SilentlyContinue)) {
        Write-Host "Active Directory module not available." -ForegroundColor Red
        Pause-Script; return
    }

    try {
        $ous = Get-ADOrganizationalUnit -Filter * -Properties CanonicalName |
            Select-Object Name, DistinguishedName, CanonicalName
        Export-Data -Object $ous -BaseName "AD_OUs"
    } catch {
        Write-Host "Failed to retrieve OU data." -ForegroundColor Red
    }
    Pause-Script
}


function Show-ADMenu {
    Clear-Host
    Write-Host ""
    Write-Host "============================================="
    Write-Host "     CS Tech Toolbox - Active Directory Tools     "
    Write-Host "============================================="
    Write-Host ""
    Write-Host " [1] Export AD Users"
    Write-Host " [2] Export AD Groups"
    Write-Host " [3] Export Organizational Units"
    Write-Host " [4] Export GPO Listings"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}
        "6" {
            irm https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/Functions-Common.ps1 | iex
            Invoke-CleanupExportFolder
        }
        "Q" { return }
        default {
            Write-Host "Invalid selection." -ForegroundColor Red
            Pause-Script
        }
    }
    Show-ADMenu
}

Show-ADMenu
