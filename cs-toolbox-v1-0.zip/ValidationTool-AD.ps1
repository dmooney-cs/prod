
function Show-ADMenu {
    Clear-Host
    Write-Host ""
    Write-Host "============================================="
    Write-Host "     CS Tech Toolbox - Active Directory Tools"
    Write-Host "============================================="
    Write-Host ""
    Write-Host " [1] Export AD Users"
    Write-Host " [2] Export AD Groups"
    Write-Host " [3] Export Organizational Units"
    Write-Host " [4] Export GPO Listings"
    Write-Host ""
    Write-Host " [Q] Quit to Main Menu"
    Write-Host ""
}
do {
    Show-ADMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Write-Host "Running: Export AD Users..." }
        '2' { Write-Host "Running: Export AD Groups..." }
        '3' { Write-Host "Running: Export OUs..." }
        '4' { Write-Host "Running: Export GPO Listings..." }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
Pause-Script
