
function Show-NetworkToolsMenu {
    Clear-Host
    Write-Host ""
    Write-Host "============================================="
    Write-Host "     CS Tech Toolbox - Network Tools"
    Write-Host "============================================="
    Write-Host ""
    Write-Host " [1] TLS 1.0 Scan"
    Write-Host " [2] Nmap Validation"
    Write-Host " [3] Validate SMB"
    Write-Host ""
    Write-Host " [Q] Quit to Main Menu"
    Write-Host ""
}
do {
    Show-NetworkToolsMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Write-Host "Running: TLS 1.0 Scan..." }
        '2' { Write-Host "Running: Nmap Validation..." }
        '3' { Write-Host "Running: Validate SMB..." }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
Pause-Script
