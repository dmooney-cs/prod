# Load shared functions from the local extracted folder
. "$PSScriptRoot\Functions-Common.ps1"

function Show-ValidationMenuC {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "         Validation Tool C - OSQuery & TLS Audit"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] OSQuery Browser Extensions Audit"
    Write-Host " [2] SSL/TLS Cipher Scan"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-ValidationMenuC
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' {
            Show-Header "OSQuery Browser Extensions Audit"
            $osquery = "$PSScriptRoot\osqueryi.exe"
            if (Test-Path $osquery) {
                $query = "SELECT * FROM chrome_extensions;"
                $raw = & $osquery --json "$query"
                $parsed = $raw | ConvertFrom-Json
                $outPath = Export-Data -Object $parsed -BaseName "BrowserExt_OSQuery" -Ext "json"
                Write-ExportPath $outPath
            } else {
                Write-Host "osqueryi.exe not found in script directory." -ForegroundColor Red
            }
            Pause-Script
        }
        '2' {
            Show-Header "SSL/TLS Cipher Scan"
            $nmap = "$PSScriptRoot\nmap.exe"
            if (Test-Path $nmap) {
                $ip = Read-Host "Enter target IP or hostname"
                $outPath = Export-Data -Object @("TLS scan for $ip started at $(Get-Date)") -BaseName "TLSCipherScan_$ip" -Ext "txt"
                & $nmap --script ssl-enum-ciphers -p 443 $ip | Out-File $outPath
                Write-ExportPath $outPath
            } else {
                Write-Host "nmap.exe not found in script directory." -ForegroundColor Red
            }
            Pause-Script
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
Pause-Script