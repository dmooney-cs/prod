# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# Local helper: ensure Export path prints consistently
function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}

# ╔════════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool C                                         ║
# ║ Version: C.9 | Browser Extensions + TLS Cipher + ZIP + Cleanup                ║
# ╚════════════════════════════════════════════════════════════════════════════════╝

function Collect-Browser-Extensions {
    Write-Host "`n===== OSQuery Browser Extensions Audit =====" -ForegroundColor Yellow

    $paths = @(
        "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe",
        "C:\Program Files\CyberCNSAgent\osqueryi.exe",
        "$env:ProgramFiles\CyberCNSAgent\osqueryi.exe",
        "$env:ProgramFiles(x86)\CyberCNSAgent\osqueryi.exe"
    )

    $osquery = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1

    if (-not $osquery) {
        Write-Host "⚠ OSQuery not found. Skipping browser extension scan." -ForegroundColor Yellow
        Pause-Script
        return
    }

    $queries = @{
        Chrome  = "SELECT * FROM chrome_extensions;"
        Edge    = "SELECT * FROM edge_extensions;"
        Firefox = "SELECT * FROM firefox_addons;"
    }

    foreach ($browser in $queries.Keys) {
        $query = $queries[$browser]
        Write-Host "`n🔍 Auditing $browser extensions..." -ForegroundColor Cyan
        try {
            $result = & "$osquery" --json "$query" 2>$null | ConvertFrom-Json
            if ($result) {
                $outPath = Export-Data -Object $result -BaseName "$browser-Extensions"
                Write-ExportPath $outPath
            } else {
                Write-Host "⚠ No $browser results found." -ForegroundColor Yellow
            }
        } catch {
            Write-Host "❌ Failed running OSQuery for $browser: $($_)" -ForegroundColor Red
        }
    }

    Pause-Script
}

function Collect-TLSCipherSuites {
    Write-Host "`n===== TLS Cipher Suite Detection =====" -ForegroundColor Yellow

    try {
        $ciphers = Get-TlsCipherSuite | Select-Object Name, Cipher, Protocol, Exchange, Hash
        if ($ciphers.Count -eq 0) {
            Write-Host "⚠ No TLS cipher suites returned." -ForegroundColor Yellow
        } else {
            $outPath = Export-Data -Object $ciphers -BaseName "TLS-Ciphers"
            Write-ExportPath $outPath
        }
    } catch {
        Write-Host "❌ Failed to retrieve TLS cipher suites: $_" -ForegroundColor Red
    }

    Pause-Script
}

function Show-ValidationMenuC {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "   Validation Tool C – Browser + TLS Checks"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Collect Browser Extension Info"
    Write-Host " [2] Detect TLS Cipher Suites"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-ValidationMenuC
    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        '1' { Collect-Browser-Extensions }
        '2' { Collect-TLSCipherSuites }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)

Pause-Script
