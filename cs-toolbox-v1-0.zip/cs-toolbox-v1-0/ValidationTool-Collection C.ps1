# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool C                      ║
# ║ Version: C.4 – Local Load + Output Handling + Pause Fixes   ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

function Show-ValidationMenuC {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "         Validation Tool C - OSQuery & TLS Audit"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] OSQuery Browser Extensions Audit"
    Write-Host " [2] SSL/TLS Cipher Scan"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-ValidationMenuC
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' {
            Show-Header "OSQuery Browser Extensions Audit"
            try {
                $osquery = "$PSScriptRoot\\osqueryi.exe"
                if (Test-Path $osquery) {
                    $query = "SELECT * FROM chrome_extensions;"
                    $raw = & $osquery --json $query
                    $parsed = $raw | ConvertFrom-Json
                    if ($parsed.Count -gt 0) {
                        $outPath = Export-Data -Object $parsed -BaseName "BrowserExt_OSQuery" -Ext "json"
                        Write-ExportPath $outPath
                    } else {
                        Write-Host "⚠ No browser extension results returned." -ForegroundColor Yellow
                    }
                } else {
                    Write-Host "❌ osqueryi.exe not found in script directory." -ForegroundColor Red
                }
            } catch {
                Write-Host "❌ Error occurred during OSQuery extension audit: $_" -ForegroundColor Red
            }
            Pause-Script
        }
        '2' {
            Show-Header "SSL/TLS Cipher Scan"
            try {
                $nmap = "$PSScriptRoot\\nmap.exe"
                if (Test-Path $nmap) {
                    $ip = Read-Host "Enter target IP or hostname"
                    if ($ip) {
                        $scanNote = @("TLS scan for $ip started at $(Get-Date)")
                        $outPath = Export-Data -Object $scanNote -BaseName "TLSCipherScan_$ip" -Ext "txt"
                        & $nmap --script ssl-enum-ciphers -p 443 $ip | Out-File $outPath
                        Write-ExportPath $outPath
                    } else {
                        Write-Host "⚠ No IP or hostname entered." -ForegroundColor Yellow
                    }
                } else {
                    Write-Host "❌ nmap.exe not found in script directory." -ForegroundColor Red
                }
            } catch {
                Write-Host "❌ Error occurred during TLS scan: $_" -ForegroundColor Red
            }
            Pause-Script
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
