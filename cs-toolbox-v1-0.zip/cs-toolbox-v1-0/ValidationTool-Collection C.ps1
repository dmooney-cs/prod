# ╔════════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool C                                         ║
# ║ Version: C.11 | Browser Extensions + TLS Cipher + ZIP + Cleanup               ║
# ╚════════════════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}

function Run-OSQueryBrowserExtensions {
    Show-Header "OSQuery Browser Extensions Audit"

    $paths = @(
        "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe",
        "C:\Program Files\CyberCNSAgent\osqueryi.exe",
        "$env:ProgramFiles\CyberCNSAgent\osqueryi.exe",
        "$env:ProgramFiles(x86)\CyberCNSAgent\osqueryi.exe"
    )

    $osquery = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1

    if (-not $osquery) {
        Write-Host "⚠ OSQuery not found. Please ensure the agent is installed." -ForegroundColor Red
        Pause-Script
        return
    }

    $queries = @{
        Chrome  = "SELECT * FROM chrome_extensions;"
        Edge    = "SELECT * FROM edge_extensions;"
        Firefox = "SELECT * FROM firefox_addons;"
    }

    foreach ($browser in $queries.Keys) {
        try {
            $results = & $osquery --json $queries[$browser] | ConvertFrom-Json
            Export-Data -Object $results -BaseName "$browser-Extensions"
        } catch {
            Write-Host "✖ Failed running OSQuery for $browser: $(${_})" -ForegroundColor Red
        }
    }

    Pause-Script
}

function Run-SSLCipherValidation {
    Show-Header "SSL Cipher Validation (Nmap Port 443)"

    $nmap = "C:\Program Files (x86)\CyberCNSAgent\nmap\nmap.exe"
    if (-not (Test-Path $nmap)) {
        Write-Host "Nmap not found at: $nmap" -ForegroundColor Red
        Pause-Script
        return
    }

    $ip = Read-Host "Enter target IP for scan"
    $log = Get-ExportPath -BaseName "SSLCipher443Scan-$ip" -Ext "txt"

    try {
        $result = & $nmap --script ssl-enum-ciphers -p 443 $ip
        $result | Out-File $log -Encoding UTF8
        Write-ExportPath $log
    } catch {
        Write-Host "Scan failed." -ForegroundColor Red
    }

    Pause-Script
}

function Show-ValidationMenuC {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "     Validation Tool C - TLS and Browser Extensions"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] SSL Cipher Test (Port 443)"
    Write-Host " [2] Audit Browser Extensions (OSQuery)"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-ValidationMenuC
    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        "1" { Run-SSLCipherValidation }
        "2" { Run-OSQueryBrowserExtensions }
        "Z" { Invoke-ZipAndEmailResults }
        "C" { Cleanup-ExportFolder }
        "Q" { break }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Start-Sleep -Seconds 1.5
        }
    }
} while ($true)
