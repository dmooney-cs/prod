# ╔═════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool C                              ║
# ║ Version: C.4 | 2025-08-06                                           ║
# ║ Includes OSQuery + TLS Cipher + ZIP + Cleanup                       ║
# ╚═════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-OSQueryBrowserExtensions {
    Show-Header "OSQuery Browser Extensions Audit"

    $osqueryPath = "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe"
    if (!(Test-Path $osqueryPath)) {
        Write-Host "OSQuery not found at expected path: $osqueryPath" -ForegroundColor Red
        Pause-Script
        return
    }

    $browsers = @(
        @{ Name = "Chrome";    Query = "SELECT * FROM chrome_extensions;" },
        @{ Name = "Edge";      Query = "SELECT * FROM edge_extensions;" },
        @{ Name = "Firefox";   Query = "SELECT * FROM firefox_addons;" }
    )

    foreach ($browser in $browsers) {
        try {
            $output = & $osqueryPath --json "$($browser.Query)" 2>$null | ConvertFrom-Json
            if ($output) {
                Export-Data -Object $output -BaseName "OSQuery-$($browser.Name)-Extensions"
            } else {
                Write-Host "⚠ No results found for $($browser.Name)" -ForegroundColor Yellow
            }
        } catch {
            Write-Host "❌ Failed running OSQuery for $($browser.Name): $($_.Exception.Message)" -ForegroundColor Red
        }
    }

    Pause-Script
}

function Run-TLSCipherScan {
    Show-Header "TLS Cipher (RDP) Scan"

    $nmapPath = "C:\Program Files (x86)\CyberCNSAgent\nmap\nmap.exe"
    if (!(Test-Path $nmapPath)) {
        Write-Host "Nmap not found at expected path: $nmapPath" -ForegroundColor Red
        Pause-Script
        return
    }

    $target = Read-Host "Enter IP address of target system"
    $cmd = "$nmapPath --script ssl-enum-ciphers -p 3389 $target"

    try {
        $output = Invoke-Expression $cmd
        $exportFile = Join-Path $ExportFolder "TLS-CipherScan.txt"
        $output | Out-File -FilePath $exportFile -Encoding UTF8
        Write-ExportPath $exportFile
    } catch {
        Write-Host "❌ Nmap scan failed: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script
}

function Show-ValidationMenuC {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "     CS Toolbox - Validation Tool C - OSQuery Tools  "
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Scan Browser Extensions (OSQuery)"
        Write-Host " [2] Check TLS 1.0 Ciphers (Nmap Port 3389)"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice) {
            "1" { Run-OSQueryBrowserExtensions }
            "2" { Run-TLSCipherScan }
            "Z" { Invoke-ZipAndEmailResults }
            "C" { Clear-ExportFolder }
            "Q" { return }
            default { Write-Host "Invalid selection. Try again." -ForegroundColor Yellow; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}

Show-ValidationMenuC
