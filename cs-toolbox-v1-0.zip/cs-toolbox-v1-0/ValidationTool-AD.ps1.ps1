# ╔═════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool AD                             ║
# ║ Version: AD.4 | 2025-08-06                                          ║
# ║ Active Directory: Users, Groups, OUs, GPOs                          ║
# ╚═════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-ADUserAudit {
    Show-Header "Active Directory User Audit"
    try {
        $users = Get-ADUser -Filter * -Properties DisplayName, EmailAddress, Enabled, LastLogonDate |
                 Select-Object Name, DisplayName, EmailAddress, Enabled, LastLogonDate
        Export-Data -Object $users -BaseName "AD-Users"
    } catch {
        Write-Host "❌ Error fetching AD Users: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

function Run-ADGroupAudit {
    Show-Header "Active Directory Group Audit"
    try {
        $groups = Get-ADGroup -Filter * |
                  Select-Object Name, GroupScope, Description
        Export-Data -Object $groups -BaseName "AD-Groups"
    } catch {
        Write-Host "❌ Error fetching AD Groups: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

function Run-ADOUAudit {
    Show-Header "Active Directory OU Audit"
    try {
        $ous = Get-ADOrganizationalUnit -Filter * |
               Select-Object Name, DistinguishedName
        Export-Data -Object $ous -BaseName "AD-OUs"
    } catch {
        Write-Host "❌ Error fetching AD OUs: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

function Run-ADGPOAudit {
    Show-Header "Active Directory GPO Audit"
    try {
        $gpos = Get-GPO -All |
                Select-Object DisplayName, Owner, CreationTime, ModificationTime
        Export-Data -Object $gpos -BaseName "AD-GPOs"
    } catch {
        Write-Host "❌ Error fetching GPOs: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

function Show-ADMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "     CS Toolbox - Active Directory Validation Tool   "
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Export AD Users"
        Write-Host " [2] Export AD Groups"
        Write-Host " [3] Export AD Organizational Units"
        Write-Host " [4] Export GPO Information"
        Write-Host " [5] Run All (1-4)"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice) {
            "1" { Run-ADUserAudit }
            "2" { Run-ADGroupAudit }
            "3" { Run-ADOUAudit }
            "4" { Run-ADGPOAudit }
            "5" {
                Run-ADUserAudit
                Run-ADGroupAudit
                Run-ADOUAudit
                Run-ADGPOAudit
            }
            "Z" { Invoke-ZipAndEmailResults }
            "C" { Clear-ExportFolder }
            "Q" { return }
            default { Write-Host "Invalid selection. Try again." -ForegroundColor Yellow; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}

Show-ADMenu
