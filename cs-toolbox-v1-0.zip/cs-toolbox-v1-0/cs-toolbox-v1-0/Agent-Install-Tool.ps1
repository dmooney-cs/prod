Ensure-ExportFolder
# Load shared functions from the local extracted folder
. "$PSScriptRoot\Functions-Common.ps1"

function Show-AgentInstallMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "             CS Toolbox - Agent Install Tool"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Install CyberCNS Agent"
    Write-Host " [2] Reinstall CyberCNS Agent"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Back to Agent Menu"
    Write-Host ""
}

function Run-AgentInstall {
    Show-Header "Install CyberCNS Agent"
    $msg = ""
    try {
        $company = Read-Host "Enter Company ID"
        $tenant = Read-Host "Enter Tenant ID"
        $key = Read-Host "Enter Secret Key"
        $agentUrl = "https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows"
        $agentPath = Join-Path $PSScriptRoot "cybercnsagent.exe"
        Invoke-WebRequest -Uri $agentUrl -OutFile $agentPath -UseBasicParsing
        $cmd = "`"$agentPath`" -c $company -e $tenant -j $key -i"
        Write-Host "Running: $cmd"
        $proc = Start-Process -FilePath $agentPath -ArgumentList "-c $company -e $tenant -j $key -i" -Wait -PassThru
        $msg = "Agent installed with exit code $($proc.ExitCode) at $(Get-Date)"
    } catch {
        $msg = "Agent install failed: $_"
        Write-Host $msg
    }
    $outPath = Export-Data -Object $msg -BaseName "AgentInstallLog" -Ext "txt"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-AgentReinstall {
    Show-Header "Reinstall CyberCNS Agent"
    $msg = ""
    try {
        $uninstallPath = "C:\Program Files (x86)\CyberCNSAgent\uninstall.bat"
        if (Test-Path $uninstallPath) {
            Start-Process -FilePath $uninstallPath -Wait
            Write-Host "Uninstalled existing agent."
        }
        Run-AgentInstall
        $msg = "Reinstall completed at $(Get-Date)"
    } catch {
        $msg = "Reinstall failed: $_"
        Write-Host $msg
    }
    $outPath = Export-Data -Object $msg -BaseName "AgentReinstallLog" -Ext "txt"
    Write-ExportPath $outPath
    Pause-Script
}

do {
    Show-AgentInstallMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Run-AgentInstall }
        '2' { Run-AgentReinstall }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection."
            Pause-Script
        }
    }
} while ($true)
Pause-Script