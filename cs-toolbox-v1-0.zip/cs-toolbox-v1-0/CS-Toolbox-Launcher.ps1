# ╔═════════════════════════════════════════════════════════════════╗
# ║ 🧰 ConnectSecure Technician Toolbox – Launcher                  ║
# ║ Version: Beta1 | 2025-08-06                                     ║
# ║ Runs tools from C:\CS-Toolbox-TEMP                              ║
# ╚═════════════════════════════════════════════════════════════════╝

function Show-LauncherMenu {
    Clear-Host
    Write-Host "╔════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║     🧰 ConnectSecure Technician Toolbox – v1.0     ║" -ForegroundColor Cyan
    Write-Host "╚════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "🧪 VALIDATION TOOLS" -ForegroundColor Yellow
    Write-Host " [1] Run Validation A – Office, Drivers, Extensions"
    Write-Host " [2] Run Validation B – Security, Logging, NMAP"
    Write-Host " [3] Run Validation C – OSQuery Browser/Programs"
    Write-Host " [4] Run Active Directory Validation"
    Write-Host " [5] Run ALL Validations (1–4)"
    Write-Host ""
    Write-Host "🖥️ SYSTEM INFO" -ForegroundColor Yellow
    Write-Host " [6] System Info – Summary"
    Write-Host " [7] System Info – Detailed"
    Write-Host ""
    Write-Host "🧰 AGENT TOOLS" -ForegroundColor Yellow
    Write-Host " [8] Agent Installer"
    Write-Host " [9] Agent Maintenance"
    Write-Host " [A] Full Agent Menu"
    Write-Host " [U] Uninstall CyberCNS Agent V4"
    Write-Host ""
    Write-Host "🛠️ UTILITIES" -ForegroundColor Yellow
    Write-Host " [T] Tools & Utilities"
    Write-Host ""
    Write-Host " [Q] Quit Toolbox"
    Write-Host ""
}

$toolRoot = "C:\CS-Toolbox-TEMP"

do {
    Show-LauncherMenu
    $choice = Read-Host "Select an option"

    switch ($choice.ToUpper()) {
        "1" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\ValidationTool-Collection A.ps1"
            }
        }
        "2" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\ValidationTool-Collection B.ps1"
            }
        }
        "3" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\ValidationTool-Collection C.ps1"
            }
        }
        "4" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\ValidationTool-AD.ps1"
            }
        }
        "5" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\ValidationTool-Collection A.ps1"
            }
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\ValidationTool-Collection B.ps1"
            }
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\ValidationTool-Collection C.ps1"
            }
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\ValidationTool-AD.ps1"
            }
        }
        "6" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\SystemInfo-A.ps1"
            }
        }
        "7" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\SystemInfo-B.ps1"
            }
        }
        "8" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\Agent-Install-Tool.ps1"
            }
        }
        "9" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\Agent-Maintenance.ps1"
            }
        }
        "A" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\Agent-Menu-Tool.ps1"
            }
        }
        "U" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\Uninstall-CyberCNSAgentV4.ps1"
            }
        }
        "T" {
            & {
                . "$toolRoot\Functions-Common.ps1"
                . "$toolRoot\Tools-Utilities.ps1"
            }
        }
        "Q" {
            Write-Host "`nExiting Toolbox..." -ForegroundColor Cyan
            break
        }
        default {
            Write-Host "`nInvalid option. Please try again." -ForegroundColor Red
            Start-Sleep -Seconds 2
        }
    }

} while ($true)
