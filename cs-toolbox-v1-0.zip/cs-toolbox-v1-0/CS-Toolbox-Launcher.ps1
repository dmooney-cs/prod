# ╔════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Main Launcher                                 ║
# ║ Version: Beta1 | 2025-08-06                                   ║
# ║ Loads 5 modular tools designed for ConnectSecure diagnostics  ║
# ╚════════════════════════════════════════════════════════════════╝

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
. "$scriptRoot\Functions-Common.ps1"

function Show-MainMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "         ConnectSecure Technicians Toolbox"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Validation Tool A         - Office, Drivers, Roaming, Extensions"
    Write-Host " [2] Validation Tool B         - Patches, VC++ Runtime Scanner"
    Write-Host " [3] Validation Tool C         - SSL Ciphers, OSQuery Extensions"
    Write-Host ""
    Write-Host " [4] Network Tools             - TLS 1.0 Scan, Nmap, Validate SMB"
    Write-Host " [5] Active Directory Tools    - Users, Groups, OUs, GPOs"
    Write-Host ""
    Write-Host " [6] System Info A             - Firewall, Defender, Disk/SMART"
    Write-Host " [7] System Info B             - Pending Reboot, App Logs, Startup Audit"
    Write-Host ""
    Write-Host " [8] Utilities                 - Running Services, Disk Space"
    Write-Host " [9] Agent Menu Tool           - Install, Uninstall, Update, Status"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results     - Compress and prepare results for support"
    Write-Host " [C] Cleanup Toolbox Data      - Remove all temp and output files"
    Write-Host " [Q] Quit"
    Write-Host ""
}

function Run-MainMenu {
    do {
        Show-MainMenu
        $choice = Read-Host "Enter your choice"
        switch ($choice) {
            "1" { . "$scriptRoot\ValidationTool-CollectionA.ps1" }
            "2" { . "$scriptRoot\ValidationTool-CollectionB.ps1" }
            "3" { . "$scriptRoot\ValidationTool-CollectionC.ps1" }
            "4" { . "$scriptRoot\Tools-Network.ps1" }
            "5" { . "$scriptRoot\ValidationTool-AD.ps1" }
            "6" { . "$scriptRoot\SystemInfo-A.ps1" }
            "7" { . "$scriptRoot\SystemInfo-B.ps1" }
            "8" { . "$scriptRoot\Tools-Utilities.ps1" }
            "9" { . "$scriptRoot\Agent-Menu-Tool.ps1" }
            "Z" { Invoke-ZipAndEmailResults }
            "C" { Invoke-CleanupToolbox }
            "Q" { return }
            default {
                Write-Host "Invalid selection. Try again..." -ForegroundColor Yellow
                Start-Sleep -Seconds 1.5
            }
        }
    } while ($true)
}

Run-MainMenu