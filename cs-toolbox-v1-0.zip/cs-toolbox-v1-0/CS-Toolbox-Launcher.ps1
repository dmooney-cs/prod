# ╔════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Main Launcher                                 ║
# ║ Version: Beta1 | 2025-08-06                                   ║
# ║ Loads 5 modular tools designed for ConnectSecure diagnostics  ║
# ╚════════════════════════════════════════════════════════════════╝

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
try {
    . "$scriptRoot\Functions-Common.ps1"
} catch {
    Write-Host "❌ Failed to load Functions-Common.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}

function Show-MainMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "         ConnectSecure Technicians Toolbox"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Validation Tool A         - Office, Drivers, Roaming, Extensions"
    Write-Host " [2] Validation Tool B         - Patches, VC++ Runtime Scanner"
    Write-Host " [3] Validation Tool C         - SSL Ciphers, OSQuery Extensions"
    Write-Host ""
    Write-Host " [4] Network Tools             - TLS 1.0 Scan, Nmap, Validate SMB"
    Write-Host " [5] Active Directory Tools    - Users, Groups, OUs, GPOs"
    Write-Host ""
    Write-Host " [6] System Info A             - Firewall, Defender, Disk/SMART"
    Write-Host " [7] System Info B             - Pending Reboot, App Logs, Startup Audit"
    Write-Host ""
    Write-Host " [8] Utilities                 - Running Services, Disk Space"
    Write-Host " [9] Agent Menu Tool           - Install, Uninstall, Update, Status"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results     - Compress and prepare results for support"
    Write-Host " [C] Cleanup Toolbox Data      - Remove all temp and output files"
    Write-Host " [Q] Quit"
    Write-Host ""
}

function Run-MainMenu {
    do {
        Show-MainMenu
        $choice = Read-Host "Enter your choice"
        switch ($choice) {
try {
    . "$scriptRoot\ValidationTool-CollectionA.ps1"
} catch {
    Write-Host "❌ Failed to load ValidationTool-CollectionA.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}
try {
    . "$scriptRoot\ValidationTool-CollectionB.ps1"
} catch {
    Write-Host "❌ Failed to load ValidationTool-CollectionB.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}
try {
    . "$scriptRoot\ValidationTool-CollectionC.ps1"
} catch {
    Write-Host "❌ Failed to load ValidationTool-CollectionC.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}
try {
    . "$scriptRoot\Tools-Network.ps1"
} catch {
    Write-Host "❌ Failed to load Tools-Network.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}
try {
    . "$scriptRoot\ValidationTool-AD.ps1"
} catch {
    Write-Host "❌ Failed to load ValidationTool-AD.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}
try {
    . "$scriptRoot\SystemInfo-A.ps1"
} catch {
    Write-Host "❌ Failed to load SystemInfo-A.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}
try {
    . "$scriptRoot\SystemInfo-B.ps1"
} catch {
    Write-Host "❌ Failed to load SystemInfo-B.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}
try {
    . "$scriptRoot\Tools-Utilities.ps1"
} catch {
    Write-Host "❌ Failed to load Tools-Utilities.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}
try {
    . "$scriptRoot\Agent-Menu-Tool.ps1"
} catch {
    Write-Host "❌ Failed to load Agent-Menu-Tool.ps1" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause
}
            "Z" { Invoke-ZipAndEmailResults }
            "C" { Invoke-CleanupToolbox }
            "Q" { return }
            default {
                Write-Host "Invalid selection. Try again..." -ForegroundColor Yellow
                Start-Sleep -Seconds 1.5
            }
        }
    } while ($true)
}

Run-MainMenu