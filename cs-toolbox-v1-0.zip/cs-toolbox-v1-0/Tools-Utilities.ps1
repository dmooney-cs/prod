Ensure-ExportFolder
# Load shared functions from the local extracted folder
. "$PSScriptRoot\Functions-Common.ps1"

function Show-UtilitiesMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "         CS Toolbox - Utilities"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] List All Running Services"
    Write-Host " [2] Show Free Disk Space"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-UtilitiesMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' {
            Show-Header "List All Running Services"
            $services = Get-Service | Where-Object { $_.Status -eq "Running" } | Select-Object Name, DisplayName, Status
            $outPath = Export-Data -Object $services -BaseName "RunningServices"
            Write-ExportPath $outPath
            Pause-Script
        }
        '2' {
            Show-Header "Show Free Disk Space"
            $disks = Get-WmiObject Win32_LogicalDisk | Select-Object DeviceID, MediaType, Size, FreeSpace
            $outPath = Export-Data -Object $disks -BaseName "FreeDiskSpace"
            Write-ExportPath $outPath
            Pause-Script
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
Pause-Script