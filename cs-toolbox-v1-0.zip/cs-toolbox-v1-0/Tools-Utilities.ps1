# ╔═════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Utilities Tool                                 ║
# ║ Version: U.4 | 2025-08-06                                           ║
# ║ Running Services, Disk Space Snapshot                              ║
# ╚═════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-ServiceAudit {
    Show-Header "Running Services Snapshot"
    $services = Get-Service | Where-Object { $_.Status -eq "Running" } |
        Select-Object DisplayName, Name, Status, StartType
    Export-Data -Object $services -BaseName "Running-Services"
    Pause-Script
}

function Run-DiskSpaceCheck {
    Show-Header "Disk Space Audit"
    $disks = Get-PSDrive -PSProvider FileSystem |
        Select-Object Name, @{Name='Size(GB)';Expression={"{0:N2}" -f ($_.Used + $_.Free)/1GB}},
                      @{Name='Free(GB)';Expression={"{0:N2}" -f ($_.Free/1GB)}},
                      @{Name='Used(GB)';Expression={"{0:N2}" -f ($_.Used/1GB)}}
    Export-Data -Object $disks -BaseName "Disk-Space"
    Pause-Script
}

function Show-UtilitiesMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "       CS Toolbox - Utilities and Diagnostics        "
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Export Running Services"
        Write-Host " [2] Export Disk Space Info"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice) {
            "1" { Run-ServiceAudit }
            "2" { Run-DiskSpaceCheck }
            "Z" { Invoke-ZipAndEmailResults }
            "C" { Clear-ExportFolder }
            "Q" { return }
            default { Write-Host "Invalid selection. Try again." -ForegroundColor Yellow; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}

Show-UtilitiesMenu
