# Load shared functions from the local extracted folder
. "$PSScriptRoot\Functions-Common.ps1"

function Show-UninstallMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "        CS Toolbox - Uninstall Agent V4 Tool"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Uninstall CyberCNS Agent V4"
    Write-Host ""
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Back to Agent Menu"
    Write-Host ""
}

function Run-AgentUninstall {
    Show-Header "Uninstalling CyberCNS Agent V4"
    $msg = ""
    try {
        $uninstallPath = "C:\Program Files (x86)\CyberCNSAgent\uninstall.bat"
        if (Test-Path $uninstallPath) {
            Start-Process -FilePath $uninstallPath -Wait
            $msg = "Uninstall completed using $uninstallPath"
        } else {
            $msg = "Uninstall batch file not found at $uninstallPath"
        }
        $outPath = Export-Data -Object $msg -BaseName "UninstallLog" -Ext "txt"
        Write-ExportPath $outPath
    } catch {
        Write-Host "Error during uninstall: $_"
    }
    Pause-Script
}

do {
    Show-UninstallMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Run-AgentUninstall }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again."
            Pause-Script
        }
    }
} while ($true)
Pause-Script