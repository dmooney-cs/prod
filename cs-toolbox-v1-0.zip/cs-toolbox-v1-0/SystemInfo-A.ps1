# Load shared functions from the local extracted folder
. "$PSScriptRoot\Functions-Common.ps1"

function Show-SystemInfoAMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "     CS Toolbox - System Information (A)"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Firewall & Defender Check"
    Write-Host " [2] Disk Space & SMART Status"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-SystemInfoAMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' {
            Show-Header "Firewall & Defender Check"
            $fw = Get-NetFirewallProfile | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction
            $def = Get-MpComputerStatus | Select-Object AMServiceEnabled, AntivirusEnabled, AntispywareEnabled, RealTimeProtectionEnabled
            $summary = [PSCustomObject]@{
                Firewall = $fw
                Defender = $def
            }
            $outPath = Export-Data -Object $summary -BaseName "FW_Defender"
            Write-ExportPath $outPath
            Pause-Script
        }
        '2' {
            Show-Header "Disk Space & SMART Status"
            $disks = Get-WmiObject Win32_LogicalDisk | Select-Object DeviceID, Size, FreeSpace, MediaType
            $smart = Get-WmiObject MSStorageDriver_FailurePredictStatus -Namespace "root\WMI" | 
                Select-Object InstanceName, PredictFailure
            $outPath1 = Export-Data -Object $disks -BaseName "DiskSpace"
            $outPath2 = Export-Data -Object $smart -BaseName "SMARTStatus"
            Write-ExportPath $outPath1
            Write-ExportPath $outPath2
            Pause-Script
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
Pause-Script