# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – System Info Tool (A)                        ║
# ║ Version: A.1 | Hostname, IP, Uptime                         ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-HostnameCheck {
    Show-Header "System Hostname"
    $hostname = hostname
    $outPath = Export-Data -Object $hostname -BaseName "Hostname" -Ext "txt"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-IPConfigSummary {
    Show-Header "IP Configuration Summary"
    $ipconfig = Get-NetIPAddress -AddressFamily IPv4 |
        Select-Object IPAddress, InterfaceAlias, PrefixOrigin, SuffixOrigin
    $outPath = Export-Data -Object $ipconfig -BaseName "IPSummary"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-UptimeReport {
    Show-Header "System Uptime Report"
    $uptime = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
    $since = (Get-Date) - $uptime
    $formatted = "Uptime: {0} days, {1} hours, {2} minutes" -f $since.Days, $since.Hours, $since.Minutes
    $outPath = Export-Data -Object $formatted -BaseName "SystemUptime" -Ext "txt"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-AllSystemInfo {
    Show-Header "Running All System Info Checks"

    $hostname = hostname
    Export-Data -Object $hostname -BaseName "Hostname" -Ext "txt"

    $ipconfig = Get-NetIPAddress -AddressFamily IPv4 |
        Select-Object IPAddress, InterfaceAlias, PrefixOrigin, SuffixOrigin
    Export-Data -Object $ipconfig -BaseName "IPSummary"

    $uptime = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
    $since = (Get-Date) - $uptime
    $formatted = "Uptime: {0} days, {1} hours, {2} minutes" -f $since.Days, $since.Hours, $since.Minutes
    Export-Data -Object $formatted -BaseName "SystemUptime" -Ext "txt"

    Write-Host "`n✅ All system info collected." -ForegroundColor Green
    Pause-Script
}

function Run-ZipAndEmailResults {
    Show-Header "Zipping and Emailing Results"
    try {
        $zipPath = Zip-ExportFolder
        Send-ZipEmail -Attachment $zipPath
        Write-ExportPath $zipPath
    } catch {
        Write-Host "❌ Error during ZIP/Email: $_" -ForegroundColor Red
    }
    Pause-Script
}

function Run-CleanupExportFolder {
    Show-Header "Cleaning Up Export Folder"
    Cleanup-ExportFolder
    Pause-Script
}

function Show-SystemInfoAMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "        CS Toolbox – System Info (A)"
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Show Hostname"
        Write-Host " [2] Show IP Configuration"
        Write-Host " [3] Show System Uptime"
        Write-Host ""
        Write-Host " [5] Run All System Info Checks"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit to Main Menu"
        Write-Host ""
        $choice = Read-Host "Select an option"

        switch ($choice.ToUpper()) {
            '1' { Run-HostnameCheck }
            '2' { Run-IPConfigSummary }
            '3' { Run-UptimeReport }
            '5' { Run-AllSystemInfo }
            'Z' { Run-ZipAndEmailResults }
            'C' { Run-CleanupExportFolder }
            'Q' { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Pause-Script
            }
        }
    } while ($true)
}

Show-SystemInfoAMenu
