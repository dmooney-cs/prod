# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

function Show-ValidationMenuB {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "        Validation Tool B - Patch & VC++ Audit"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Windows Patch Validation (Get-HotFix)"
    Write-Host " [2] Windows Patch Validation (WMIC/COM)"
    Write-Host " [3] Patch Validation (osquery)"
    Write-Host " [4] VC++ Runtime Detection"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-ValidationMenuB
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' {
            Show-Header "Windows Patch Validation (Get-HotFix)"
            $patches = Get-HotFix | Select-Object HotFixID, InstalledOn, Description
            $outPath = Export-Data -Object $patches -BaseName "Patches_GetHotFix"
            Write-ExportPath $outPath
            Pause-Script
        }
        '2' {
            Show-Header "Windows Patch Validation (WMIC/COM)"
            $patches = Get-WmiObject Win32_QuickFixEngineering | Select-Object HotFixID, Description, InstalledOn
            $outPath = Export-Data -Object $patches -BaseName "Patches_WMIC"
            Write-ExportPath $outPath
            Pause-Script
        }
        '3' {
            Show-Header "Patch Validation (osquery)"
            $osquery = "$PSScriptRoot\osqueryi.exe"
            if (Test-Path $osquery) {
                $query = "SELECT hotfix_id, description, installed_on FROM patches;"
                $raw = & $osquery --json "$query"
                $parsed = $raw | ConvertFrom-Json
                $outPath = Export-Data -Object $parsed -BaseName "Patches_Osquery" -Ext "json"
                Write-ExportPath $outPath
            } else {
                Write-Host "osqueryi.exe not found in script directory."
            }
            Pause-Script
        }
        '4' {
            Show-Header "VC++ Runtime Detection"
            $vcList = Get-ChildItem "C:\Program Files*" -Recurse -Filter "vcredist*.exe" -ErrorAction SilentlyContinue | 
                Select-Object FullName, Name
            $outPath = Export-Data -Object $vcList -BaseName "VCRedist"
            Write-ExportPath $outPath
            Pause-Script
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again."
            Pause-Script
        }
    }
} while ($true)
Pause-Script
