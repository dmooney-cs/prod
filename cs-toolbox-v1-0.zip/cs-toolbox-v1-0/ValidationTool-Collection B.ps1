. "$PSScriptRoot\Functions-Common.ps1"

# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool B                      ║
# ║ Version: B.3 | Patches, VC++ Runtimes                       ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-PatchesAudit {
    Show-Header "Installed Patches Audit"

    $osquery = "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe"
    if (!(Test-Path $osquery)) {
        Write-Host "OSQuery not found. Skipping patches audit." -ForegroundColor Yellow
        Pause-Script
        return
    }

    $query = "SELECT hotfix_id, description, installed_on FROM patches;"
    try {
        $raw = & $osquery "--json" $query
        $parsed = $raw | ConvertFrom-Json
        Export-Data -Object $parsed -BaseName "Patches_Osquery" -Ext "json"
        Export-Data -Object $parsed -BaseName "Patches_Osquery" -Ext "csv"
    } catch {
        Write-Host "OSQuery failed to run or returned invalid data." -ForegroundColor Red
    }

    Pause-Script
}

function Run-VCRuntimeAudit {
    Show-Header "VC++ Runtime Detection"

    $results = Get-WmiObject -Class Win32_Product |
        Where-Object { $_.Name -like "*Visual C++*" } |
        Select-Object Name, Version, InstallDate

    Export-Data -Object $results -BaseName "VCRuntime"
    Pause-Script
}

# Main Execution
Run-PatchesAudit
Run-VCRuntimeAudit
