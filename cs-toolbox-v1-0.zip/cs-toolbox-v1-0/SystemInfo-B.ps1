Ensure-ExportFolder
# Load shared functions from the local extracted folder
. "$PSScriptRoot\Functions-Common.ps1"

function Show-SystemInfoBMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "      CS Toolbox - System Information (B)"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Check for Pending Reboot"
    Write-Host " [2] Summarize Application Event Logs (last 7 days)"
    Write-Host " [3] Startup / Autostart Audit"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-SystemInfoBMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' {
            Show-Header "Pending Reboot Detector"
            $pending = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending" -ErrorAction SilentlyContinue
            $result = if ($pending) { "Reboot required" } else { "No reboot required" }
            $outPath = Export-Data -Object $result -BaseName "PendingReboot" -Ext "txt"
            Write-ExportPath $outPath
            Pause-Script
        }
        '2' {
            Show-Header "Summarize Application Event Logs (Last 7 Days)"
            $since = (Get-Date).AddDays(-7)
            $logs = Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$since} | 
                Select-Object TimeCreated, Id, LevelDisplayName, Message
            $outPath = Export-Data -Object $logs -BaseName "AppEventLog"
            Write-ExportPath $outPath
            Pause-Script
        }
        '3' {
            Show-Header "Startup / Autostart Audit"
            $startup = Get-CimInstance -ClassName Win32_StartupCommand | 
                Select-Object Name, Command, Location, User
            $outPath = Export-Data -Object $startup -BaseName "StartupItems"
            Write-ExportPath $outPath
            Pause-Script
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
Pause-Script