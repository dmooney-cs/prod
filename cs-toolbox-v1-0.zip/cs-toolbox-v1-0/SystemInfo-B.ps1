# ╔═════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – System Info Tool B                             ║
# ║ Version: B.4 | 2025-08-06                                           ║
# ║ Pending Reboot, App Logs, Startup Apps                             ║
# ╚═════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-PendingRebootCheck {
    Show-Header "Pending Reboot Check"

    $pending = @{
        CBS = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending')
        WindowsUpdate = (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired')
        SCCM = (Test-Path 'HKLM:\SOFTWARE\Microsoft\SMS\Mobile Client\Reboot Management\RebootRequired')
        PendingFileRename = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue)
    }

    Export-Data -Object $pending.GetEnumerator() | Select-Object Name, Value -BaseName "PendingRebootCheck"
    Pause-Script
}

function Run-AppCrashLogs {
    Show-Header "Application Event Logs (Last 7 Days)"

    $since = (Get-Date).AddDays(-7)
    $logs = Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$since; Level=2} -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, ProviderName, Id, LevelDisplayName, Message

    Export-Data -Object $logs -BaseName "App-Crash-Logs"
    Pause-Script
}

function Run-StartupAppAudit {
    Show-Header "Startup Applications"

    $startup = Get-CimInstance Win32_StartupCommand |
        Select-Object Name, Command, Location, User

    Export-Data -Object $startup -BaseName "Startup-Apps"
    Pause-Script
}

function Show-SystemInfoBMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "    CS Toolbox - System Info B - Startup + Reboot    "
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Check Pending Reboot Status"
        Write-Host " [2] Export Application Logs (last 7 days)"
        Write-Host " [3] Audit Startup Applications"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice) {
            "1" { Run-PendingRebootCheck }
            "2" { Run-AppCrashLogs }
            "3" { Run-StartupAppAudit }
            "Z" { Invoke-ZipAndEmailResults }
            "C" { Clear-ExportFolder }
            "Q" { return }
            default { Write-Host "Invalid selection. Try again." -ForegroundColor Yellow; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}

Show-SystemInfoBMenu
