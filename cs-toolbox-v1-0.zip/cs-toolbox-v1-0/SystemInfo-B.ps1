# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – System Info Tool (B)                        ║
# ║ Version: B.1 | Reboot Check, Event Logs, Autostarts        ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-PendingRebootCheck {
    Show-Header "Pending Reboot Detector"
    $pending = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending" -ErrorAction SilentlyContinue
    $result = if ($pending) { "Reboot required" } else { "No reboot required" }
    $outPath = Export-Data -Object $result -BaseName "PendingReboot" -Ext "txt"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-EventLogSummary {
    Show-Header "Summarize Application Event Logs (Last 7 Days)"
    $since = (Get-Date).AddDays(-7)
    $logs = Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$since} |
        Select-Object TimeCreated, Id, LevelDisplayName, Message
    $outPath = Export-Data -Object $logs -BaseName "AppEventLog"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-StartupAudit {
    Show-Header "Startup / Autostart Audit"
    $startup = Get-CimInstance -ClassName Win32_StartupCommand |
        Select-Object Name, Command, Location, User
    $outPath = Export-Data -Object $startup -BaseName "StartupItems"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-AllSystemChecks {
    Show-Header "Running All System Info Checks"

    $pending = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending" -ErrorAction SilentlyContinue
    $result = if ($pending) { "Reboot required" } else { "No reboot required" }
    Export-Data -Object $result -BaseName "PendingReboot" -Ext "txt"

    $since = (Get-Date).AddDays(-7)
    $logs = Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$since} |
        Select-Object TimeCreated, Id, LevelDisplayName, Message
    Export-Data -Object $logs -BaseName "AppEventLog"

    $startup = Get-CimInstance -ClassName Win32_StartupCommand |
        Select-Object Name, Command, Location, User
    Export-Data -Object $startup -BaseName "StartupItems"

    Write-Host "`n✅ All system checks completed." -ForegroundColor Green
    Pause-Script
}

function Run-ZipAndEmailResults {
    Show-Header "Zipping and Emailing Results"
    try {
        $zipPath = Zip-ExportFolder
        Send-ZipEmail -Attachment $zipPath
        Write-ExportPath $zipPath
    } catch {
        Write-Host "❌ Error during ZIP/Email: $_" -ForegroundColor Red
    }
    Pause-Script
}

function Run-CleanupExportFolder {
    Show-Header "Cleaning Up Export Folder"
    Cleanup-ExportFolder
    Pause-Script
}

function Show-SystemInfoBMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "       CS Toolbox – System Information (B)"
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Check for Pending Reboot"
        Write-Host " [2] Summarize Application Event Logs (Last 7 Days)"
        Write-Host " [3] Startup / Autostart Audit"
        Write-Host ""
        Write-Host " [5] Run All System Checks"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit to Main Menu"
        Write-Host ""
        $choice = Read-Host "Select an option"

        switch ($choice.ToUpper()) {
            '1' { Run-PendingRebootCheck }
            '2' { Run-EventLogSummary }
            '3' { Run-StartupAudit }
            '5' { Run-AllSystemChecks }
            'Z' { Run-ZipAndEmailResults }
            'C' { Run-CleanupExportFolder }
            'Q' { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Pause-Script
            }
        }
    } while ($true)
}

Show-SystemInfoBMenu
