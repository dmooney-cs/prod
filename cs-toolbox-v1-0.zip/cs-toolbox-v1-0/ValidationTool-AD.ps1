# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# Local helper: ensure Export path prints consistently
function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}

function Ensure-ExportFolder {
    if (-not (Test-Path "C:\Script-Exports")) {
        New-Item -Path "C:\" -Name "Script-Exports" -ItemType Directory -Force | Out-Null
    }
}

# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Validation Tool AD                         ║
# ║ Version: AD.1 | AD Users, Groups, Computers, OUs           ║
# ╚═════════════════════════════════════════════════════════════╝

Ensure-ExportFolder

function Run-ADUsers {
    Show-Header "Collecting Active Directory Users"
    $users = Get-ADUser -Filter * -Properties * | Select-Object Name, SamAccountName, Enabled, LastLogonDate, PasswordLastSet, Created, Modified
    Export-Data -Object $users -BaseName "AD_Users"
    Pause-Script
}

function Run-ADGroups {
    Show-Header "Collecting Active Directory Groups"
    $groups = Get-ADGroup -Filter * -Properties * | Select-Object Name, GroupScope, GroupCategory, DistinguishedName, Created, Modified
    Export-Data -Object $groups -BaseName "AD_Groups"
    Pause-Script
}

function Run-ADComputers {
    Show-Header "Collecting Active Directory Computers"
    $computers = Get-ADComputer -Filter * -Properties * | Select-Object Name, DNSHostName, OperatingSystem, Enabled, LastLogonDate, Created, Modified
    Export-Data -Object $computers -BaseName "AD_Computers"
    Pause-Script
}

function Run-ADOUs {
    Show-Header "Collecting Active Directory Organizational Units"
    $ous = Get-ADOrganizationalUnit -Filter * -Properties * | Select-Object Name, DistinguishedName, Created, Modified
    Export-Data -Object $ous -BaseName "AD_OUs"
    Pause-Script
}

function Run-AllADCollections {
    Show-Header "Running All AD Collections"
    $users = Get-ADUser -Filter * -Properties * | Select-Object Name, SamAccountName, Enabled, LastLogonDate, PasswordLastSet, Created, Modified
    Export-Data -Object $users -BaseName "AD_Users"

    $groups = Get-ADGroup -Filter * -Properties * | Select-Object Name, GroupScope, GroupCategory, DistinguishedName, Created, Modified
    Export-Data -Object $groups -BaseName "AD_Groups"

    $computers = Get-ADComputer -Filter * -Properties * | Select-Object Name, DNSHostName, OperatingSystem, Enabled, LastLogonDate, Created, Modified
    Export-Data -Object $computers -BaseName "AD_Computers"

    $ous = Get-ADOrganizationalUnit -Filter * -Properties * | Select-Object Name, DistinguishedName, Created, Modified
    Export-Data -Object $ous -BaseName "AD_OUs"

    Write-Host "`n✅ All AD collections completed." -ForegroundColor Green
    Pause-Script
}

function Run-ZipAndEmailResults {
    Show-Header "Zipping and Emailing Results"
    try {
        $zipPath = Zip-ExportFolder
        Send-ZipEmail -Attachment $zipPath
        Write-ExportPath $zipPath
    } catch {
        Write-Host "❌ Error during ZIP/Email: $($_)" -ForegroundColor Red
    }
    Pause-Script
}

function Run-CleanupExportFolder {
    Show-Header "Cleaning Up Export Folder"
    Cleanup-ExportFolder
    Pause-Script
}

function Show-ADMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "       CS Toolbox - Active Directory Collection Tool "
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Collect AD Users"
        Write-Host " [2] Collect AD Groups"
        Write-Host " [3] Collect AD Computers"
        Write-Host " [4] Collect AD Organizational Units"
        Write-Host ""
        Write-Host " [5] Run All (1–4)"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit to Main Menu"
        Write-Host ""
        $choice = Read-Host "Select an option"

        switch ($choice.ToUpper()) {
            '1' { Run-ADUsers }
            '2' { Run-ADGroups }
            '3' { Run-ADComputers }
            '4' { Run-ADOUs }
            '5' { Run-AllADCollections }
            'Z' { Run-ZipAndEmailResults }
            'C' { Run-CleanupExportFolder }
            'Q' { return }
            default { Write-Host "`nInvalid selection. Press any key to try again..."; $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") }
        }
    } while ($true)
}

Show-ADMenu
