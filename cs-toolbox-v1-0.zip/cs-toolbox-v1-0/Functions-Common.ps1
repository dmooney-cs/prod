# ==========================================
#    CS Toolbox - Shared Utility Functions
# ==========================================

# Set the global export directory (change in one place only)
$Global:ExportDir = "C:\CS-Toolbox-TEMP\Collected-Info"
if (!(Test-Path $Global:ExportDir)) { New-Item -ItemType Directory -Path $Global:ExportDir -Force | Out-Null }

function Show-Header {
    param ([string]$Title)
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "  $Title"
    Write-Host "====================================================="
    Write-Host ""
}

function Pause-Script {
    Read-Host "Press any key to continue..."
}

function Write-ExportPath {
    param([string]$Path)
    Write-Host "Exported to: $Path" -ForegroundColor Green
}

function Export-Data {
    param(
        [Parameter(Mandatory=$true)][object]$Object,
        [Parameter(Mandatory=$true)][string]$BaseName,
        [string]$Ext = "csv"
    )
    # Ensure export folder exists every time
    if (!(Test-Path $Global:ExportDir)) { New-Item -ItemType Directory -Path $Global:ExportDir -Force | Out-Null }
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $outPath = Join-Path $Global:ExportDir ("{0}_{1}.{2}" -f $BaseName, $timestamp, $Ext)

    if ($Ext -eq "json") {
        $Object | ConvertTo-Json | Out-File -Encoding UTF8 $outPath
    } elseif ($Ext -eq "txt") {
        $Object | Out-File -Encoding UTF8 $outPath
    } else {
        $Object | Export-Csv -NoTypeInformation -Path $outPath
    }
    return $outPath
}

function Run-ZipAndEmailResults {
    $zipFile = "C:\CS-Toolbox-TEMP\Collected-Info.zip"
    $exportDir = $Global:ExportDir

    if (!(Test-Path $exportDir) -or !(Get-ChildItem $exportDir -Recurse | Where-Object { -not $_.PSIsContainer })) {
        Write-Host "⚠️  No data to zip. The export folder is missing or empty." -ForegroundColor Yellow
        Pause-Script
        return
    }

    if (Test-Path $zipFile) { Remove-Item $zipFile -Force }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::CreateFromDirectory($exportDir, $zipFile)
    Write-Host "✅ All results zipped at $zipFile" -ForegroundColor Green

    try {
        $Outlook = New-Object -ComObject Outlook.Application
        $Mail = $Outlook.CreateItem(0)
        $Mail.Subject = "CS Toolbox Results"
        $Mail.Body = "Results attached."
        $Mail.Attachments.Add($zipFile)
        $Mail.Display()
        Write-Host "📧 Outlook email created. Review and send." -ForegroundColor Green
    } catch {
        $mailto = "mailto:?subject=CS Toolbox Results&body=Results attached. Please manually attach: $zipFile"
        Start-Process $mailto
        Write-Host "📨 Outlook not available. Opened default email client." -ForegroundColor Yellow
    }
    Pause-Script
}
    Pause-Script
}

function Run-CleanupExportFolder {
    $rootFolder = "C:\CS-Toolbox-TEMP"
    if (Test-Path $rootFolder) {
        Remove-Item -Path $rootFolder -Recurse -Force
        Write-Host "All Toolbox files and exports cleaned up from $rootFolder" -ForegroundColor Green
    } else {
        Write-Host "$rootFolder does not exist, nothing to clean up." -ForegroundColor Yellow
    }
    Pause-Script
}