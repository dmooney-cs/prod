. "$PSScriptRoot\Functions-Common.ps1"

function Show-ValidationMenuA {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "       Validation Tool A - App + Driver Checks"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Validate Microsoft Office Installations"
    Write-Host " [2] Audit Installed Drivers"
    Write-Host " [3] Scan Roaming Profiles for Applications"
    Write-Host " [4] Detect Browser Extensions (Chrome, Edge, Firefox)"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-ValidationMenuA
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' {
            Show-Header "Microsoft Office Validation"
            $apps = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, `
                                      HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue |
                Where-Object { $_.DisplayName -match "Office|Microsoft 365|Word|Excel|Outlook" } |
                Select-Object DisplayName, DisplayVersion, Publisher, InstallDate
            $outPath = Export-Data -Object $apps -BaseName "OfficeAudit"
            Write-ExportPath $outPath
            Pause-Script
        }
        '2' {
            Show-Header "Installed Drivers Audit"
            $drivers = Get-WmiObject Win32_PnPSignedDriver |
                Select-Object DeviceName, DriverVersion, Manufacturer, DriverDate
            $outPath = Export-Data -Object $drivers -BaseName "DriverAudit"
            Write-ExportPath $outPath
            Pause-Script
        }
        '3' {
            Show-Header "Roaming Profiles Applications"
            $profiles = Get-WmiObject Win32_UserProfile | Where-Object { $_.Special -eq $false -and $_.LocalPath }
            $result = @()
            foreach ($profile in $profiles) {
                $apps = Get-ChildItem -Path "$($profile.LocalPath)\AppData\Roaming" -Recurse -Filter *.exe -ErrorAction SilentlyContinue
                foreach ($app in $apps) {
                    $result += [PSCustomObject]@{
                        User = $profile.LocalPath
                        App = $app.Name
                        Path = $app.FullName
                    }
                }
            }
            $outPath = Export-Data -Object $result -BaseName "RoamingApps"
            Write-ExportPath $outPath
            Pause-Script
        }
        '4' {
            Show-Header "Browser Extensions Audit"
            # Insert your real browser extension audit logic here if needed!
            $results = @()
            $outPath = Export-Data -Object $results -BaseName "BrowserExt"
            Write-ExportPath $outPath
            Pause-Script
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
Pause-Script