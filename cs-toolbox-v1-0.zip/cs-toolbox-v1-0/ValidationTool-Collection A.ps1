# ╔═════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool A                              ║
# ║ Version: A.4 | 2025-08-06                                           ║
# ║ Office, Drivers, Dual Roaming Profiles, Browser Extensions         ║
# ╚═════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-OfficeValidation {
    Show-Header "Office Installation Audit"
    $apps = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, `
                              HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue |
        Where-Object { $_.DisplayName -match "Office|Microsoft 365|Word|Excel|Outlook" } |
        Select-Object DisplayName, DisplayVersion, Publisher, InstallDate
    Export-Data -Object $apps -BaseName "Office-Audit"
    Pause-Script
}

function Run-DriverAudit {
    Show-Header "Installed Driver Audit"
    $drivers = Get-WmiObject Win32_PnPSignedDriver |
        Select-Object DeviceName, DriverVersion, Manufacturer, DriverDate
    Export-Data -Object $drivers -BaseName "Drivers-Audit"
    Pause-Script
}

function Run-RoamingProfileAudit {
    Show-Header "Roaming Profile Software Audit"
    $roamPaths = Get-ChildItem "C:\Users" -Directory | Where-Object { Test-Path "$($_.FullName)\AppData\Roaming" }
    $results = foreach ($user in $roamPaths) {
        $apps = Get-ChildItem -Path "$($user.FullName)\AppData\Roaming" -Directory -ErrorAction SilentlyContinue |
            Select-Object @{Name='User';Expression={$user.Name}}, Name, FullName
        $apps
    }
    Export-Data -Object $results -BaseName "Roaming-Profile-Apps"
    Pause-Script
}

function Run-BrowserExtensionAudit {
    Show-Header "Browser Extension Audit (Chrome, Edge, Firefox)"
    $results = @()

    $browsers = @(
        @{ Name = "Chrome"; Path = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Extensions" },
        @{ Name = "Edge";   Path = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Extensions" },
        @{ Name = "Firefox"; Path = "$env:APPDATA\Mozilla\Firefox\Profiles" }
    )

    foreach ($browser in $browsers) {
        if (Test-Path $browser.Path) {
            $exts = Get-ChildItem -Path $browser.Path -Recurse -Directory -ErrorAction SilentlyContinue |
                Select-Object @{Name='Browser';Expression={$browser.Name}}, Name, FullName
            $results += $exts
        }
    }

    Export-Data -Object $results -BaseName "Browser-Extensions"
    Pause-Script
}

function Show-ValidationMenuA {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "     CS Toolbox - Validation Tool A - App & Driver   "
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Validate Microsoft Office Installations"
        Write-Host " [2] Audit Installed Drivers"
        Write-Host " [3] Scan Roaming Profiles for Applications"
        Write-Host " [4] Detect Browser Extensions (Chrome, Edge, Firefox)"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice) {
            "1" { Run-OfficeValidation }
            "2" { Run-DriverAudit }
            "3" { Run-RoamingProfileAudit }
            "4" { Run-BrowserExtensionAudit }
            "Z" { Invoke-ZipAndEmailResults }
            "C" { Clear-ExportFolder }
            "Q" { return }
            default { Write-Host "Invalid selection. Try again." -ForegroundColor Yellow; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}

Show-ValidationMenuA
