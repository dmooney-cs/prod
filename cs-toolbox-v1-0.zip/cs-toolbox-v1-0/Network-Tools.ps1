# ╔═════════════════════════════════════════════════════════════════════╗
# ║ 🌐 CS Tech Toolbox – Network Tools                                  ║
# ║ Version: N.6 | TLS Scan, SMB Validate, Admin$ Test + Export Tools   ║
# ╚═════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}

function Run-TLSScanWithNmap {
    Show-Header "TLS 1.0 Cipher Scan via Nmap"
    $nmapPath = "C:\Program Files (x86)\CyberCNSAgent\nmap\nmap.exe"

    if (!(Test-Path $nmapPath)) {
        Write-Host "Nmap not found at: $nmapPath" -ForegroundColor Red
        Pause-Script
        return
    }

    $target = Read-Host "Enter target IP address"
    $output = & $nmapPath --script ssl-enum-ciphers -p 3389 $target
    $file = Get-ExportPath -BaseName "TLS-Nmap-Scan-$target" -Ext "txt"
    $output | Out-File -FilePath $file -Encoding UTF8
    Write-ExportPath $file
    Pause-Script
}

function Run-ValidateSMB {
    Show-Header "Validate SMB Access with validatesmb.exe"

    $exePath = Join-Path $PSScriptRoot "validatesmb.exe"
    if (!(Test-Path $exePath)) {
        try {
            Invoke-WebRequest -Uri "https://betadev.mycybercns.com/agents/validatesmb/validatesmb.exe" -OutFile $exePath
        } catch {
            Write-Host "❌ Failed to download validatesmb.exe" -ForegroundColor Red
            Pause-Script
            return
        }
    }

    $domain = Read-Host "Enter FQDN domain"
    $user = Read-Host "Enter username"
    $password = Read-Host "Enter password"
    $target = Read-Host "Enter SMB target IP"

    $logPath = Get-ExportPath -BaseName "SMBValidation-$target" -Ext "txt"
    try {
        & $exePath validatesmb $domain $user $password $target | Tee-Object -FilePath $logPath
        Write-ExportPath $logPath
    } catch {
        Write-Host "❌ Error during SMB validation" -ForegroundColor Red
    }

    Pause-Script
}

function Run-TestAdminShare {
    Show-Header "Test Admin Share Access (\\IP\admin$)"

    $ip = Read-Host "Enter target IP address"
    $path = "\\$ip\admin$"

    try {
        Get-ChildItem $path | Out-Null
        Write-Host "`n✅ Successfully accessed $path" -ForegroundColor Green
    } catch {
        Write-Host "`n❌ Could not access $path" -ForegroundColor Red
    }

    Pause-Script
}

function Show-NetworkMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "       CS Toolbox – Network Testing Tools"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] TLS 1.0 Scan with Nmap (Port 3389)"
    Write-Host " [2] Validate SMB Access with credentials"
    Write-Host " [3] Test Admin Share \\x.x.x.x\admin$"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-NetworkMenu
    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        "1" { Run-TLSScanWithNmap }
        "2" { Run-ValidateSMB }
        "3" { Run-TestAdminShare }
        "Z" { Invoke-ZipAndEmailResults }
        "C" { Cleanup-ExportFolder }
        "Q" { break }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Start-Sleep -Seconds 1.5
        }
    }
} while ($true)
