# ╔════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Agent Menu Tool                                ║
# ║ Version: 1.3 | Install, Uninstall, Update, Status, Maintenance ║
# ╚════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

function Show-AgentMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "       CS Toolbox – ConnectSecure Agent Menu"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Install Agent V4           - Download + Setup"
    Write-Host " [2] Uninstall Agent V4         - Remove all traces"
    Write-Host " [3] Update Agent V4            - Pull and Replace Binary"
    Write-Host " [4] Check Agent Status         - Services + Version Check"
    Write-Host ""
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Quit to Main Menu"
    Write-Host ""
}

function Run-AgentMenu {
    do {
        Show-AgentMenu
        $choice = Read-Host "Select an option"
        switch ($choice) {
            "1" { . "$PSScriptRoot\Agent-Install-Tool.ps1" }
            "2" { . "$PSScriptRoot\Agent-Uninstall-Tool.ps1" }
            "3" { . "$PSScriptRoot\Agent-Update-Tool.ps1" }
            "4" { . "$PSScriptRoot\Agent-Status-Tool.ps1" }
            "C" { Invoke-CleanupToolbox }
            "Q" { return }
            default {
                Write-Host "Invalid selection. Please try again." -ForegroundColor Red
                Start-Sleep -Seconds 1.5
            }
        }
    } while ($true)
}

Run-AgentMenu