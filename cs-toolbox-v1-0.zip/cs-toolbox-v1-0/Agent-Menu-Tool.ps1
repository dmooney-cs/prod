# Load shared functions from the local extracted folder
. "$PSScriptRoot\Functions-Common.ps1"

function Show-AgentMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "            CS Toolbox - Agent Menu Tool"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Check Agent Status"
    Write-Host " [2] Install Agent"
    Write-Host " [3] Uninstall Agent"
    Write-Host " [4] Update Agent"
    Write-Host " [5] Agent Maintenance"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Back to Main Menu"
    Write-Host ""
}

do {
    Show-AgentMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' {
            Show-Header "Check Agent Status"
            # Inline logic or link to a dedicated script if needed
            Pause-Script
        }
        '2' {
            # Link to Agent-Install-Tool.ps1
            $tool = Join-Path $PSScriptRoot "Agent-Install-Tool.ps1"
            if (Test-Path $tool) {
                . $tool
            } else {
                Write-Host "Agent-Install-Tool.ps1 not found!" 
                Pause-Script
            }
        }
        '3' {
            # Link to Uninstall-CyberCNSAgentV4.ps1
            $tool = Join-Path $PSScriptRoot "Uninstall-CyberCNSAgentV4.ps1"
            if (Test-Path $tool) {
                . $tool
            } else {
                Write-Host "Uninstall-CyberCNSAgentV4.ps1 not found!" 
                Pause-Script
            }
        }
        '4' {
            # Link to Update-Agent-Tool.ps1 (show error if missing)
            $tool = Join-Path $PSScriptRoot "Update-Agent-Tool.ps1"
            if (Test-Path $tool) {
                . $tool
            } else {
                Write-Host "Update-Agent-Tool.ps1 not found!" 
                Pause-Script
            }
        }
        '5' {
            # Link to Agent-Maintenance.ps1
            $tool = Join-Path $PSScriptRoot "Agent-Maintenance.ps1"
            if (Test-Path $tool) {
                . $tool
            } else {
                Write-Host "Agent-Maintenance.ps1 not found!" 
                Pause-Script
            }
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again."
            Pause-Script
        }
    }
} while ($true)
Pause-Script