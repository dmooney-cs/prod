# Load shared functions from the local extracted folder
. "$PSScriptRoot\Functions-Common.ps1"

function Run-CheckAgentStatus {
    Show-Header "Check CyberCNS Agent Status"

    $service = Get-Service -Name "cybercnsagent" -ErrorAction SilentlyContinue
    $version = ""
    $lastSeen = ""
    $status = "Unknown"
    $host = $env:COMPUTERNAME
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    if ($service) {
        $status = $service.Status
        $log = "C:\Program Files (x86)\CyberCNSAgent\logs\cybercns.txt"
        if (Test-Path $log) {
            $version = Select-String -Path $log -Pattern "Agent Version\s+:" | Select-Object -First 1 | ForEach-Object { $_.Line.Split(":")[1].Trim() }
        }
        $json = "C:\Program Files (x86)\CyberCNSAgent\lastcheckin.json"
        if (Test-Path $json) {
            $data = Get-Content $json | ConvertFrom-Json
            $lastSeen = Get-Date ($data.lastCheckin) -Format "yyyy-MM-dd HH:mm:ss"
        }
    }

    $info = [PSCustomObject]@{
        Hostname     = $host
        Status       = $status
        Version      = $version
        LastCheckIn  = $lastSeen
        CheckedAt    = $timestamp
    }

    $outPath = Export-Data -Object $info -BaseName "AgentStatus"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-ClearPendingJobs {
    Show-Header "Clear Pending Job Queue"
    $path = "C:\Program Files (x86)\CyberCNSAgent\pendingjobqueue"
    $count = 0

    if (Test-Path $path) {
        try {
            $files = Get-ChildItem $path -File
            $count = $files.Count
            $files | Remove-Item -Force
            Write-Host "Cleared $count pending job(s)."
        } catch {
            Write-Host "Error clearing job queue: $_"
        }
    } else {
        Write-Host "Job queue not found."
    }

    Pause-Script
}

function Run-SetSMB {
    Show-Header "Set SMB and Enable Firewall Rules"
    try {
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name SMB2 -Type DWord -Value 1 -Force
        Set-NetFirewallRule -DisplayName "File And Printer Sharing (SMB-In)" -Enabled True -Profile Any
        Set-NetFirewallRule -DisplayName "File And Printer Sharing (NB-Session-In)" -Enabled True -Profile Any
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name LocalAccountTokenFilterPolicy -Type DWord -Value 1 -Force
        Write-Host "SMB 2 enabled and firewall rules configured."
        $result = "SMB 2 enabled and firewall rules configured."
    } catch {
        Write-Host "Failed to set SMB settings."
        $result = "Failed to set SMB settings."
    }
    $outPath = Export-Data -Object $result -BaseName "SetSMB" -Ext "txt"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-CheckSMB {
    Show-Header "Check SMB Version Status"
    $output = @()
    $regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"

    $smb1 = Get-ItemProperty -Path $regPath -Name SMB1 -ErrorAction SilentlyContinue
    $smb2 = Get-ItemProperty -Path $regPath -Name SMB2 -ErrorAction SilentlyContinue

    $output += [PSCustomObject]@{
        SMBVersion = "SMB1"
        Enabled    = if ($smb1.SMB1 -eq 1) { "Yes" } else { "No" }
        DisableKey = "Set-ItemProperty -Path `"$regPath`" -Name SMB1 -Value 0"
    }

    $output += [PSCustomObject]@{
        SMBVersion = "SMB2"
        Enabled    = if ($smb2.SMB2 -eq 1) { "Yes" } else { "No" }
        DisableKey = "Set-ItemProperty -Path `"$regPath`" -Name SMB2 -Value 0"
    }

    $outPath = Export-Data -Object $output -BaseName "SMB_Version_Status"
    Write-ExportPath $outPath
    Pause-Script
}

function Show-AgentMaintenanceMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "           CS Toolbox - Agent Maintenance"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Check Agent Status"
    Write-Host " [2] Clear Pending Jobs"
    Write-Host " [3] Set SMB Configuration"
    Write-Host " [4] Check SMB Version"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Back to Agent Menu"
    Write-Host ""
}

do {
    Show-AgentMaintenanceMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        "1" { Run-CheckAgentStatus }
        "2" { Run-ClearPendingJobs }
        "3" { Run-SetSMB }
        "4" { Run-CheckSMB }
        "Z" { Run-ZipAndEmailResults }
        "C" { Run-CleanupExportFolder }
        "Q" { Pause-Script; return }
        default {
            Write-Host "Invalid selection."
            Pause-Script
        }
    }
} while ($true)
Pause-Script