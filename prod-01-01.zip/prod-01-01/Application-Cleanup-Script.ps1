#Requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# =====================================================================
#  Application-Cleanup-Script.ps1
#  - Search installed apps by name
#  - Select app from list
#  - Stop related services
#  - Uninstall via MSI ProductCode (if available) or UninstallString
#  - Ask confirmation before deleting leftover files
#  - Remove uninstall registry key (optional)
#  - Confirm removal
#  - Stream live log to same folder as this script
# =====================================================================

# ---------- Logging Setup ----------
# Determine script folder
$scriptRoot = $PSScriptRoot
if (-not $scriptRoot) {
    $scriptPath = $MyInvocation.MyCommand.Path
    if ($scriptPath) {
        $scriptRoot = Split-Path -Parent $scriptPath
    } else {
        $scriptRoot = (Get-Location).Path
    }
}

$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$script:LogPath = Join-Path $scriptRoot ("Application-Cleanup-Log_{0}.txt" -f $timestamp)

# Ensure log file exists and write header
"============================================================" | Out-File -LiteralPath $script:LogPath -Encoding UTF8 -Force
"Application Cleanup Script Log - Started $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" | Add-Content -LiteralPath $script:LogPath
"Log file: $script:LogPath" | Add-Content -LiteralPath $script:LogPath
"============================================================" | Add-Content -LiteralPath $script:LogPath

function Write-Log {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR','STEP','DEBUG')][string]$Level = 'INFO',
        [System.ConsoleColor]$Color = [System.ConsoleColor]::Gray
    )

    $ts   = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[{0}] [{1}] {2}" -f $ts, $Level, $Message

    # Console
    Write-Host $Message -ForegroundColor $Color

    # File
    Add-Content -LiteralPath $script:LogPath -Value $line
}

function Show-Header {
    param([string]$Title)

    Write-Log '============================================================' 'STEP' 'Cyan'
    Write-Log ("  {0}" -f $Title) 'STEP' 'Cyan'
    Write-Log '============================================================' 'STEP' 'Cyan'
}

function Read-Choice {
    param(
        [string]$Prompt,
        [string[]]$ValidInputs
    )

    while ($true) {
        Write-Host
        $inputVal = Read-Host $Prompt
        if ($ValidInputs -contains $inputVal) {
            Write-Log ("User input for '{0}': {1}" -f $Prompt, $inputVal) 'DEBUG' 'DarkGray'
            return $inputVal
        }
        Write-Log ("Invalid input '{0}'. Valid options: {1}" -f $inputVal, ($ValidInputs -join ', ')) 'WARN' 'Yellow'
        Write-Host "Invalid input. Valid options: $($ValidInputs -join ', ')" -ForegroundColor Yellow
    }
}

function Get-UninstallRegistryItems {
    [CmdletBinding()]
    param()

    Write-Log "Collecting uninstall registry items..." 'INFO' 'Gray'

    $paths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
    )

    $items = @()

    foreach ($path in $paths) {
        if (-not (Test-Path -LiteralPath $path)) {
            Write-Log "Uninstall key path not found: $path" 'DEBUG' 'DarkGray'
            continue
        }

        Get-ChildItem -LiteralPath $path | ForEach-Object {
            $keyPath = $_.PSPath
            try {
                $props = Get-ItemProperty -LiteralPath $keyPath -ErrorAction Stop
            } catch {
                Write-Log ("Failed to read uninstall key: {0} - {1}" -f $keyPath, $_.Exception.Message) 'WARN' 'Yellow'
                return
            }

            # ---- SAFE property access under StrictMode ----
            $nameProp = $props.PSObject.Properties['DisplayName']
            if (-not $nameProp -or -not $nameProp.Value) { return }
            $name = [string]$nameProp.Value

            $verProp    = $props.PSObject.Properties['DisplayVersion']
            $pubProp    = $props.PSObject.Properties['Publisher']
            $locProp    = $props.PSObject.Properties['InstallLocation']
            $uninstProp = $props.PSObject.Properties['UninstallString']

            $ver    = if ($verProp)    { [string]$verProp.Value }    else { $null }
            $pub    = if ($pubProp)    { [string]$pubProp.Value }    else { $null }
            $loc    = if ($locProp)    { [string]$locProp.Value }    else { $null }
            $uninst = if ($uninstProp) { [string]$uninstProp.Value } else { $null }

            $key = $_.PSChildName

            # Heuristic: MSI if key is GUID or uninstall string uses msiexec
            $isGuidPattern = '^\{?[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}?$'
            $isGuidKey     = $false
            if ($key -and ($key -match $isGuidPattern)) { $isGuidKey = $true }

            $isMsi = $false
            if ($isGuidKey -or ($uninst -and ($uninst -match 'msiexec\.exe'))) {
                $isMsi = $true
            }

            $productCode = $null
            if ($isGuidKey) {
                # keep braces if they exist; msiexec accepts {GUID}
                $productCode = $key
            } elseif ($uninst -and ($uninst -match '\{[0-9A-Fa-f-]{36}\}')) {
                $productCode = $matches[0]
            }

            $items += [PSCustomObject]@{
                Name            = $name
                DisplayName     = $name
                DisplayVersion  = $ver
                Publisher       = $pub
                InstallLocation = $loc
                UninstallString = $uninst
                ProductCode     = $productCode
                IsMsi           = $isMsi
                RegistryPath    = $keyPath
                RegistryKey     = $key
            }
        }
    }

    Write-Log ("Found {0} uninstall entries." -f $items.Count) 'INFO' 'Gray'
    return $items
}

function Get-AppSelection {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$SearchTerm
    )

    $apps = @(Get-UninstallRegistryItems)
    if ($apps.Count -eq 0) {
        Write-Log "No installed applications found via registry." 'WARN' 'Yellow'
        Write-Host "No installed applications found via registry." -ForegroundColor Yellow
        return $null
    }

    $matches = @(
        $apps | Where-Object {
            $_.Name -like ("*" + $SearchTerm + "*")
        } | Sort-Object Name
    )

    if ($matches.Count -eq 0) {
        Write-Log ("No applications matched search term '{0}'." -f $SearchTerm) 'WARN' 'Yellow'
        Write-Host "No applications matched '$SearchTerm'." -ForegroundColor Yellow
        return $null
    }

    Show-Header ("Matches for '{0}'" -f $SearchTerm)
    Write-Log ("Search term '{0}' returned {1} matches." -f $SearchTerm, $matches.Count) 'INFO' 'Gray'

    $index = 1
    foreach ($app in $matches) {
        $ver = if ($app.DisplayVersion) { $app.DisplayVersion } else { 'N/A' }
        $pub = if ($app.Publisher)      { $app.Publisher }      else { 'N/A' }

        Write-Log ("[{0}] {1}" -f $index, $app.Name) 'INFO' 'White'
        Write-Log ("     Version  : {0}" -f $ver) 'INFO' 'DarkGray'
        Write-Log ("     Publisher: {0}" -f $pub) 'INFO' 'DarkGray'
        if ($app.ProductCode) {
            Write-Log ("     Product  : {0}" -f $app.ProductCode) 'DEBUG' 'DarkGray'
        } elseif ($app.UninstallString) {
            Write-Log ("     Uninst   : {0}" -f $app.UninstallString) 'DEBUG' 'DarkGray'
        }
        Write-Host
        $index++
    }

    $valid = @('Q')
    for ($i = 1; $i -le $matches.Count; $i++) { $valid += $i.ToString() }

    $choice = Read-Choice -Prompt "Select application number or Q to quit" -ValidInputs $valid
    if ($choice -eq 'Q') {
        Write-Log "User cancelled selection (Q)." 'INFO' 'Gray'
        return $null
    }

    $selectedIndex = [int]$choice - 1
    $selected = $matches[$selectedIndex]
    Write-Log ("User selected application: {0}" -f $selected.Name) 'INFO' 'Green'
    return $selected
}

function Stop-AppServices {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$AppName
    )

    Show-Header ("Step 1: Stopping services related to '{0}'" -f $AppName)

    $services = @(
        Get-Service -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -like ("*" + $AppName + "*") -or
            $_.Name        -like ("*" + $AppName + "*")
        }
    )

    if ($services.Count -eq 0) {
        Write-Log ("No services found matching '{0}'." -f $AppName) 'INFO' 'Gray'
        return
    }

    Write-Log ("Found {0} matching services." -f $services.Count) 'INFO' 'Gray'

    foreach ($svc in $services) {
        Write-Log ("Stopping service: {0} ({1}) - Status: {2}" -f $svc.DisplayName, $svc.Name, $svc.Status) 'INFO' 'Gray'
        if ($svc.Status -ne 'Stopped') {
            try {
                Stop-Service -Name $svc.Name -Force -ErrorAction Stop
                $svc.WaitForStatus('Stopped', (New-TimeSpan -Seconds 30))
                Write-Log ("Service stopped: {0}" -f $svc.Name) 'INFO' 'Green'
            } catch {
                Write-Log ("Failed to stop service {0}: {1}" -f $svc.Name, $_.Exception.Message) 'ERROR' 'Red'
            }
        } else {
            Write-Log ("Service already stopped: {0}" -f $svc.Name) 'INFO' 'DarkGray'
        }
    }
}

function Invoke-AppUninstall {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][psobject]$App
    )

    Show-Header ("Step 2: Running uninstall for '{0}'" -f $App.Name)

    if ($App.ProductCode -and $App.IsMsi) {
        Write-Log ("Detected MSI ProductCode: {0}" -f $App.ProductCode) 'INFO' 'Gray'

        $args = "/x$($App.ProductCode) /qn /norestart"
        Write-Log ("Running: msiexec.exe {0}" -f $args) 'INFO' 'Gray'
        try {
            $proc = Start-Process -FilePath "msiexec.exe" -ArgumentList $args -Wait -PassThru -ErrorAction Stop
            Write-Log ("msiexec exit code: {0}" -f $proc.ExitCode) 'INFO' 'Gray'
        } catch {
            Write-Log ("Uninstall failed for {0}: {1}" -f $App.Name, $_.Exception.Message) 'ERROR' 'Red'
        }
    } elseif ($App.UninstallString) {
        Write-Log "No MSI ProductCode, falling back to stored UninstallString." 'INFO' 'Gray'
        Write-Log ("UninstallString: {0}" -f $App.UninstallString) 'DEBUG' 'DarkGray'

        # Try to split executable and arguments
        $un   = $App.UninstallString.Trim()
        $exe  = $un
        $args = ''
        if ($un.StartsWith('"')) {
            $secondQuote = $un.IndexOf('"', 1)
            if ($secondQuote -gt 0) {
                $exe = $un.Substring(0, $secondQuote + 1)
                if ($un.Length -gt ($secondQuote + 1)) {
                    $args = $un.Substring($secondQuote + 1).Trim()
                }
            }
        } else {
            $firstSpace = $un.IndexOf(' ')
            if ($firstSpace -gt 0) {
                $exe  = $un.Substring(0, $firstSpace)
                $args = $un.Substring($firstSpace + 1).Trim()
            }
        }

        Write-Log ("Executing uninstall: exe={0} args={1}" -f $exe, $args) 'INFO' 'Gray'

        try {
            if ($args) {
                Start-Process -FilePath $exe -ArgumentList $args -Wait -ErrorAction Stop
            } else {
                Start-Process -FilePath $exe -Wait -ErrorAction Stop
            }
            Write-Log ("Uninstall command completed for {0}." -f $App.Name) 'INFO' 'Green'
        } catch {
            Write-Log ("Uninstall command failed for {0}: {1}" -f $App.Name, $_.Exception.Message) 'ERROR' 'Red'
        }
    } else {
        Write-Log ("No uninstall information found for application {0}." -f $App.Name) 'WARN' 'Yellow'
    }
}

function Remove-AppFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][psobject]$App
    )

    Show-Header "Step 3: Removing leftover files"

    $basePath = $null

    if ($App.InstallLocation -and (Test-Path -LiteralPath $App.InstallLocation)) {
        $basePath = $App.InstallLocation
        Write-Log ("Using InstallLocation as base path: {0}" -f $basePath) 'INFO' 'Gray'
    } else {
        # Fallback guess (optional): C:\Program Files (x86)\AppName
        $guess = Join-Path "C:\Program Files (x86)" $App.Name
        if (Test-Path -LiteralPath $guess) {
            $basePath = $guess
            Write-Log ("Using guessed program files path as base path: {0}" -f $basePath) 'INFO' 'Gray'
        }
    }

    if (-not $basePath) {
        Write-Log ("No valid installation path found to remove for {0}." -f $App.Name) 'WARN' 'Yellow'
        Write-Host "No valid installation path found to remove." -ForegroundColor Yellow
        return
    }

    Write-Log ("Detected install/leftover path: {0}" -f $basePath) 'INFO' 'Gray'
    Write-Host ("Detected install/leftover path: {0}" -f $basePath)

    # Explicit confirmation to delete leftover files
    $confirm = Read-Choice -Prompt "Delete this folder and ALL contents? (Y/N)" -ValidInputs @('Y','N')
    if ($confirm -eq 'Y') {
        Write-Log ("User confirmed deletion of folder: {0}" -f $basePath) 'INFO' 'Gray'
        try {
            Remove-Item -LiteralPath $basePath -Recurse -Force -ErrorAction Stop
            Write-Log ("Folder removed: {0}" -f $basePath) 'INFO' 'Green'
        } catch {
            Write-Log ("Failed to remove folder {0}: {1}" -f $basePath, $_.Exception.Message) 'ERROR' 'Red'
        }
    } else {
        Write-Log ("User declined deletion of folder: {0}" -f $basePath) 'INFO' 'Yellow'
        Write-Host "Skipped folder removal."
    }
}

function Remove-AppRegistryKey {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][psobject]$App
    )

    Show-Header "Step 4: Removing uninstall registry key (optional)"

    $targets = @()
    if ($App.ProductCode) {
        $codeNoBraces = $App.ProductCode.Trim('{}')
        $targets += ('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\{0}'    -f $codeNoBraces)
        $targets += ('HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{0}' -f $codeNoBraces)
    }

    if ($targets.Count -eq 0) {
        if ($App.RegistryPath) {
            $targets += $App.RegistryPath
        } else {
            Write-Log ("No registry key identified for app {0}." -f $App.Name) 'WARN' 'Yellow'
            Write-Host "No registry key identified for this app." -ForegroundColor Yellow
            return
        }
    }

    foreach ($path in $targets) {
        if (Test-Path -LiteralPath $path) {
            Write-Log ("Found uninstall registry key: {0}" -f $path) 'INFO' 'Gray'
            $ans = Read-Choice -Prompt "Remove this registry key? (Y/N)" -ValidInputs @('Y','N')
            if ($ans -eq 'Y') {
                try {
                    Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction Stop
                    Write-Log ("Registry key removed: {0}" -f $path) 'INFO' 'Green'
                } catch {
                    Write-Log ("Failed to remove registry key {0}: {1}" -f $path, $_.Exception.Message) 'ERROR' 'Red'
                }
            } else {
                Write-Log ("User skipped registry key removal: {0}" -f $path) 'INFO' 'Yellow'
            }
        } else {
            Write-Log ("Registry key path not found (skipped): {0}" -f $path) 'DEBUG' 'DarkGray'
        }
    }
}

function Confirm-AppRemoved {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][psobject]$App
    )

    Show-Header "Step 5: Confirming removal"

    # Check uninstall registry again
    $stillThere = @(
        Get-UninstallRegistryItems | Where-Object {
            $_.Name -eq $App.Name
        }
    )

    if ($stillThere.Count -gt 0) {
        Write-Log ("Application still present in uninstall registry entries for {0}:" -f $App.Name) 'WARN' 'Yellow'
        foreach ($item in $stillThere) {
            Write-Log ("  - {0}  (Version: {1})" -f $item.Name, $item.DisplayVersion) 'WARN' 'Yellow'
        }
    } else {
        Write-Log ("No registry uninstall entries remain for application {0}." -f $App.Name) 'INFO' 'Green'
    }

    # Optional: Win32_Product check (WARNING: can be slow / side-effect)
    Write-Host
    $doWmi = Read-Choice -Prompt "Also check Win32_Product (may be slow)? (Y/N)" -ValidInputs @('Y','N')
    if ($doWmi -eq 'Y') {
        Write-Log "Running Win32_Product verification..." 'INFO' 'Gray'
        try {
            $wmi = @(
                Get-WmiObject -Class Win32_Product -ErrorAction Stop | Where-Object {
                    $_.Name -like ("*" + $App.Name + "*")
                }
            )
            if ($wmi.Count -gt 0) {
                Write-Log ("Win32_Product still reports matching entries for {0}:" -f $App.Name) 'WARN' 'Yellow'
                foreach ($w in $wmi) {
                    Write-Log ("  - {0}  (Version: {1})" -f $w.Name, $w.Version) 'WARN' 'Yellow'
                }
            } else {
                Write-Log ("Win32_Product reports no matching entries for {0}." -f $App.Name) 'INFO' 'Green'
            }
        } catch {
            Write-Log ("Win32_Product check failed: {0}" -f $_.Exception.Message) 'ERROR' 'Red'
        }
    } else {
        Write-Log "User skipped Win32_Product verification." 'INFO' 'Gray'
    }
}

# =====================================================================
# Main
# =====================================================================

Clear-Host
Show-Header "Application Search & Clean Uninstaller"
Write-Log "Script started." 'INFO' 'Gray'
Write-Log ("Logging to: {0}" -f $script:LogPath) 'INFO' 'Gray'

$search = Read-Host "Enter part of the application name to search for"
Write-Log ("User search term: '{0}'" -f $search) 'INFO' 'Gray'

if (-not $search) {
    Write-Log "No search term entered. Exiting." 'WARN' 'Yellow'
    Write-Host "No search term entered. Exiting." -ForegroundColor Yellow
    return
}

$app = Get-AppSelection -SearchTerm $search
if (-not $app) {
    Write-Log "No application selected. Exiting." 'WARN' 'Yellow'
    Write-Host "No application selected. Exiting." -ForegroundColor Yellow
    return
}

Show-Header "Selected Application"
Write-Log ("Name     : {0}" -f $app.Name) 'INFO' 'White'
Write-Log ("Version  : {0}" -f ($app.DisplayVersion  -as [string])) 'INFO' 'White'
Write-Log ("Publisher: {0}" -f ($app.Publisher       -as [string])) 'INFO' 'White'
Write-Log ("Location : {0}" -f ($app.InstallLocation -as [string])) 'INFO' 'White'
Write-Log ("Product  : {0}" -f ($app.ProductCode     -as [string])) 'INFO' 'White'

Write-Host
$proceed = Read-Choice -Prompt "Proceed with full removal steps for this application? (Y/N)" -ValidInputs @('Y','N')
if ($proceed -ne 'Y') {
    Write-Log "User cancelled full removal steps." 'WARN' 'Yellow'
    Write-Host "User cancelled. Exiting." -ForegroundColor Yellow
    return
}

Write-Log ("Beginning removal sequence for application: {0}" -f $app.Name) 'STEP' 'Cyan'

Stop-AppServices       -AppName $app.Name
Invoke-AppUninstall    -App      $app
Remove-AppFiles        -App      $app
Remove-AppRegistryKey  -App      $app
Confirm-AppRemoved     -App      $app

Write-Host
Write-Log ("All steps completed for application: {0}" -f $app.Name) 'STEP' 'Cyan'
Write-Log "Script completed." 'INFO' 'Gray'
Write-Host ("All steps completed. Log written to: {0}" -f $script:LogPath) -ForegroundColor Cyan
