# ================================
# CS Toolbox - Cleanup Self Destruct
# Standalone force delete (self-copies to %TEMP% and runs elevated)
# PS 5.1 safe
# ================================

$ErrorActionPreference = "SilentlyContinue"
$targetPath = "C:\CS-Toolbox-TEMP"

# --- Step 0: If not already running from %TEMP%, copy self there and relaunch elevated ---
$currentPath = $MyInvocation.MyCommand.Definition
$tempPath    = Join-Path $env:TEMP "Toolbox-Cleanup-SelfDestruct.ps1"

if (-not ($currentPath -ieq $tempPath)) {
    Write-Host "`nPreparing cleanup..." -ForegroundColor Cyan
    try {
        Copy-Item -Path $currentPath -Destination $tempPath -Force
        Write-Host ("Copied cleanup script to: {0}" -f $tempPath) -ForegroundColor Yellow
    } catch {
        Write-Host ("❌ Failed to copy script to TEMP: {0}" -f $_.Exception.Message) -ForegroundColor Red
        exit 1
    }

    # Relaunch from TEMP as admin
    Write-Host "Launching elevated cleanup process..." -ForegroundColor Cyan
    Start-Process powershell.exe -ArgumentList "-ExecutionPolicy Bypass -NoProfile -File `"$tempPath`"" -Verb RunAs
    exit
}

Write-Host "`n=== CS Toolbox Cleanup - Self Destruct ===" -ForegroundColor Cyan
Start-Sleep -Milliseconds 400

# --- Step 1: Stop processes that may lock the folder (without killing ourselves) ---
$processesToStop = @(
    "cybercnsagent",
    "connectsecureagentmonitor",
    "nmap",
    "osqueryd",
    "powershell"  # only ones rooted in the target path will be stopped (see filter)
)

$myPid = $PID
foreach ($name in $processesToStop) {
    # Try to scope to processes actually running from inside the target path (safer), else fall back to name-only
    $procs = @()
    try {
        $procs = Get-Process -Name $name -ErrorAction SilentlyContinue | Where-Object {
            $_.Id -ne $myPid -and
            $_.Path -and ($_.Path -like "$targetPath*")
        }
        if (-not $procs -or $procs.Count -eq 0) {
            # fallback: all by name, excluding ourselves
            $procs = Get-Process -Name $name -ErrorAction SilentlyContinue | Where-Object { $_.Id -ne $myPid }
        }
    } catch { }

    foreach ($p in $procs) {
        try {
            Write-Host ("Stopping process: {0} (PID {1})" -f $p.ProcessName, $p.Id) -ForegroundColor Yellow
            Stop-Process -Id $p.Id -Force -ErrorAction Stop
        } catch {
            Write-Host ("Could not stop {0}: {1}" -f $name, $_.Exception.Message) -ForegroundColor DarkGray
        }
    }
}

Start-Sleep -Milliseconds 800

# --- Step 2: Force delete with retries ---
function Clear-ReadOnlyAttributes {
    param([string]$Path)
    try {
        Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                if ($_.PSIsContainer) {
                    # Directories: remove ReadOnly attribute if set
                    if ($_.Attributes -band [IO.FileAttributes]::ReadOnly) {
                        $_.Attributes = $_.Attributes -bxor [IO.FileAttributes]::ReadOnly
                    }
                } else {
                    # Files
                    $_.IsReadOnly = $false
                }
            } catch { }
        }
    } catch { }
}

function Try-DeleteTarget {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return $true }
    try {
        Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
        return $true
    } catch {
        return $false
    }
}

if (Test-Path $targetPath) {
    Write-Host ("Deleting {0} ..." -f $targetPath) -ForegroundColor Cyan

    $attempts = 0
    $maxAttempts = 3
    $deleted = $false

    while (-not $deleted -and $attempts -lt $maxAttempts) {
        $attempts++

        # 1) Clear read-only flags
        Clear-ReadOnlyAttributes -Path $targetPath

        # 2) Try remove
        $deleted = Try-DeleteTarget -Path $targetPath
        if ($deleted) { break }

        # 3) If still present, wait briefly and retry
        Write-Host ("Retry {0}/{1}..." -f $attempts, $maxAttempts) -ForegroundColor DarkYellow
        Start-Sleep -Seconds 1
    }

    if ($deleted) {
        Write-Host "✅ Folder deleted successfully." -ForegroundColor Green
    } else {
        Write-Host "❌ Failed to delete folder after multiple attempts. It may still be in use." -ForegroundColor Red
    }
} else {
    Write-Host ("⚠ Folder not found: {0}" -f $targetPath) -ForegroundColor Yellow
}

Start-Sleep -Milliseconds 400

# (Optional) Remove the temp copy of this script after execution (best-effort)
try {
    # Schedule a delayed self-delete using cmd so we can exit first
    $cmd = "cmd.exe /c ping 127.0.0.1 -n 2 >NUL & del /f /q `"$tempPath`""
    Start-Process -FilePath "cmd.exe" -ArgumentList "/c $cmd" -WindowStyle Hidden
} catch { }

exit
