Start-Sleep -Seconds 5

# Attempt to delete folder
$target = "C:\CS-Toolbox-TEMP"

try {
    if (Test-Path $target) {
        Remove-Item -Path $target -Recurse -Force -ErrorAction Stop
        Write-Host "🧹 Deleted: $target" -ForegroundColor Green
    } else {
        Write-Host "⚠️ Folder not found: $target" -ForegroundColor Yellow
    }
} catch {
    Write-Host "❌ Error during cleanup: $_" -ForegroundColor Red
}

# Optionally kill parent process
Stop-Process -Id $PID -Force
