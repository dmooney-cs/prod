Start-Sleep -Seconds 5

$targetPath = "C:\CS-Toolbox-TEMP"
$tempScript = "$env:TEMP\Toolbox-Cleanup-SelfDestruct.ps1"

try {
    if (Test-Path $targetPath) {
        Remove-Item -Path $targetPath -Recurse -Force -ErrorAction Stop
    }
} catch {
    Write-Host "❌ Failed to delete folder: $($_.Exception.Message)" -ForegroundColor Red
}

Start-Sleep -Seconds 2

try {
    if (Test-Path $tempScript) {
        Remove-Item -Path $tempScript -Force
    }
} catch {
    Write-Host "❌ Failed to delete cleanup script itself: $($_.Exception.Message)" -ForegroundColor Red
}

exit
