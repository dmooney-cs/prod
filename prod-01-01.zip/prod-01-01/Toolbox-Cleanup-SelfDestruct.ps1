﻿<# 
.SYNOPSIS
  Ultra-aggressive cleanup & self-destruct with diagnostics for ConnectSecure Toolbox folders.

.PARAMETER TargetPath
  Folder to remove (default: C:\CS-Toolbox-TEMP)

.PARAMETER Diag
  Enables detailed logging: transcript, verbose output, expanded error details, ACL/SDDL dumps.

.EXAMPLE
  powershell -NoProfile -ExecutionPolicy Bypass -File .\Toolbox-Cleanup-SelfDestruct.ps1 `
    -TargetPath "C:\CS-Toolbox-TEMP\prod-01-01" -Diag
#>

[CmdletBinding()]
param(
  [string]$TargetPath = "C:\CS-Toolbox-TEMP",
  [switch]$Diag
)

# =================== Diagnostics & Helpers ===================
$global:CS_LogPath = Join-Path $env:TEMP ("CS_Cleanup_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".log")

function Log([string]$Level, [string]$Message) {
  $ts   = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
  $line = ("[{0}] {1}  {2}" -f ($Level.ToUpper()), $ts, $Message)
  $lc   = ''
  if ($null -ne $Level) { $lc = $Level.ToString().ToLower() }

  $color = 'White'
  if     ($lc -eq 'ok')    { $color = 'Green' }
  elseif ($lc -eq 'info')  { $color = 'Cyan' }
  elseif ($lc -eq 'warn')  { $color = 'Yellow' }
  elseif ($lc -eq 'fatal' -or $lc -eq 'error') { $color = 'Red' }

  Write-Host $line -ForegroundColor $color
}

function Log-Exception([string]$Context, [System.Exception]$ex) {
  $w32 = $null
  try { $w32 = (New-Object System.ComponentModel.Win32Exception([Runtime.InteropServices.Marshal]::GetLastWin32Error())).Message } catch {}
  Log 'error' ("{0} failed:" -f $Context)
  Log 'error' ("  Type: {0}" -f $ex.GetType().FullName)
  Log 'error' ("  Message: {0}" -f $ex.Message)
  Log 'error' ("  HResult: 0x{0:X8}" -f $ex.HResult)
  if ($w32) { Log 'error' ("  Win32: {0}" -f $w32) }
  if ($ex.InnerException) { Log 'error' ("  Inner: {0}" -f $ex.InnerException.Message) }
  if ($ex.ScriptStackTrace) {
    Log 'error' "  Stack:"
    $ex.ScriptStackTrace -split "`n" | ForEach-Object { Log 'error' ("    {0}" -f $_) }
  } elseif ($ex.StackTrace) {
    Log 'error' "  Stack:"
    $ex.StackTrace -split "`n" | ForEach-Object { Log 'error' ("    {0}" -f $_) }
  }
}

if ($Diag) {
  try {
    $VerbosePreference = 'Continue'
    $InformationPreference = 'Continue'
    Start-Transcript -Path $global:CS_LogPath -Append -ErrorAction Stop | Out-Null
    Log 'info' ("Transcript started: {0}" -f $global:CS_LogPath)
  } catch {
    Log-Exception "Start-Transcript" $_.Exception
  }
}

# Fail fast inside inner ops; we catch & log
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# =================== Elevation ===================
function Assert-Elevated {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p  = New-Object Security.Principal.WindowsPrincipal($id)
  if (-not $p.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) {
    Log 'info' "Re-launching elevated..."
    $args = @(
      "-NoProfile","-ExecutionPolicy","Bypass","-File",
      "`"$PSCommandPath`"",
      "-TargetPath","`"$TargetPath`""
    )
    if ($Diag) { $args += "-Diag" }
    Start-Process -FilePath "powershell.exe" -ArgumentList $args -Verb RunAs
    exit
  }
}

# =================== Long-path helpers & P/Invoke ===================
function As-Long([string]$p) {
  if ($p -like "\\?\*") { return $p }
  if ($p -match '^[\\]{2}') { return "\\?\UNC\" + $p.Substring(2) }
  return "\\?\" + $p
}

# Correct member-only declaration for Add-Type (no using/class; correct quotes)
Add-Type -Namespace Win32 -Name Native -MemberDefinition @"
[System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError=true, CharSet=System.Runtime.InteropServices.CharSet.Unicode)]
public static extern bool MoveFileEx(string lpExistingFileName, string lpNewFileName, int dwFlags);
"@

$MOVEFILE_DELAY_UNTIL_REBOOT = 0x4

function Mark-For-DeleteOnReboot([string]$path) {
  # MoveFileEx wants a non-\\?\ path
  $p = $path
  if ($p -like "\\?\UNC\*") { $p = "\\" + $p.Substring(7) }
  elseif ($p -like "\\?\*") { $p = $p.Substring(4) }
  $ok = [Win32.Native]::MoveFileEx($p, $null, $MOVEFILE_DELAY_UNTIL_REBOOT)
  if (-not $ok) {
    $err = (New-Object System.ComponentModel.Win32Exception([Runtime.InteropServices.Marshal]::GetLastWin32Error())).Message
    throw ("MoveFileEx failed: {0} (path={1})" -f $err, $p)
  }
}

# =================== Core operations ===================
function Kill-ProcsInPath([string]$path) {
  try {
    Log 'info' ("Killing processes running from under: {0}" -f $path)
    Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
      try {
        if ($_.Path -and ($_.Path -like "$path*")) {
          Stop-Process -Id $_.Id -Force -ErrorAction Stop
          Log 'ok' ("Killed {0} ({1})" -f $_.ProcessName, $_.Id)
        }
      } catch {
        Log-Exception ("Stop-Process " + $_.ProcessName) $_.Exception
      }
    }
    # Close Explorer windows rooted in the path (best effort)
    try {
      $shell = New-Object -ComObject Shell.Application -ErrorAction Stop
      foreach ($w in @($shell.Windows())) {
        try {
          $loc = $w.Document.Folder.Self.Path
          if ($loc -and ($loc -like "$path*")) { $w.Quit() }
        } catch {}
      }
    } catch { Log-Exception "Close Explorer windows" $_.Exception }
  } catch { Log-Exception "Kill-ProcsInPath" $_.Exception }
}

function Reset-OwnershipAndAcl([string]$path) {
  Log 'info' "Taking ownership + granting Administrators:(OI)(CI)F ..."
  try { & takeown.exe /F "$path" /R /D Y | Write-Verbose } catch { Log-Exception "takeown.exe" $_.Exception }
  try { & icacls.exe "$path" /grant "*S-1-5-32-544:(OI)(CI)F" /T /C | Write-Verbose } catch { Log-Exception "icacls.exe grant" $_.Exception }
}

function Clear-Attributes([string]$path) {
  Log 'info' "Clearing ReadOnly/Hidden/System attributes recursively..."
  try {
    Get-ChildItem -LiteralPath $path -Force -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
      try { [System.IO.File]::SetAttributes($_.FullName, [System.IO.FileAttributes]::Normal) } catch { }
    }
    try { [System.IO.File]::SetAttributes($path, [System.IO.FileAttributes]::Directory) } catch { }
  } catch { Log-Exception "Clear-Attributes" $_.Exception }
}

function Try-Remove([string]$path) {
  $lp = As-Long $path
  for ($i=1; $i -le 6; $i++) {
    try {
      Log 'info' ("Remove-Item attempt {0} ..." -f $i)
      Remove-Item -LiteralPath $lp -Recurse -Force -ErrorAction Stop -Verbose:$Diag
      Log 'ok' ("Removed {0}" -f $path)
      return $true
    } catch {
      Log-Exception ("Remove-Item attempt " + $i) $_.Exception
      Start-Sleep -Milliseconds 700
      Kill-ProcsInPath $path
    }
  }
  return $false
}

function Robocopy-Purge([string]$path) {
  Log 'warn' "Falling back to robocopy purge..."
  try {
    $empty = Join-Path ([IO.Path]::GetTempPath()) ([IO.Path]::GetRandomFileName())
    New-Item -ItemType Directory -Path $empty -Force | Out-Null
    & robocopy "$empty" "$path" /MIR /NFL /NDL /NJH /NJS /NC /NS /NP
    Remove-Item -LiteralPath (As-Long $path) -Recurse -Force -ErrorAction SilentlyContinue -Verbose:$Diag
    Remove-Item -LiteralPath (As-Long $empty) -Recurse -Force -ErrorAction SilentlyContinue
    return -not (Test-Path -LiteralPath $path)
  } catch {
    Log-Exception "Robocopy purge" $_.Exception
    return $false
  }
}

function Schedule-StartupSweep([string]$path) {
  Log 'warn' "Scheduling delete-on-boot and startup sweeps..."
  try {
    # Mark everything for delete-on-reboot
    if (Test-Path -LiteralPath $path) {
      $all = Get-ChildItem -LiteralPath $path -Force -Recurse -ErrorAction SilentlyContinue
      $files = $all | Where-Object { -not $_.PSIsContainer }
      $dirs  = $all | Where-Object { $_.PSIsContainer } | Sort-Object FullName -Descending
      foreach ($f in $files) { try { Mark-For-DeleteOnReboot $f.FullName } catch { Log-Exception "Mark-For-DeleteOnReboot file" $_.Exception } }
      foreach ($d in $dirs)  { try { Mark-For-DeleteOnReboot $d.FullName } catch { Log-Exception "Mark-For-DeleteOnReboot dir" $_.Exception } }
      try { Mark-For-DeleteOnReboot $path } catch { Log-Exception "Mark-For-DeleteOnReboot root" $_.Exception }
      Log 'ok' "Marked tree for delete-on-reboot."
    }
  } catch { Log-Exception "Delete-on-reboot marking" $_.Exception }

  try {
    # RunOnce at next user logon
    $runOnce = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
    $cmd = "cmd.exe /c rmdir /s /q `"`\\?\$path`""
    New-ItemProperty -Path $runOnce -Name ("CS_Cleanup_" + ([Guid]::NewGuid().ToString("N"))) -Value $cmd -PropertyType String -Force | Out-Null
    Log 'ok' "RunOnce registered."
  } catch { Log-Exception "Register RunOnce" $_.Exception }

  try {
    # Startup task (SYSTEM) early in boot
    $action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c rmdir /s /q `"`\\?\$path`""
    $trigger = New-ScheduledTaskTrigger -AtStartup
    $taskName = "CS_Toolbox_StartupCleanup_" + ([Guid]::NewGuid().ToString("N"))
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -RunLevel Highest -User "SYSTEM" -Force | Out-Null
    Log 'ok' ("Startup cleanup task created: {0}" -f $taskName)
  } catch { Log-Exception "Register-ScheduledTask" $_.Exception }
}

function Dump-WhatRemains([string]$path) {
  if (-not (Test-Path -LiteralPath $path)) { return }
  Log 'warn' ("Remaining content under: {0}" -f $path)
  try {
    $items = Get-ChildItem -LiteralPath $path -Force -Recurse -ErrorAction SilentlyContinue |
      Select-Object FullName, @{n='LengthKB';e={[int]($_.Length/1KB)}}, Attributes, LastWriteTime |
      Sort-Object FullName
    foreach ($it in $items) {
      $line = "{0}  {1} KB  {2}  {3}" -f $it.FullName, $it.LengthKB, $it.Attributes, $it.LastWriteTime
      Log 'warn' $line
    }
  } catch { Log-Exception "Listing remaining files" $_.Exception }

  try {
    Log 'info' "ACL (SDDL) for root:"
    $acl = Get-Acl -LiteralPath $path
    Log 'info' $acl.Sddl
  } catch { Log-Exception "Get-Acl SDDL" $_.Exception }

  try {
    Log 'info' "icacls /verify output:"
    & icacls.exe "$path" /verify | ForEach-Object { Log 'info' $_ }
  } catch { Log-Exception "icacls /verify" $_.Exception }
}

# =================== Entry ===================
try {
  Assert-Elevated

  # Normalize TargetPath & guard
  $resolved = Resolve-Path -LiteralPath $TargetPath -ErrorAction SilentlyContinue
  if ($resolved) { $TargetPath = $resolved.Path }
  Log 'info' ("TargetPath: {0}" -f $TargetPath)
  if (-not (Test-Path -LiteralPath $TargetPath)) {
    Log 'info' "Nothing to delete; path not found."
    if ($Diag) { try { Stop-Transcript | Out-Null } catch {} }
    exit 0
  }

  # If running from inside target, spawn helper to delete after exit
  if ( (Get-Location).Path -like "$TargetPath*" ) {
    Log 'warn' "Current directory is inside target. Launching detached helper..."

    $helper = @'
$ErrorActionPreference = "Stop"
function AsLong([string]$p){ if($p -like "\\?\*"){ return $p } if($p -match '^[\\]{2}'){ return "\\?\UNC\" + $p.Substring(2) } return "\\?\" + $p }
$t = "@TARGET_PATH@"
for($i=1; $i -le 60; $i++){
  Start-Sleep -Milliseconds 500
  try{
    if(Test-Path $t){
      Get-ChildItem -LiteralPath $t -Force -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
        try { [System.IO.File]::SetAttributes($_.FullName, [System.IO.FileAttributes]::Normal) } catch {}
      }
    }
    Remove-Item -LiteralPath (AsLong $t) -Recurse -Force -ErrorAction Stop
    exit 0
  } catch {}
}
try{
  if(Test-Path $t){
    $empty = Join-Path ([IO.Path]::GetTempPath()) ([IO.Path]::GetRandomFileName())
    New-Item -ItemType Directory -Path $empty | Out-Null
    & robocopy "$empty" "$t" /MIR /NFL /NDL /NJH /NJS /NC /NS /NP | Out-Null
    Remove-Item -LiteralPath (AsLong $t) -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath (AsLong $empty) -Recurse -Force -ErrorAction SilentlyContinue
  }
}catch{}
exit 0
'@

    # Inject target path safely
    $helper = $helper.Replace('@TARGET_PATH@', $TargetPath)

    $tmp = Join-Path $env:TEMP ("cs_cleanup_" + [IO.Path]::GetRandomFileName() + ".ps1")
    Set-Content -LiteralPath $tmp -Value $helper -Encoding UTF8

    $argsArr = @(
      "-NoProfile",
      "-ExecutionPolicy","Bypass",
      "-WindowStyle","Hidden",
      "-File","`"$tmp`""
    )
    Start-Process -FilePath "powershell.exe" -ArgumentList $argsArr -WindowStyle Hidden
    Log 'ok' "Helper launched. Close the toolbox window; deletion will follow."
    if ($Diag) { try { Stop-Transcript | Out-Null } catch {} }
    exit 0
  }

  Log 'info' "Starting cleanup sequence..."
  Kill-ProcsInPath $TargetPath
  Reset-OwnershipAndAcl $TargetPath
  Clear-Attributes $TargetPath

  if (Try-Remove $TargetPath) {
    # === NEW: always try to remove the parent if it is now empty ===
    try {
      $parent = Split-Path -Parent $TargetPath
      if ($parent -and (Test-Path $parent) -and -not (Get-ChildItem -LiteralPath $parent -Force)) {
        Remove-Item -LiteralPath (As-Long $parent) -Force -ErrorAction SilentlyContinue
        Log 'ok' ("Parent removed (empty): {0}" -f $parent)
      }
    } catch { Log-Exception "Remove empty parent" $_.Exception }

    Log 'ok' "Cleanup complete."
    if ($Diag) { try { Stop-Transcript | Out-Null } catch {} }
    exit 0
  }

  if (Robocopy-Purge $TargetPath) {
    # === Try once more to remove parent if purge emptied it ===
    try {
      $parent = Split-Path -Parent $TargetPath
      if ($parent -and (Test-Path $parent) -and -not (Get-ChildItem -LiteralPath $parent -Force)) {
        Remove-Item -LiteralPath (As-Long $parent) -Force -ErrorAction SilentlyContinue
        Log 'ok' ("Parent removed (empty): {0}" -f $parent)
      }
    } catch { Log-Exception "Remove empty parent (after purge)" $_.Exception }

    Log 'ok' "Cleanup complete (robocopy purge)."
    if ($Diag) { try { Stop-Transcript | Out-Null } catch {} }
    exit 0
  }

  Dump-WhatRemains $TargetPath
  Schedule-StartupSweep $TargetPath
  Log 'warn' "Cleanup deferred to next boot. Everything is marked/scheduled for removal."

  if ($Diag) { try { Stop-Transcript | Out-Null } catch {} }
  exit 0
}
catch {
  Log-Exception "Unhandled" $_.Exception
  Dump-WhatRemains $TargetPath
  if ($Diag) { try { Stop-Transcript | Out-Null } catch {} }
  exit 1
}
