# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ===============================
# ConnectSecure Technicians Toolbox - Launcher (R6.5 - hard paths)
# ===============================

function Show-MainMenu {
    Write-Host ""
    Write-Host " [1] OSQuery Data Collection      - Apps, search, browser extensions"
    Write-Host " [2] Nmap Data Collection         - Local network scan profiles"
    Write-Host " [3] Secondary Validation Tools   - Collection A bundle"
    Write-Host " [5] Active Directory Tools       - Users, Groups, OUs, GPOs"
    Write-Host " [6] System Info A                - Firewall, Defender, Disk/SMART"
    Write-Host " [7] System Info B                - Pending Reboot, App Logs, Startup"
    Write-Host " [8] Utilities                    - Services, Disk Space"
    Write-Host " [9] Agent Menu Tool              - Install, Reinstall, Uninstall"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results        - Compress results for support"
    Write-Host " [C] Cleanup and Exit Toolbox"
    Write-Host ""
}

function Invoke-FixedTool {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$DisplayName,
        [Parameter(Mandatory)][string]$FullPath
    )

    if (-not (Test-Path -LiteralPath $FullPath)) {
        Write-Host ""
        Write-Host "❌ $DisplayName script not found at:" -ForegroundColor Red
        Write-Host "   $FullPath"
        Pause-Script "Press any key to return to the menu..."
        return
    }

    try {
        Write-Host ""
        Write-Host "→ Launching: $FullPath"
        & $FullPath
    } catch {
        Write-Host ("❌ ERROR launching {0}: {1}" -f $FullPath, $_.Exception.Message) -ForegroundColor Red
        Write-Log   ("ERROR: launch failed for {0}: {1}" -f $FullPath, $_.Exception.Message)
    }

    Pause-Script "Press any key to return to the menu..."
}

function Run-Choice {
    param([Parameter(Mandatory)][string]$Choice)

    switch ($Choice.Trim().ToUpperInvariant()) {
        '1' { Invoke-FixedTool -DisplayName 'OSQuery Data Collection'    -FullPath 'C:\CS-Toolbox-TEMP\prod-01-01\Osquery-Data-Collection.ps1' }
        '2' { Invoke-FixedTool -DisplayName 'Nmap Data Collection'       -FullPath 'C:\CS-Toolbox-TEMP\prod-01-01\Nmap-Data-Collection.ps1' }
        '3' { Invoke-FixedTool -DisplayName 'Secondary Validation Tools' -FullPath 'C:\CS-Toolbox-TEMP\prod-01-01\ValidationTool-Collection A.ps1' }
        '5' { Invoke-FixedTool -DisplayName 'Active Directory Tools'     -FullPath 'C:\CS-Toolbox-TEMP\prod-01-01\ValidationTool-AD.ps1' }
        '6' { Invoke-FixedTool -DisplayName 'System Info A'              -FullPath 'C:\CS-Toolbox-TEMP\prod-01-01\SystemInfo-A.ps1' }
        '7' { Invoke-FixedTool -DisplayName 'System Info B'              -FullPath 'C:\CS-Toolbox-TEMP\prod-01-01\SystemInfo-B.ps1' }
        '8' { Invoke-FixedTool -DisplayName 'Utilities'                  -FullPath 'C:\CS-Toolbox-TEMP\prod-01-01\Tools-Utilities.ps1' }
        '9' { Invoke-FixedTool -DisplayName 'Agent Menu Tool'            -FullPath 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-Menu-Tool.ps1' }
        'Z' {
            try {
                $zipPath = Zip-Results
                Write-Host ""
                Write-Host "Zip created: $zipPath"
                Email-Results -ZipPath $zipPath
            } catch {
                Write-Host ("❌ ERROR creating/emailing zip: {0}" -f $_.Exception.Message) -ForegroundColor Red
                Write-Log   ("ERROR: Zip/Email failed: {0}" -f $_.Exception.Message)
            }
            Pause-Script "Press any key to return to the menu..."
        }
        'C' { Invoke-FinalCleanupAndExit }
        Default {
            Write-Host "Invalid selection. Please choose a listed option." -ForegroundColor Yellow
            Pause-Script "Press any key to continue..."
        }
    }
}

# --- Main Loop ---
while ($true) {
    Clear-Host
    Show-Header "ConnectSecure Technicians Toolbox"
    Show-MainMenu
    $choice = Read-Host "Enter your choice"
    try {
        Run-Choice -Choice $choice
    } catch {
        Write-Host ("❌ ERROR running selection: {0}" -f $_.Exception.Message) -ForegroundColor Red
        Write-Log   ("ERROR: Selection failed: {0}" -f $_.Exception.Message)
        Pause-Script "Press any key to return to the menu..."
    }
}
