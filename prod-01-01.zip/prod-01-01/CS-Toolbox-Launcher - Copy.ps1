# --- Load shared functions immediately (MUST BE FIRST ON EVERY FILE) ---
$commonPath = "C:\CS-Toolbox-TEMP\prod-01-01\Functions-Common.ps1"

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found at $commonPath" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

try {
    . $commonPath  # dot-source so all functions are loaded before anything else
} catch {
    Write-Host ("❌ ERROR: Failed to load Functions-Common.ps1: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit 1
}

# Provide launcher root to child scripts and prep export folders
$global:CSLauncherRoot = "C:\CS-Toolbox-TEMP\prod-01-01"
Ensure-ExportFolder

# ===============================
# ConnectSecure Technicians Toolbox - Launcher (PS 5.1)
# ===============================

# --- Menu UI ---
function Show-MainMenu {
    Write-Host ""
    Write-Host " ConnectSecure Technicians Toolbox"
    Write-Host ""
    Write-Host ""
    Write-Host " [1] OSQuery Data Collection    - Browser/Apps/Patches via osquery"
    Write-Host " [2] Nmap Data Collection       - Port/Service scan via nmap"
    Write-Host " [3] Secondary Validation Tools - Office, Drivers, Roaming, Browser Ext, WMIC Patches"
    Write-Host ""
    Write-Host " [4] Network Tools              - TLS 1.0 Scan, Validate SMB, misc"
    Write-Host " [5] Active Directory Tools     - Users, Groups, OUs, GPOs"
    Write-Host ""
    Write-Host " [6] System Info A              - Firewall, Defender, Disk/SMART"
    Write-Host " [7] System Info B              - Pending Reboot, App Logs, Startup Audit"
    Write-Host ""
    Write-Host " [8] Utilities                  - Running Services, Disk Space"
    Write-Host " [9] Agent Menu Tool            - Install, Uninstall, Status, Maintenance"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results      - Compress results and open Outlook"
    Write-Host " [C] Cleanup Toolbox Data       - Remove temp/output and self-clean"
    Write-Host " [Q] Quit                       - Optional cleanup before exit"
    Write-Host ""
}

function Run-Choice {
    param([string]$Choice)

    switch -Regex ($Choice) {
        '^[1]$' { Launch-Tool -ScriptName 'OSQuery-Data-Collection.ps1'; return }
        '^[2]$' { Launch-Tool -ScriptName 'Nmap-Data-Collection.ps1';    return }
        '^[3]$' { Launch-Tool -ScriptName 'Secondary-Validation-Tools.ps1'; return }

        '^[4]$' { Launch-Tool -ScriptName 'Network-Tools.ps1';           return }
        '^[5]$' { Launch-Tool -ScriptName 'ActiveDirectory-Tools.ps1';   return }

        '^[6]$' { Launch-Tool -ScriptName 'System-Info-A.ps1';           return }
        '^[7]$' { Launch-Tool -ScriptName 'System-Info-B.ps1';           return }

        '^[8]$' { Launch-Tool -ScriptName 'Utilities.ps1';               return }
        '^[9]$' { Launch-Tool -ScriptName 'Agent-Menu-Tool.ps1';         return }

        '^[zZ]$' {
            try {
                $zip = Zip-Results
                if ($zip) {
                    Write-Host ""
                    Write-Host ("Created/attached results: {0}" -f $zip) -ForegroundColor Cyan
                }
            } catch {
                Write-Host ("❌ Zip/Email failed: {0}" -f $_.Exception.Message) -ForegroundColor Red
                Write-Log   ("ERROR: Zip-Results failed: {0}" -f $_.Exception.Message)
            }
            Pause-Script "Press any key to return to the menu..."
            return
        }

        '^[cC]$' {
            Invoke-FinalCleanupAndExit
            exit 0
        }

        '^[qQ]$' {
            Write-SessionSummary
            exit 0
        }

        default {
            Write-Host "Unrecognized choice. Please try again." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
            return
        }
    }
}

# --- Main Loop ---
while ($true) {
    Clear-Host
    Show-Header "ConnectSecure Technicians Toolbox"
    Show-MainMenu
    $choice = Read-Host "Enter your choice"
    try {
        Run-Choice -Choice $choice
    } catch {
        Write-Host ("❌ ERROR running selection: {0}" -f $_.Exception.Message) -ForegroundColor Red
        Write-Log   ("ERROR: Selection failed: {0}" -f $_.Exception.Message)
        Pause-Script "Press any key to return to the menu..."
    }
}
