# Agent Install / Reinstall — Notes (prod-01-01)
Baseline: as of 2025-08-12

Flow
- Display service status for: CyberCNSAgent, ConnectSecureAgentMonitor (Installed/Status/StartType)
- If either service exists, prompt: "Reinstall ConnectSecure?" and (optionally) launch Agent-Uninstall-Tool.ps1 inline
- Download latest agent link from API (TLS 1.2):
  GET https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows
- Install with required variables (no quotes in params):
  cybercnsagent.exe -c <company> -e <tenant> -j <key> -i
- Actions available in the Agent Menu Tool: **Install**, **Reinstall**, **Remove**
- Show final service status and success message
- Log to: C:\CS-Toolbox-TEMP\Collected-Info\Agent\

Tips
- Use admin PowerShell
- Keep parameters tight; no quotes around values
- If install fails, run Uninstall tool first, then Install
