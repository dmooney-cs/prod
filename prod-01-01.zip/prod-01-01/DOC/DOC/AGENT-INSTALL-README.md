# Agent Menu Tool
Actions:
- **Install:** Download latest via API and install with required parameters (unquoted)
- **Reinstall:** Full uninstall -> API download -> install (no local EXE logic)
- **Uninstall:** Remove agent; show service status before/after

**Logs:** `C:\CS-Toolbox-TEMP\Collected-Info\Agent Logs`  
Requires admin PowerShell; enforces TLS 1.2 for API calls.
