# Developer Notes
- Standardize on **Functions-Common.ps1 R6** (PS 5.1–safe) for shared helpers.
- Every script: loader block **above** `Show-Header`.
- Unify exports under `C:\CS-Toolbox-TEMP\Collected-Info`.
- Keep sub-tools returning to the Launcher on **Q** (same window).
- Avoid external script references; fully inline logic per project standard.
