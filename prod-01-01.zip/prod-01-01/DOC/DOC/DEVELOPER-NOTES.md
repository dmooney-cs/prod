# Developer Notes — Packaging & Release
Updated: 2025-08-12

Targets
- PowerShell 5.1 compatibility
- All tools fully inlined; shared helpers reside in Functions-Common.ps1
- Consistent prompts, colors, pause behavior

Packaging (manual steps)
1. Verify scripts pass basic lint (PSScriptAnalyzer) and smoke run
2. Update CHANGELOG.txt
3. Zip `prod-01-01` contents (excluding prior zips) for release

Future Build-Release.ps1 (backlog)
- Assemble ZIP
- Update /DOC, update CHANGELOG, compute hashes
- Optional Pester quick tests as a gate
- Insert version banner & session summary
