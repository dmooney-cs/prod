# Secondary Validation Tools (Collection A)
- **Windows Patch Audit (WMI):** Installed updates via WMI
- **VC++ Runtime Validation:** Uses `Run-VcppValidation`; structured console + timestamped CSV
- **TLS/SSL Policy Audit (Local Host):** SCHANNEL/.NET strong crypto policy snapshot
- **Registry Uninstall Search:** Wildcard search across HKLM/HKCU uninstall entries

**Exports:** `C:\CS-Toolbox-TEMP\Collected-Info\` under relevant subfolders
