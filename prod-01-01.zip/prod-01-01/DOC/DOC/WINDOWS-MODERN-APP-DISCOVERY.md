# Windows Modern App Discovery
- Show all apps across all users (`Get-AppxPackage -AllUsers`)
- Search by Name/PackageFamilyName/Publisher (wildcards e.g., `*Whiteboard*`)
- On-screen table preview aligned with other subscripts

**Exports:** `C:\CS-Toolbox-TEMP\Collected-Info\ModernApps` (CSV, optional JSON)  
Press **Q** to return to the Launcher (same window).
