# ConnectSecure Technicians Toolbox — Documentation
**Revision:** 2025-08-12  
**Bundle:** prod-01-01 (DOC folder)  
**Baseline:** Functions-Common.ps1 R6 (PS 5.1–safe, email body totals, unified Zip/Email)

This documentation reflects the latest structure/flow as of 2025-08-12. Keep this whole **DOC** folder inside `C:\CS-Toolbox-TEMP\prod-01-01\DOC`.


## What’s included
- **Quickstart** and command to download+run the Launcher
- **Menu map** with current script names
- **Support Playbook** for collecting artifacts and sending to support
- **ChangeLog** detailing recent updates
- **Troubleshooting** for common errors
- Tool-specific notes for Agent, Nmap, and OSQuery

## Folder layout
```
C:\CS-Toolbox-TEMP\
  prod-01-01\
    CS-Toolbox-Launcher.ps1
    Functions-Common.ps1  (R6 baseline)
    *.ps1                  (all tools fully inlined)
    DOC\                  (this folder)
    DOC\*.md, *.txt, *.png (these docs)
    Collected-Info\       (runtime exports, logs)
```
All sub-tools return to the Launcher when you press **Q**. Zip/Email and Cleanup live on the Launcher as **[Z]** and **[C]**.

## Menu Map

```mermaid
flowchart TD
  A[CS-Toolbox-Launcher.ps1] --> B[2: Osquery-Data-Collection.ps1]
  A --> C[3: Nmap-Data-Collection.ps1]
  A --> D[4: Network-Tools.ps1]
  A --> E[5: ValidationTool-AD.ps1]
  A --> F[6: SystemInfo-A.ps1]
  A --> G[7: SystemInfo-B.ps1]
  A --> H[8: Tools-Utilities.ps1]
  A --> I[9: Agent-Menu-Tool.ps1]
  A --> Z[Z: Zip-Results / Email-Results]
  A --> X[C: Cleanup Toolbox Data]
  B --> A
  C --> A
  D --> A
  E --> A
  F --> A
  G --> A
  H --> A
  I --> A
```


## Standards & conventions
- **Loader block** appears at the *very top* of each tool to import `Functions-Common.ps1` before `Show-Header`.
- **Exports** go to: `C:\CS-Toolbox-TEMP\Collected-Info`
- **Email** flow uses Outlook COM where possible; subject format: `Company | Tenant | Ticket | CS Toolbox Files`
- **Run All** options appear in some tools; all are fully inlined, no external URLs invoked except Agent API and optional downloads explicitly noted.
- **Press any key** style pauses are consistent, with optional auto-continue in backlog.

## Launcher from ZIP (preferred)
Use this one-liner in an elevated PowerShell to fetch and run the launcher script that downloads and extracts the toolbox ZIP automatically:

```
powershell -ExecutionPolicy Bypass -NoProfile -Command "irm 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-FromZip.ps1' | iex"
```

**What it does**
- Forces TLS 1.2 for the web request
- Downloads the latest prod-01-01 ZIP
- Extracts to `C:\\CS-Toolbox-TEMP\\prod-01-01\\`
- Unblocks scripts and sets the working directory
- Starts `CS-Toolbox-Launcher.ps1` in the same window
- Ensures `Functions-Common.ps1` R6 loads first for `Show-Header`
- All exports go to `C:\\CS-Toolbox-TEMP\\Collected-Info`


## Current Launcher Items
```
[1] OSQuery Data Collection   - Browser/Apps via osquery
[2] Nmap Data Collection      - Port/Service scan via nmap
[3] Secondary Validation Tools- Patch (WMI), VC++ audit, TLS/SSL policy

[4] Network Tools             - TLS 1.0 Scan, Validate SMB, misc
[5] Active Directory Tools    - Users, Groups, OUs, GPOs

[6] System Info A             - Firewall, Defender, Disk/SMART
[7] System Info B             - Pending Reboot, App Logs, Startup Audit

[8] Utilities                 - Running Services, Disk Space
[9] Agent Menu Tool           - Install, Reinstall, Remove

[Z] Zip and Email Results     - Compress results for support
[C] Cleanup Toolbox Data      - Remove temp/output and self-clean
[Q] Quit                      - Return to launcher or exit
```
