# ConnectSecure Technicians Toolbox — README
(2025-08-12)

## Menu (Current)
- [1] OSQuery Data Collection — Apps, Search, Browser Extensions
- [2] Nmap Data Collection — Adapters/Subnets, Quick & Deep Profiles
- [3] Secondary Validation Tools — Patch Audit (WMI), VC++ Runtime, TLS/SSL Policy, Registry Uninstall Search
- [4] Windows Modern App Discovery — Enumerate & search Modern/Store apps
- [5] Active Directory Tools — Users, Groups, OUs, GPOs
- [6] System Info A — Firewall, Defender, Disk/SMART
- [7] System Info B — Pending Reboot, App Logs, Startup
- [8] Utilities — Services, Disk Space
- [9] Agent Menu Tool — Install, Reinstall, Uninstall
- [Z] Zip & Email Results — Compress artifacts + compose email
- [C] Cleanup & Exit — Controlled self-destruct of toolbox

## Standards
- PowerShell 5.1 target (PS7 generally OK)
- Every script starts with the Functions-Common.ps1 (R6) loader block **before** `Show-Header`
- All exports: `C:\CS-Toolbox-TEMP\Collected-Info`
- Press **Q** in any sub-tool to return to the Launcher in the **same window**
- [Z] subject: `Company | Tenant | Ticket | CS Toolbox Files` (R6 email body includes totals + file listing)

## Launch from ZIP (Preferred)
```powershell
powershell -ExecutionPolicy Bypass -NoProfile -Command "irm 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-FromZip.ps1' | iex"
```
- Extracts to `C:\CS-Toolbox-TEMP\prod-01-01\`, unblocks, sets working folder, launches **in same console**
