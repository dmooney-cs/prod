# Support Playbook — Field Sequence
1) OSQuery (apps full/search/extensions)  
2) Nmap (choose adapter/subnet; Quick/Deep)  
3) Secondary Validation Tools (WMI Patch, VC++ Runtime, TLS/SSL Policy, Registry Uninstall Search)  
4) Windows Modern App Discovery  
5) Agent Menu Tool as needed (Install/Reinstall/Uninstall)  
Z) Zip & Email ; C) Cleanup

**Artifacts:** `C:\CS-Toolbox-TEMP\Collected-Info`  
- Network\Nmap-Scan_*.txt/.xml, OSQuery\*.csv/.json, Registry\*.json, ModernApps\*.csv/.json, Agent Logs\*.log
