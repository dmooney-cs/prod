# OSQuery Data Collection
- Applications (Full Inventory) from osquery `programs`
- Search for Specific Application (LIKE on name/publisher)
- Browser Extensions (Chrome/Edge/Firefox)

**Exports:** CSV (and JSON where implemented) to `C:\CS-Toolbox-TEMP\Collected-Info\OSQuery`  
Press **Q** to return to the Launcher (same window).
