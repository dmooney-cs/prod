# OSQuery Data Collection — Notes (prod-01-01)
Baseline: as of 2025-08-12

Menu
[1] Applications (Full Inventory) — from osquery 'programs'
[2] Search for Specific Application — LIKE filter on name/publisher
[3] Browser Extensions — Chrome/Edge/Firefox

Behavior
- Exports to: C:\CS-Toolbox-TEMP\Collected-Info\OSQuery\
- Displays results on-screen and writes CSV (+ JSON where implemented)
- 'Q' returns to the Launcher in the same window

Tips
- Guard for missing osquery: auto-exit with clear message if osquery isn't present
- Use UTF-8 (no BOM) when writing CSVs
