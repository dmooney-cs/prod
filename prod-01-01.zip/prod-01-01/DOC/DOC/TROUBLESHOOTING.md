# Troubleshooting
- **Execution Policy prompts:** Use the provided one-liner (Bypass/NoProfile).
- **Permissions:** Run PowerShell as **Administrator**.
- **Nmap not found:** Tool auto-installs under Program Files (x86)\CyberCNSAgent\nmap.
- **Email compose failures:** Falls back from Outlook COM -> classic Outlook `/a` -> mailto+Explorer.
- **No results:** Check `C:\CS-Toolbox-TEMP\Collected-Info\SessionSummary_*.txt`.
