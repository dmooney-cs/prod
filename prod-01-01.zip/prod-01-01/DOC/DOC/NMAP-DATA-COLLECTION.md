# Nmap Data Collection — Notes (prod-01-01)
Baseline: as of 2025-08-12

Overview
- Detect active IPv4 adapters (IP/Prefix/Gateway)
- Offer suggested targets:
  [1] Host /32
  [2] Subnet /24 (where applicable)
  [3] Supernet /16 (where applicable)
  [C] Custom target

Scan Profiles
- Quick: top 1000 ports, faster timing, early drop of dead IPs
- Deep: engineer-approved profile, service/version detection, larger top-ports
- (Optional 3rd) Full: long run; ensure summary is shown before returning

Output
- Text and XML written to: C:\CS-Toolbox-TEMP\Collected-Info\Network\
- On completion, show a brief summary:
  • Hosts up / scanned
  • Output file paths
  • Elapsed time

Gotchas
- Ensure the nmap folder is: C:\Program Files (x86)\CyberCNSAgent\nmap\ (no nested nmap\nmap)
- Double-backslashes in the command line are okay in logs (escaped strings), but verify the resolved path exists
- If no subnets calculate, fall back to host /32 and display a warning
