# Nmap Data Collection
- Auto-installs Nmap to `C:\Program Files (x86)\CyberCNSAgent\nmap` if missing
- Detects IPv4 adapters; lists **all**; proposes `/24` subnets (fallback to host /32)
- Profiles: **Quick** (top ports, version-light), **Deep** (engineer-approved)

**Exports:** `.txt` and `.xml` to `C:\CS-Toolbox-TEMP\Collected-Info\Network` with timestamps  
Clear on-screen status and pause before returning.
