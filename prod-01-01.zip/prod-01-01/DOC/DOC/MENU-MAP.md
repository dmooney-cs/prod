# Menu Map (prod-01-01)
Updated: 2025-08-12

* [1] OSQuery Data Collection — Apps, Search, Browser Extensions
* [2] Nmap Data Collection — Adapters/Subnets, Quick & Deep Profiles
* [3] Secondary Validation Tools — Patch Audit (WMI), VC++ Runtime, TLS/SSL Policy, Registry Uninstall Search
* [4] Windows Modern App Discovery — Enumerate & search Modern/Store apps
* [5] Active Directory Tools — Users, Groups, OUs, GPOs
* [6] System Info A — Firewall, Defender, Disk/SMART
* [7] System Info B — Pending Reboot, App Logs, Startup
* [8] Utilities — Services, Disk Space
* [9] Agent Menu Tool — Install, Reinstall, Uninstall
* [Z] Zip & Email Results — Compress artifacts + compose email
* [C] Cleanup & Exit — Controlled self-destruct of toolbox
