# Security Notes
- Enforce TLS 1.2 for all API operations.
- Prefer signed scripts for enterprise distribution when applicable.
- Optionally verify SHA-256 of downloaded agents and store alongside artifacts.
- Email compose paths: Outlook COM (preferred), Outlook `/a`, mailto fallback.
