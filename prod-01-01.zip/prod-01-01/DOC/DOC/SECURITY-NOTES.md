# Security Notes
Last updated: 2025-08-12

- Downloads use TLS 1.2: [Net.ServicePointManager]::SecurityProtocol = Tls12
- Session-only ExecutionPolicy Bypass avoids permanent policy changes
- Future backlog: SHA-256 verification of downloads; optional script signing
- No telemetry is sent; artifacts remain local unless you email them via [Z]
