
CS Toolbox Update - 2025-08-09

Included:
- CS-Toolbox-Launcher.ps1 (adds [N] Nmap Data Collection; [O] OSQuery Data Collection)
- ValidationTool-Collection B.ps1 (B.14): WMI Patch Audit, VC++ Runtime, Dependency Walker DLL Scan
- ValidationTool-Collection C.ps1 (C.6): SSL/TLS Protocols & Cipher Suites
- Osquery-Data-Collection.ps1 (v1.1): Apps, Extensions, Patch Audit
- Nmap-Data-Collection.ps1 (v1.1): TLS 1.0, Host/Port, SMB

Standards:
- Exports to C:\CS-Toolbox-TEMP\Collected-Info
- No Zip/Cleanup inside sub-scripts (centralized in Launcher)

Notes:
- Nmap path preference: CyberCNS Agent bundled Nmap at
  C:\Program Files (x86)\CyberCNSAgent\nmap\nmap.exe, then standard installs.
- Dependency Walker downloaded on demand into Tools-Temp if not present.
