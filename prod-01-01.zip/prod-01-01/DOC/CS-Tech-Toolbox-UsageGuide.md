# 📘 CS Toolbox – Script Usage Guide

This guide explains how to use each individual script in the ConnectSecure Toolbox.

## `ValidationTool-Collection A`
- Launch from the toolbox or run directly in PowerShell.
- Scans installed Microsoft Office products, system drivers, user-installed apps (roaming/active), and browser extensions.
- No input required; data is collected and exported to `C:\Script-Export` with timestamps.
- You will be prompted to press ENTER between steps for review.

## `ValidationTool-Collection B`
- Launch from the toolbox or run standalone in PowerShell.
- Collects Windows patch info from Get-HotFix, WMIC, and osquery.
- Also scans dependencies of any DLL/EXE using the embedded Dependency Walker utility.
- Results exported to CSV in `C:\Script-Export`. Prompts are used throughout for review and selection.

## `ValidationTool-Collection C`
- Run from the toolbox or directly in PowerShell.
- Uses osquery to collect browser extension data, and Nmap to check SSL/TLS cipher support.
- Nmap and Npcap must be available (the script will install Npcap OEM if needed).
- Results saved to CSV files in the export folder.

## `Agent-Maintenance`
- Includes a submenu for: Agent Status Check, Clear Pending Jobs, Set SMB, and Check SMB.
- No manual inputs needed for most actions — logic is automatic.
- SMB features modify firewall and registry. All actions are logged.
- Outputs CSV results and prompts user before continuing.

## `Agent-Install-Tool`
- Checks if CyberCNS Agent is installed. If yes, offers to uninstall and re-install.
- Prompts for Company ID, Tenant ID, and Secret Key.
- Downloads latest agent from ConnectSecure API, runs install in-place.
- Logs to transcript and CSV, saved in `C:\Script-Export`.

## `Network-Tools`
- Launch from menu or directly in PowerShell.
- Menu includes: SMB Version Check, TLS 1.0 RDP Scan, Full Nmap SSL Scan.
- Some scans require Nmap to be installed (check will run first).
- Prompts for target IP or uses local machine. Results saved to CSV or TXT.

## `ValidationTool-AD`
- Queries Active Directory using PowerShell native cmdlets.
- No input required if run from a domain-joined workstation.
- Collects users, groups, OUs, GPOs, and computer accounts.
- Results saved to CSV. Prompts user between each collection.

## `SystemInfo-A`
- Scans Windows Defender, Firewall, and disk status including SMART info.
- No inputs required; runs directly and saves outputs to export path.
- Useful for hardware and protection status validation.

## `SystemInfo-B`
- Detects if system requires reboot, checks startup/autostart entries, and summarizes Event Logs.
- No inputs required; will prompt user between sections.
- All logs and summaries exported to the standard folder.


### Agent Menu Options
- [3] Update Agent V4 – Pull and Replace Binary