# ConnectSecure Technicians Toolbox — Documentation
**Revision:** 2025-08-12  
**Bundle:** prod-01-01 (DOC folder)  
**Baseline:** Functions-Common.ps1 R6 (PS 5.1–safe, email body totals, unified Zip/Email)

This documentation reflects the latest structure/flow as of 2025-08-12. Keep this whole **DOC** folder inside `C:\CS-Toolbox-TEMP\prod-01-01\DOC`.


## When to collect & send
Run the toolbox *before* opening a ticket when possible, or for any of:
- Agent install/update issues
- Network visibility or port/service checks
- Application inventory or browser extension questions
- Patch audit discrepancies

## What to run
1. **Agent Menu Tool** > Install/Reinstall/Remove as needed
2. **Nmap Data Collection** > Quick (top ports) or Deep (engineer profile)
3. **OSQuery Data Collection** > Apps, Search, or Extensions

## Where files are saved
All outputs land in: `C:\CS-Toolbox-TEMP\Collected-Info`  
You’ll typically see:
- `SessionSummary_*.txt` (run summary with timestamps)
- `Network\Nmap-Scan_*.txt/.xml` (Nmap results)
- `OSQuery\*.csv` and `*.json` (apps / extensions)
- `VCppValidation_*.csv` (VC++ runtime audit when invoked)
- `Agent\*.log` (agent actions)
- Zip archives created by **[Z] Zip and Email Results**

## Emailing results (built-in)
From the Launcher press **[Z]**, then follow prompts:
- Choose support default or custom email
- Provide Company, Tenant, and optional Ticket #
- Subject format: `Company | Tenant | Ticket | CS Toolbox Files`
- The email body auto-includes file counts and per-file listings

## Submitting a ticket
Include:
- The zip created by **[Z]** (or `Collected-Info` contents if manual)
- A short problem summary and recent changes
- Optional: screenshots of any error dialogs

## Privacy & retention
Artifacts remain local unless you email them. Use **[C]** to clean up after sending.
