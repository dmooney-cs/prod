# Troubleshooting — Common Issues
Updated: 2025-08-12

Execution Policy / SmartScreen
- Use session-only bypass: start PowerShell with -ExecutionPolicy Bypass
- Unblock scripts after extraction: Unblock-File *.ps1

Call Depth Overflow / Header
- Ensure every tool starts with the loader block for Functions-Common.ps1
- Use the latest Functions-Common.ps1 (R6) at the repo root

Property 'Count' or 'IPv4Address' not found
- Typically from unexpected object shape when enumerating adapters
- Normalize objects from Get-NetIPConfiguration / Get-NetAdapter
- Check for null gateways and IPv6-only adapters

UInt32 conversion errors on subnet math (e.g., -1 to UInt32)
- Validate prefix length and address family before mask math
- Ignore disconnected/virtual adapters with invalid data

Nmap not found or nested folder
- Path should be: C:\Program Files (x86)\CyberCNSAgent\nmap\nmap.exe
- If you see nmap\nmap\nmap.exe, flatten the folder structure

Sub-menus exiting instead of returning
- Confirm 'Q' path calls back into CS-Toolbox-Launcher.ps1 in the **same window**
- Use Launch-Tool helper and avoid new PowerShell processes where possible
