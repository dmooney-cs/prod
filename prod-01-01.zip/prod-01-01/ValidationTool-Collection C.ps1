# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool C                                      ║
# ║ Version: C.3 | TLS Ciphers, OSQuery Extensions, Cleanup + ZIP              ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

Ensure-ExportFolder

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}

function Run-TLSCipherScan {
    Show-Header "Checking Supported TLS Cipher Suites"

    $cipherList = Get-TlsCipherSuite |
        Sort-Object Name |
        Select-Object Name, CipherSuite, Protocol, Exchange, Hash

    Export-Data -Object $cipherList -BaseName "TLS-CipherSuites"
    Pause-Script
}

function Run-OSQueryExtensionsScan {
    Show-Header "Checking OSQuery Extensions"

    $osqueryPath = "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe"
    if (-not (Test-Path $osqueryPath)) {
        Write-Host "❌ OSQuery not found at $osqueryPath"
        Pause-Script
        return
    }

    $query = "SELECT name, version, sdk_version, path FROM osquery_extensions;"
    $output = & "$osqueryPath" --json "$query" | ConvertFrom-Json
    Export-Data -Object $output -BaseName "OSQuery-Extensions"
    Pause-Script
}

function Show-ValidationMenuC {
    Clear-Host
    Write-Host "====================================================="
    Write-Host "     CS Toolbox - Validation Tool C"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] TLS Cipher Suites Audit"
    Write-Host " [2] OSQuery Extensions Audit"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

# Main Loop
do {
    Show-ValidationMenuC
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Run-TLSCipherScan }
        '2' { Run-OSQueryExtensionsScan }
        'Z' { Invoke-ZipAndEmailResults }
        'C' { Invoke-CleanupExport }
        'Q' { return }
        default { Write-Host "`nInvalid selection. Please choose again." -ForegroundColor Yellow }
    }
} while ($true)
