# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool C                      ║
# ║ Version: C.5 | 2025-08-07                                   ║
# ║ Includes OSQuery + TLS Cipher + ZIP + Cleanup              ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Collect-Browser-Extensions {
    Show-Header "OSQuery - Browser Extensions"
    $paths = @(
        "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe",
        "C:\Program Files\CyberCNSAgent\osqueryi.exe"
    )

    $osquery = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1

    if (-not $osquery) {
        Write-Host "❌ OSQuery not found. Skipping browser extension scan." -ForegroundColor Red
        Pause-Script
        return
    }

    $browsers = @("chrome", "edge", "firefox")
    foreach ($browser in $browsers) {
        Show-Header "Scanning Extensions: $browser"
        $query = "SELECT identifier, name, description, version FROM ${browser}_extensions;"
        try {
            $output = & $osquery --json "$query" 2>$null | ConvertFrom-Json
            if ($output) {
                Export-Data -Object $output -BaseName "OSQuery-$browser-Extensions"
                Write-SessionSummary "$browser extensions collected via OSQuery"
            } else {
                Write-Host "⚠ No extensions found for $browser." -ForegroundColor Yellow
            }
        } catch {
            Write-Host "❌ Failed running OSQuery for $browser: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    Pause-Script
}

function Collect-TLS-CipherSupport {
    Show-Header "Checking TLS Cipher Support"
    try {
        $ciphers = Get-TlsCipherSuite | Sort-Object Name | Select-Object Name, CipherSuite, Protocol
        Export-Data -Object $ciphers -BaseName "TLS-CipherSuites"
        Write-SessionSummary "TLS cipher suites collected"
    } catch {
        Write-Host "❌ Failed to collect TLS Cipher Suites: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

function Run-AllCollection {
    Collect-TLS-CipherSupport
    Collect-Browser-Extensions
}

# Main Menu
do {
    Show-Header "Validation Tool C - SSL + Extensions"

    Write-Host " [1] Check TLS Cipher Suites"
    Write-Host " [2] Scan Browser Extensions via OSQuery"
    Write-Host " [3] Run All Collection Tasks"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""

    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        "1" { Collect-TLS-CipherSupport }
        "2" { Collect-Browser-Extensions }
        "3" { Run-AllCollection }
        "Z" { Invoke-ZipAndEmailResults }
        "C" { Cleanup-ExportFolder }
        "Q" { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Please try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
