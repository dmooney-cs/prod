# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool C                      ║
# ║ Version: C.4 | 2025-08-07                                   ║
# ║ Includes OSQuery + TLS Cipher + ZIP + Cleanup              ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Collect-Browser-Extensions {
    Show-Header "OSQuery Browser Extensions Audit"

    $osqueryPaths = @(
        "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe",
        "C:\Program Files\CyberCNSAgent\osqueryi.exe"
    )

    $osquery = $osqueryPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

    if (-not $osquery) {
        Write-Host "✖ OSQuery not found. Skipping extension audit." -ForegroundColor Red
        return
    }

    $browsers = @{
        "Chrome"  = "SELECT name, description, version FROM chrome_extensions;";
        "Edge"    = "SELECT name, description, version FROM edge_extensions;";
        "Firefox" = "SELECT name, version FROM firefox_addons;"
    }

    foreach ($browser in $browsers.Keys) {
        $query = $browsers[$browser]
        $outputFile = Join-Path $exportPath "BrowserExtensions-$browser.csv"
        try {
            $results = & $osquery --json "$query" | ConvertFrom-Json
            if ($results) {
                $results | Export-Csv -Path $outputFile -NoTypeInformation -Force
                Write-Host "✔ $browser extensions exported to: $outputFile" -ForegroundColor Green
            } else {
                Write-Host "✖ No $browser extension data found." -ForegroundColor Yellow
            }
        } catch {
            Write-Host "✖ Failed running OSQuery for ${browser}: $_" -ForegroundColor Red
        }
    }

    Pause-Script
}

function Run-TLS-CipherCheck {
    Show-Header "Validating TLS Cipher Availability"
    $tlsList = @(
        [PSCustomObject]@{Protocol="SSL 2.0";    Key="SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server";  Value="Enabled"},
        [PSCustomObject]@{Protocol="SSL 3.0";    Key="SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server";  Value="Enabled"},
        [PSCustomObject]@{Protocol="TLS 1.0";    Key="SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server";  Value="Enabled"},
        [PSCustomObject]@{Protocol="TLS 1.1";    Key="SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server";  Value="Enabled"},
        [PSCustomObject]@{Protocol="TLS 1.2";    Key="SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server";  Value="Enabled"},
        [PSCustomObject]@{Protocol="TLS 1.3";    Key="SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.3\Server";  Value="Enabled"}
    )

    foreach ($tls in $tlsList) {
        $enabled = Get-ItemProperty -Path "HKLM:\$($tls.Key)" -Name $tls.Value -ErrorAction SilentlyContinue | Select-Object -ExpandProperty $tls.Value -ErrorAction SilentlyContinue
        if ($enabled -eq 1) {
            Write-Host "✔ $($tls.Protocol) is ENABLED" -ForegroundColor Green
        } else {
            Write-Host "⚠ $($tls.Protocol) is DISABLED or not configured" -ForegroundColor Yellow
        }
    }

    Pause-Script
}

function Show-ValidationCMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "       Validation Tool C - Browser + TLS Check"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Collect Browser Extensions"
    Write-Host " [2] Check TLS Cipher Settings"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

# Main menu loop
do {
    Show-ValidationCMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Collect-Browser-Extensions }
        '2' { Run-TLS-CipherCheck }
        'Z' { try { Invoke-ZipAndEmailResults } catch { Write-Host "✖ ZIP/Email error: $_" -ForegroundColor Red; Pause-Script } }
        'C' { try { Invoke-CleanupExports } catch { Write-Host "✖ Cleanup error: $_" -ForegroundColor Red; Pause-Script } }
        'Q' { break }
        default { Write-Host "Invalid selection." -ForegroundColor Red; Start-Sleep -Seconds 1 }
    }
} while ($true)
