# Load shared functions first - required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { $null = Read-Host }
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { $null = Read-Host }
    return
}

Ensure-ExportFolder

# CS Tech Toolbox – Validation Tool C
# TLS/SSL protocol and cipher survey (OSQuery items removed)
# Exports -> C:\CS-Toolbox-TEMP\Collected-Info

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (-not (Test-Path $commonPath)) { Write-Host "ERROR: Functions-Common.ps1 missing." -ForegroundColor Red; Pause-Script; return }
try { Invoke-Expression (Get-Content $commonPath -Raw -Encoding UTF8) } catch { Write-Host ("ERROR loading common: {0}" -f $_) -ForegroundColor Red; Pause-Script; return }
Ensure-ExportFolder
$ErrorActionPreference = 'Continue'

function Write-Export { param([Parameter(Mandatory)][object]$Object,[Parameter(Mandatory)][string]$BaseName,[string]$Ext='csv')
    if (Get-Command Export-Data -ErrorAction SilentlyContinue) { Export-Data -Object $Object -BaseName $BaseName -Ext $Ext; return }
    $outDir="C:\CS-Toolbox-TEMP\Collected-Info"; if (-not (Test-Path $outDir)) { New-Item $outDir -ItemType Directory -Force | Out-Null }
    $ts=Get-Date -Format "yyyy-MM-dd_HH-mm-ss"; $file=Join-Path $outDir ("{0}_{1}.{2}" -f $BaseName,$ts,$Ext)
    try { if ($Ext -ieq 'csv'){ $Object|Export-Csv -NoTypeInformation -Encoding UTF8 -Path $file } elseif($Ext -ieq 'json'){ $Object|ConvertTo-Json -Depth 7|Out-File -Encoding UTF8 -FilePath $file } else { $Object|Out-File -Encoding UTF8 -FilePath $file } ; Write-Host ("Exported: {0}" -f $file) -ForegroundColor Green } catch { Write-Host ("Export failed: {0}" -f $_) -ForegroundColor Red }
}

function Get-SchannelProtocolState { param([string]$Protocol,[string]$Role)
    $base = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\$Protocol\$Role"
    $enabled=$null; $disabledByDefault=$null
    if (Test-Path $base){ try { $p=Get-ItemProperty -Path $base -ErrorAction SilentlyContinue; $enabled=$p.Enabled; $disabledByDefault=$p.DisabledByDefault } catch {} }
    [pscustomobject]@{ Protocol=$Protocol; Role=$Role; Enabled=$enabled; DisabledByDefault=$disabledByDefault; RegPath=$base }
}

function Run-TlsCipherSurvey {
    try {
        Show-Header "TLS/SSL Protocol and Cipher Survey"
        $protocols=@('SSL 2.0','SSL 3.0','TLS 1.0','TLS 1.1','TLS 1.2','TLS 1.3')
        $states = foreach($proto in $protocols){ Get-SchannelProtocolState -Protocol $proto -Role 'Client'; Get-SchannelProtocolState -Protocol $proto -Role 'Server' }
        if (-not $states){ $states = ,[pscustomobject]@{ Protocol='(none)'; Role=''; Enabled=$null; DisabledByDefault=$null; RegPath='' } }

        $cipherObjects=@()
        $gts=Get-Command Get-TlsCipherSuite -ErrorAction SilentlyContinue
        if ($gts){ try { $cipherObjects = Get-TlsCipherSuite -ErrorAction Stop | Select-Object Name,Cipher,Hash,KeyExchange,Protocols } catch { Write-Host ("Get-TlsCipherSuite failed: {0}" -f $_) -ForegroundColor Yellow } }
        if (-not $cipherObjects){ $cipherObjects = ,[pscustomobject]@{ Name='(unavailable)'; Cipher=''; Hash=''; KeyExchange=''; Protocols='' } }

        Write-Export -Object $states -BaseName 'TLS-Protocol-States'
        Write-Export -Object $cipherObjects -BaseName 'TLS-CipherSuites'
        Pause-Script
    } catch { Write-Host ("TLS/SSL survey error: {0}" -f $_) -ForegroundColor Red; Pause-Script }
}

function Show-Menu {
    Show-Header "Validation Tool C"
    Write-Host " [1] TLS/SSL Protocol and Cipher Survey"
    Write-Host ""
    Write-Host " [Q] Return to Main Menu"
    Write-Host ""
}

do {
    Show-Menu
    $choice = (Read-Host "Enter your choice").ToUpper()
    switch ($choice) {
        '1' { Run-TlsCipherSurvey }
        'Q' {
            & "C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1"
            return
        }
        default { Write-Host "Invalid selection. Try again." -ForegroundColor Yellow ; Start-Sleep 1 }
    }
} while ($true)

return
