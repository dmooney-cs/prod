﻿# =====================================================================
# Remove-CyberCNSAgentFolder.ps1  (force unlock + delete, PS 5.1)
#
# Target: C:\Program Files (x86)\CyberCNSAgent
#
# What it does:
#   0) ALWAYS stop + HARD-delete services:
#        - CyberCNSAgent
#        - CyberCNSAgentMonitor
#      (even if the target folder does not exist)
#      Escalation: sc stop/delete -> kill PID -> delete service registry key
#      -> RunOnce forced delete if still present
#   1) Stop + delete other CyberCNS/path-referencing services (best effort)
#   2) Disable/stop scheduled tasks whose actions reference TargetPath
#   3) Kill processes running from TargetPath and named cybercns*
#   4) If handle.exe is available: find locking PIDs under TargetPath and kill them
#   5) Take ownership + grant Administrators Full Control
#   6) Delete with retries + file-by-file cleanup
#   7) Robocopy mirror-purge fallback
#   8) If still locked: rename folder and set RunOnce deletion on next boot
#
# Supports:
#   -ExportOnly  => exports JSON to C:\CS-Toolbox-TEMP\Collected-Info and exits
# =====================================================================

$TargetPath = 'C:\Program Files (x86)\CyberCNSAgent'
$ExportOnly = $false

# Allow quick "-ExportOnly" when pasted into console
if ($args -and ($args | ForEach-Object { $_.ToString().ToLowerInvariant() }) -contains '-exportonly') {
    $ExportOnly = $true
}

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$CollectedInfo = 'C:\CS-Toolbox-TEMP\Collected-Info'
$null = New-Item -ItemType Directory -Path $CollectedInfo -Force -ErrorAction SilentlyContinue
$LogPath    = Join-Path $CollectedInfo 'remove-cybercnsagent.log'
$ExportPath = Join-Path $CollectedInfo 'remove-cybercnsagent-export.json'

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$Level] $ts $Message"
    Add-Content -Path $LogPath -Value $line -Encoding UTF8
    Write-Host $line
}

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-HandleExe {
    $candidates = @()

    try { if ($PSScriptRoot) { $candidates += (Join-Path $PSScriptRoot 'handle.exe') } } catch {}

    $candidates += 'C:\CS-Toolbox-TEMP\prod-01-01\DOCS\ETC\handle.exe'
    $candidates += 'C:\CS-Toolbox-TEMP\Launchers\handle.exe'

    foreach ($p in $candidates) {
        if (Test-Path -LiteralPath $p) { return $p }
    }

    $cmd = Get-Command handle.exe -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { return $cmd.Source }

    return $null
}

if ($ExportOnly) {
    $payload = [ordered]@{
        Script     = 'Remove-CyberCNSAgentFolder.ps1'
        Timestamp  = (Get-Date).ToString('o')
        TargetPath = $TargetPath
        LogPath    = $LogPath
        Planned    = @(
            "ALWAYS stop + HARD-delete services: CyberCNSAgent, CyberCNSAgentMonitor (even if folder missing)",
            "Stop + delete other services named *CyberCNS* or PathName referencing TargetPath",
            "Disable/stop scheduled tasks whose actions reference TargetPath",
            "Kill processes running from TargetPath and named cybercns*",
            "If handle.exe present: identify locking PIDs under TargetPath and kill them",
            "takeown + icacls admins full control",
            "Remove-Item delete retries + file-by-file cleanup",
            "Robocopy mirror-purge fallback",
            "If still locked: rename folder and RunOnce rd /s /q on next boot"
        )
    }
    $payload | ConvertTo-Json -Depth 6 | Set-Content -Path $ExportPath -Encoding UTF8
    Write-Host "Exported: $ExportPath"
    exit 0
}

if (-not (Test-Admin)) { throw "Run this in an elevated PowerShell (Admin)." }

Write-Log "TargetPath: $TargetPath"

# ------------------------- 0) ALWAYS stop + HARD-delete these services -------------------------
# Runs regardless of whether $TargetPath exists.
$mustDeleteServices = @('CyberCNSAgent', 'CyberCNSAgentMonitor')

foreach ($svcName in $mustDeleteServices) {
    Write-Log "FORCE service removal: $svcName"

    # 1) Stop (best-effort)
    try {
        Write-Log "Stopping service: $svcName"
        sc.exe stop $svcName | Out-Null
    } catch {}

    # 2) Wait briefly for stop / disappearance
    for ($w = 1; $w -le 10; $w++) {
        Start-Sleep -Seconds 1
        $cur = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
        if (-not $cur -or $cur.State -eq 'Stopped') { break }
    }

    # 3) Kill its service process by PID (if any)
    try {
        $cur = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
        if ($cur -and $cur.ProcessId -and [int]$cur.ProcessId -gt 0) {
            Write-Log "Killing service process for $svcName (PID $($cur.ProcessId))"
            Stop-Process -Id ([int]$cur.ProcessId) -Force -ErrorAction SilentlyContinue
        }
    } catch {}

    # 4) Try normal delete a few times
    for ($i = 1; $i -le 3; $i++) {
        try {
            Write-Log "Deleting service: $svcName (attempt $($i))"
            sc.exe delete $svcName | Out-Null
        } catch {}
        Start-Sleep -Seconds 1

        $stillThere = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
        if (-not $stillThere) { break }
    }

    # 5) HARD delete: remove registry service key if still present
    $stillThere = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
    if ($stillThere) {
        Write-Log "Service still present after sc delete; HARD removing registry key..." "WARN"

        $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$svcName"
        try {
            if (Test-Path -LiteralPath $svcKey) {
                # Best-effort to ensure perms (registry icacls via reg path)
                cmd.exe /c "icacls `"HKLM\System\CurrentControlSet\Services\$svcName`" /grant Administrators:F /t /c" | Out-Null
                Remove-Item -LiteralPath $svcKey -Recurse -Force -ErrorAction Stop
                Write-Log "Deleted registry key: $svcKey"
            } else {
                Write-Log "Registry key not found: $svcKey (service may be held by SCM cache)" "WARN"
            }
        } catch {
            Write-Log "Registry key removal failed: $($_.Exception.Message)" "ERROR"
        }

        # Re-check
        Start-Sleep -Seconds 1
        $stillThere2 = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
        if ($stillThere2) {
            # 6) Last resort: schedule forced removal at next boot/logon
            $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
            $runOnceKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
            $cmd = "cmd.exe /c sc stop `"$svcName`" & sc delete `"$svcName`" & reg delete `"HKLM\System\CurrentControlSet\Services\$svcName`" /f"
            $name = "ForceDeleteService_${svcName}_$stamp"

            Write-Log "Still present. Staging RunOnce forced removal: $name" "WARN"
            New-Item -Path $runOnceKey -Force | Out-Null
            New-ItemProperty -Path $runOnceKey -Name $name -Value $cmd -PropertyType String -Force | Out-Null

            Write-Log "Service removal staged via RunOnce (reboot recommended): $svcName" "WARN"
        } else {
            Write-Log "Service removed after registry key deletion: $svcName"
        }
    } else {
        Write-Log "Service deleted: $svcName"
    }
}
# ---------------------------------------------------------------------

# If folder doesn't exist after service cleanup, exit cleanly
if (-not (Test-Path -LiteralPath $TargetPath)) {
    Write-Log "TargetPath not found after service cleanup; nothing else to delete." "WARN"
    exit 0
}

# ------------------------- 1) Stop + DELETE other related services -------------------------
Write-Log "Stopping and deleting other CyberCNS/path services..."
try {
    $services = Get-CimInstance Win32_Service -ErrorAction Stop

    $targetServices = $services | Where-Object {
        ($_.Name -like '*CyberCNS*') -or
        ($_.DisplayName -like '*CyberCNS*') -or
        ($_.PathName -and $_.PathName -like "*$TargetPath*")
    }

    # Avoid reprocessing the mandatory ones
    $targetServices = $targetServices | Where-Object { $mustDeleteServices -notcontains $_.Name }

    foreach ($s in $targetServices) {
        Write-Log "Processing service: $($s.Name)  (State=$($s.State))"

        if ($s.State -ne 'Stopped') {
            Write-Log "Stopping service: $($s.Name)"
            sc.exe stop $s.Name | Out-Null

            for ($w = 1; $w -le 20; $w++) {
                Start-Sleep -Seconds 1
                $cur = Get-CimInstance Win32_Service -Filter "Name='$($s.Name)'" -ErrorAction SilentlyContinue
                if (-not $cur -or $cur.State -eq 'Stopped') { break }
            }
        }

        Write-Log "Deleting service: $($s.Name)"
        sc.exe delete $s.Name | Out-Null
    }

    Start-Sleep -Seconds 2
}
catch {
    Write-Log "Other service stop/delete step failed: $($_.Exception.Message)" "WARN"
}

# ------------------------- 2) Disable scheduled tasks referencing TargetPath -------------------------
try {
    Write-Log "Disabling scheduled tasks referencing target path..."
    $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue
    foreach ($t in $tasks) {
        try {
            $actionsText = ($t.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' | '
            if ($actionsText -and $actionsText -like "*$TargetPath*") {
                Write-Log "Disabling task: $($t.TaskName) (Path: $($t.TaskPath))"
                Disable-ScheduledTask -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction SilentlyContinue | Out-Null
                Stop-ScheduledTask    -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction SilentlyContinue | Out-Null
            }
        } catch {}
    }
} catch {
    Write-Log "Scheduled task step failed: $($_.Exception.Message)" "WARN"
}

# ------------------------- 3) Kill processes (by path AND by name) -------------------------
try {
    Write-Log "Killing processes running from target path..."
    Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $exe = $_.MainModule.FileName
            if ($exe -and $exe.StartsWith($TargetPath, [StringComparison]::OrdinalIgnoreCase)) {
                Write-Log "Stopping process: $($_.Name) (PID $($_.Id))"
                Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
            }
        } catch {}
    }

    Write-Log "Killing processes named cybercns* ..."
    Get-Process -Name 'cybercns*' -ErrorAction SilentlyContinue | ForEach-Object {
        Write-Log "Stopping process: $($_.Name) (PID $($_.Id))"
        Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
    }

    cmd.exe /c 'taskkill /f /im CyberCNSAgent.exe >nul 2>&1' | Out-Null
    cmd.exe /c 'taskkill /f /im CyberCNS*.exe >nul 2>&1' | Out-Null
    Start-Sleep -Seconds 2
} catch {
    Write-Log "Process kill step failed: $($_.Exception.Message)" "WARN"
}

# ------------------------- 4) handle.exe: identify lockers and kill them -------------------------
$handleExe = Find-HandleExe
if ($handleExe) {
    try {
        Write-Log "handle.exe found at: $handleExe"
        Write-Log "Searching for locking handles under target path..."

        $out = & $handleExe -accepteula -nobanner "$TargetPath" 2>$null
        $pids = New-Object System.Collections.Generic.HashSet[int]

        foreach ($line in $out) {
            if ($line -match '\spid:\s*(\d+)\s') {
                [void]$pids.Add([int]$Matches[1])
            }
        }

        if ($pids.Count -gt 0) {
            Write-Log ("Found locking PIDs: " + (($pids | Sort-Object) -join ', '))
            foreach ($pid in ($pids | Sort-Object)) {
                try {
                    $p = Get-Process -Id $pid -ErrorAction SilentlyContinue
                    if ($p) {
                        Write-Log "Force killing PID $pid ($($p.Name))"
                        Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
                    } else {
                        Write-Log "PID $pid no longer running"
                    }
                } catch {}
            }
            Start-Sleep -Seconds 2
        } else {
            Write-Log "handle.exe did not report any PIDs for $TargetPath (may be kernel/driver/AV lock)" "WARN"
        }
    } catch {
        Write-Log "handle.exe step failed: $($_.Exception.Message)" "WARN"
    }
} else {
    Write-Log "handle.exe not found. (Optional) Place Sysinternals handle.exe next to this script or in Launchers." "WARN"
}

# ------------------------- 5) Ownership + ACL -------------------------
try {
    Write-Log "Taking ownership..."
    cmd.exe /c "takeown /f `"$TargetPath`" /r /d y" | Out-Null

    Write-Log "Granting Administrators full control..."
    cmd.exe /c "icacls `"$TargetPath`" /grant *S-1-5-32-544:F /t /c" | Out-Null
} catch {
    Write-Log "ACL/ownership step failed: $($_.Exception.Message)" "WARN"
}

# ------------------------- 6) Delete with retries + file-by-file cleanup -------------------------
$deleted = $false
for ($i = 1; $i -le 5; $i++) {
    try {
        Write-Log "Attempt $($i): Remove-Item -Recurse -Force ..."
        Remove-Item -LiteralPath $TargetPath -Recurse -Force -ErrorAction Stop
        $deleted = $true
        break
    } catch {
        Write-Log "Attempt $($i) failed: $($_.Exception.Message)" "WARN"

        # Try to delete what we can (often clears most files)
        try {
            Get-ChildItem -LiteralPath $TargetPath -Recurse -Force -ErrorAction SilentlyContinue |
                Sort-Object FullName -Descending |
                ForEach-Object {
                    try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue } catch {}
                }
        } catch {}

        Start-Sleep -Seconds 2
    }
}

# ------------------------- 7) Robocopy purge fallback -------------------------
if (-not $deleted -and (Test-Path -LiteralPath $TargetPath)) {
    try {
        Write-Log "Fallback: robocopy mirror-purge..."
        $empty = Join-Path $env:TEMP ("empty_" + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $empty -Force | Out-Null

        cmd.exe /c "robocopy `"$empty`" `"$TargetPath`" /MIR /R:1 /W:1 /NFL /NDL /NJH /NJS" | Out-Null

        Remove-Item -LiteralPath $empty -Recurse -Force -ErrorAction SilentlyContinue

        Write-Log "Final delete attempt..."
        Remove-Item -LiteralPath $TargetPath -Recurse -Force -ErrorAction Stop
        $deleted = $true
    } catch {
        Write-Log "Robocopy fallback failed: $($_.Exception.Message)" "ERROR"
    }
}

# ------------------------- 8) If still locked: rename and schedule delete at next boot -------------------------
if (-not $deleted -and (Test-Path -LiteralPath $TargetPath)) {
    try {
        $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
        $staged = $TargetPath + "_DELETE_ME_" + $stamp

        Write-Log "Still locked. Renaming folder to stage deletion: $staged" "WARN"
        Rename-Item -LiteralPath $TargetPath -NewName (Split-Path -Leaf $staged) -ErrorAction Stop

        $runOnceKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
        $cmd = "cmd.exe /c rd /s /q `"$staged`""
        $name = "DeleteCyberCNSAgent_$stamp"

        Write-Log "Setting RunOnce cleanup: $cmd" "WARN"
        New-Item -Path $runOnceKey -Force | Out-Null
        New-ItemProperty -Path $runOnceKey -Name $name -Value $cmd -PropertyType String -Force | Out-Null

        Write-Log "STAGED: Folder renamed + RunOnce set. Reboot is recommended to finish deletion." "WARN"
        exit 2
    } catch {
        Write-Log "Stage-delete-on-reboot failed: $($_.Exception.Message)" "ERROR"
    }
}

if ($deleted -and -not (Test-Path -LiteralPath $TargetPath)) {
    Write-Log "SUCCESS: Deleted $TargetPath"
    exit 0
} else {
    Write-Log "FAILED: Still locked. If cybercns.log is locked by AV/EDR, reboot (or Safe Mode) may be required." "ERROR"
    exit 1
}
```
```powershell
# =====================================================================
# Remove-CyberCNSAgentFolder.ps1  (force unlock + delete, PS 5.1)
#
# Target: C:\Program Files (x86)\CyberCNSAgent
#
# What it does:
#   0) ALWAYS stop + HARD-delete services:
#        - CyberCNSAgent
#        - CyberCNSAgentMonitor
#      (even if the target folder does not exist)
#      Escalation: sc stop/delete -> kill PID -> delete service registry key
#      -> RunOnce forced delete if still present
#   1) Stop + delete other CyberCNS/path-referencing services (best effort)
#   2) Disable/stop scheduled tasks whose actions reference TargetPath
#   3) Kill processes running from TargetPath and named cybercns*
#   4) If handle.exe is available: find locking PIDs under TargetPath and kill them
#   5) Take ownership + grant Administrators Full Control
#   6) Delete with retries + file-by-file cleanup
#   7) Robocopy mirror-purge fallback
#   8) If still locked: rename folder and set RunOnce deletion on next boot
#
# Supports:
#   -ExportOnly  => exports JSON to C:\CS-Toolbox-TEMP\Collected-Info and exits
# =====================================================================

$TargetPath = 'C:\Program Files (x86)\CyberCNSAgent'
$ExportOnly = $false

# Allow quick "-ExportOnly" when pasted into console
if ($args -and ($args | ForEach-Object { $_.ToString().ToLowerInvariant() }) -contains '-exportonly') {
    $ExportOnly = $true
}

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$CollectedInfo = 'C:\CS-Toolbox-TEMP\Collected-Info'
$null = New-Item -ItemType Directory -Path $CollectedInfo -Force -ErrorAction SilentlyContinue
$LogPath    = Join-Path $CollectedInfo 'remove-cybercnsagent.log'
$ExportPath = Join-Path $CollectedInfo 'remove-cybercnsagent-export.json'

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$Level] $ts $Message"
    Add-Content -Path $LogPath -Value $line -Encoding UTF8
    Write-Host $line
}

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Find-HandleExe {
    $candidates = @()

    try { if ($PSScriptRoot) { $candidates += (Join-Path $PSScriptRoot 'handle.exe') } } catch {}

    $candidates += 'C:\CS-Toolbox-TEMP\prod-01-01\DOCS\ETC\handle.exe'
    $candidates += 'C:\CS-Toolbox-TEMP\Launchers\handle.exe'

    foreach ($p in $candidates) {
        if (Test-Path -LiteralPath $p) { return $p }
    }

    $cmd = Get-Command handle.exe -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { return $cmd.Source }

    return $null
}

if ($ExportOnly) {
    $payload = [ordered]@{
        Script     = 'Remove-CyberCNSAgentFolder.ps1'
        Timestamp  = (Get-Date).ToString('o')
        TargetPath = $TargetPath
        LogPath    = $LogPath
        Planned    = @(
            "ALWAYS stop + HARD-delete services: CyberCNSAgent, CyberCNSAgentMonitor (even if folder missing)",
            "Stop + delete other services named *CyberCNS* or PathName referencing TargetPath",
            "Disable/stop scheduled tasks whose actions reference TargetPath",
            "Kill processes running from TargetPath and named cybercns*",
            "If handle.exe present: identify locking PIDs under TargetPath and kill them",
            "takeown + icacls admins full control",
            "Remove-Item delete retries + file-by-file cleanup",
            "Robocopy mirror-purge fallback",
            "If still locked: rename folder and RunOnce rd /s /q on next boot"
        )
    }
    $payload | ConvertTo-Json -Depth 6 | Set-Content -Path $ExportPath -Encoding UTF8
    Write-Host "Exported: $ExportPath"
    exit 0
}

if (-not (Test-Admin)) { throw "Run this in an elevated PowerShell (Admin)." }

Write-Log "TargetPath: $TargetPath"

# ------------------------- 0) ALWAYS stop + HARD-delete these services -------------------------
# Runs regardless of whether $TargetPath exists.
$mustDeleteServices = @('CyberCNSAgent', 'CyberCNSAgentMonitor')

foreach ($svcName in $mustDeleteServices) {
    Write-Log "FORCE service removal: $svcName"

    # 1) Stop (best-effort)
    try {
        Write-Log "Stopping service: $svcName"
        sc.exe stop $svcName | Out-Null
    } catch {}

    # 2) Wait briefly for stop / disappearance
    for ($w = 1; $w -le 10; $w++) {
        Start-Sleep -Seconds 1
        $cur = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
        if (-not $cur -or $cur.State -eq 'Stopped') { break }
    }

    # 3) Kill its service process by PID (if any)
    try {
        $cur = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
        if ($cur -and $cur.ProcessId -and [int]$cur.ProcessId -gt 0) {
            Write-Log "Killing service process for $svcName (PID $($cur.ProcessId))"
            Stop-Process -Id ([int]$cur.ProcessId) -Force -ErrorAction SilentlyContinue
        }
    } catch {}

    # 4) Try normal delete a few times
    for ($i = 1; $i -le 3; $i++) {
        try {
            Write-Log "Deleting service: $svcName (attempt $($i))"
            sc.exe delete $svcName | Out-Null
        } catch {}
        Start-Sleep -Seconds 1

        $stillThere = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
        if (-not $stillThere) { break }
    }

    # 5) HARD delete: remove registry service key if still present
    $stillThere = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
    if ($stillThere) {
        Write-Log "Service still present after sc delete; HARD removing registry key..." "WARN"

        $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$svcName"
        try {
            if (Test-Path -LiteralPath $svcKey) {
                # Best-effort to ensure perms (registry icacls via reg path)
                cmd.exe /c "icacls `"HKLM\System\CurrentControlSet\Services\$svcName`" /grant Administrators:F /t /c" | Out-Null
                Remove-Item -LiteralPath $svcKey -Recurse -Force -ErrorAction Stop
                Write-Log "Deleted registry key: $svcKey"
            } else {
                Write-Log "Registry key not found: $svcKey (service may be held by SCM cache)" "WARN"
            }
        } catch {
            Write-Log "Registry key removal failed: $($_.Exception.Message)" "ERROR"
        }

        # Re-check
        Start-Sleep -Seconds 1
        $stillThere2 = Get-CimInstance Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
        if ($stillThere2) {
            # 6) Last resort: schedule forced removal at next boot/logon
            $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
            $runOnceKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
            $cmd = "cmd.exe /c sc stop `"$svcName`" & sc delete `"$svcName`" & reg delete `"HKLM\System\CurrentControlSet\Services\$svcName`" /f"
            $name = "ForceDeleteService_${svcName}_$stamp"

            Write-Log "Still present. Staging RunOnce forced removal: $name" "WARN"
            New-Item -Path $runOnceKey -Force | Out-Null
            New-ItemProperty -Path $runOnceKey -Name $name -Value $cmd -PropertyType String -Force | Out-Null

            Write-Log "Service removal staged via RunOnce (reboot recommended): $svcName" "WARN"
        } else {
            Write-Log "Service removed after registry key deletion: $svcName"
        }
    } else {
        Write-Log "Service deleted: $svcName"
    }
}
# ---------------------------------------------------------------------

# If folder doesn't exist after service cleanup, exit cleanly
if (-not (Test-Path -LiteralPath $TargetPath)) {
    Write-Log "TargetPath not found after service cleanup; nothing else to delete." "WARN"
    exit 0
}

# ------------------------- 1) Stop + DELETE other related services -------------------------
Write-Log "Stopping and deleting other CyberCNS/path services..."
try {
    $services = Get-CimInstance Win32_Service -ErrorAction Stop

    $targetServices = $services | Where-Object {
        ($_.Name -like '*CyberCNS*') -or
        ($_.DisplayName -like '*CyberCNS*') -or
        ($_.PathName -and $_.PathName -like "*$TargetPath*")
    }

    # Avoid reprocessing the mandatory ones
    $targetServices = $targetServices | Where-Object { $mustDeleteServices -notcontains $_.Name }

    foreach ($s in $targetServices) {
        Write-Log "Processing service: $($s.Name)  (State=$($s.State))"

        if ($s.State -ne 'Stopped') {
            Write-Log "Stopping service: $($s.Name)"
            sc.exe stop $s.Name | Out-Null

            for ($w = 1; $w -le 20; $w++) {
                Start-Sleep -Seconds 1
                $cur = Get-CimInstance Win32_Service -Filter "Name='$($s.Name)'" -ErrorAction SilentlyContinue
                if (-not $cur -or $cur.State -eq 'Stopped') { break }
            }
        }

        Write-Log "Deleting service: $($s.Name)"
        sc.exe delete $s.Name | Out-Null
    }

    Start-Sleep -Seconds 2
}
catch {
    Write-Log "Other service stop/delete step failed: $($_.Exception.Message)" "WARN"
}

# ------------------------- 2) Disable scheduled tasks referencing TargetPath -------------------------
try {
    Write-Log "Disabling scheduled tasks referencing target path..."
    $tasks = Get-ScheduledTask -ErrorAction SilentlyContinue
    foreach ($t in $tasks) {
        try {
            $actionsText = ($t.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' | '
            if ($actionsText -and $actionsText -like "*$TargetPath*") {
                Write-Log "Disabling task: $($t.TaskName) (Path: $($t.TaskPath))"
                Disable-ScheduledTask -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction SilentlyContinue | Out-Null
                Stop-ScheduledTask    -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction SilentlyContinue | Out-Null
            }
        } catch {}
    }
} catch {
    Write-Log "Scheduled task step failed: $($_.Exception.Message)" "WARN"
}

# ------------------------- 3) Kill processes (by path AND by name) -------------------------
try {
    Write-Log "Killing processes running from target path..."
    Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            $exe = $_.MainModule.FileName
            if ($exe -and $exe.StartsWith($TargetPath, [StringComparison]::OrdinalIgnoreCase)) {
                Write-Log "Stopping process: $($_.Name) (PID $($_.Id))"
                Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
            }
        } catch {}
    }

    Write-Log "Killing processes named cybercns* ..."
    Get-Process -Name 'cybercns*' -ErrorAction SilentlyContinue | ForEach-Object {
        Write-Log "Stopping process: $($_.Name) (PID $($_.Id))"
        Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
    }

    cmd.exe /c 'taskkill /f /im CyberCNSAgent.exe >nul 2>&1' | Out-Null
    cmd.exe /c 'taskkill /f /im CyberCNS*.exe >nul 2>&1' | Out-Null
    Start-Sleep -Seconds 2
} catch {
    Write-Log "Process kill step failed: $($_.Exception.Message)" "WARN"
}

# ------------------------- 4) handle.exe: identify lockers and kill them -------------------------
$handleExe = Find-HandleExe
if ($handleExe) {
    try {
        Write-Log "handle.exe found at: $handleExe"
        Write-Log "Searching for locking handles under target path..."

        $out = & $handleExe -accepteula -nobanner "$TargetPath" 2>$null
        $pids = New-Object System.Collections.Generic.HashSet[int]

        foreach ($line in $out) {
            if ($line -match '\spid:\s*(\d+)\s') {
                [void]$pids.Add([int]$Matches[1])
            }
        }

        if ($pids.Count -gt 0) {
            Write-Log ("Found locking PIDs: " + (($pids | Sort-Object) -join ', '))
            foreach ($pid in ($pids | Sort-Object)) {
                try {
                    $p = Get-Process -Id $pid -ErrorAction SilentlyContinue
                    if ($p) {
                        Write-Log "Force killing PID $pid ($($p.Name))"
                        Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue
                    } else {
                        Write-Log "PID $pid no longer running"
                    }
                } catch {}
            }
            Start-Sleep -Seconds 2
        } else {
            Write-Log "handle.exe did not report any PIDs for $TargetPath (may be kernel/driver/AV lock)" "WARN"
        }
    } catch {
        Write-Log "handle.exe step failed: $($_.Exception.Message)" "WARN"
    }
} else {
    Write-Log "handle.exe not found. (Optional) Place Sysinternals handle.exe next to this script or in Launchers." "WARN"
}

# ------------------------- 5) Ownership + ACL -------------------------
try {
    Write-Log "Taking ownership..."
    cmd.exe /c "takeown /f `"$TargetPath`" /r /d y" | Out-Null

    Write-Log "Granting Administrators full control..."
    cmd.exe /c "icacls `"$TargetPath`" /grant *S-1-5-32-544:F /t /c" | Out-Null
} catch {
    Write-Log "ACL/ownership step failed: $($_.Exception.Message)" "WARN"
}

# ------------------------- 6) Delete with retries + file-by-file cleanup -------------------------
$deleted = $false
for ($i = 1; $i -le 5; $i++) {
    try {
        Write-Log "Attempt $($i): Remove-Item -Recurse -Force ..."
        Remove-Item -LiteralPath $TargetPath -Recurse -Force -ErrorAction Stop
        $deleted = $true
        break
    } catch {
        Write-Log "Attempt $($i) failed: $($_.Exception.Message)" "WARN"

        # Try to delete what we can (often clears most files)
        try {
            Get-ChildItem -LiteralPath $TargetPath -Recurse -Force -ErrorAction SilentlyContinue |
                Sort-Object FullName -Descending |
                ForEach-Object {
                    try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue } catch {}
                }
        } catch {}

        Start-Sleep -Seconds 2
    }
}

# ------------------------- 7) Robocopy purge fallback -------------------------
if (-not $deleted -and (Test-Path -LiteralPath $TargetPath)) {
    try {
        Write-Log "Fallback: robocopy mirror-purge..."
        $empty = Join-Path $env:TEMP ("empty_" + [guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $empty -Force | Out-Null

        cmd.exe /c "robocopy `"$empty`" `"$TargetPath`" /MIR /R:1 /W:1 /NFL /NDL /NJH /NJS" | Out-Null

        Remove-Item -LiteralPath $empty -Recurse -Force -ErrorAction SilentlyContinue

        Write-Log "Final delete attempt..."
        Remove-Item -LiteralPath $TargetPath -Recurse -Force -ErrorAction Stop
        $deleted = $true
    } catch {
        Write-Log "Robocopy fallback failed: $($_.Exception.Message)" "ERROR"
    }
}

# ------------------------- 8) If still locked: rename and schedule delete at next boot -------------------------
if (-not $deleted -and (Test-Path -LiteralPath $TargetPath)) {
    try {
        $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
        $staged = $TargetPath + "_DELETE_ME_" + $stamp

        Write-Log "Still locked. Renaming folder to stage deletion: $staged" "WARN"
        Rename-Item -LiteralPath $TargetPath -NewName (Split-Path -Leaf $staged) -ErrorAction Stop

        $runOnceKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
        $cmd = "cmd.exe /c rd /s /q `"$staged`""
        $name = "DeleteCyberCNSAgent_$stamp"

        Write-Log "Setting RunOnce cleanup: $cmd" "WARN"
        New-Item -Path $runOnceKey -Force | Out-Null
        New-ItemProperty -Path $runOnceKey -Name $name -Value $cmd -PropertyType String -Force | Out-Null

        Write-Log "STAGED: Folder renamed + RunOnce set. Reboot is recommended to finish deletion." "WARN"
        exit 2
    } catch {
        Write-Log "Stage-delete-on-reboot failed: $($_.Exception.Message)" "ERROR"
    }
}

if ($deleted -and -not (Test-Path -LiteralPath $TargetPath)) {
    Write-Log "SUCCESS: Deleted $TargetPath"
    exit 0
} else {
    Write-Log "FAILED: Still locked. If cybercns.log is locked by AV/EDR, reboot (or Safe Mode) may be required." "ERROR"
    exit 1
}
```
