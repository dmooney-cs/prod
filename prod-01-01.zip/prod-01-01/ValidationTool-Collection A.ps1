# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool A                                      ║
# ║ Version: A.9 | App, Driver, Profile + Browser Extension + Zip + Cleanup    ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Show-ValidationMenuA {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "       Validation Tool A - App + Driver Checks"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Validate Microsoft Office Installations"
    Write-Host " [2] Audit Installed Drivers"
    Write-Host " [3] Scan Roaming Profiles for Applications"
    Write-Host " [4] Detect Browser Extensions (Chrome)"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit to Main Menu"
    Write-Host ""
}

do {
    Show-ValidationMenuA
    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        '1' {
            Show-Header "Office Installation Audit"
            $apps = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, `
                                      HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue |
                Where-Object { $_.DisplayName -match "Office|Microsoft 365|Word|Excel|Outlook" } |
                Select-Object DisplayName, DisplayVersion, Publisher, InstallDate
            Export-Data -Object $apps -BaseName "OfficeAudit"
            Write-SessionSummary "Office audit completed"
            Pause-Script
        }
        '2' {
            Show-Header "Driver Audit"
            $drivers = Get-WmiObject Win32_PnPSignedDriver | Select-Object DeviceName, DriverVersion, Manufacturer, DriverDate
            Export-Data -Object $drivers -BaseName "InstalledDrivers"
            Write-SessionSummary "Driver audit completed"
            Pause-Script
        }
        '3' {
            Show-Header "Roaming Profile Applications"
            $profiles = Get-ChildItem "C:\Users" -Directory | Where-Object { $_.Name -notin @("Default", "Public", "All Users") }
            $results = @()
            foreach ($profile in $profiles) {
                $path = Join-Path $profile.FullName "AppData\Local\Programs"
                if (Test-Path $path) {
                    $apps = Get-ChildItem $path -Directory -ErrorAction SilentlyContinue | Select-Object Name, FullName
                    foreach ($app in $apps) {
                        $results += [PSCustomObject]@{
                            Profile  = $profile.Name
                            AppName  = $app.Name
                            AppPath  = $app.FullName
                        }
                    }
                }
            }
            Export-Data -Object $results -BaseName "RoamingProfileApps"
            Write-SessionSummary "Roaming apps collected"
            Pause-Script
        }
        '4' {
            Show-Header "Browser Extension Audit"
            $output = @()
            $chrome = "$env:LOCALAPPDATA\Google\Chrome\User Data"
            if (Test-Path $chrome) {
                $profiles = Get-ChildItem $chrome -Directory | Where-Object { $_.Name -like "Default" -or $_.Name -like "Profile*" }
                foreach ($profile in $profiles) {
                    $extPath = Join-Path $profile.FullName "Extensions"
                    if (Test-Path $extPath) {
                        Get-ChildItem $extPath -Directory | ForEach-Object {
                            $output += [PSCustomObject]@{
                                Browser     = "Chrome"
                                Profile     = $profile.Name
                                ExtensionID = $_.Name
                            }
                        }
                    }
                }
            }
            Export-Data -Object $output -BaseName "BrowserExtensions"
            Write-SessionSummary "Browser extensions scanned"
            Pause-Script
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
