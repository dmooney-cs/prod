# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool A                                      ║
# ║ Version: A.4 | Office, Drivers, Roaming, Extensions                         ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ══════════════════════════════════════════════════════════════════════════════

function Run-OfficeValidation {
    Show-Header "Office Installation Audit"
    $apps = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, `
                              HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -match "Office|Microsoft 365|Word|Excel|Outlook" } |
            Select-Object DisplayName, DisplayVersion, Publisher, InstallDate
    Export-Data -Object $apps -BaseName "OfficeAudit"
    Pause-Script
}

function Run-DriverAudit {
    Show-Header "Installed Drivers Audit"
    $drivers = Get-WmiObject Win32_PnPSignedDriver |
        Select-Object DeviceName, DriverVersion, DriverDate, Manufacturer
    Export-Data -Object $drivers -BaseName "DriverAudit"
    Pause-Script
}

function Run-RoamingAudit {
    Show-Header "Roaming Profile Application Scan"
    $userProfiles = Get-ChildItem "$env:SystemDrive\Users" -Directory |
                    Where-Object { Test-Path "$($_.FullName)\AppData\Roaming" }

    $results = foreach ($profile in $userProfiles) {
        $roamingPath = "$($profile.FullName)\AppData\Roaming"
        if (Test-Path $roamingPath) {
            Get-ChildItem -Path $roamingPath -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                [PSCustomObject]@{
                    User      = $profile.Name
                    AppFolder = $_.Name
                    Path      = $_.FullName
                }
            }
        }
    }

    Export-Data -Object $results -BaseName "RoamingProfiles"
    Pause-Script
}

function Run-BrowserExtensionAudit {
    Show-Header "Browser Extension Detection"
    $extensions = @()

    # Chrome
    $chromePath = "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Extensions"
    if (Test-Path $chromePath) {
        Get-ChildItem -Path $chromePath -Directory | ForEach-Object {
            $extensions += [PSCustomObject]@{
                Browser = "Chrome"
                ID      = $_.Name
                Path    = $_.FullName
            }
        }
    }

    # Edge
    $edgePath = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Extensions"
    if (Test-Path $edgePath) {
        Get-ChildItem -Path $edgePath -Directory | ForEach-Object {
            $extensions += [PSCustomObject]@{
                Browser = "Edge"
                ID      = $_.Name
                Path    = $_.FullName
            }
        }
    }

    # Firefox
    $firefoxProfiles = Get-ChildItem "$env:APPDATA\Mozilla\Firefox\Profiles" -Directory -ErrorAction SilentlyContinue
    foreach ($profile in $firefoxProfiles) {
        $extJson = Join-Path $profile.FullName "extensions.json"
        if (Test-Path $extJson) {
            $json = Get-Content $extJson -Raw | ConvertFrom-Json
            foreach ($ext in $json.addons) {
                $extensions += [PSCustomObject]@{
                    Browser = "Firefox"
                    ID      = $ext.id
                    Path    = $ext.location
                }
            }
        }
    }

    Export-Data -Object $extensions -BaseName "BrowserExtensions"
    Pause-Script
}

# ══════════════════════════════════════════════════════════════════════════════

function Show-ValidationMenuA {
    do {
        Show-Header "Validation Tool A - App + Driver Checks"

        Write-Host " [1] Validate Microsoft Office Installations"
        Write-Host " [2] Audit Installed Drivers"
        Write-Host " [3] Scan Roaming Profiles for Applications"
        Write-Host " [4] Detect Browser Extensions (Chrome, Edge, Firefox)"
        Write-Host ""
        Write-Host " [R] Run All Checks Above"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice.ToUpper()) {
            "1" { Run-OfficeValidation }
            "2" { Run-DriverAudit }
            "3" { Run-RoamingAudit }
            "4" { Run-BrowserExtensionAudit }
            "R" {
                Run-OfficeValidation
                Run-DriverAudit
                Run-RoamingAudit
                Run-BrowserExtensionAudit
            }
            "Q" { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

Show-ValidationMenuA
