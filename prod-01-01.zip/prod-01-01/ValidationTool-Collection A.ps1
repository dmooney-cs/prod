# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ===========================================
#  Validation Tool - Collection B+C (No OSQ/Nmap)
#  Modules:
#    1) Windows Patch Audit (WMI)
#    2) VC++ Runtime Validation (Run-VcppValidation from Common)
#    3) TLS/SSL Policy Audit (Local Host)
# ===========================================

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ExportRoot = "C:\CS-Toolbox-TEMP\Collected-Info"

function Show-BCMenu {
    Clear-Host
    Show-Header "Validation Tool - Collection B+C"

    Write-Host ""
    Write-Host " [1] Windows Patch Audit (WMI)           - Installed updates via Win32_QuickFixEngineering"
    Write-Host " [2] VC++ Runtime Validation             - Detect Visual C++ redistributables (CSV report)"
    Write-Host " [3] TLS/SSL Policy Audit (Local Host)   - SCHANNEL protocols, cipher order, .NET strong crypto"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results               - Compress results for support"
    Write-Host " [C] Cleanup Toolbox Data                - Remove temp/output and self-clean"
    Write-Host " [Q] Quit to Main Menu"
    Write-Host ""
}

function Run-WmiPatchAudit {
    try {
        Write-Host "Collecting installed update list (WMI / Get-HotFix)..." -ForegroundColor Cyan
        $ts = Get-Date -Format "yyyyMMdd_HHmmss"
        $host = $env:COMPUTERNAME
        $csv = Join-Path $ExportRoot ("PatchAudit-WMI-{0}-{1}.csv" -f $host, $ts)

        $items = @()

        # Prefer Get-HotFix; supplement with WMI if needed
        try {
            $ghf = Get-HotFix -ErrorAction Stop | Sort-Object InstalledOn
            foreach ($h in $ghf) {
                $items += [pscustomobject]@{
                    Source       = "Get-HotFix"
                    ComputerName = $h.ComputerName
                    HotFixID     = $h.HotFixID
                    Description  = $h.Description
                    InstalledOn  = $h.InstalledOn
                }
            }
        } catch {
            Write-Host "Get-HotFix failed, falling back to WMI only." -ForegroundColor Yellow
        }

        try {
            $wmi = Get-WmiObject -Class Win32_QuickFixEngineering -ErrorAction Stop
            foreach ($w in $wmi) {
                $date = $null
                if ($w.InstalledOn) {
                    # Some locales use different date formats; best-effort parse
                    try { $date = [datetime]::Parse($w.InstalledOn) } catch { $date = $w.InstalledOn }
                }
                $items += [pscustomobject]@{
                    Source       = "WMI"
                    ComputerName = $w.CSName
                    HotFixID     = $w.HotFixID
                    Description  = $w.Description
                    InstalledOn  = $date
                }
            }
        } catch {
            Write-Host "WMI Win32_QuickFixEngineering query failed: $($_.Exception.Message)" -ForegroundColor Yellow
        }

        if ($items.Count -eq 0) {
            Write-Host "No updates found by Get-HotFix or WMI." -ForegroundColor Yellow
        } else {
            $items | Sort-Object InstalledOn | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csv
            Write-Host "✅ Saved patch audit to $csv" -ForegroundColor Green

            # Summary
            $count = $items.Count
            $latest = ($items | Where-Object { $_.InstalledOn } | Sort-Object InstalledOn -Descending | Select-Object -First 1).InstalledOn
            Write-Host ("Summary: {0} updates found. Latest InstalledOn: {1}" -f $count, (if ($latest) { $latest } else { "N/A" })) -ForegroundColor Cyan
        }
    } catch {
        Write-Host "❌ Patch audit failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

function Get-RegDWORD {
    param([string]$Path, [string]$Name)
    try {
        $v = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop | Select-Object -ExpandProperty $Name
        return [int]$v
    } catch { return $null }
}

function Get-RegString {
    param([string]$Path, [string]$Name)
    try {
        $v = Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop | Select-Object -ExpandProperty $Name
        return [string]$v
    } catch { return $null }
}

function Read-SChannelProtocolState {
    # Returns objects describing protocol enable/disable per SCHANNEL registry
    $base = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols"
    $protos = @("SSL 2.0","SSL 3.0","TLS 1.0","TLS 1.1","TLS 1.2","TLS 1.3")
    $rows = @()

    foreach ($p in $protos) {
        $clientKey = Join-Path $base ($p + "\Client")
        $serverKey = Join-Path $base ($p + "\Server")

        $cEnabled    = Get-RegDWORD -Path $clientKey -Name "Enabled"
        $cDisabled   = Get-RegDWORD -Path $clientKey -Name "DisabledByDefault"
        $sEnabled    = Get-RegDWORD -Path $serverKey -Name "Enabled"
        $sDisabled   = Get-RegDWORD -Path $serverKey -Name "DisabledByDefault"

        # Interpret: if values missing, Windows may use defaults (often enabled for modern TLS).
        $clientState = if ($cEnabled -eq 1 -and $cDisabled -ne 1) { "Enabled" } elseif ($cEnabled -eq 0 -or $cDisabled -eq 1) { "Disabled" } else { "Default/Unknown" }
        $serverState = if ($sEnabled -eq 1 -and $sDisabled -ne 1) { "Enabled" } elseif ($sEnabled -eq 0 -or $sDisabled -eq 1) { "Disabled" } else { "Default/Unknown" }

        $rows += [pscustomobject]@{
            Protocol     = $p
            ClientState  = $clientState
            ServerState  = $serverState
            ClientEnabledValue  = $cEnabled
            ClientDisabledByDefault = $cDisabled
            ServerEnabledValue  = $sEnabled
            ServerDisabledByDefault = $sDisabled
        }
    }

    return $rows
}

function Read-CipherSuitePolicy {
    # Best-effort: new Windows versions expose Get-TlsCipherSuite; else read policy registry
    $ts = Get-Date -Format "yyyyMMdd_HHmmss"
    $host = $env:COMPUTERNAME
    $outCsv = Join-Path $ExportRoot ("TLS-CipherSuites-{0}-{1}.csv" -f $host, $ts)

    $rows = @()

    if (Get-Command Get-TlsCipherSuite -ErrorAction SilentlyContinue) {
        try {
            $c = Get-TlsCipherSuite | Select-Object Name, Cipher, Hash, KeyExchange, ExchangeAlgorithm, Protocols
            foreach ($x in $c) {
                $rows += [pscustomobject]@{
                    Name       = $x.Name
                    Cipher     = $x.Cipher
                    Hash       = $x.Hash
                    KeyExchange= $x.KeyExchange
                    Algorithm  = $x.ExchangeAlgorithm
                    Protocols  = ($x.Protocols -join ',')
                    Source     = "Get-TlsCipherSuite"
                }
            }
        } catch {
            Write-Host "Get-TlsCipherSuite failed: $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }

    # Policy order (if configured)
    $policyKey = "HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002"
    $order = Get-RegString -Path $policyKey -Name "Functions"
    if ($order) {
        $names = $order.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        $pos = 0
        foreach ($n in $names) {
            $pos++
            $rows += [pscustomobject]@{
                Name       = $n
                Cipher     = $null
                Hash       = $null
                KeyExchange= $null
                Algorithm  = $null
                Protocols  = $null
                Source     = "PolicyOrder($pos)"
            }
        }
    }

    if ($rows.Count -gt 0) {
        $rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outCsv
        Write-Host "✅ Saved cipher suite details to $outCsv" -ForegroundColor Green
    } else {
        Write-Host "No cipher suite info available from cmdlets or policy." -ForegroundColor Yellow
    }
}

function Read-DotNetStrongCrypto {
    $paths = @(
        "HKLM:\SOFTWARE\Microsoft\.NETFramework\v2.0.50727",
        "HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319",
        "HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v2.0.50727",
        "HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework\v4.0.30319"
    )
    $rows = @()
    foreach ($p in $paths) {
        $sc = Get-RegDWORD -Path $p -Name "SchUseStrongCrypto"
        $rows += [pscustomobject]@{
            Path              = $p
            SchUseStrongCrypto= $sc
            Effective         = if ($sc -eq 1) { "Enabled" } elseif ($sc -eq 0) { "Disabled" } else { "Default/Unknown" }
        }
    }
    return $rows
}

function Run-TlsPolicyAudit {
    try {
        Write-Host "Auditing SCHANNEL TLS/SSL protocol state..." -ForegroundColor Cyan
        $ts = Get-Date -Format "yyyyMMdd_HHmmss"
        $host = $env:COMPUTERNAME
        $protCsv = Join-Path $ExportRoot ("TLS-Protocols-{0}-{1}.csv" -f $host, $ts)
        $dotCsv  = Join-Path $ExportRoot ("DotNet-StrongCrypto-{0}-{1}.csv" -f $host, $ts)

        $prot = Read-SChannelProtocolState
        $prot | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $protCsv
        Write-Host "✅ Saved SCHANNEL protocol state to $protCsv" -ForegroundColor Green

        Write-Host "Collecting cipher suite info..." -ForegroundColor Cyan
        Read-CipherSuitePolicy

        Write-Host ".NET strong crypto flags..." -ForegroundColor Cyan
        $dot = Read-DotNetStrongCrypto
        $dot | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $dotCsv
        Write-Host "✅ Saved .NET strong crypto report to $dotCsv" -ForegroundColor Green

        # Quick on-screen summary
        $tls10 = ($prot | Where-Object Protocol -eq 'TLS 1.0')
        $tls11 = ($prot | Where-Object Protocol -eq 'TLS 1.1')
        $tls12 = ($prot | Where-Object Protocol -eq 'TLS 1.2')
        $tls13 = ($prot | Where-Object Protocol -eq 'TLS 1.3')

        Write-Host ""
        Write-Host "Summary:" -ForegroundColor Cyan
        Write-Host ("  TLS 1.0 -> Client:{0}  Server:{1}" -f $tls10.ClientState, $tls10.ServerState)
        Write-Host ("  TLS 1.1 -> Client:{0}  Server:{1}" -f $tls11.ClientState, $tls11.ServerState)
        Write-Host ("  TLS 1.2 -> Client:{0}  Server:{1}" -f $tls12.ClientState, $tls12.ServerState)
        Write-Host ("  TLS 1.3 -> Client:{0}  Server:{1}" -f $tls13.ClientState, $tls13.ServerState)
    } catch {
        Write-Host "❌ TLS/SSL audit failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

function Run-VCpp {
    try {
        Write-Host "Running VC++ Runtime Validation..." -ForegroundColor Cyan
        Run-VcppValidation
    } catch {
        Write-Host "❌ VC++ validation failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

# ======== Main Loop ========
while ($true) {
    Show-BCMenu
    $choice = (Read-Host "Enter your choice").Trim().ToUpperInvariant()

    switch ($choice) {
        '1' { Run-WmiPatchAudit }
        '2' { Run-VCpp }
        '3' { Run-TlsPolicyAudit }

        'Z' {
            try {
                Zip-Results
                Pause-Script "Zip complete. Press any key to return..."
            } catch {
                Write-Host "ERROR zipping results: $($_.Exception.Message)" -ForegroundColor Red
                Pause-Script
            }
        }
        'C' {
            try {
                Invoke-FinalCleanupAndExit
            } catch {
                Write-Host "ERROR during cleanup: $($_.Exception.Message)" -ForegroundColor Red
                Pause-Script
            }
        }
        'Q' {
            try { Launch-Tool "CS-Toolbox-Launcher.ps1" } catch { Write-Host "⚠ Could not relaunch main menu: $($_.Exception.Message)" -ForegroundColor Yellow }
            break
        }
        Default {
            Write-Host "Unknown choice. Please try again." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
        }
    }
}
