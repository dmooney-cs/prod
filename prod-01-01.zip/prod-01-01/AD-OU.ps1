#requires -version 5.1

[CmdletBinding()]
param(
    [string]$OutPath = $null,
    [switch]$Quiet,
    [switch]$ExportOnly
)

# If -ExportOnly is supplied, force quiet output (still writes JSON).
if ($ExportOnly) { $Quiet = $true }

# Reduce non-essential console output when quiet
if ($Quiet) {
    $WarningPreference     = 'SilentlyContinue'
    $InformationPreference = 'SilentlyContinue'
}


# ---- Standard output directory bootstrap----
$CS_OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AD'
New-Item -Path $CS_OutRoot -ItemType Directory -Force -ErrorAction Stop | Out-Null

if ([string]::IsNullOrWhiteSpace($OutPath)) {
    $OutPath = Join-Path $CS_OutRoot 'AD-OU_data.json'
}

# Ensure the parent folder of the final path exists (covers custom -OutPath values too)
$__parent = Split-Path -Parent $OutPath
if ($__parent) { New-Item -Path $__parent -ItemType Directory -Force -ErrorAction Stop | Out-Null }
# ---- end standard block ----

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

function Write-ResultJson {
    param([hashtable]$Payload, [string]$Path)

    $dir = Split-Path -Path $Path -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

    $Payload | ConvertTo-Json -Depth 10 -Compress |
        Out-File -FilePath $Path -Encoding UTF8

    try { $resolved = (Resolve-Path -Path $Path).Path } catch { $resolved = $Path }
    if (-not $Quiet) { Write-Host "" }
    if (-not $Quiet) { Write-Host "JSON saved to: $resolved" -ForegroundColor Cyan }
}

function Safe-ToString($value) {
    if ($null -eq $value) { return "" }
    return $value
}

try {
    # Modules needed
    try { Import-Module ActiveDirectory -ErrorAction Stop } catch { throw "ActiveDirectory module not found. Install RSAT/AD tools." }
    $gpAvailable = $true
    try { Import-Module GroupPolicy -ErrorAction Stop } catch { $gpAvailable = $false }

    # Context for header
    $domain = (Get-ADDomain).DNSRoot
    $forest = (Get-ADForest).Name

    $properties = @('Name','ManagedBy','Created','Modified','DistinguishedName','ObjectGUID')

    $ouList = foreach ($ou in Get-ADOrganizationalUnit -Filter '*' -Properties $properties) {
        if ($null -eq $ou) { continue }
        if ($ou.DistinguishedName -notlike '*OU=*') { continue }

        # Determine emptiness (no immediate children)
        $isEmpty = $false
        try {
            $children = Get-ADObject -SearchBase $ou.DistinguishedName -SearchScope OneLevel -Filter *
            if (-not $children) { $isEmpty = $true }
        } catch { $isEmpty = $true }

        # Gather linked GPOs (if GroupPolicy module available)
        $linkedGPO = @()
        if ($gpAvailable) {
            try {
                $inherit = Get-GPInheritance -Target $ou.DistinguishedName -ErrorAction Stop
                if ($inherit -and $inherit.GpoLinks) {
                    foreach ($lg in $inherit.GpoLinks) {
                        $linkedGPO += [pscustomobject]@{
                            name     = $lg.DisplayName
                            enabled  = [bool]$lg.Enabled
                            enforced = [bool]$lg.Enforced
                        }
                    }
                }
            } catch { }
        }

        $linkedNames = if ($linkedGPO.Count -gt 0) { ($linkedGPO | ForEach-Object name) -join '; ' } else { '' }

        [pscustomobject][ordered]@{
            domain             = $domain
            ouName             = $ou.Name
            managedBy          = Safe-ToString $ou.ManagedBy
            ouCreated          = ($ou.Created).ToString('dd-MM-yyyy HH:mm:ss')
            ouModified         = ($ou.Modified).ToString('dd-MM-yyyy HH:mm:ss')
            distinguishedName  = $ou.DistinguishedName
            guid               = $ou.ObjectGUID
            empty              = $isEmpty
            linkedGpoCount     = $linkedGPO.Count
            linkedGpoNames     = $linkedNames
            linkedGPO          = $linkedGPO  # full detail in JSON
        }
    }

    $count = ($ouList | Measure-Object).Count

    # On-screen summary + readable table
    if (-not $Quiet) { Write-Host "" }
    if (-not $Quiet) { Write-Host ("Discovered {0} OU(s)  |  Domain: {1}  |  Forest: {2}  |  GP Links: {3}" -f $count, $domain, $forest, ($(if($gpAvailable){'enabled'}else{'unavailable'}))) -ForegroundColor Green }

    if (-not $Quiet) {
        $ouList |
        Select-Object ouName, empty, managedBy, linkedGpoCount, linkedGpoNames, ouCreated, ouModified, distinguishedName |
        Sort-Object ouName |
        Format-Table -Wrap -AutoSize
    }

    # Persist and echo path
    $payloadOk = @{
        status = $true
        domain = $domain
        forest = $forest
        count  = $count
        data   = $ouList
    }
    Write-ResultJson -Payload $payloadOk -Path $OutPath
}
catch {
    $err = $_
    if (-not $Quiet) { Write-Warning $err.Exception.Message }

    $payloadFail = @{
        status     = $false
        msg        = $err.Exception.Message
        stackTrace = ($err | Out-String)
    }

    try {
        Write-ResultJson -Payload $payloadFail -Path $OutPath
    } catch {
        if (-not $Quiet) { Write-Host "" }
        if (-not $Quiet) { Write-Host "Failed to write JSON to: $OutPath" -ForegroundColor Red }
        if (-not $Quiet) { Write-Host ($payloadFail | ConvertTo-Json -Depth 5) -ForegroundColor Yellow }
    }
}