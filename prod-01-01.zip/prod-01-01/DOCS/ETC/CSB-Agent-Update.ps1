﻿#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent,
    [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# -----------------------------
# Config
# -----------------------------
$script:CollectedInfoRoot   = 'C:\CS-Toolbox-TEMP\Collected-Info'
$script:EulaStatePath       = Join-Path $script:CollectedInfoRoot 'EulaAcceptedAt.txt'
$script:EulaSourceUrl       = 'https://connectsecure.com/eula'
$script:EulaPromptWindowMin = 15

$script:ToolboxBase   = 'C:\CS-Toolbox-TEMP\prod-01-01'
$script:DevToolsDlUrl = 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1'

# Internal flag (do not document) so we can re-launch elevated/hidden without looping
$IsInner = ($env:CS_TOOLBOX_SILENT_INNER -eq '1')

# -----------------------------
# Helpers
# -----------------------------
function Ensure-Folder {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Start-ElevatedInstance {
    param([switch]$Hidden)

    $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$PSCommandPath`"")
    if ($Silent)     { $args += '-Silent' }
    if ($ExportOnly) { $args += '-ExportOnly' }

    Start-Process powershell.exe `
        -Verb RunAs `
        -WindowStyle ($(if ($Hidden) { 'Hidden' } else { 'Normal' })) `
        -ArgumentList ($args -join ' ') | Out-Null
}

function Show-StatusHeader {
    Clear-Host
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " ConnectSecure Toolbox - Operation Running (Admin Required)  " -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "This script is running. This window will auto-close shortly." -ForegroundColor Yellow
    Write-Host ""
}

function Show-Footer {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " Operation finished (some steps may have failed).            " -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "Closing in 30 seconds..." -ForegroundColor Yellow
    Start-Sleep 30
}

# -----------------------------
# EULA (only when NOT -Silent)
# -----------------------------
function Save-EulaAcceptedAt {
    try {
        Ensure-Folder -Path $script:CollectedInfoRoot
        Set-Content -Path $script:EulaStatePath -Value (Get-Date).ToString('o') -Encoding UTF8 -Force
    } catch { }
}

function Test-EulaStillValid {
    try {
        if (-not (Test-Path $script:EulaStatePath)) { return $false }
        $raw = (Get-Content -Path $script:EulaStatePath -Encoding UTF8 -ErrorAction Stop | Select-Object -First 1).Trim()
        if (-not $raw) { return $false }
        $dt = [datetime]::Parse($raw)
        ((New-TimeSpan -Start $dt -End (Get-Date)).TotalMinutes -lt [double]$script:EulaPromptWindowMin)
    } catch { return $false }
}

function Ensure-EulaGate {
    if (Test-EulaStillValid) { return }

    Clear-Host
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " End User License Agreement (EULA) - Required                " -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Please review the EULA at:" -ForegroundColor Yellow
    Write-Host "  $script:EulaSourceUrl" -ForegroundColor Yellow
    Write-Host ""

    while ($true) {
        Write-Host "Y) Agree and proceed" -ForegroundColor White
        Write-Host "N) Decline and cleanup/self-destruct" -ForegroundColor White
        $r = (Read-Host "Selection (Y/N)").Trim().ToUpperInvariant()
        if ($r -eq 'Y') { Save-EulaAcceptedAt; return }
        if ($r -eq 'N') {
            try {
                $sd = Join-Path $script:ToolboxBase 'Toolbox-Cleanup-SelfDestruct.ps1'
                if (Test-Path $sd) { & $sd -Silent }
            } catch { }
            exit 1
        }
        Write-Host "[WARN] Invalid selection. Please enter Y or N." -ForegroundColor Yellow
    }
}

# -----------------------------
# Step runner (continue on failure)
# -----------------------------
function Invoke-Step {
    param(
        [Parameter(Mandatory)][int]$Num,
        [Parameter(Mandatory)][int]$Total,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][scriptblock]$Action
    )

    try {
        if (-not $Silent) {
            Write-Host ("[Step {0}/{1}] {2}" -f $Num, $Total, $Name) -ForegroundColor Cyan
        }

        $global:LASTEXITCODE = 0
        & $Action

        if ($LASTEXITCODE -ne 0) { throw ("Exit code {0}" -f $LASTEXITCODE) }

        if (-not $Silent) {
            Write-Host ("[ OK ] {0}" -f $Name) -ForegroundColor Green
            Write-Host ""
        }
    }
    catch {
        if (-not $Silent) {
            Write-Host ("[FAIL] {0} - {1}" -f $Name, $_.Exception.Message) -ForegroundColor Red
            Write-Host ""
        }
        # Silent mode: swallow and continue
    }
}

# -----------------------------
# Elevation
# -----------------------------
$isAdmin = ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    if ($Silent) {
        $env:CS_TOOLBOX_SILENT_INNER = '1'
        Start-ElevatedInstance -Hidden
    } else {
        Start-ElevatedInstance
    }
    exit
}

# If already admin AND -Silent requested, spawn hidden worker and exit visible instance
if ($Silent -and -not $IsInner) {
    $env:CS_TOOLBOX_SILENT_INNER = '1'

    $argList = @(
        '-NoProfile',
        '-ExecutionPolicy','Bypass',
        '-File', "`"$PSCommandPath`"",
        '-Silent'
    )
    if ($ExportOnly) { $argList += '-ExportOnly' }

    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList $argList | Out-Null
    exit
}

# -----------------------------
# Run
# -----------------------------
Ensure-Folder -Path $script:CollectedInfoRoot

$ts = Get-Date -Format 'yyyyMMdd_HHmmss'
$logPath = Join-Path $script:CollectedInfoRoot ("CSB-Agent-Update_{0}.log" -f $ts)

try {
    Set-ExecutionPolicy -Scope Process Bypass -Force
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    if ($Silent) {
        Start-Transcript -Path $logPath -Append | Out-Null
        $ProgressPreference = 'SilentlyContinue'
    } else {
        if (-not $ExportOnly) { Ensure-EulaGate }
        Show-StatusHeader
    }

    $totalSteps = 4

    Invoke-Step 1 $totalSteps "Stage Toolbox (skip if already present)" {
        $toolOk = (Test-Path $script:ToolboxBase) -and (Test-Path (Join-Path $script:ToolboxBase 'Agent-Update-Tool.ps1'))
        if ($toolOk) { return }

        $tmp = Join-Path $env:TEMP ("CS-Toolbox-Launcher-DevTools-DL_{0}.ps1" -f (Get-Random))
        try {
            Invoke-WebRequest -Uri $script:DevToolsDlUrl -UseBasicParsing -ErrorAction Stop | Select-Object -ExpandProperty Content |
                Set-Content -Path $tmp -Encoding UTF8 -Force

            & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $tmp | Out-Null
        } finally {
            Remove-Item -Path $tmp -Force -ErrorAction SilentlyContinue
        }

        if (-not (Test-Path $script:ToolboxBase)) { throw "Toolbox folder not found after staging: $script:ToolboxBase" }
        if (-not (Test-Path (Join-Path $script:ToolboxBase 'Agent-Update-Tool.ps1'))) {
            throw "Agent-Update-Tool.ps1 not found after staging in: $script:ToolboxBase"
        }
    }

    Invoke-Step 2 $totalSteps "Unblock toolbox scripts" {
        if (-not (Test-Path $script:ToolboxBase)) { throw "Toolbox folder not found: $script:ToolboxBase" }
        Get-ChildItem $script:ToolboxBase -Recurse -Filter *.ps1 -File | Unblock-File
    }

    Invoke-Step 3 $totalSteps "Agent Update Tool (Quiet)" {
        Set-Location $script:ToolboxBase
        if (Test-Path (Join-Path $script:ToolboxBase 'Agent-Update-Tool.ps1')) {
            & .\Agent-Update-Tool.ps1 -Quiet | Out-Null
        } else {
            throw "Agent-Update-Tool.ps1 not found in $script:ToolboxBase"
        }
    }

    Invoke-Step 4 $totalSteps "Cleanup / Self-destruct (Silent)" {
        Set-Location $script:ToolboxBase
        if (Test-Path (Join-Path $script:ToolboxBase 'Toolbox-Cleanup-SelfDestruct.ps1')) {
            & .\Toolbox-Cleanup-SelfDestruct.ps1 -Silent | Out-Null
        } else {
            throw "Toolbox-Cleanup-SelfDestruct.ps1 not found in $script:ToolboxBase"
        }
    }
}
catch {
    if (-not $Silent) {
        Write-Host ""
        Write-Host "[ERROR] Wrapper-level error:" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    } else {
        ("WRAPPER ERROR: {0}" -f $_.Exception.Message) | Out-File -FilePath $logPath -Append -Encoding UTF8
    }
}
finally {
    # ALWAYS cleanup/self-destruct no matter what happened
    try {
        if (Test-Path $script:ToolboxBase) { Set-Location $script:ToolboxBase }
        $cleanup = Join-Path $script:ToolboxBase 'Toolbox-Cleanup-SelfDestruct.ps1'
        if (Test-Path $cleanup) { & $cleanup -Silent | Out-Null }
    } catch { }

    if ($Silent) {
        try { Stop-Transcript | Out-Null } catch { }
        exit
    } else {
        Show-Footer
    }
}
