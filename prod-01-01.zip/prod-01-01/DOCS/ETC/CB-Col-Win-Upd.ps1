﻿Set-ExecutionPolicy -Scope Process Bypass -Force; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; irm 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1' | iex
Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File
cd C:\CS-Toolbox-TEMP\prod-01-01
.\Windows-Update-Details.ps1 -Exportonly
.\OSQuery-WMIC-Patch.ps1 -Exportonly
.\Agent-Log-Review.ps1 -LogPath "$Path"
.\Agent-msg-Correlator.ps1 -LogPath "$Path" -Exportonly 
.\Agent-Job-Review.ps1 -LogPath "$Path" -AllLogs -Silent
.\Agent-Update-Tool.ps1 -quiet
.\zip-encrypt-htmltemplate.ps1 -s -c CompanyName -t TicketNumber
.\Toolbox-Cleanup-SelfDestruct.ps1 -Silent