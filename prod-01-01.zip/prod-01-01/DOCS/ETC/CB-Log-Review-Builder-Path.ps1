﻿# NOTE- Script could take between 5sec-several minutes to run. Patience.
# NOTE- Files created @ C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs
$Path = "C:\Users\dmoon\OneDrive - ConnectSecure\Toolbackup\logs-nov-collection\178278\GH0326L2419087"
cd C:\CS-Toolbox-TEMP\prod-01-01
Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File
Set-ExecutionPolicy -Scope Process Bypass -Force
.\Agent-Log-Review.ps1 -LogPath "$Path"
.\Agent-msg-Correlator.ps1 -LogPath "$Path" -Exportonly 
.\Agent-Job-Review.ps1 -LogPath "$Path" -AllLogs -Silent