﻿$App = "APP-NAME"
cd C:\CS-Toolbox-TEMP\prod-01-01
Set-ExecutionPolicy -Scope Process Bypass -Force
.\Registry-Search.ps1 -App $App -NoMenu
.\Osquery-Data-Collection.ps1 -App “$App” -ExportOnly
.\Windows-Modern-App-Discovery.ps1 -App "$App"
.\Browser-Extensions-Details.ps1 -App "$App" -Exportonly