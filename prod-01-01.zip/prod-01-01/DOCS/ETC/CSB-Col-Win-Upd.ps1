﻿#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# =====================================================================
# REPLACE THESE VALUES
# =====================================================================
$CompanyName  = 'changeme'
$TicketNumber = 'changeme'
# =====================================================================

# -----------------------------
# Config
# -----------------------------
$script:CollectedInfoRoot   = 'C:\CS-Toolbox-TEMP\Collected-Info'
$script:EulaStatePath       = Join-Path $script:CollectedInfoRoot 'EulaAcceptedAt.txt'  # ISO 8601 "o"
$script:EulaSourceUrl       = 'https://connectsecure.com/eula'
$script:EulaPromptWindowMin = 15

$script:ToolboxBase         = 'C:\CS-Toolbox-TEMP\prod-01-01'
$script:DevToolsDlUrl       = 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1'

# Internal flag (do not document) so we can re-launch elevated/hidden without looping
$IsInner = ($env:CS_TOOLBOX_SILENT_INNER -eq '1')

function Ensure-Folder {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Start-ElevatedInstance {
    param([switch]$Hidden)

    $args = @(
        '-NoProfile'
        '-ExecutionPolicy', 'Bypass'
        '-File', "`"$PSCommandPath`""
    )
    if ($Silent) { $args += '-Silent' }

    $psi = @{
        FilePath     = 'powershell.exe'
        ArgumentList = ($args -join ' ')
        Verb         = 'RunAs'
        WindowStyle  = ($(if ($Hidden) { 'Hidden' } else { 'Normal' }))
    }

    # NOTE: UAC prompt may still appear depending on policy; cannot be bypassed reliably.
    Start-Process @psi | Out-Null
}

function Show-StatusHeader {
    Clear-Host
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " ConnectSecure Toolbox - Operation Running (Admin Required)  " -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "This script is running. This window will auto-close in under 5 minutes." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "After it completes, check this folder for .csb files:" -ForegroundColor White
    Write-Host "  C:\CS-Toolbox-TEMP\ZIP" -ForegroundColor Green
    Write-Host ""
    Write-Host "For support-related issues, send any .csb files to support@connectsecure.com or attach them to the existing support request." -ForegroundColor White
    Write-Host ""
    Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray
    Write-Host ""
}

function Show-Footer {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " Operation finished (some steps may have failed).            " -ForegroundColor Cyan
    Write-Host " Check: C:\CS-Toolbox-TEMP\ZIP for .csb files.               " -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "If tied to a support request, email any .csb files to Support." -ForegroundColor White
    Write-Host "Closing in 30 seconds..." -ForegroundColor Yellow
    Start-Sleep -Seconds 30
}

# -----------------------------
# EULA helpers (immediate Y option + M paging)
# -----------------------------
function Save-EulaAcceptedAt([datetime]$dt) {
    try {
        Ensure-Folder -Path $script:CollectedInfoRoot
        Set-Content -LiteralPath $script:EulaStatePath -Value $dt.ToString('o') -Encoding UTF8 -Force
    } catch { }
}

function Load-EulaAcceptedAt {
    try {
        if (-not (Test-Path $script:EulaStatePath)) { return $null }
        $raw = (Get-Content -LiteralPath $script:EulaStatePath -Encoding UTF8 -ErrorAction Stop | Select-Object -First 1).Trim()
        if (-not $raw) { return $null }
        return [datetime]::Parse($raw)
    } catch { return $null }
}

function Test-EulaStillValid {
    $dt = Load-EulaAcceptedAt
    if (-not $dt) { return $false }
    $ageMin = (New-TimeSpan -Start $dt -End (Get-Date)).TotalMinutes
    return ($ageMin -lt [double]$script:EulaPromptWindowMin)
}

function Get-EulaFromWeb {
    $result = [ordered]@{
        FetchOk        = $false
        SourceUrl      = $script:EulaSourceUrl
        FetchError     = $null
        SourcedAtLocal = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        LastUpdated    = $null
        Paras          = New-Object System.Collections.Generic.List[string]
    }

    try {
        $resp = Invoke-WebRequest -Uri $script:EulaSourceUrl -UseBasicParsing -TimeoutSec 12 -ErrorAction Stop
        $html = $resp.Content
        if (-not $html) { throw "Empty response content." }

        $mUpd = [regex]::Match($html, '(?i)last\s+updated[^<]{0,80}')
        if ($mUpd.Success) { $result.LastUpdated = ($mUpd.Value -replace '\s+', ' ').Trim() }

        $pMatches = [regex]::Matches($html, '(?is)<p\b[^>]*>(.*?)</p>')
        foreach ($m in $pMatches) {
            $inner = $m.Groups[1].Value
            $inner = ($inner -replace '(?is)<br\s*/?>', "`n")
            $inner = ($inner -replace '(?is)<[^>]+>', ' ')
            $inner = [System.Net.WebUtility]::HtmlDecode($inner)
            $inner = ($inner -replace '\s+\n', "`n")
            $inner = ($inner -replace '\n\s+', "`n")
            $inner = ($inner -replace '[ \t]{2,}', ' ')
            $inner = $inner.Trim()
            if ($inner) { [void]$result.Paras.Add($inner) }
        }

        if ($result.Paras.Count -lt 1) { throw "Unable to parse EULA text (no paragraphs found)." }

        $result.FetchOk = $true
        return [pscustomobject]$result
    } catch {
        $result.FetchOk    = $false
        $result.FetchError = $_.Exception.Message
        return [pscustomobject]$result
    }
}

function Invoke-SelfDestructAndExit {
    try {
        $sd = Join-Path $script:ToolboxBase 'Toolbox-Cleanup-SelfDestruct.ps1'
        if (Test-Path $sd) { & $sd -Silent }
    } catch { }
    exit 1
}

function Ensure-EulaGate {
    if (Test-EulaStillValid) { return $true }

    $eula = Get-EulaFromWeb

    if (-not $eula.FetchOk) {
        Clear-Host
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host " End User License Agreement (EULA) - Required                " -ForegroundColor Cyan
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host (" Sourced Date: {0}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) -ForegroundColor DarkGray
        Write-Host (" Source URL:   {0}" -f $script:EulaSourceUrl) -ForegroundColor DarkGray
        Write-Host ""
        Write-Host "[WARN]  This device could not retrieve the EULA from the website." -ForegroundColor Yellow
        Write-Host ("       Please view the EULA here: {0}" -f $script:EulaSourceUrl) -ForegroundColor Yellow
        Write-Host ("       Reason: {0}" -f $eula.FetchError) -ForegroundColor DarkGray
        Write-Host ""

        while ($true) {
            Write-Host "Y) Agree and proceed" -ForegroundColor White
            Write-Host "N) Decline (cleanup/self-destruct) and exit" -ForegroundColor White
            Write-Host ""
            $resp = (Read-Host "Selection (Y/N)").Trim().ToUpperInvariant()
            switch ($resp) {
                'Y' { Save-EulaAcceptedAt (Get-Date); return $true }
                'N' { Invoke-SelfDestructAndExit; return $false }
                default { Write-Host "[WARN] Invalid selection. Please enter Y or N." -ForegroundColor Yellow }
            }
        }
    }

    $idx = 0
    while ($true) {
        Clear-Host
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host " End User License Agreement (EULA) - Required                " -ForegroundColor Cyan
        Write-Host "============================================================" -ForegroundColor Cyan
        Write-Host (" Sourced Date: {0}" -f $eula.SourcedAtLocal) -ForegroundColor DarkGray
        Write-Host (" Source URL:   {0}" -f $eula.SourceUrl) -ForegroundColor DarkGray
        if ($eula.LastUpdated) { Write-Host (" {0}" -f $eula.LastUpdated) -ForegroundColor DarkGray }
        Write-Host ""
        Write-Host (" Paragraph {0} of {1}" -f ($idx + 1), $eula.Paras.Count) -ForegroundColor DarkGray
        Write-Host ""
        Write-Host $eula.Paras[$idx] -ForegroundColor Yellow
        Write-Host ""

        Write-Host "Y) Agree and proceed" -ForegroundColor White
        Write-Host "N) Decline (cleanup/self-destruct) and exit" -ForegroundColor White
        if ($eula.Paras.Count -gt 1 -and $idx -lt ($eula.Paras.Count - 1)) {
            Write-Host "M) Show next paragraph" -ForegroundColor White
        }
        Write-Host ""

        $resp = (Read-Host "Selection (Y/N/M)").Trim().ToUpperInvariant()
        switch ($resp) {
            'Y' { Save-EulaAcceptedAt (Get-Date); return $true }
            'N' { Invoke-SelfDestructAndExit; return $false }
            'M' { if ($idx -lt ($eula.Paras.Count - 1)) { $idx++ } }
            default { Write-Host "[WARN] Invalid selection. Please enter Y, N, or M." -ForegroundColor Yellow }
        }
    }
}

# -----------------------------
# Step runner (continue on failure)
# -----------------------------
function Invoke-Step {
    param(
        [Parameter(Mandatory)][int]$Number,
        [Parameter(Mandatory)][int]$Total,
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][scriptblock]$Action
    )

    $result = [ordered]@{
        Step    = "$Number/$Total"
        Name    = $Name
        Status  = 'OK'
        Message = ''
    }

    try {
        if (-not $Silent) {
            Write-Host ("[Step {0}/{1}] {2}" -f $Number, $Total, $Name) -ForegroundColor Cyan
        } else {
            Write-Output ("[Step {0}/{1}] {2}" -f $Number, $Total, $Name)
        }

        $global:LASTEXITCODE = 0
        & $Action

        if ($LASTEXITCODE -ne 0) {
            throw ("Non-zero exit code: {0}" -f $LASTEXITCODE)
        }

        if (-not $Silent) {
            Write-Host ("[ OK ] {0}" -f $Name) -ForegroundColor Green
            Write-Host ""
        } else {
            Write-Output ("[ OK ] {0}" -f $Name)
        }
    }
    catch {
        $result.Status  = 'FAIL'
        $result.Message = $_.Exception.Message

        if (-not $Silent) {
            Write-Host ("[FAIL] {0}" -f $Name) -ForegroundColor Red
            Write-Host ("       {0}" -f $_.Exception.Message) -ForegroundColor Red
            Write-Host ""
        } else {
            Write-Output ("[FAIL] {0} :: {1}" -f $Name, $_.Exception.Message)
        }
    }

    return [pscustomobject]$result
}

# -----------------------------
# Elevate to Admin
# -----------------------------
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    if ($Silent) {
        $env:CS_TOOLBOX_SILENT_INNER = '1'
        Start-ElevatedInstance -Hidden
        exit
    } else {
        Start-ElevatedInstance
        exit
    }
}

# If already admin AND -Silent requested, spawn hidden worker and exit visible instance
if ($Silent -and -not $IsInner) {
    $env:CS_TOOLBOX_SILENT_INNER = '1'
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', "`"$PSCommandPath`"",
        '-Silent'
    ) | Out-Null
    exit
}

# -----------------------------
# Run
# -----------------------------
Ensure-Folder -Path $script:CollectedInfoRoot
$logPath  = Join-Path $script:CollectedInfoRoot ("RunWU_Agent_Collected_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
$results  = New-Object System.Collections.Generic.List[object]

try {
    Set-ExecutionPolicy -Scope Process Bypass -Force
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    if ($Silent) {
        Start-Transcript -Path $logPath -Append | Out-Null
    } else {
        Ensure-EulaGate | Out-Null
        Show-StatusHeader
    }

    $totalSteps = 10

    $results.Add((Invoke-Step 1 $totalSteps "Download/Stage Toolbox (DevTools DL)" {
        Invoke-Expression (Invoke-RestMethod -Uri $script:DevToolsDlUrl -ErrorAction Stop)
    })) | Out-Null

    $results.Add((Invoke-Step 2 $totalSteps "Unblock toolbox scripts" {
        if (Test-Path $script:ToolboxBase) {
            Get-ChildItem $script:ToolboxBase -Recurse -Filter *.ps1 -File | Unblock-File
        } else {
            throw "Toolbox folder not found: $script:ToolboxBase"
        }
    })) | Out-Null

    try { Set-Location $script:ToolboxBase } catch {}

    $results.Add((Invoke-Step 3 $totalSteps "Windows Update Details (ExportOnly)" {
        .\Windows-Update-Details.ps1 -Exportonly
    })) | Out-Null

    $results.Add((Invoke-Step 4 $totalSteps "OSQuery WMIC Patch (ExportOnly)" {
        .\OSQuery-WMIC-Patch.ps1 -Exportonly
    })) | Out-Null

    $results.Add((Invoke-Step 5 $totalSteps "Agent Log Review (DefaultLogs ExportOnly)" {
        .\Agent-Log-Review.ps1 -Defaultlogs -Exportonly
    })) | Out-Null

    $results.Add((Invoke-Step 6 $totalSteps "Agent Msg Correlator (DefaultLogs ExportOnly)" {
        .\Agent-msg-Correlator.ps1 -Defaultlogs -Exportonly
    })) | Out-Null

    $results.Add((Invoke-Step 7 $totalSteps "Agent Job Review (AllLogs Silent)" {
        .\Agent-Job-Review.ps1 -AllLogs -Silent
    })) | Out-Null

    $results.Add((Invoke-Step 8 $totalSteps "Agent Update Tool (Quiet)" {
        .\Agent-Update-Tool.ps1 -quiet
    })) | Out-Null

    $results.Add((Invoke-Step 9 $totalSteps "ZIP + Encrypt (Company/Ticket placeholders)" {
        .\zip-encrypt-htmltemplate.ps1 -s -c $CompanyName -t $TicketNumber
    })) | Out-Null
	
	$results.Add((Invoke-Step 10 $totalSteps "Cleanup / Self-destruct (Silent)" {
        .\Toolbox-Cleanup-SelfDestruct.ps1 -Silent
    })) | Out-Null
}
catch {
    if (-not $Silent) {
        Write-Host ""
        Write-Host "[ERROR] Wrapper-level error:" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    } else {
        "WRAPPER ERROR: $($_.Exception.Message)" | Out-File -FilePath $logPath -Append -Encoding UTF8
    }
}
finally {
    # ALWAYS run cleanup/self-destruct no matter what happened above
    try {
        $cleanup = Join-Path $script:ToolboxBase 'Toolbox-Cleanup-SelfDestruct.ps1'
        if (Test-Path $cleanup) {
            if ($Silent) { Write-Output "[FINAL] Cleanup/Self-Destruct (Silent)" }
            else { Write-Host "[FINAL] Cleanup/Self-Destruct (Silent)" -ForegroundColor Cyan }
            & $cleanup -Silent
        } else {
            if ($Silent) { Write-Output "[FINAL] Cleanup skipped (script not found)." }
            else { Write-Host "[FINAL] Cleanup skipped (script not found)." -ForegroundColor Yellow }
        }
    } catch {
        if ($Silent) { Write-Output ("[FINAL] Cleanup failed: {0}" -f $_.Exception.Message) }
        else { Write-Host ("[FINAL] Cleanup failed: {0}" -f $_.Exception.Message) -ForegroundColor Red }
    }

    # Save summary CSV
    try {
        $summaryPath = Join-Path $script:CollectedInfoRoot ("RunWU_Agent_Summary_{0}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
        $results | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $summaryPath -Force
        if (-not $Silent) {
            Write-Host ("Summary saved: {0}" -f $summaryPath) -ForegroundColor Green
            Write-Host ""
        }
    } catch { }

    if ($Silent) {
        try { Stop-Transcript | Out-Null } catch {}
        exit
    } else {
        Show-Footer
    }
}
