﻿#requires -version 5.1
[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# =====================================================================
# REPLACE THESE VALUES
# =====================================================================
$CompanyName  = 'changemechangeme'
$TicketNumber = 'changemechangeme'
$UserSecretJ  = 'changeme'   # used for Agent-Install-Tool.ps1 -j
# =====================================================================

# NOTE- Script could take between 5sec-several minutes to run. Patience.
# NOTE- Files created @ C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs

function Write-Step {
    param(
        [Parameter(Mandatory)][int]$Num,
        [Parameter(Mandatory)][string]$Text
    )
    Write-Host ""
    Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray
    Write-Host ("[Step {0}] {1}" -f $Num, $Text) -ForegroundColor Cyan
    Write-Host "------------------------------------------------------------" -ForegroundColor DarkGray
}

function Pause-ForUser {
    Write-Host ""
    Write-Host "Press any key to close..." -ForegroundColor Yellow
    try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { Start-Sleep -Seconds 15 }
}

# Elevate to Admin (new visible window)
if (-not ([Security.Principal.WindowsPrincipal] `
    [Security.Principal.WindowsIdentity]::GetCurrent()
).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {

    Start-Process powershell.exe `
        -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" `
        -Verb RunAs `
        -WindowStyle Normal

    exit
}

# --- Always-visible status message ---
Clear-Host
$host.UI.RawUI.WindowTitle = "ConnectSecure Toolbox - Operation Running"
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " ConnectSecure Toolbox - Operation Running (Admin Required)  " -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This script is running. You will see each step listed below." -ForegroundColor Yellow
Write-Host ""
Write-Host "After it completes, check this folder for .csb files:" -ForegroundColor White
Write-Host "  C:\CS-Toolbox-TEMP\ZIP" -ForegroundColor Green
Write-Host ""
Write-Host "For support-related issues, send any .csb files to support@connectsecure.com or attach them to the existing support request." -ForegroundColor White
Write-Host ""

try {
    Write-Step 1 "Prepare PowerShell session (ExecutionPolicy, TLS)"
    Set-ExecutionPolicy -Scope Process Bypass -Force
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    Write-Step 2 "Download/Load CS Toolbox DevTools"
    irm 'https://raw.githubusercontent.com/dmooney-cs/prod/refs/heads/main/CS-Toolbox-Launcher-DevTools-DL.ps1' | iex

    Write-Step 3 "Set working directory + unblock scripts"
    Set-Location "C:\CS-Toolbox-TEMP\prod-01-01"
    Get-ChildItem "C:\CS-Toolbox-TEMP\prod-01-01" -Recurse -Filter *.ps1 -File | Unblock-File

    Write-Step 4 "Run Agent-Log-Review (DefaultLogs, ExportOnly)"
    .\Agent-Log-Review.ps1 -Defaultlogs -Exportonly

    Write-Step 5 "Run Agent-msg-Correlator (DefaultLogs, ExportOnly)"
    .\Agent-msg-Correlator.ps1 -Defaultlogs -Exportonly

    Write-Step 6 "Run Agent-Job-Review (AllLogs, Silent)"
    .\Agent-Job-Review.ps1 -AllLogs -Silent

    Write-Step 7 "Run Agent-Install-Tool (reinstall, silent, -j secret)"
    .\Agent-Install-Tool.ps1 -reinstall -silent -j $UserSecretJ

    Write-Step 8 "Create encrypted CSB bundle (Company + Ticket)"
    .\zip-encrypt-htmltemplate.ps1 -s -c $CompanyName -t $TicketNumber

    Write-Step 9 "Cleanup / Self-destruct (Silent)"
    .\Toolbox-Cleanup-SelfDestruct.ps1 -Silent

    Write-Host ""
    Write-Host "[OK] All steps completed." -ForegroundColor Green
}
catch {
    Write-Host ""
    Write-Host "[ERROR] The operation encountered an error:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
}
finally {
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host " Operation finished (or exited).                             " -ForegroundColor Cyan
    Write-Host " Check: C:\CS-Toolbox-TEMP\ZIP for .csb files.               " -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "For support-related issues, send any .csb files to support@connectsecure.com or attach them to the existing support request." -ForegroundColor White

    # This is the key part for right-click runs: keep the window open.
    Pause-ForUser
}
