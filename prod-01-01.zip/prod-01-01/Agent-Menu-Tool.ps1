# ╔═════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Agent Menu Tool                                 ║
# ║ Version: 1.4 | 2025-08-07 | Summary Logging + Consistency Fixes ║
# ╚═════════════════════════════════════════════════════════════════╝

# ───────────── Shared UI + Export Helpers ─────────────
function Show-Header {
    param ([string]$Title)
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host ("         " + $Title)
    Write-Host "====================================================="
    Write-Host ""
}
function Pause-Script {
    Write-Host ""
    Write-Host "Press any key to continue..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
function Export-Data {
    param (
        [Parameter(Mandatory = $true)][object]$Object,
        [Parameter(Mandatory = $true)][string]$BaseName,
        [string]$Ext = "csv"
    )
    $folder = "C:\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $folder)) {
        New-Item -Path $folder -ItemType Directory -Force | Out-Null
    }
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $filename = "$BaseName-$timestamp.$Ext"
    $path = Join-Path $folder $filename
    $Object | Export-Csv -Path $path -NoTypeInformation -Force
    return $path
}
function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}
function Ensure-ExportFolder {
    $Global:ExportRoot = "C:\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $Global:ExportRoot)) {
        New-Item -Path $Global:ExportRoot -ItemType Directory -Force | Out-Null
    }
}
function Write-Log {
    param (
        [string]$Message,
        [string]$LogPath
    )
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $LogPath -Value "$ts  $Message"
}
function Write-SessionSummary {
    param ([string]$Line)
    Ensure-ExportFolder
    $summaryFile = Join-Path $Global:ExportRoot "SessionSummary.txt"
    $ts = Get-Date -Format "HH:mm:ss"
    Add-Content -Path $summaryFile -Value "$ts  $Line"
}

# ───────────── Core Agent Menu Functions ─────────────

function Run-AgentInstaller {
    Show-Header "Install CyberCNS Agent"

    $svc1 = Get-Service -Name "CyberCNSAgent" -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name "CyberCNSAgentMonitor" -ErrorAction SilentlyContinue

    if ($svc1 -or $svc2) {
        Write-Host "`nConnectSecure Agent is already installed."
        Write-Host "Would you like to uninstall it first? (Y/N)"
        $un = Read-Host
        if ($un -match '^[Yy]') {
            Run-AgentUninstall
        } else {
            Write-Host "Returning to menu..."
            Pause-Script
            return
        }
    }

    $url = "https://cybercns-agent-download-link.com/installer.exe"
    $tempPath = "$env:TEMP\CyberCNS-AgentInstaller.exe"

    Write-Host "Downloading agent installer..."
    try {
        Invoke-WebRequest -Uri $url -OutFile $tempPath -UseBasicParsing
        Start-Process -FilePath $tempPath -Wait
        Write-Host "`nInstallation completed."
        Write-SessionSummary "Installed CyberCNS Agent from $url"
    } catch {
        Write-Host "❌ Failed to download or run installer: $($_.Exception.Message)" -ForegroundColor Red
        Write-SessionSummary "❌ Agent install failed: $($_.Exception.Message)"
    }

    Pause-Script
}

function Run-AgentUninstall {
    Show-Header "Uninstall CyberCNS Agent V4"

    $path = "C:\Program Files (x86)\CyberCNSAgent\uninstall.bat"
    if (Test-Path $path) {
        Start-Process -FilePath $path -Wait
        Write-Host "`nUninstall script executed."
        Write-SessionSummary "Ran agent uninstall script."
    } else {
        Write-Host "❌ Uninstall script not found at $path" -ForegroundColor Red
        Write-SessionSummary "❌ Agent uninstall script not found."
    }

    Pause-Script
}

function Run-AgentStatus {
    Show-Header "Agent Status and Service Check"
    $output = @()

    $services = @("CyberCNSAgent", "CyberCNSAgentMonitor")
    foreach ($svc in $services) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s) {
            $line = "[$svc] installed - Status: $($s.Status)"
            Write-Host $line -ForegroundColor Green
            $output += $line
        } else {
            $line = "[$svc] is NOT installed."
            Write-Host $line -ForegroundColor Yellow
            $output += $line
        }
    }

    $logPath = Export-Data -Object $output -BaseName "AgentStatus" -Ext "txt"
    Write-ExportPath $logPath
    Write-SessionSummary "Checked agent service status."
    Pause-Script
}

function Run-AgentMaintenance {
    Show-Header "Agent Maintenance + Reset Tools"

    $logPath = "C:\Program Files (x86)\CyberCNSAgent\logs"
    if (Test-Path $logPath) {
        Write-Host "`nFound logs at: $logPath"
        $exportZip = "C:\CS-Toolbox-TEMP\Collected-Info\CyberCNSAgentLogs.zip"
        Compress-Archive -Path $logPath -DestinationPath $exportZip -Force
        Write-Host "`nZipped logs to: $exportZip"
        Write-SessionSummary "Compressed agent logs."
    } else {
        Write-Host "No log folder found at expected path." -ForegroundColor DarkYellow
        Write-SessionSummary "⚠️ No agent log folder found."
    }

    $confirm = Read-Host "`nDo you want to reset the agent configuration files? (Y/N)"
    if ($confirm -match '^[Yy]') {
        $configFiles = @(
            "C:\Program Files (x86)\CyberCNSAgent\config.json",
            "C:\Program Files (x86)\CyberCNSAgent\agent.conf"
        )
        foreach ($file in $configFiles) {
            if (Test-Path $file) {
                Remove-Item -Path $file -Force
                Write-Host "Deleted: $file"
            }
        }
        Write-SessionSummary "Reset agent config files."
    }

    Pause-Script
}

function Run-AgentUpdate {
    Show-Header "ConnectSecure Agent Updater"

    Ensure-ExportFolder
    $agentPath = "C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe"
    $logPath = Join-Path $Global:ExportRoot "AgentUpdate-Log.txt"
    $shouldUpdate = $true

    Write-Log "Stopping CyberCNS services..." $logPath
    Stop-Service -Name "cybercnsagent" -Force -ErrorAction SilentlyContinue
    Stop-Service -Name "cybercnsagentmonitor" -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 3

    if (Test-Path $agentPath) {
        try {
            $versionOutput = & $agentPath -v
            Write-Log "Detected version info: $versionOutput" $logPath

            $versionArray = $versionOutput -split '\s+'
            $version = $versionArray[-1]

            if ([version]$version -ge [version]"4.3.62") {
                Write-Log "CyberCNSAgent is already up to date (version $version)." $logPath
                Write-SessionSummary "Agent already up to date ($version)"
                $shouldUpdate = $false
            } else {
                Write-Log "Outdated version detected: $version. Proceeding with update..." $logPath
            }
        } catch {
            Write-Log "⚠️ Version check failed. Proceeding with update..." $logPath
        }
    } else {
        Write-Log "Agent executable not found. Proceeding with fresh install..." $logPath
    }

    if ($shouldUpdate) {
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $source = (Invoke-RestMethod -Method "Get" -Uri "https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows")
            Write-Log "Downloading agent from: $source" $logPath

            Invoke-WebRequest -Uri $source -OutFile $agentPath -UseBasicParsing
            Write-Log "✅ Agent downloaded and replaced successfully." $logPath
            Write-SessionSummary "Agent updated from $source"
        } catch {
            Write-Log "❌ Download failed: $($_.Exception.Message)" $logPath
            Write-SessionSummary "❌ Agent update failed: $($_.Exception.Message)"
        }
    }

    Write-Log "Restarting CyberCNS services..." $logPath
    Start-Service -Name "cybercnsagent" -ErrorAction SilentlyContinue
    Start-Service -Name "cybercnsagentmonitor" -ErrorAction SilentlyContinue

    Write-ExportPath $logPath
    Pause-Script
}

# ───────────── Main Menu ─────────────

function Show-AgentMenu {
    do {
        Show-Header "Agent Menu Tool – Install, Uninstall, Status, Update"

        Write-Host " [1] Install CyberCNS Agent"
        Write-Host " [2] Uninstall CyberCNS Agent"
        Write-Host " [3] Agent Status + Service Check"
        Write-Host " [4] Agent Maintenance & Reset Tools"
        Write-Host " [5] Update CyberCNS Agent"
        Write-Host ""
        Write-Host " [Q] Back to Main Menu"
        Write-Host ""

        $choice = Read-Host "Enter your selection"

        switch ($choice) {
            '1' { Run-AgentInstaller }
            '2' { Run-AgentUninstall }
            '3' { Run-AgentStatus }
            '4' { Run-AgentMaintenance }
            '5' { Run-AgentUpdate }
            'Q' { return }
            'q' { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

# Entry point
Show-AgentMenu
