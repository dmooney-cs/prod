# ╔═════════════════════════════════════════════════════════════╗
# ║ ⚙️ CS Toolbox – Agent Menu Tool                             ║
# ║ Version: 1.1 | Install, Uninstall, Update, Maintenance      ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Launch-AgentSubTool {
    param ([string]$name)
    $path = Join-Path $PSScriptRoot $name
    if (Test-Path $path) {
        Write-SessionSummary "Launched: $name"
        & $path
    } else {
        Write-Host "❌ Script not found: $name" -ForegroundColor Red
        Pause-Script
    }
}

function Show-AgentMenu {
    do {
        Clear-Host
        Show-Header "ConnectSecure – Agent Menu"

        Write-Host " [1] Install CyberCNS Agent"
        Write-Host " [2] Uninstall CyberCNS Agent"
        Write-Host " [3] Update CyberCNS Agent"
        Write-Host " [4] Agent Maintenance (Logs, Status, Fixes)"
        Write-Host ""
        Write-Host " [Q] Quit to Main Menu"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice.ToUpper()) {
            "1" { Launch-AgentSubTool "Agent-Install-Tool.ps1" }
            "2" { Launch-AgentSubTool "Uninstall-CyberCNSAgentV4.ps1" }
            "3" { Launch-AgentSubTool "Agent-Update-Tool.ps1" }
            "4" { Launch-AgentSubTool "Agent-Maintenance.ps1" }
            "Q" { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Pause-Script
            }
        }
    } while ($true)
}

# 🚀 Show the menu on load
Show-AgentMenu
