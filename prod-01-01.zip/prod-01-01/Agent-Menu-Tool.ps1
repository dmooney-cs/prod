# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Agent Menu Tool                             ║
# ║ Version: 1.2 | Install, Uninstall, Status, Maintenance      ║
# ╚═════════════════════════════════════════════════════════════╝

Ensure-ExportFolder

function Run-AgentInstall {
    Show-Header "Install ConnectSecure Agent"
    Write-Host "🔧 Installing agent... (placeholder)" -ForegroundColor Cyan
    Write-SessionSummary "Agent install initiated"
    Pause-Script
}

function Run-AgentUninstall {
    Show-Header "Uninstall ConnectSecure Agent"
    Write-Host "🗑️ Uninstalling agent... (placeholder)" -ForegroundColor Cyan
    Write-SessionSummary "Agent uninstall initiated"
    Pause-Script
}

function Run-AgentStatus {
    Show-Header "Check Agent Status"
    Write-Host "📋 Checking status... (placeholder)" -ForegroundColor Cyan
    Write-SessionSummary "Agent status checked"
    Pause-Script
}

function Run-AgentMaintenance {
    Show-Header "Agent Maintenance Tasks"
    Write-Host "🛠️ Running maintenance... (placeholder)" -ForegroundColor Cyan
    Write-SessionSummary "Agent maintenance started"
    Pause-Script
}

function Run-ZipAndEmailResults {
    Show-Header "Zipping and Emailing Results"
    try {
        $zipPath = Zip-ExportFolder
        Send-ZipEmail -Attachment $zipPath
        Write-ExportPath $zipPath
        Write-SessionSummary "Zipped and launched email for results"
    } catch {
        Write-Host "❌ Error during ZIP/Email: $_" -ForegroundColor Red
        Write-SessionSummary "ZIP/email failed"
    }
    Pause-Script
}

function Run-CleanupExportFolder {
    Show-Header "Cleaning Up Export Folder"
    Cleanup-ExportFolder
    Write-SessionSummary "Export folder cleaned"
    Pause-Script
}

function Show-AgentMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "       CS Toolbox – Agent Management Menu"
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Install Agent"
        Write-Host " [2] Uninstall Agent"
        Write-Host " [3] Check Agent Status"
        Write-Host " [4] Agent Maintenance"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Back to Main Menu"
        Write-Host ""
        $choice = Read-Host "Select an option"

        switch ($choice.ToUpper()) {
            '1' { Run-AgentInstall }
            '2' { Run-AgentUninstall }
            '3' { Run-AgentStatus }
            '4' { Run-AgentMaintenance }
            'Z' { Run-ZipAndEmailResults }
            'C' { Run-CleanupExportFolder }
            'Q' { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Pause-Script
            }
        }
    } while ($true)
}

Show-AgentMenu
