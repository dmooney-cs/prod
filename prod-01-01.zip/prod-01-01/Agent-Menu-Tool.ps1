# ================================================
# Agent-Menu-Tool.ps1 (Minimal with Return to Main Launcher)
# - Only 1: Install/Reinstall, 2: Uninstall
# - Q returns to CS-Toolbox-Launcher.ps1 in same folder
# ================================================

# Base path is the folder this script lives in
$BasePath = Split-Path -Parent $MyInvocation.MyCommand.Definition

function Show-Header {
    param([string]$Title = "Agent Menu Tool")
    Write-Host "   ConnectSecure Technicians Toolbox" -ForegroundColor Cyan
    Write-Host "========================================================="
    $hostName = $env:COMPUTERNAME
    $userName = $env:USERNAME
    $isAdmin  = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()
                ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    $commonTag = "Common-$(Get-Date -Format 'yyyy-MM-dd') R1"
    Write-Host (" Host: {0}   User: {1}   Admin: {2}   Common: {3}" -f $hostName,$userName,$isAdmin,$commonTag)
    Write-Host ""
    Write-Host " $Title"
    Write-Host ""
}

function Run-FromFolder {
    param(
        [Parameter(Mandatory=$true)][string]$ScriptName
    )
    $full = Join-Path $BasePath $ScriptName
    Write-Host ("Launching: {0}" -f $ScriptName) -ForegroundColor DarkCyan
    if (Test-Path -LiteralPath $full) {
        try {
            & $full
        } catch {
            Write-Host ("ERROR launching {0}: {1}" -f $ScriptName, $_.Exception.Message) -ForegroundColor Red
            Read-Host -Prompt "Press any key to continue..."
        }
    } else {
        Write-Host ("ERROR: {0} not found in {1}" -f $ScriptName, $BasePath) -ForegroundColor Red
        Read-Host -Prompt "Press any key to continue..."
    }
}

do {
    Clear-Host
    Show-Header "Agent Menu Tool"
    Write-Host ""
    Write-Host " [1] Agent Install-Reinstall  - Deploy or repair agent"
    Write-Host " [2] Uninstall Agent          - Remove agent and cleanup"
    Write-Host ""
    Write-Host " [Q] Return to Main Menu"
    Write-Host ""

    $choice = Read-Host "Enter choice"
    switch ($choice.ToUpperInvariant()) {
        '1' { Run-FromFolder -ScriptName 'Agent-Install-Tool.ps1' }
        '2' { Run-FromFolder -ScriptName 'Agent-Uninstall-Tool.ps1' }
        'Q' { 
            Run-FromFolder -ScriptName 'CS-Toolbox-Launcher.ps1'
            break
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Seconds 1
        }
    }
} while ($true)
