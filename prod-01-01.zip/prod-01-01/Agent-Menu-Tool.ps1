# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "[ERROR] Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host ("[ERROR] Failed to load Functions-Common.ps1: {0}" -f $_) -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}


# --- Compatibility shims (safeguards if Functions-Common.ps1 lacks certain functions) ---
if (-not (Get-Command -Name Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    if (Get-Command -Name EnsureFolders -ErrorAction SilentlyContinue) {
        function Ensure-ExportFolder {
            param()
            try { EnsureFolders } catch { Write-Host "[WARN] EnsureFolders call failed: $($_.Exception.Message)" -ForegroundColor Yellow }
        }
    } else {
        function Ensure-ExportFolder {
            param()
            try {
                $root = if ($global:CS_TempRoot) { $global:CS_TempRoot } else { 'C:\CS-Toolbox-TEMP' }
                $zip  = if ($global:CS_ZipRoot)  { $global:CS_ZipRoot }  else { Join-Path $root 'ZIP' }
                $logs = if ($global:CS_LogsRoot) { $global:CS_LogsRoot } else { Join-Path $root 'LOGS' }
                foreach ($d in @($root,$zip,$logs)) {
                    if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
                }
                Write-Host "[OK] Ensured export folders: $root; $zip; $logs" -ForegroundColor Green
            } catch {
                Write-Host ("[WARN] Ensure-ExportFolder shim failed: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
            }
        }
    }
}
if (-not (Get-Command -Name Pause-Script -ErrorAction SilentlyContinue)) {
    function Pause-Script { param([string]$Message = "Press ENTER to continue..."); Write-Host ""; Read-Host $Message | Out-Null }
}
if (-not (Get-Command -Name Show-Header -ErrorAction SilentlyContinue)) {
    function Show-Header { param([string]$Title="Agent Actions", [string]$Subtitle="Install | Update | Uninstall"); 
        Write-Host ("="*60)
        Write-Host " $Title"
        if ($Subtitle) { Write-Host " $Subtitle" }
        Write-Host ("="*60)
    }
}
# --- End shims ---

# --- Safe wrapper to handle both signatures of Ensure-ExportFolder (with/without -Path) ---
function Invoke-EnsureExport {
    try {
        $cmd = Get-Command -Name Ensure-ExportFolder -ErrorAction Stop
        $hasPath = $false
        try { if ($cmd.Parameters.ContainsKey('Path')) { $hasPath = $true } } catch {}
        $root = if ($global:CS_TempRoot) { $global:CS_TempRoot } else { 'C:\CS-Toolbox-TEMP' }
        if ($hasPath) {
            Ensure-ExportFolder -Path $root
        } else {
            Ensure-ExportFolder
        }
    } catch {
        # Fallback: ensure basic folder structure manually
        try {
            $zip  = if ($global:CS_ZipRoot)  { $global:CS_ZipRoot }  else { Join-Path $root 'ZIP' }
            $logs = if ($global:CS_LogsRoot) { $global:CS_LogsRoot } else { Join-Path $root 'LOGS' }
            foreach ($d in @($root,$zip,$logs)) {
                if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
            }
            Write-Host "[OK] Ensured export folders (fallback): $root; $zip; $logs"
        } catch {
            Write-Host ("[ERROR] Failed to ensure export folders: {0}" -f $_.Exception.Message) -ForegroundColor Red
        }
    }
}
# --- End wrapper ---


Invoke-EnsureExport

# =================================================================================================
# Agent-Menu-Tool.ps1  (PS 5.1 Safe, Same-Window Launches, ASCII-only)
# - Adds new [3] Update Agent option, HARD-LINKED to absolute path below.
# - All child tools are launched in the SAME PowerShell window (no new process).
# - Robust return flow: after a child script finishes, press ENTER to return to this menu.
# - [Q] returns to CS-Toolbox-Launcher in the SAME window when present.
# - Show-Header is called with Title/Subtitle only if the function defines those parameters,
#   preventing PowerShell from prompting for missing mandatory params.
# =================================================================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Continue'

# ---------- Constants (hard links) ---------------------------------------------------------------
$AgentInstallPath   = 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-Install-Tool.ps1'
$AgentUninstallPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-Uninstall-Tool.ps1'
# New hard link per request:
$AgentUpdatePath    = 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-Update-Tool.ps1'

# Launcher path for [Q]
$LauncherPath = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'

function Safe-ShowHeader {
    param(
        [string]$Title    = 'ConnectSecure Technicians Toolbox',
        [string]$Subtitle = 'Agent Menu Tool - Install, Reinstall, Remove, Update'
    )
    try {
        $cmd = Get-Command -Name Show-Header -ErrorAction Stop
        $params = @{}
        if ($cmd.Parameters.ContainsKey('Title'))    { $params['Title']    = $Title }
        if ($cmd.Parameters.ContainsKey('Subtitle')) { $params['Subtitle'] = $Subtitle }
        if ($cmd.Parameters.ContainsKey('NoLogo'))   { $params['NoLogo']   = $false }
        & $cmd @params
    } catch {
        # Fallback banner if Show-Header is unavailable
        Write-Host ""
        Write-Host ("   {0}" -f $Subtitle) -ForegroundColor Cyan
        $len = [Math]::Max(57, $Subtitle.Length + 3)
        Write-Host ("".PadLeft($len,'=')) -ForegroundColor DarkCyan
        Write-Host ""
    }
}

function Write-MenuHeader {
    Safe-ShowHeader
}

function Invoke-ChildScriptSameWindow {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$DisplayName
    )
    if (-not $Path) {
        Write-Host "[ERROR] Internal error: empty path." -ForegroundColor Red
        Pause-Script -Message "Press ENTER to return to the Agent Menu Tool"
        return
    }
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Host "[ERROR] Script not found:" -ForegroundColor Red
        Write-Host ("        {0}" -f $Path) -ForegroundColor Yellow
        Pause-Script -Message "Press ENTER to return to the Agent Menu Tool"
        return
    }

    try { Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue } catch { }

    Write-Host ""
    Write-Host ("[>] Launching {0} in this window..." -f $DisplayName) -ForegroundColor Green
    Write-Host ""

    try {
        & $Path
    } catch {
        Write-Host ("[ERROR] Error while running {0}: {1}" -f $DisplayName, $_.Exception.Message) -ForegroundColor Red
    } finally {
        Write-Host ""
        Read-Host "Press ENTER to Return to Agent Menu Tool"
    }
}

function Show-AgentMenu {
    do {
        Clear-Host
        Write-MenuHeader

        Write-Host " [1] Install / Reinstall Agent     - Download via API & install" -ForegroundColor White
        Write-Host " [2] Remove Agent                  - Full uninstall & cleanup" -ForegroundColor White
        Write-Host " [3] Update Agent                  - Check and update if newer" -ForegroundColor White
        Write-Host ""
        Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor White
        Write-Host ""

        $choice = Read-Host "Enter your choice (1/2/3/Q)"
        switch ($choice.ToUpper()) {
            '1' {
                Invoke-ChildScriptSameWindow -Path $AgentInstallPath -DisplayName 'Agent Install/Reinstall Tool'
            }
            '2' {
                Invoke-ChildScriptSameWindow -Path $AgentUninstallPath -DisplayName 'Agent Uninstall Tool'
            }
            '3' {
                Invoke-ChildScriptSameWindow -Path $AgentUpdatePath -DisplayName 'Agent Update Tool'
            }
            'Q' {
                if (Test-Path -LiteralPath $LauncherPath) {
                    Write-Host ""
                    Write-Host "[<] Returning to CS Toolbox Launcher..." -ForegroundColor Cyan
                    try {
                        try { Unblock-File -LiteralPath $LauncherPath -ErrorAction SilentlyContinue } catch { }
                        & $LauncherPath
                        return
                    } catch {
                        Write-Host ("[ERROR] Failed to launch CS-Toolbox-Launcher.ps1: {0}" -f $_.Exception.Message) -ForegroundColor Red
                        Pause-Script -Message "Press ENTER to exit"
                        return
                    }
                } else {
                    Write-Host ("[WARN] Launcher not found at: {0}" -f $LauncherPath) -ForegroundColor Yellow
                    Pause-Script -Message "Press ENTER to exit"
                    return
                }
            }
            Default {
                Write-Host "Invalid choice. Please select 1, 2, 3, or Q." -ForegroundColor Yellow
                Start-Sleep -Milliseconds 900
            }
        }
    } while ($true)
}

# Entry
Show-AgentMenu