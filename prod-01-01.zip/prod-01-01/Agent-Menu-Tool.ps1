# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    try {
        . $commonPath
    } catch {
        Write-Host "❌ ERROR: Exception occurred while loading Functions-Common.ps1"
        Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host "`nPress any key to exit..."
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        return
    }
} else {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "Expected path: $commonPath"
    Write-Host "`nThis script cannot continue without common functions."
    Write-Host "`nPress any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═══════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Agent Menu Tool                                  ║
# ║ Install / Uninstall / Maintenance / Update Status                    ║
# ╚═══════════════════════════════════════════════════════════════════════╝

Ensure-ExportFolder

function Show-AgentMenu {
    Clear-Host
    Write-Host "====================================================="
    Write-Host "       CS Toolbox - Agent Menu"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Install CyberCNS Agent"
    Write-Host " [2] Uninstall CyberCNS Agent"
    Write-Host " [3] Run Agent Maintenance Tasks"
    Write-Host " [4] Run Agent Update Script"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Back to Main Menu"
    Write-Host ""
}

function Launch-Tool {
    param ([string]$ScriptName)
    $toolPath = Join-Path $PSScriptRoot $ScriptName
    if (Test-Path $toolPath) {
        powershell.exe -ExecutionPolicy Bypass -File $toolPath
    } else {
        Write-Host "`n❌ $ScriptName not found." -ForegroundColor Red
        Pause-Script
    }
}

# Main Loop
do {
    Show-AgentMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Launch-Tool 'Agent-Install-Tool.ps1' }
        '2' { Launch-Tool 'Agent-Uninstall-Tool.ps1' }
        '3' { Launch-Tool 'Agent-Maintenance.ps1' }
        '4' { Launch-Tool 'Agent-Update-Tool.ps1' }
        'Z' { Invoke-ZipAndEmailResults }
        'C' { Invoke-CleanupExport }
        'Q' { return }
        default {
            Write-Host "`nInvalid selection. Please choose again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
