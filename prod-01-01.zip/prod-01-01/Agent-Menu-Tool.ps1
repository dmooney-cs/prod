# ╔═════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Agent Menu Tool                                 ║
# ║ Version: 1.1 | Install, Uninstall, Status, Maintenance, Update  ║
# ╚═════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

function Run-AgentInstaller {
    Show-Header "Install CyberCNS Agent"

    $svc1 = Get-Service -Name "CyberCNSAgent" -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name "CyberCNSAgentMonitor" -ErrorAction SilentlyContinue

    if ($svc1 -or $svc2) {
        Write-Host "`nConnectSecure Agent is already installed."
        Write-Host "Would you like to uninstall it first? (Y/N)"
        $un = Read-Host
        if ($un -match '^[Yy]') {
            Run-AgentUninstall
        } else {
            Write-Host "Returning to menu..."
            Pause-Script
            return
        }
    }

    $url = "https://cybercns-agent-download-link.com/installer.exe"
    $tempPath = "$env:TEMP\CyberCNS-AgentInstaller.exe"

    Write-Host "Downloading agent installer..."
    try {
        Invoke-WebRequest -Uri $url -OutFile $tempPath -UseBasicParsing
        Start-Process -FilePath $tempPath -Wait
        Write-Host "`nInstallation completed."
    } catch {
        Write-Host "❌ Failed to download or run installer: $_" -ForegroundColor Red
    }

    Pause-Script
}

function Run-AgentUninstall {
    Show-Header "Uninstall CyberCNS Agent V4"

    $path = "C:\Program Files (x86)\CyberCNSAgent\uninstall.bat"
    if (Test-Path $path) {
        Start-Process -FilePath $path -Wait
        Write-Host "`nUninstall script executed."
    } else {
        Write-Host "❌ Uninstall script not found at $path" -ForegroundColor Red
    }

    Pause-Script
}

function Run-AgentStatus {
    Show-Header "Agent Status and Service Check"

    $services = @("CyberCNSAgent", "CyberCNSAgentMonitor")
    foreach ($svc in $services) {
        $s = Get-Service -Name $svc -ErrorAction SilentlyContinue
        if ($s) {
            Write-Host "[$svc] is installed - Status: $($s.Status)" -ForegroundColor Green
        } else {
            Write-Host "[$svc] is NOT installed." -ForegroundColor Yellow
        }
    }

    Pause-Script
}

function Run-AgentMaintenance {
    Show-Header "Agent Maintenance + Reset Tools"

    $logPath = "C:\Program Files (x86)\CyberCNSAgent\logs"
    if (Test-Path $logPath) {
        Write-Host "`nFound logs at: $logPath"
        $exportZip = "C:\Scripts-Exports\CyberCNSAgentLogs.zip"
        Compress-Archive -Path $logPath -DestinationPath $exportZip -Force
        Write-Host "`nZipped logs to: $exportZip"
    } else {
        Write-Host "No log folder found at expected path." -ForegroundColor DarkYellow
    }

    $confirm = Read-Host "`nDo you want to reset the agent configuration files? (Y/N)"
    if ($confirm -match '^[Yy]') {
        $configFiles = @(
            "C:\Program Files (x86)\CyberCNSAgent\config.json",
            "C:\Program Files (x86)\CyberCNSAgent\agent.conf"
        )
        foreach ($file in $configFiles) {
            if (Test-Path $file) {
                Remove-Item -Path $file -Force
                Write-Host "Deleted: $file"
            }
        }
    }

    Pause-Script
}

function Run-AgentUpdate {
    Show-Header "Update CyberCNS Agent"

    $updateScript = Join-Path $PSScriptRoot 'Agent-Update-Tool.ps1'
    if (Test-Path $updateScript) {
        try {
            . $updateScript
        } catch {
            Write-Host "❌ Error running Agent-Update-Tool.ps1: $_" -ForegroundColor Red
            Pause-Script
        }
    } else {
        Write-Host "❌ Update script not found at $updateScript" -ForegroundColor Red
        Pause-Script
    }
}

function Show-AgentMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "           CS Toolbox – Agent Menu Tool"
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Install CyberCNS Agent"
        Write-Host " [2] Uninstall CyberCNS Agent"
        Write-Host " [3] Agent Status + Service Check"
        Write-Host " [4] Agent Maintenance & Reset Tools"
        Write-Host " [5] Update CyberCNS Agent"
        Write-Host ""
        Write-Host " [Q] Back to Main Menu"
        Write-Host ""

        $choice = Read-Host "Enter your selection"

        switch ($choice) {
            '1' { Run-AgentInstaller }
            '2' { Run-AgentUninstall }
            '3' { Run-AgentStatus }
            '4' { Run-AgentMaintenance }
            '5' { Run-AgentUpdate }
            'Q' { return }
            'q' { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

# ╔═════════════════════════════════════════════════════════════════╗
# ║ Entry Point                                                    ║
# ╚═════════════════════════════════════════════════════════════════╝
Show-AgentMenu
