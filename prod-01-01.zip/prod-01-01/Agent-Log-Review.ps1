# Load shared functions first - required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host ("ERROR: Failed to load Functions-Common.ps1: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder
Show-Header -Title "CyberCNS Agent Log Review - Analyze errors, repetition and correlate with Windows"

# ==============================
# Agent-Log-Review.ps1 (Sub-Tool)
# ==============================
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- Settings
$ExportRoot    = 'C:\CS-Toolbox-TEMP\Collected-Info\AgentLogs'
$TimeStamp     = Get-Date -Format 'yyyyMMdd_HHmmss'
$ComputerName  = $env:COMPUTERNAME
$DefaultDays   = 7
$TopNPerFile   = 7
$TopMessagesForCorrelation = 10
$CorrelationWindowSeconds  = 5

# Patterns considered "error-like"
$ErrorRegex = '(?i)\b(error|fail(?:ed|ure)?|exception|critical|fatal|warn(?:ing)?)\b'

# Preferred ConnectSecure agent log path (detectable) and fallback variant
$PreferredAgentLog = 'C:\Program Files (x86)\CyberCNSAgent\log'
$FallbackAgentLogs = 'C:\Program Files (x86)\CyberCNSAgent\logs'

# ------------- Helpers -------------
function New-DirSafe {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -Path $Path -ItemType Directory | Out-Null
    }
}

function Detect-ConnectSecureLogDir {
    if (Test-Path -LiteralPath $PreferredAgentLog) { return (Resolve-Path $PreferredAgentLog).Path }
    if (Test-Path -LiteralPath $FallbackAgentLogs) { return (Resolve-Path $FallbackAgentLogs).Path }
    return $null
}

function Get-LineTimestamp {
    param([string]$Line)
    if ([string]::IsNullOrWhiteSpace($Line)) { return $null }
    $patterns = @(
        '(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?)',
        '(\d{1,2}/\d{1,2}/\d{2,4}[ T]\d{1,2}:\d{2}:\d{2}(?: ?[AP]M)?)'
    )
    foreach ($p in $patterns) {
        $m = [regex]::Match($Line, $p)
        if ($m.Success) {
            $s = $m.Groups[1].Value
            $dt = $null
            if ([datetime]::TryParse($s, [ref]$dt)) { return $dt }
        }
    }
    return $null
}

function Normalize-Message {
    param([string]$Line)
    if ([string]::IsNullOrWhiteSpace($Line)) { return '' }

    $n = $Line
    $n = $n -replace '\b\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?\b',''
    $n = $n -replace '\b\d{1,2}/\d{1,2}/\d{2,4}[ T]\d{1,2}:\d{2}:\d{2}(?: ?[AP]M)?\b',''
    $n = $n -replace '\b[0-9a-fA-F]{8}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{4}\-[0-9a-fA-F]{12}\b',''
    $n = $n -replace '\b0x[0-9a-fA-F]+\b',''
    $n = $n -replace '\b[0-9a-fA-F]{10,}\b',''
    $n = $n -replace '\b(?:\d{1,3}\.){3}\d{1,3}\b',''
    $n = $n -replace '\[(?:PID|pid)?\s*\d+\]',''
    $n = $n -replace '\b\d{5,}\b',''
    $n = ($n -replace '\s+',' ').Trim()
    return $n
}

# Analyze a single file -> returns list; never $null
function Analyze-File {
    param([Parameter(Mandatory)][string]$Path)

    $results = New-Object System.Collections.Generic.List[object]
    $lineNo = 0

    $encodings = @([System.Text.UTF8Encoding]::new($false), [System.Text.Encoding]::Unicode, [System.Text.Encoding]::ASCII)
    $reader = $null
    foreach ($enc in $encodings) {
        try { $reader = New-Object System.IO.StreamReader($Path, $enc, $true); break } catch { continue }
    }
    if (-not $reader) {
        Write-Log ("WARN: Could not open {0} with common encodings." -f $Path)
        return @()
    }

    try {
        while (-not $reader.EndOfStream) {
            $line = $reader.ReadLine(); $lineNo++
            if ([string]::IsNullOrWhiteSpace($line)) { continue }

            $ts    = Get-LineTimestamp -Line $line
            $isErr = [bool]([regex]::IsMatch($line, $ErrorRegex))
            $norm  = Normalize-Message -Line $line

            if ($isErr -or ($norm.Length -ge 6)) {
                $results.Add([pscustomobject]@{
                    File        = $Path
                    LineNo      = $lineNo
                    Raw         = $line
                    Normalized  = if ($norm) { $norm } else { $line }
                    IsErrorLike = $isErr
                    Timestamp   = $ts
                })
            }
        }
    } catch {
        Write-Log ("WARN: Exception while reading {0}: {1}" -f $Path, $_.Exception.Message)
    } finally {
        $reader.Close(); $reader.Dispose()
    }

    if ($results.Count -eq 0) { return @() }
    return $results
}

function Summarize-Results {
    param([Parameter(Mandatory)][object[]]$Rows)

    $perFileTop =
        $Rows |
        Group-Object File, Normalized |
        Select-Object @{n='File';e={$_.Group[0].File}},
                      @{n='Message';e={$_.Group[0].Normalized}},
                      @{n='Count';e={$_.Count}},
                      @{n='ErrorLike';e={$_.Group.Where({$_.IsErrorLike}).Count -gt 0}} |
        Sort-Object File, Count -Descending

    $overallTop =
        $Rows |
        Group-Object Normalized |
        Select-Object @{n='Message';e={$_.Group[0].Normalized}},
                      @{n='Count';e={$_.Count}},
                      @{n='ErrorLike';e={$_.Group.Where({$_.IsErrorLike}).Count -gt 0}} |
        Sort-Object Count -Descending

    [pscustomobject]@{
        PerFile      = $perFileTop
        Overall      = $overallTop
        TotalFiles   = ($Rows | Select-Object -Expand File -Unique | Measure-Object).Count
        TotalLines   = $Rows.Count
        ErrorLines   = ($Rows | Where-Object IsErrorLike).Count
        RawRows      = $Rows
    }
}

function Show-Results {
    param(
        [Parameter(Mandatory)][pscustomobject]$Summary,
        [Parameter(Mandatory)][string]$LogFolder,
        [Parameter(Mandatory)][string]$CorrelationSource  # "Live Windows" or "EVTX in <folder>" or "None"
    )

    Write-Host ""
    Write-Host (" Analysis folder  : {0}" -f $LogFolder) -ForegroundColor Yellow
    Write-Host (" Correlation from : {0}" -f $CorrelationSource) -ForegroundColor Yellow
    Write-Host (" Files analyzed   : {0}" -f $Summary.TotalFiles) -ForegroundColor Yellow
    Write-Host (" Lines reviewed   : {0}" -f $Summary.TotalLines) -ForegroundColor Yellow
    Write-Host (" Error-like hits  : {0}" -f $Summary.ErrorLines) -ForegroundColor Yellow
    Write-Host ""

    Write-Host "=== Top Messages per File (most frequent first) ===" -ForegroundColor Cyan
    $Summary.PerFile |
        Group-Object File |
        ForEach-Object {
            $file = $_.Name
            Write-Host ""
            Write-Host ("File: {0}" -f $file) -ForegroundColor Gray
            $_.Group |
                Sort-Object Count -Descending |
                Select-Object -First $TopNPerFile |
                ForEach-Object {
                    Write-Host ("Count    : {0}" -f $_.Count) -ForegroundColor Yellow
                    Write-Host ("ErrorLike: {0}" -f $_.ErrorLike) -ForegroundColor Yellow
                    Write-Host  "Message  :" -ForegroundColor White
                    Write-Host  ("  {0}" -f $_.Message) -ForegroundColor White
                    Write-Host ""
                }
        }

    Write-Host "=== Overall Top Repeated Messages (all files) ===" -ForegroundColor Cyan
    $Summary.Overall |
        Select-Object -First 20 |
        ForEach-Object {
            Write-Host ("Count    : {0}" -f $_.Count) -ForegroundColor Yellow
            Write-Host ("ErrorLike: {0}" -f $_.ErrorLike) -ForegroundColor Yellow
            Write-Host  "Message  :" -ForegroundColor White
            Write-Host  ("  {0}" -f $_.Message) -ForegroundColor White
            Write-Host ""
        }
}

function Export-Results {
    param(
        [Parameter(Mandatory)][pscustomobject]$Summary,
        [Parameter(Mandatory)][string]$ExportFolder
    )
    New-DirSafe -Path $ExportFolder

    $csvPerFile = Join-Path $ExportFolder ("AgentLogs_PerFileTop_{0}_{1}.csv" -f $ComputerName, $TimeStamp)
    $csvOverall = Join-Path $ExportFolder ("AgentLogs_OverallTop_{0}_{1}.csv" -f $ComputerName, $TimeStamp)
    $jsonPath   = Join-Path $ExportFolder ("AgentLogs_Summary_{0}_{1}.json" -f $ComputerName, $TimeStamp)

    $Summary.PerFile | Select-Object File, Message, Count, ErrorLike |
        Export-Csv -Path $csvPerFile -Encoding UTF8 -NoTypeInformation
    $Summary.Overall | Select-Object Message, Count, ErrorLike |
        Export-Csv -Path $csvOverall -Encoding UTF8 -NoTypeInformation

    $jsonObj = @{
        Host        = $ComputerName
        GeneratedAt = (Get-Date).ToString('s')
        Totals      = @{
            Files     = $Summary.TotalFiles
            Lines     = $Summary.TotalLines
            ErrorHits = $Summary.ErrorLines
        }
        PerFileTop  = $Summary.PerFile
        OverallTop  = $Summary.Overall
    }
    Write-Utf8NoBom -Path $jsonPath -Content (($jsonObj | ConvertTo-Json -Depth 6))

    Write-Log "Exported:`n  $csvPerFile`n  $csvOverall`n  $jsonPath"
    return @($csvPerFile, $csvOverall, $jsonPath)
}

# ---- Windows Event Log loading (live) ----
function Load-WindowsEvents {
    param([datetime]$StartTime,[datetime]$EndTime)
    Write-Host ""
    Write-Host ("Loading Windows events from live logs: {0} to {1}..." -f $StartTime, $EndTime) -ForegroundColor Yellow

    $logs = @('System','Application')
    $all = @()
    foreach ($log in $logs) {
        try {
            $ev = Get-WinEvent -FilterHashtable @{ LogName = $log; StartTime = $StartTime; EndTime = $EndTime } -ErrorAction Stop |
                Where-Object { $_.LevelDisplayName -in @('Error','Warning') } |
                Select-Object TimeCreated, Id, ProviderName, LevelDisplayName, Message, LogName
            $all += $ev
            Write-Host ("  {0,-11}: {1} events (Error/Warning)" -f $log, ($ev | Measure-Object).Count) -ForegroundColor DarkGray
        } catch {
            Write-Host ("  Warning: Failed to read {0}: {1}" -f $log, $_.Exception.Message) -ForegroundColor DarkYellow
        }
    }
    return $all
}

# ---- Windows Event Log loading (EVTX files in a folder) ----
function Load-WindowsEventsFromFolder {
    param([string]$Folder,[datetime]$StartTime,[datetime]$EndTime)
    Write-Host ""
    Write-Host ("Loading Windows events from EVTX files in: {0}" -f $Folder) -ForegroundColor Yellow

    $evtxFiles = Get-ChildItem -LiteralPath $Folder -Filter *.evtx -File -ErrorAction SilentlyContinue
    if (-not $evtxFiles -or $evtxFiles.Count -eq 0) {
        Write-Host "  No .evtx files found in the selected folder." -ForegroundColor Yellow
        return @()
    }

    $ranked = @()
    $ranked += ($evtxFiles | Where-Object { $_.Name -match '(?i)system' })
    $ranked += ($evtxFiles | Where-Object { $_.Name -match '(?i)application' })
    $ranked += ($evtxFiles | Where-Object { $_.Name -notmatch '(?i)system|application' })

    $all = @()
    foreach ($f in $ranked | Select-Object -Unique) {
        try {
            $ev = Get-WinEvent -Path $f.FullName -FilterHashtable @{ StartTime = $StartTime; EndTime = $EndTime } -ErrorAction Stop |
                Where-Object { $_.LevelDisplayName -in @('Error','Warning') } |
                Select-Object TimeCreated, Id, ProviderName, LevelDisplayName, Message, @{n='LogName';e={$f.BaseName}}
            $all += $ev
            Write-Host ("  {0,-30}: {1} events (Error/Warning)" -f $f.Name, ($ev | Measure-Object).Count) -ForegroundColor DarkGray
        } catch {
            Write-Host ("  Warning: Failed to read EVTX {0}: {1}" -f $f.FullName, $_.Exception.Message) -ForegroundColor DarkYellow
        }
    }
    return $all
}

function Correlate-AgentToWindows {
    param(
        [Parameter(Mandatory)]$Summary,
        [Parameter(Mandatory)][int]$TopNMessages,
        [Parameter(Mandatory)][datetime]$StartTime,
        [Parameter(Mandatory)][datetime]$EndTime,
        [Parameter(Mandatory)][int]$WindowSeconds,
        [string]$WindowsEvtxFolder = $null
    )

    $topMsgs = $Summary.Overall | Select-Object -First $TopNMessages
    if (-not $topMsgs -or $topMsgs.Count -eq 0) { return @() }

    $winEvents = @()
    if ($WindowsEvtxFolder) {
        $winEvents = Load-WindowsEventsFromFolder -Folder $WindowsEvtxFolder -StartTime $StartTime -EndTime $EndTime
        if (-not $winEvents -or $winEvents.Count -eq 0) {
            Write-Host "No usable Windows events from EVTX files. Falling back to live logs..." -ForegroundColor Yellow
            $winEvents = Load-WindowsEvents -StartTime $StartTime -EndTime $EndTime
        }
    } else {
        $winEvents = Load-WindowsEvents -StartTime $StartTime -EndTime $EndTime
    }
    if (-not $winEvents -or $winEvents.Count -eq 0) { return @() }

    $bucket = @{}
    foreach ($e in $winEvents) {
        if ($e.TimeCreated) {
            $secKey = [datetime]::SpecifyKind([datetime]$e.TimeCreated, 'Utc').ToUniversalTime().ToString('yyyyMMddHHmmss')
            if (-not $bucket.ContainsKey($secKey)) { $bucket[$secKey] = New-Object System.Collections.Generic.List[object] }
            $bucket[$secKey].Add($e)
        }
    }

    $rows = $Summary.RawRows
    $matches = New-Object System.Collections.Generic.List[object]

    foreach ($tm in $topMsgs) {
        $msg = $tm.Message
        $agentHits = $rows | Where-Object { $_.Normalized -eq $msg -and $_.Timestamp }
        foreach ($hit in $agentHits) {
            $t = [datetime]::SpecifyKind([datetime]$hit.Timestamp, 'Utc').ToUniversalTime()
            for ($offset = -$WindowSeconds; $offset -le $WindowSeconds; $offset++) {
                $key = $t.AddSeconds($offset).ToString('yyyyMMddHHmmss')
                if ($bucket.ContainsKey($key)) {
                    foreach ($ev in $bucket[$key]) {
                        $matches.Add([pscustomobject]@{
                            AgentTime      = $hit.Timestamp
                            AgentFile      = $hit.File
                            AgentLineNo    = $hit.LineNo
                            AgentMessage   = $hit.Normalized
                            WindowsTime    = $ev.TimeCreated
                            WindowsLog     = $ev.LogName
                            WindowsID      = $ev.Id
                            WindowsLevel   = $ev.LevelDisplayName
                            WindowsSource  = $ev.ProviderName
                            WindowsMessage = $ev.Message
                            TimeDiffSec    = [int]([Math]::Abs( (New-TimeSpan -Start $hit.Timestamp -End $ev.TimeCreated).TotalSeconds ))
                        })
                    }
                }
            }
        }
    }

    return $matches
}

function Show-Correlations {
    param([Parameter(Mandatory)][object[]]$Correlated,[int]$WindowSeconds)

    if (-not $Correlated -or $Correlated.Count -eq 0) {
        Write-Host ""
        Write-Host "No Windows System/Application events correlated within the specified time window." -ForegroundColor Yellow
        return
    }

    Write-Host ""
    Write-Host ("=== Correlations: Agent issues vs Windows Events (+/- {0} sec) ===" -f $WindowSeconds) -ForegroundColor Cyan
    $total = ($Correlated | Measure-Object).Count
    Write-Host (" Correlated pairs found: {0}" -f $total) -ForegroundColor Yellow
    Write-Host ""

    $Correlated |
        Group-Object AgentMessage |
        ForEach-Object {
            $agentMsg = $_.Name
            $group    = $_.Group
            Write-Host "Agent Message:" -ForegroundColor White
            Write-Host ("  {0}" -f $agentMsg) -ForegroundColor White
            Write-Host ("  Correlated occurrences: {0}" -f ($group | Measure-Object).Count) -ForegroundColor Yellow

            $group |
                Group-Object WindowsLog, WindowsSource, WindowsID |
                Sort-Object Count -Descending |
                Select-Object -First 5 |
                ForEach-Object {
                    $g2 = $_.Group
                    $sample = $g2 | Select-Object -First 1
                    Write-Host ("    - {0} | {1} | EventID {2}  (Count: {3})" -f $sample.WindowsLog, $sample.WindowsSource, $sample.WindowsID, ($g2 | Measure-Object).Count) -ForegroundColor Gray
                    Write-Host  "      Windows Message:"
                    Write-Host  ("        {0}" -f $sample.WindowsMessage) -ForegroundColor DarkGray
                }

            Write-Host ""
        }
}

function Export-Correlations {
    param(
        [Parameter(Mandatory)][object[]]$Correlated,
        [Parameter(Mandatory)][string]$ExportFolder
    )
    if (-not $Correlated -or $Correlated.Count -eq 0) { return $null }

    $csv = Join-Path $ExportFolder ("AgentLogs_Correlations_{0}_{1}.csv" -f $ComputerName, $TimeStamp)
    $json= Join-Path $ExportFolder ("AgentLogs_Correlations_{0}_{1}.json" -f $ComputerName, $TimeStamp)

    $Correlated |
        Select-Object AgentTime, AgentFile, AgentLineNo, AgentMessage,
                      WindowsTime, WindowsLog, WindowsID, WindowsLevel, WindowsSource, TimeDiffSec,
                      WindowsMessage |
        Export-Csv -Path $csv -Encoding UTF8 -NoTypeInformation

    Write-Utf8NoBom -Path $json -Content (($Correlated | ConvertTo-Json -Depth 6))
    Write-Log "Exported correlations:`n  $csv`n  $json"
    return @($csv, $json)
}

function Choose-LogFolder {
    $detected = Detect-ConnectSecureLogDir
    if ($detected) {
        Write-Host ("Detected ConnectSecure logs at: {0}" -f $detected) -ForegroundColor Green
        Write-Host "[1] Use detected ConnectSecure folder" -ForegroundColor Cyan
        Write-Host "[2] Choose a different folder" -ForegroundColor Cyan
        Write-Host "[Q] Cancel / Return to Launcher" -ForegroundColor Cyan
        $sel = Read-Host "Enter choice (1/2/Q)"
        switch ($sel.ToUpper()) {
            '1' { return @{ Folder = $detected; UsingDetected = $true } }
            '2' {
                $chosen = $null
                while (-not $chosen) {
                    $suggest = 'C:\CS-Toolbox-TEMP\AgentLogs'
                    Write-Host "Enter a folder to analyze (containing .log files):" -ForegroundColor Gray
                    Write-Host ("  {0}" -f $suggest) -ForegroundColor Yellow
                    $path = Read-Host "Log folder (ENTER for suggested)"
                    if ([string]::IsNullOrWhiteSpace($path)) { $path = $suggest }
                    if (Test-Path -LiteralPath $path) { $chosen = (Resolve-Path $path).Path }
                    else { Write-Host ("ERROR: Folder not found: {0}" -f $path) -ForegroundColor Red }
                }
                return @{ Folder = $chosen; UsingDetected = $false }
            }
            'Q' { return $null }
            default {
                Write-Host "Invalid choice. Cancelling." -ForegroundColor Yellow
                return $null
            }
        }
    } else {
        Write-Host "ConnectSecure agent log folder not detected." -ForegroundColor Yellow
        $chosen = $null
        while (-not $chosen) {
            $suggest = 'C:\CS-Toolbox-TEMP\AgentLogs'
            Write-Host "Enter a folder to analyze (containing .log files):" -ForegroundColor Gray
            Write-Host ("  {0}" -f $suggest) -ForegroundColor Yellow
            $path = Read-Host "Log folder (ENTER for suggested)"
            if ([string]::IsNullOrWhiteSpace($path)) { $path = $suggest }
            if (Test-Path -LiteralPath $path) { $chosen = (Resolve-Path $path).Path }
            else { Write-Host ("ERROR: Folder not found: {0}" -f $path) -ForegroundColor Red }
        }
        return @{ Folder = $chosen; UsingDetected = $false }
    }
}

function Do-One-Review {
    param()

    # 1) Decide log folder (ask even if detected)
    $choice = Choose-LogFolder
    if (-not $choice) { return }
    $logFolder = $choice.Folder
    $usingDetected = [bool]$choice.UsingDetected

    # 2) Days to review
    $days = $DefaultDays
    $daysText = Read-Host ("How many days of logs to review? (Default {0})" -f $DefaultDays)
    if (-not [string]::IsNullOrWhiteSpace($daysText)) {
        $tmp = 0
        if ([int]::TryParse($daysText, [ref]$tmp)) { $days = [int]$tmp } else { Write-Host ("Invalid number. Using default {0}." -f $DefaultDays) -ForegroundColor Yellow }
    }

    # 3) Gather log files
    $cutoff = (Get-Date).AddDays(-1 * $days)
    $files = Get-ChildItem -LiteralPath $logFolder -Filter *.log -File -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -ge $cutoff } |
        Sort-Object LastWriteTime -Descending

    if (-not $files -or $files.Count -eq 0) {
        Write-Host ("No .log files modified in the last {0} day(s) under:" -f $days) -ForegroundColor Yellow
        Write-Host ("  {0}" -f $logFolder) -ForegroundColor Yellow
        return
    }

    Write-Host ""
    Write-Host ("Analyzing {0} log file(s)..." -f $files.Count) -ForegroundColor Yellow

    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($f in $files) {
        Write-Host ("  - {0} (last write {1})" -f $f.FullName, $f.LastWriteTime) -ForegroundColor DarkGray
        $batch = Analyze-File -Path $f.FullName
        if ($batch -and $batch.Count -gt 0) { $rows.AddRange($batch) }
    }

    if ($rows.Count -eq 0) {
        Write-Host ""
        Write-Host "No error-like or repetitive lines found in the selected timeframe." -ForegroundColor Yellow
        return
    }

    # 4) Summarize and show (also surface folder and correlation source)
    $corrSource = "None (not requested)"
    $summary = Summarize-Results -Rows $rows.ToArray()
    Show-Results -Summary $summary -LogFolder $logFolder -CorrelationSource $corrSource

    # 5) Export analysis
    $exports = Export-Results -Summary $summary -ExportFolder $ExportRoot
    Write-Host ""
    Write-Host "Exports written:" -ForegroundColor Green
    $exports | ForEach-Object { Write-Host ("  {0}" -f $_) -ForegroundColor Green }

    # 6) Optional Windows correlation
    Write-Host ""
    $ans = Read-Host "Compare with Windows Event Logs for commonality? (Y/N)"
    if ($ans -and $ans.Trim().ToUpper() -eq 'Y') {
        $end   = Get-Date
        $start = $end.AddDays(-1 * $days)

        # If user selected a non-detected folder, prefer EVTX in same folder; else live logs
        $evtxFolder = $null
        if (-not $usingDetected) {
            $evtxExists = Get-ChildItem -LiteralPath $logFolder -Filter *.evtx -File -ErrorAction SilentlyContinue
            if ($evtxExists -and $evtxExists.Count -gt 0) { $evtxFolder = $logFolder }
        }

        if ($evtxFolder) { $corrSource = ("EVTX in {0}" -f $evtxFolder) } else { $corrSource = "Live Windows (System/Application)" }

        $correlated = Correlate-AgentToWindows -Summary $summary -TopNMessages $TopMessagesForCorrelation -StartTime $start -EndTime $end -WindowSeconds $CorrelationWindowSeconds -WindowsEvtxFolder $evtxFolder

        # Re-show the summary line with the actual correlation source before details
        Write-Host ""
        Write-Host ("Correlation source: {0}" -f $corrSource) -ForegroundColor Yellow

        Show-Correlations -Correlated $correlated -WindowSeconds $CorrelationWindowSeconds
        $corrExports = Export-Correlations -Correlated $correlated -ExportFolder $ExportRoot
        if ($corrExports) {
            Write-Host ""
            Write-Host "Correlation exports:" -ForegroundColor Green
            $corrExports | ForEach-Object { Write-Host ("  {0}" -f $_) -ForegroundColor Green }
        }
    }

    # 7) Session footer (like other subs)
    Write-SessionSummary -ExtraLines @(
        "Agent Log Review",
        ("Folder: {0}" -f $logFolder),
        ("Files analyzed: {0}" -f $summary.TotalFiles),
        ("Lines reviewed: {0}" -f $summary.TotalLines),
        ("Error-like hits: {0}" -f $summary.ErrorLines),
        ("Correlation source: {0}" -f $corrSource)
    )
}

function Run-AgentLogReview {
    try {
        New-DirSafe -Path $ExportRoot

        while ($true) {
            Do-One-Review

            Write-Host ""
            Write-Host "[A] Run another log review" -ForegroundColor Cyan
            Write-Host "[Q] Return to CS-Toolbox Launcher" -ForegroundColor Cyan
            $choice = Read-Host "Enter your choice (A/Q)"
            switch ($choice.ToUpper()) {
                'A' { continue }
                'Q' {
                    $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
                    if (Test-Path $launcher) {
                        try { & $launcher } catch { Write-Host ("Warning: Could not relaunch: {0}" -f $_.Exception.Message) -ForegroundColor Yellow }
                    } else {
                        Write-Host ("Warning: Launcher not found at {0}" -f $launcher) -ForegroundColor Yellow
                    }
                    break
                }
                Default { break }
            }
        }
    } catch {
        Write-Host ("ERROR during log review: {0}" -f $_.Exception.Message) -ForegroundColor Red
        Write-Log ("ERROR: {0}" -f $_.Exception.ToString())
        Pause-Script "Press any key to return..."
    }
}

# ----- Entry -----
Run-AgentLogReview
