<# ====================================================
  Agent-Log-Review.ps1  (v7al - fix: avoid $Host automatic variable; top-level combined "Detected 3rd Party Download URL's" for cyberpatch*; exclude CS domains; keep per-file "Attempted URLs during Patching"; CS hosts via wildcard + bare hostnames; per-severity last 10; de-dupe; combined Servers/IPs; safe paths; smart HTML name; hardened Time/Line handling in Last 10 block; CS URL/IP sections collapsed by default)
====================================================== #>

#Requires -RunAsAdministrator
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ---- Tunables ----
$ContextBefore          = 3
$ContextAfter           = 3
$MaxExamplesPerPattern  = 12
$LargeFileContextMB     = 25
$FoldUrlToHost          = $true
$LogoUrl                = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-logo.svg'
$DefaultLogsRoot        = 'C:\Program Files (x86)\CyberCNSAgent\logs'
$SearchPatterns         = @('*.log','*.txt','*.json','*.evtx','*.zip','*.gz')  # copy-only: evtx/zip/gz
$AnalyzeExts            = @('.log','.txt','.json')

# ---- Paths ----
$LauncherPath           = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'

# -------- Bootstrap (optional common lib) --------
$commonPath = 'C:\CS-Toolbox-TEMP\prod-01-01\Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) { try { . $commonPath } catch { } }
if (-not $global:CS_TempRoot) { $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP' }

# -------- Console helpers --------
if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
  function Show-Header { param([string]$Title='ConnectSecure Technicians Toolbox')
    Write-Host ("`n $Title") -ForegroundColor Cyan
    Write-Host ('='*58)
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $env:COMPUTERNAME,"$env:USERDOMAIN\$env:USERNAME",$isAdmin) -ForegroundColor Gray
    Write-Host ('='*58); Write-Host ''
  }
}
if (-not (Get-Command Write-Info -ErrorAction SilentlyContinue)) { function Write-Info { param([string]$Msg) Write-Host ("[INFO]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Cyan } }
if (-not (Get-Command Write-OK   -ErrorAction SilentlyContinue)) { function Write-OK   { param([string]$Msg) Write-Host ("[OK]    {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Green } }
if (-not (Get-Command Write-Warn -ErrorAction SilentlyContinue)) { function Write-Warn { param([string]$Msg) Write-Host ("[WARN]  {0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$Msg) -ForegroundColor Yellow } }
if (-not (Get-Command Ensure-Folder -ErrorAction SilentlyContinue)) { function Ensure-Folder { param([Parameter(Mandatory)][string]$Path) if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Force -Path $Path | Out-Null } } }

# -------- Utility helpers --------
function HtmlEscape($s) { return ($s -replace '&','&amp;' -replace '<','&lt;' -replace '>','&gt;') }
function Normalize-PathInput {
  param([Parameter(Mandatory)][string]$Raw)
  $t = $Raw.Trim()
  if ($t.StartsWith('"') -and $t.EndsWith('"') -and $t.Length -ge 2) { $t = $t.Substring(1, $t.Length-2) }
  if ($t.StartsWith("'") -and $t.EndsWith("'") -and $t.Length -ge 2) { $t = $t.Substring(1, $t.Length-2) }
  [Environment]::ExpandEnvironmentVariables($t).Trim()
}
function Get-RelativePath {
  param([Parameter(Mandatory)][string]$Base, [Parameter(Mandatory)][string]$Full)
  try {
    $baseUri = (Resolve-Path -LiteralPath $Base -ErrorAction Stop).ProviderPath
    $fullUri = (Resolve-Path -LiteralPath $Full -ErrorAction Stop).ProviderPath
    $u1 = New-Object System.Uri(("file://" + ($baseUri -replace '\\','/').TrimEnd('/') + '/'))
    $u2 = New-Object System.Uri(("file://" + ($fullUri -replace '\\','/')))
    $rel = $u1.MakeRelativeUri($u2).ToString()
    return [Uri]::UnescapeDataString($rel) -replace '/','\'
  } catch { return (Split-Path -Leaf $Full) }
}
function Read-FileLines {
  param([Parameter(Mandatory)][string]$Path)
  try {
    $c = Get-Content -LiteralPath $Path -ErrorAction Stop
    if ($null -eq $c) { return @() }
    if ($c -is [string]) { return @($c) }
    return @($c)
  } catch {
    Write-Warn ("Failed to read file: {0}" -f $_.Exception.Message)
    return @()
  }
}
function ValueOr { param($v,$fallback) if ($null -eq $v) { return $fallback } $sv = [string]$v; if ([string]::IsNullOrWhiteSpace($sv)) { return $fallback } return $sv }

# -------- Timestamp parsing --------
function TryParse-LineDateTime {
  param([string]$Line,[datetime]$FallbackDate)
  if ([string]::IsNullOrWhiteSpace($Line)) { return $null }

  $m = [regex]::Match($Line,'(?<!\d)(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?(?:Z|[+-]\d{2}:\d{2})?')
  if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

  $m = [regex]::Match($Line,'(?<!\d)(\d{4}/\d{2}/\d{2})[ T](\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success) { try { return [datetime]::Parse($m.Groups[1].Value+' '+$m.Groups[2].Value+$m.Groups[3].Value) } catch {} }

  $m = [regex]::Match($Line,'(?<!\d)(\d{2}:\d{2}:\d{2})(\.\d+)?')
  if ($m.Success -and $FallbackDate) {
    try {
      $h=[int]$m.Groups[1].Value.Substring(0,2)
      $mi=[int]$m.Groups[1].Value.Substring(3,2)
      $s=[int]$m.Groups[1].Value.Substring(6,2)
      return (Get-Date -Date $FallbackDate.Date -Hour $h -Minute $mi -Second $s)
    } catch {}
  }
  return $null
}

# -------- Pattern normalization --------
function Normalize-LineForPattern {
  param([string]$Line)
  if ($null -eq $Line) { return '' }
  $norm = $Line
  $norm = $norm -replace '\b\d{4}[-\/]\d{2}[-\/]\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?\b',''
  $norm = $norm -replace '\b\d{2}:\d{2}:\d{2}(?:\.\d+)?\b',''
  if ($FoldUrlToHost) { $norm = [regex]::Replace($norm,'https?://([^/\s]+)[^\s\]]*','{URL:$1}') }
  $norm = $norm -replace '\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b','{GUID}'
  $norm = $norm -replace '\b0x[0-9A-Fa-f]+\b','{HEX}'
  $norm = $norm -replace '\s+',' '
  $norm = $norm.Trim()
  if ($norm.Length -gt 220) { $norm = $norm.Substring(0,220) }
  return $norm
}

# -------- IP extraction (non-local only) --------
function Get-NonLocalIpCountsFromLog {
  param([Parameter(Mandatory)][string]$LogPath)
  $counts = @{}
  if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }
  $lines = Read-FileLines -Path $LogPath
  if (@($lines).Count -eq 0) { return $counts }

  $ipRegex = [regex]'(?<!\d)(\d{1,3}(?:\.\d{1,3}){3})(?!\d)'
  foreach ($ln in $lines) {
    foreach ($m in $ipRegex.Matches([string]$ln)) {
      $ip = $m.Groups[1].Value
      if ([string]::IsNullOrWhiteSpace($ip)) { continue }
      if ($ip -like '10.*') { continue }
      if ($ip -like '192.168.*') { continue }
      if ($ip -like '172.*') {
        $oct2 = [int]($ip.Split('.')[1])
        if ($oct2 -ge 16 -and $oct2 -le 31) { continue }
      }
      if ($ip -like '127.*') { continue }
      if ($ip -like '169.254.*') { continue }
      if ($ip -like '0.*') { continue }
      if ($ip -like '255.*') { continue }
      if (-not $counts.ContainsKey($ip)) { $counts[$ip] = 0 }
      $counts[$ip]++
    }
  }
  return $counts
}

# -------- Helper: is ConnectSecure host? --------
function Test-IsCsHost {
  param([Parameter(Mandatory)][string]$HostName)
  $h = $HostName.ToLowerInvariant()
  return ( ($h -eq 'myconnectsecure.com') -or ($h -like '*.myconnectsecure.com') -or
           ($h -eq 'mycybercns.com')     -or ($h -like '*.mycybercns.com') )
}

# -------- Any HTTP/HTTPS URL counter (raw) --------
function Get-HttpOrHttpsUrlCountsFromLog {
  param([Parameter(Mandatory)][string]$LogPath)
  $counts = @{}
  if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }
  $lines = Read-FileLines -Path $LogPath
  if (@($lines).Count -eq 0) { return $counts }
  $urlRegex = [regex]'https?://[^\s"''\]\)<>]+'
  foreach ($ln in $lines) {
    foreach ($m in $urlRegex.Matches([string]$ln)) {
      $u = [string]$m.Value
      if ([string]::IsNullOrWhiteSpace($u)) { continue }
      while ($u.Length -gt 0 -and '.;,)]'.Contains($u[$u.Length-1])) { $u = $u.Substring(0,$u.Length-1) }
      if (-not $counts.ContainsKey($u)) { $counts[$u] = 0 }
      $counts[$u]++
    }
  }
  return $counts
}

# -------- ConnectSecure servers (URLs and bare hostnames) --------
function Get-CsServersFromLog {
  param([Parameter(Mandatory)][string]$LogPath)
  $counts = @{}
  if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $counts }
  $lines = Read-FileLines -Path $LogPath
  if (@($lines).Count -eq 0) { return $counts }

  $urlRegex     = [regex]'https?://[^\s"''\]\)<>]+'
  $hostRegexNet = [regex]'(?i)\b([a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:myconnectsecure\.com|mycybercns\.com))\b'

  foreach ($ln in $lines) {
    # URLs
    foreach ($m in $urlRegex.Matches([string]$ln)) {
      $u = [string]$m.Value
      if ([string]::IsNullOrWhiteSpace($u)) { continue }
      while ($u.Length -gt 0 -and '.;,)]'.Contains($u[$u.Length-1])) { $u = $u.Substring(0,$u.Length-1) }
      $urlHost = $null
      try { $urlHost = ([Uri]$u).Host } catch {
        $hm = [regex]::Match($u,'^https?://([^/:?#]+)'); if ($hm.Success) { $urlHost = $hm.Groups[1].Value }
      }
      if ($urlHost -and (Test-IsCsHost -HostName $urlHost)) {
        if (-not $counts.ContainsKey($u)) { $counts[$u] = 0 }
        $counts[$u]++
      }
    }
    # Bare hostnames
    foreach ($hm in $hostRegexNet.Matches([string]$ln)) {
      $hostOnlyName = $hm.Groups[1].Value.ToLowerInvariant()
      if (-not $counts.ContainsKey($hostOnlyName)) { $counts[$hostOnlyName] = 0 }
      $counts[$hostOnlyName]++
    }
  }
  return $counts
}

# -------- URL + App extraction for patch logs --------
function Get-UrlAttemptsWithAppFromLog {
  param([Parameter(Mandatory)][string]$LogPath)
  $result = @{}  # URL -> @{ Count=#, App='...' }
  if (-not (Test-Path -LiteralPath $LogPath -PathType Leaf)) { return $result }
  $lines = Read-FileLines -Path $LogPath
  if (@($lines).Count -eq 0) { return $result }

  $urlRegex = [regex]'https?://[^\s"''\]\)<>]+'
  $appTokens = @(
    'winget','choco','Chocolatey','msiexec','WindowsUpdateAgent','WuApi','WUAgent','WUAPI',
    'DISM','BITS','Start-BitsTransfer','Invoke-WebRequest','iwr','curl','wget','PowerShell',
    'PatchMyPC','ConnectSecure Agent','Agent','pswindowsupdate','PSWindowsUpdate','sconfig'
  )
  for ($i=0; $i -lt $lines.Count; $i++) {
    $ln = [string]$lines[$i]
    foreach ($m in $urlRegex.Matches($ln)) {
      $url = [string]$m.Value
      if ([string]::IsNullOrWhiteSpace($url)) { continue }
      while ($url.Length -gt 0 -and '.;,)]'.Contains($url[$url.Length-1])) { $url = $url.Substring(0,$url.Length-1) }

      if (-not $result.ContainsKey($url)) { $result[$url] = [ordered]@{ Count = 0; App = $null } }
      $result[$url].Count++

      if (-not $result[$url].App) {
        $start = [Math]::Max(0,$i-3); $stop = $i
        $ctxText = ($lines[$start..$stop] -join ' ')
        foreach ($t in $appTokens) { if ($ctxText -match [regex]::Escape($t)) { $result[$url].App = $t; break } }
        if (-not $result[$url].App) {
          $fstop = [Math]::Min($lines.Count-1,$i+3)
          $fText = ($lines[$i..$fstop] -join ' ')
          foreach ($t in $appTokens) { if ($fText -match [regex]::Escape($t)) { $result[$url].App = $t; break } }
        }
      }
    }
  }
  return $result
}

# -------- Patch-log detector --------
function Is-PatchLog {
  param([string]$PathOrName)
  $n = [IO.Path]::GetFileName($PathOrName)
  return ($n -match '(?i)\bpatch|windows.?update|wuapi|wua|pswindowsupdate|dism|kb\d{6,}\b')
}

# -------- Agent Summary Parser --------
function Get-AgentSummaryFromLogs {
  param([Parameter(Mandatory)][string]$CollectDir)

  $candidate = Get-ChildItem -Path $CollectDir -Recurse -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Extension -in $AnalyzeExts } |
               Sort-Object FullName | Where-Object { $_.Name -match 'cybercns' } | Select-Object -First 1
  if (-not $candidate) {
    $candidate = Get-ChildItem -Path $CollectDir -Recurse -File -ErrorAction SilentlyContinue |
                 Where-Object { $_.Extension -in $AnalyzeExts } |
                 Where-Object { Select-String -Path $_.FullName -Pattern 'AGENT INFO' -SimpleMatch -ErrorAction SilentlyContinue } |
                 Select-Object -First 1
  }
  if (-not $candidate) { return $null }

  $meta = [ordered]@{
    Hostname     = $null
    IP           = $null
    MAC          = $null
    AgentVersion = $null
    AgentID      = $null
    TenantID     = $null
    CompanyID    = $null
    AgentType    = $null
    PODID        = $null
    SourceFile   = $candidate.FullName
  }

  $lines = Read-FileLines -Path $candidate.FullName
  foreach ($ln in $lines) {
    if (-not $meta.IP -and $ln -match 'IP ADDRESS') {
      $ipm  = [regex]::Match($ln,'(?<!\d)(\d{1,3}(?:\.\d{1,3}){3})(?!\d)')
      if ($ipm.Success) { $meta.IP = $ipm.Groups[1].Value }
      $macm = [regex]::Match($ln,'\b([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})\b')
      if ($macm.Success) { $meta.MAC = $macm.Groups[1].Value.ToLower() }
      $hostm = [regex]::Match($ln,'HostName.?s\s*\[([^\]]+)\]')
      if ($hostm.Success) { $meta.Hostname = $hostm.Groups[1].Value }
      if (-not $meta.Hostname) {
        $uidm = [regex]::Match($ln,"UniqueId.?s\s*\[([^\]]+)\]")
        if ($uidm.Success) {
          $maybe = ($uidm.Groups[1].Value -split '[\s,]') | Where-Object { $_ -and ($_ -notmatch ':') } | Select-Object -First 1
          if ($maybe) { $meta.Hostname = $maybe }
        }
      }
    }
    if ($ln -match '\[Agent Version\s*:-\s*([^\]]+)\]') { $meta.AgentVersion = $Matches[1].Trim() }
    if ($ln -match '\[Agent ID\s*:-\s*([^\]]+)\]')      { $meta.AgentID      = $Matches[1].Trim() }
    if ($ln -match '\[Tenant ID\s*:-\s*([^\]]+)\]')     { $meta.TenantID     = $Matches[1].Trim() }
    if ($ln -match '\[Company ID\s*:-\s*([^\]]+)\]')    { $meta.CompanyID    = $Matches[1].Trim() }
    if ($ln -match '\[Agent Type\s*:-\s*([^\]]+)\]')    { $meta.AgentType    = $Matches[1].Trim() }
    if ($ln -match '\[PODID\s*:-\s*([^\]]+)\]')         { $meta.PODID        = $Matches[1].Trim() }
  }

  return $meta
}

# -------- Analysis (per-file) --------
function Analyze-File {
  param([string]$FilePath)

  $levelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'
  $countsByLevel = @{ ERROR=0; FATAL=0; EXCEPTION=0; WARN=0; WARNING=0; FAIL=0; TIMEOUT=0; UNAUTHORIZED=0; ACCESSDENIED=0 }
  $patterns     = @{}
  $contexts     = @{}
  $patternTimes = @{}
  $errorEvents  = New-Object System.Collections.Generic.List[object]

  $file = Get-Item -LiteralPath $FilePath -ErrorAction SilentlyContinue
  $limitCtx = $false
  if ($file -and $file.Length -gt ($LargeFileContextMB*1MB)) { $limitCtx = $true }

  $lines = Read-FileLines -Path $FilePath
  $lines = @($lines)
  if ($lines.Count -eq 0) {
    $now = Get-Date
    return [PSCustomObject]@{
      File=$FilePath; Total=0; Counts=$countsByLevel; Patterns=$patterns; Contexts=$contexts; Limited=$limitCtx;
      Frequencies=@{}; LatestTimestamp=$now; Last10=@(); Events=@()
    }
  }

  # Determine latest timestamp in file
  $fallbackDate = if ($file) { $file.LastWriteTime } else { Get-Date }
  $latestInFile = $null
  foreach ($ln in $lines) {
    $dt = TryParse-LineDateTime -Line $ln -FallbackDate $fallbackDate
    if ($dt) { if ($null -eq $latestInFile -or $dt -gt $latestInFile) { $latestInFile = $dt } }
  }
  if (-not $latestInFile) { $latestInFile = $fallbackDate }

  # Full pass: collect events
  for ($i=0;$i -lt $lines.Count;$i++) {
    $line = [string]$lines[$i]
    if ($line -match $levelRegex) {
      $upper = $Matches[1].ToUpperInvariant()
      switch -Regex ($upper) {
        '^ERROR$'        {$countsByLevel.ERROR++}
        '^FATAL$'        {$countsByLevel.FATAL++}
        '^EXCEPTION$'    {$countsByLevel.EXCEPTION++}
        '^WARN$'         {$countsByLevel.WARN++}
        '^WARNING$'      {$countsByLevel.WARNING++}
        '^FAIL(ED)?$'    {$countsByLevel.FAIL++}
        '^TIMEOUT$'      {$countsByLevel.TIMEOUT++}
        '^UNAUTHORIZED$' {$countsByLevel.UNAUTHORIZED++}
        'ACCESS DENIED'  {$countsByLevel.ACCESSDENIED++}
      }

      $norm = Normalize-LineForPattern -Line $line
      if (-not $patterns.ContainsKey($norm)) { $patterns[$norm] = 0 }
      $patterns[$norm]++

      if (-not $contexts.ContainsKey($norm)) { $contexts[$norm] = @() }
      if (-not $patternTimes.ContainsKey($norm)) { $patternTimes[$norm] = @() }

      $dt2 = TryParse-LineDateTime -Line $line -FallbackDate $fallbackDate
      if ($dt2) { $patternTimes[$norm] += $dt2 }

      $maxCtx = if ($limitCtx) { [Math]::Min($MaxExamplesPerPattern,3) } else { $MaxExamplesPerPattern }
      if (@($contexts[$norm]).Count -lt $maxCtx) {
        $start=[Math]::Max(0,$i-$ContextBefore); $end=[Math]::Min($lines.Count-1,$i+$ContextAfter)
        $k=$end+1
        while($k -lt $lines.Count) {
          $n=[string]$lines[$k]
          if($n -eq $null -or $n -eq '') { $k++; break }
          if($n -match '^\s') { $k++ } else { break }
        }
        $end=[Math]::Min($lines.Count-1,$k-1)
        $ctx="Context for line $($i+1) (+/-$ContextBefore/$ContextAfter)`n"
        for($p=$start;$p -le $end;$p++){
          $prefix=('   '); if($p -eq $i){ $prefix='>> ' }
          $ctx += ("{0,5}: {1}{2}`n" -f ($p+1), $prefix, $lines[$p])
        }
        $contexts[$norm] += @([PSCustomObject]@{ Time=$dt2; Line=$i; Text=$ctx })
      }

      # per-event capture (tight +/-1)
      $evStart=[Math]::Max(0,$i-1); $evEnd=[Math]::Min($lines.Count-1,$i+1)
      $evCtx="Event context at line $($i+1)`n"
      for($ep=$evStart;$ep -le $evEnd;$ep++){
        $evPrefix=('   '); if($ep -eq $i){ $evPrefix='>> ' }
        $evCtx += ("{0,5}: {1}{2}`n" -f ($ep+1), $evPrefix, $lines[$ep])
      }
      $errorEvents.Add([PSCustomObject]@{
        Time    = $dt2
        Line    = $i
        Level   = $upper
        Pattern = $norm
        Text    = $evCtx
      })
    }
  }

  # Frequency (avg minutes) per pattern
  $frequencies = @{}
  foreach ($kv in $patternTimes.GetEnumerator()) {
    $pat = $kv.Key
    $arr = @($kv.Value | Where-Object { $_ } | Sort-Object)
    if ($arr.Count -ge 2) {
      $mins = @()
      for ($j=1; $j -lt $arr.Count; $j++) { $mins += (($arr[$j] - $arr[$j-1]).TotalMinutes) }
      $avg = if ($mins.Count -gt 0) { ($mins | Measure-Object -Average).Average } else { 0 }
      $frequencies[$pat] = [Math]::Round([double]$avg,2)
    } else { $frequencies[$pat] = $null }
  }

  # Last 10 overall (kept for CSV/compat)
  $last10 = @(
    $errorEvents |
      Sort-Object -Property @{Expression={ if ($_.Time) { $_.Time } else { Get-Date '0001-01-01' } }; Descending=$true},
                             @{Expression={$_.Line}; Descending=$true} |
      Select-Object -First 10
  )

  return [PSCustomObject]@{
    File            = $FilePath
    Total           = $lines.Count
    Counts          = $countsByLevel
    Patterns        = $patterns
    Contexts        = $contexts
    Frequencies     = $frequencies
    LatestTimestamp = $latestInFile
    Last10          = $last10
    Events          = $errorEvents
  }
}

# -------- Report builder --------
function Collect-And-Report {
  param([string[]]$Roots)

  $outDir = Join-Path $global:CS_TempRoot 'Collected-Info\AgentLogs'
  Ensure-Folder $outDir
  $ts=Get-Date -Format 'yyyyMMdd_HHmmss'
  $collectDir=Join-Path $outDir ('Collect_'+$ts)
  Ensure-Folder $collectDir

  $found=$false

  foreach($root in ($Roots | Where-Object { $_ -and (Test-Path -LiteralPath $_) })) {
    $rootQ = '"' + (Resolve-Path -LiteralPath $root).ProviderPath + '"'
    Write-Info "Scanning $rootQ ..."
    if (Test-Path -LiteralPath $root -PathType Leaf) {
      $found = $true
      $dest = Join-Path $collectDir 'SelectedFiles'
      Ensure-Folder $dest
      Copy-Item -LiteralPath $root -Destination (Join-Path $dest (Split-Path $root -Leaf)) -Force -ErrorAction SilentlyContinue
      Write-OK ("Copied file: {0}" -f $root)
    } else {
      $dest=Join-Path $collectDir ((Split-Path $root -Leaf)-replace'[^\w\.-]','_'); Ensure-Folder $dest
      try {
        $items = Get-ChildItem -LiteralPath (Resolve-Path -LiteralPath $root) -Recurse -File -Include $SearchPatterns -ErrorAction SilentlyContinue
        if ($items) {
          $found=$true
          $i=0; foreach($f in $items){ $i++; if($i%50 -eq 0){ Write-Info (" Copying files... {0}/{1}" -f $i,$items.Count) }
            $rel = Get-RelativePath -Base $root -Full $f.FullName
            $tgt = Join-Path $dest $rel
            Ensure-Folder (Split-Path $tgt -Parent)
            Copy-Item -LiteralPath $f.FullName -Destination $tgt -Force -ErrorAction SilentlyContinue
          }
          Write-OK ("Copied {0} files from {1}" -f $items.Count,$rootQ)
        } else { Write-Warn ("No matching files found under {0}" -f $rootQ) }
      } catch { Write-Warn ("Scan error on {0}: {1}" -f $rootQ,$_.Exception.Message) }
    }
  }

  if(-not $found){
    Write-Warn 'No logs found'
    $html = @"
<!doctype html><html><head><meta charset="utf-8"><title>Agent Log Review</title>
<style>
body{font-family:Segoe UI,Arial;margin:20px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
.kicker{background:#fff4d6;border:1px solid #ffd27a;padding:10px;border-radius:8px;}
</style></head><body>
<div class="logo-wrap"><img src="$LogoUrl" alt="ConnectSecure logo"></div>
<h1>ConnectSecure - Agent Log Review</h1>
<div class="kicker">
  <h3>No logs were collected</h3>
  <p>We did not find any files matching *.log, *.txt, *.json, *.evtx, *.zip, or *.gz in the selected location(s).</p>
</div>
</body></html>
"@
    $htmlPath=Join-Path $collectDir 'index.html'
    $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html)
    [System.IO.File]::WriteAllBytes($htmlPath, $bytes)
    Write-OK ("Wrote HTML report: $htmlPath")
    try{ Start-Process $htmlPath }catch{}
    return
  }

  # Build HTML
  $html=[System.Text.StringBuilder]::new()
  $null=$html.AppendLine('<!doctype html><html><head><meta charset="utf-8"><title>Agent Log Review</title>')
  $null=$html.AppendLine('<style>
body{font-family:Segoe UI,Arial;margin:20px;}
h1{text-align:center;margin:6px 0 2px;}
.logo-wrap{text-align:center;margin:8px 0 18px;}
.logo-wrap img{height:44px;}
details{margin:8px 0;}
summary{cursor:pointer;font-weight:bold;}
pre{white-space:pre-wrap;word-break:break-word;background:#f9f9f9;padding:6px;border:1px solid #ddd;border-radius:6px;}
table{border-collapse:collapse;width:100%;margin:6px 0 10px;}
th,td{border:1px solid #e5e5e5;padding:6px 8px;text-align:left;vertical-align:top;}
th{background:#fafafa;}
.small{color:#888;}
.kicker{background:#eef7ff;border:1px solid #cfe6ff;padding:8px 10px;border-radius:10px;margin:6px 0 10px;}
.kicker h3{margin:0 0 6px 0;}
.badge{display:inline-block;padding:2px 6px;border:1px solid #aaa;border-radius:6px;font-size:12px;color:#555;background:#fafafa;margin-left:6px;}
.summary{background:#fff7e6;border:1px solid #ffd699;padding:10px 12px;border-radius:10px;margin:8px 0 10px;}
.summary h2{margin:4px 0 8px 0;}
.summary table{width:auto;border-collapse:separate;border-spacing:0 4px;}
.summary td{border:none;padding:2px 10px 2px 0;}
.key{color:#555;font-weight:600;white-space:nowrap;}
.val{color:#000;}
.src{color:#888;font-size:12px;margin-top:4px;}
.servers{background:#f4f9ff;border:1px solid #cfe6ff;padding:10px 12px;border-radius:10px;margin:8px 0 16px;}
.servers h3{margin:4px 0 8px 0;}
.servers table{width:100%;}
</style></head><body>')
  $null=$html.AppendLine('<div class="logo-wrap"><img src="'+ (HtmlEscape $LogoUrl) +'" alt="ConnectSecure logo"></div>')
  $null=$html.AppendLine('<h1>ConnectSecure - Agent Log Review</h1>')

  # ---- Gather analyzed files (once)
  $textFiles = Get-ChildItem -Path $collectDir -Recurse -File -ErrorAction SilentlyContinue |
               Where-Object { $_.Extension -in '.log','.txt','.json' }

  # Aggregates across all files
  $allSrvCounts = @{}
  $allIpCounts  = @{}
  $overallLatest = Get-Date '1900-01-01'

  # New: top-level 3rd-party table data structure (Host|URL|Count) across cyberpatch* files
  $thirdPartyRows  = @{}   # "host|url" -> count (non-CS only)

  foreach ($tf in $textFiles) {
    # CS servers (URLs + bare hostnames)
    $srv = Get-CsServersFromLog -LogPath $tf.FullName
    foreach ($kv in $srv.GetEnumerator()) {
      if (-not $allSrvCounts.ContainsKey($kv.Key)) { $allSrvCounts[$kv.Key] = 0 }
      $allSrvCounts[$kv.Key] += [int]$kv.Value
    }
    # IPs
    $ips = Get-NonLocalIpCountsFromLog -LogPath $tf.FullName
    foreach ($kv in $ips.GetEnumerator()) {
      if (-not $allIpCounts.ContainsKey($kv.Key)) { $allIpCounts[$kv.Key] = 0 }
      $allIpCounts[$kv.Key] += [int]$kv.Value
    }

    # Accumulate top-level 3rd party URLs ONLY from cyberpatch* files
    $name = [IO.Path]::GetFileName($tf.FullName)
    if ($name -match '(?i)^cyberpatch(\.|-|_)') {
      $urlCounts = Get-HttpOrHttpsUrlCountsFromLog -LogPath $tf.FullName
      foreach ($kv in $urlCounts.GetEnumerator()) {
        $url = [string]$kv.Key
        $cnt = [int]$kv.Value
        # Extract host and exclude CS hosts
        $urlHostTP = $null
        try { $urlHostTP = ([Uri]$url).Host } catch {
          $hm = [regex]::Match($url,'^https?://([^/:?#]+)'); if ($hm.Success) { $urlHostTP = $hm.Groups[1].Value }
        }
        if ($urlHostTP -and (Test-IsCsHost -HostName $urlHostTP)) { continue }
        if (-not $urlHostTP) { $urlHostTP = '' }
        $key = ($urlHostTP.ToLowerInvariant() + '|' + $url)
        if (-not $thirdPartyRows.ContainsKey($key)) { $thirdPartyRows[$key] = 0 }
        $thirdPartyRows[$key] += $cnt
      }
    }
  }

  # ---- Device Summary
  $agentMeta = $null
  try { $agentMeta = Get-AgentSummaryFromLogs -CollectDir $collectDir } catch { $agentMeta = $null }

  if ($agentMeta) {
    $h = HtmlEscape( (ValueOr $agentMeta.Hostname '-') )
    $ip= HtmlEscape( (ValueOr $agentMeta.IP       '-') )
    $mc= HtmlEscape( (ValueOr $agentMeta.MAC      '-') )
    $av= HtmlEscape( (ValueOr $agentMeta.AgentVersion '-') )
    $aid=HtmlEscape( (ValueOr $agentMeta.AgentID      '-') )
    $tid=HtmlEscape( (ValueOr $agentMeta.TenantID     '-') )
    $cid=HtmlEscape( (ValueOr $agentMeta.CompanyID    '-') )
    $aty=HtmlEscape( (ValueOr $agentMeta.AgentType    '-') )
    $pod=HtmlEscape( (ValueOr $agentMeta.PODID        '-') )
    $src=HtmlEscape( (ValueOr $agentMeta.SourceFile   '') )

    $null=$html.AppendLine('<div class="summary">')
    $null=$html.AppendLine('<h2>Device Summary</h2>')
    $null=$html.AppendLine('<table>')
    $null=$html.AppendLine("<tr><td class='key'>Hostname</td><td class='val'>$h</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>IP Address</td><td class='val'>$ip</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>MAC Address</td><td class='val'>$mc</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Agent Version</td><td class='val'>$av</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Agent ID</td><td class='val'>$aid</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Tenant ID</td><td class='val'>$tid</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Company ID</td><td class='val'>$cid</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>Agent Type</td><td class='val'>$aty</td></tr>")
    $null=$html.AppendLine("<tr><td class='key'>PODID</td><td class='val'>$pod</td></tr>")
    $null=$html.AppendLine('</table>')
    if ($src) { $null=$html.AppendLine("<div class='src'>Parsed from: $src</div>") }
    $null=$html.AppendLine('</div>')
  }

  # ---- NEW: Top-level "Detected 3rd Party Download URL's" (only if we saw any cyberpatch* file & found non-CS URLs)
  if ($thirdPartyRows.Keys.Count -gt 0) {
    $null=$html.AppendLine('<div class="servers">')
    $null=$html.AppendLine('<h3>Detected 3rd Party Download URL&#39;s (from cyberpatch logs)</h3>')
    $null=$html.AppendLine('<table><thead><tr><th style="width:30%">Host</th><th style="width:60%">URL</th><th>Count</th></tr></thead><tbody>')
    $thirdPartyRows.GetEnumerator() |
      Sort-Object -Property @{Expression='Value';Descending=$true}, @{Expression='Key'} |
      ForEach-Object {
        $parts = $_.Key.Split('|',2)
        $hostCol  = if ($parts.Count -ge 1) { $parts[0] } else { '' }
        $urlCol   = if ($parts.Count -ge 2) { $parts[1] } else { '' }
        $cnt   = $_.Value
        $null=$html.AppendLine("<tr><td>"+(HtmlEscape $hostCol)+"</td><td>"+(HtmlEscape $urlCol)+"</td><td>"+$cnt+"</td></tr>")
      }
    $null=$html.AppendLine('</tbody></table>')
    $null=$html.AppendLine('</div>')
  }

  # ---- Combined CS Servers (across all files) - COLLAPSED
  $null=$html.AppendLine('<details class="servers"><summary>ConnectSecure Servers Detected within Logs Reviewed</summary>')
  if ($allSrvCounts.Keys.Count -gt 0) {
    $null=$html.AppendLine('<table><thead><tr><th style="width:72%">URL or Host</th><th>Hits</th></tr></thead><tbody>')
    $allSrvCounts.GetEnumerator() |
      Sort-Object -Property @{Expression='Value';Descending=$true}, @{Expression='Key'} |
      ForEach-Object {
        $keyEsc = HtmlEscape $_.Key
        $cnt    = $_.Value
        $null=$html.AppendLine("<tr><td>$keyEsc</td><td>$cnt</td></tr>")
      }
    $null=$html.AppendLine('</tbody></table>')
  } else {
    $null=$html.AppendLine('<div class="small">No ConnectSecure server references detected across the logs reviewed.</div>')
  }
  $null=$html.AppendLine('</details>')

  # ---- Combined IPs (across all files) - COLLAPSED
  $null=$html.AppendLine('<details class="servers"><summary>IP&#39;s Detected within Logs Reviewed</summary>')
  if ($allIpCounts.Keys.Count -gt 0) {
    $null=$html.AppendLine('<table><thead><tr><th style="width:50%">IP Address</th><th>Occurrences</th></tr></thead><tbody>')
    $allIpCounts.GetEnumerator() |
      Sort-Object -Property @{Expression='Value';Descending=$true}, @{Expression='Key'} |
      ForEach-Object {
        $ipEsc = HtmlEscape $_.Key
        $cnt   = $_.Value
        $null=$html.AppendLine("<tr><td>$ipEsc</td><td>$cnt</td></tr>")
      }
    $null=$html.AppendLine('</tbody></table>')
  } else {
    $null=$html.AppendLine('<div class="small">No non-local IPs detected across the logs reviewed.</div>')
  }
  $null=$html.AppendLine('</details>')

  # ---- Per-file analysis sections
  foreach($tf in $textFiles){
    Write-Info ("Analyzing " + $tf.FullName)
    $res=Analyze-File -FilePath $tf.FullName
    if ($null -eq $res) { continue }
    if ($res.LatestTimestamp -and $res.LatestTimestamp -gt $overallLatest) { $overallLatest = $res.LatestTimestamp }
    $fname=Split-Path $tf.FullName -Leaf

    $null=$html.AppendLine("<details><summary>"+(HtmlEscape $fname)+" - "+$res.Total+" lines</summary>")

    # ----- PATCH LOG EXTRA (per-file): Attempted URLs during Patching with app guess
    if (Is-PatchLog -PathOrName $tf.FullName) {
      $null=$html.AppendLine('<div class="kicker">')
      $null=$html.AppendLine('<h3>Attempted URLs during Patching</h3>')
      $urlApp = Get-UrlAttemptsWithAppFromLog -LogPath $tf.FullName
      if ($urlApp.Keys.Count -gt 0) {
        $null=$html.AppendLine('<table><thead><tr><th style="width:64%">URL</th><th>Attempts</th><th>Application</th></tr></thead><tbody>')
        $urlApp.GetEnumerator() |
          Sort-Object -Property @{Expression={$_.Value.Count};Descending=$true}, @{Expression='Key'} |
          ForEach-Object {
            $uEsc = HtmlEscape $_.Key
            $cnt  = $_.Value.Count
            $app  = ValueOr $_.Value.App 'n/a'
            $null=$html.AppendLine("<tr><td>$uEsc</td><td>$cnt</td><td>"+(HtmlEscape $app)+"</td></tr>")
          }
        $null=$html.AppendLine('</tbody></table>')
      } else {
        $null=$html.AppendLine('<div class="small">No URLs detected in this patch log.</div>')
      }
      $null=$html.AppendLine('</div>')
    }

    # ----- Last 10 Severity events (per category, collapsible, de-duplicated by pattern) - HARDENED
    $null=$html.AppendLine('<div class="kicker">')
    $null=$html.AppendLine('<h3>Last 10 Severity events</h3>')

    # Safely sort all events newest → oldest, even if some objects lack Time/Line
    $eventsSorted = @(
      $res.Events |
        Sort-Object -Property @{
          Expression = {
            if ($_ -is [psobject] -and $_.PSObject.Properties.Name -contains 'Time' -and $_.Time) {
              $_.Time
            } else {
              Get-Date '0001-01-01'
            }
          }
          Descending = $true
        }, @{
          Expression = {
            if ($_ -is [psobject] -and $_.PSObject.Properties.Name -contains 'Line') {
              $_.Line
            } else {
              -1
            }
          }
          Descending = $true
        }
    )

    $sevOrder = @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESS DENIED')
    foreach ($sev in $sevOrder) {
      $grpRaw = @($eventsSorted | Where-Object { $_ -is [psobject] -and $_.Level -eq $sev })
      if ($grpRaw.Count -eq 0) { continue }

      # Most-recent per Pattern, then top 10 (safe Time/Line access)
      $grpUnique = @(
        $grpRaw | Group-Object -Property Pattern | ForEach-Object {
          $_.Group | Sort-Object -Property @{
            Expression = {
              if ($_ -is [psobject] -and $_.PSObject.Properties.Name -contains 'Time' -and $_.Time) {
                $_.Time
              } else {
                Get-Date '0001-01-01'
              }
            }
            Descending = $true
          }, @{
            Expression = {
              if ($_ -is [psobject] -and $_.PSObject.Properties.Name -contains 'Line') {
                $_.Line
              } else {
                -1
              }
            }
            Descending = $true
          } | Select-Object -First 1
        } | Sort-Object -Property @{
          Expression = {
            if ($_ -is [psobject] -and $_.PSObject.Properties.Name -contains 'Time' -and $_.Time) {
              $_.Time
            } else {
              Get-Date '0001-01-01'
            }
          }
          Descending = $true
        }, @{
          Expression = {
            if ($_ -is [psobject] -and $_.PSObject.Properties.Name -contains 'Line') {
              $_.Line
            } else {
              -1
            }
          }
          Descending = $true
        } | Select-Object -First 10
      )

      # Safely compute latestTime without assuming .Time exists
      $timeCandidates = $grpUnique | Where-Object {
        $_ -is [psobject] -and
        $_.PSObject.Properties.Name -contains 'Time' -and
        $_.Time
      }
      $latestTime = if ($timeCandidates) {
        ($timeCandidates | Sort-Object -Property Time -Descending | Select-Object -First 1).Time
      } else {
        $null
      }

      $latestTxt  = if ($latestTime) { $latestTime.ToString('yyyy-MM-dd HH:mm:ss') } else { 'n/a' }
      $plural     = if ($grpUnique.Count -eq 1) { '' } else { 's' }
      $summaryText = ('{0} - {1} event{2} (latest {3})' -f $sev, $grpUnique.Count, $plural, $latestTxt)

      $null=$html.AppendLine('<details><summary>'+ (HtmlEscape $summaryText) +'</summary>')
      $null=$html.AppendLine('<table><thead><tr>' +
        '<th>#</th><th>When</th><th style="width:48%">Pattern</th>' +
        '<th>Overall Occurrences</th><th>Avg Frequency (min)</th><th>Est. Next Occurrence</th></tr></thead><tbody>')

      $rowIdx = 1
      foreach ($ev in $grpUnique) {
        $whenTxt = if ($ev -is [psobject] -and $ev.PSObject.Properties.Name -contains 'Time' -and $ev.Time) {
          $ev.Time.ToString('yyyy-MM-dd HH:mm:ss')
        } else {
          'n/a'
        }
        $pat     = [string]$ev.Pattern
        $cnt     = if ($res.Patterns.ContainsKey($pat)) { $res.Patterns[$pat] } else { 1 }
        $freq    = if ($res.Frequencies.ContainsKey($pat)) { $res.Frequencies[$pat] } else { $null }
        $freqTxt = if ($freq -ne $null) { ([double]$freq).ToString('N2', [System.Globalization.CultureInfo]::InvariantCulture) } else { 'n/a' }

        $etaTxt  = if ($ev -is [psobject] -and
                       $ev.PSObject.Properties.Name -contains 'Time' -and
                       $ev.Time -and
                       $freq -ne $null -and
                       $freq -gt 0) {
          ($ev.Time.AddMinutes($freq)).ToString('yyyy-MM-dd HH:mm:ss')
        } else {
          'n/a'
        }

        $null=$html.AppendLine('<tr><td>'+ $rowIdx +'</td><td>'+ (HtmlEscape $whenTxt) +'</td><td>'+ (HtmlEscape $pat) +
                               '</td><td>'+ $cnt +'</td><td>'+ $freqTxt +'</td><td>'+ (HtmlEscape $etaTxt) +'</td></tr>')

        $titleWhen = $whenTxt
        $title = ('{0} context #{1} - {2}' -f $sev, $rowIdx, $titleWhen)

        $ctxText = if ($ev -is [psobject] -and $ev.PSObject.Properties.Name -contains 'Text') {
          [string]$ev.Text
        } else {
          ''
        }

        $null=$html.AppendLine('<tr><td colspan="6"><details><summary>'+ (HtmlEscape $title) +'</summary><pre>'+ (HtmlEscape $ctxText) +'</pre></details></td></tr>')
        $rowIdx++
      }
      $null=$html.AppendLine('</tbody></table>')
      $null=$html.AppendLine('</details>')
    }

    $null=$html.AppendLine('</div>')  # end kicker

    # ----- Full-file severity table
    $null=$html.AppendLine('<table><thead><tr><th>Severity</th><th>Count</th></tr></thead><tbody>')
    foreach($k in @('ERROR','FATAL','EXCEPTION','WARN','WARNING','FAIL','TIMEOUT','UNAUTHORIZED','ACCESSDENIED')){
      $null=$html.AppendLine("<tr><td>"+$k+"</td><td>"+$res.Counts[$k]+"</td></tr>")
    }
    $null=$html.AppendLine('</tbody></table>')

    # ----- Full-file patterns dropdowns newest -> oldest
    $ordered=$res.Patterns.GetEnumerator()|Sort-Object Value -Descending
    foreach($entry in $ordered){
      $patKey = $entry.Key
      $patEsc = (HtmlEscape $patKey)
      $cnt    = $entry.Value
      $freq   = if ($res.Frequencies.ContainsKey($patKey)) { $res.Frequencies[$patKey] } else { $null }
      $freqText = if ($freq -ne $null) {
        ([double]$freq).ToString('N2', [System.Globalization.CultureInfo]::InvariantCulture) + ' min'
      } else {
        'n/a'
      }

      $null=$html.AppendLine('<details><summary>'+ $patEsc +' - <span class="small">Count: '+$cnt+' - Frequency: '+$freqText+'</span></summary>')

      if ($res.Contexts.ContainsKey($patKey)) {
        $ctxItems = @($res.Contexts[$patKey])
        if ($ctxItems.Count -gt 0 -and ($ctxItems[0] -isnot [psobject] -or -not $ctxItems[0].PSObject.Properties.Match('Text'))) {
          $ctxItems = @($ctxItems | ForEach-Object { [PSCustomObject]@{ Time=$null; Line=0; Text=[string]$_ } })
        }
        $ctxOrdered = @(
          $ctxItems |
          Sort-Object -Property @{
            Expression = {
              if ($_ -is [psobject] -and $_.PSObject.Properties.Name -contains 'Time' -and $_.Time) {
                $_.Time
              } else {
                Get-Date '0001-01-01'
              }
            }
            Descending = $true
          }, @{
            Expression = {
              if ($_ -is [psobject] -and $_.PSObject.Properties.Name -contains 'Line') {
                $_.Line
              } else {
                -1
              }
            }
            Descending = $true
          }
        )
        $idx=1
        foreach($ci in $ctxOrdered){
          $null=$html.AppendLine("<h4>Example "+$idx+"</h4><pre>"+(HtmlEscape $ci.Text)+"</pre>")
          $idx++
        }
      }

      $null=$html.AppendLine('</details>')
    }
    $null=$html.AppendLine('</details>')

    # CSV (pattern summary per file)
    $csvPath=Join-Path $collectDir ($fname+'_ErrorSummary.csv')
    $res.Patterns.GetEnumerator()|Sort-Object Value -Descending|
      Select-Object @{n='Pattern';e={$_.Key}},@{n='Count';e={$_.Value}},@{n='FrequencyMin';e={$res.Frequencies[$_.Key]}} |
      Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath
  }

  # ---- Finalize HTML name per requested format ----
  $hostFrag  = if ($agentMeta) { ValueOr $agentMeta.Hostname $env:COMPUTERNAME } else { $env:COMPUTERNAME }
  $agentFrag = if ($agentMeta) { ValueOr $agentMeta.AgentID 'unknown-agent' } else { 'unknown-agent' }
  $lastLogTS = if ($overallLatest -and $overallLatest -gt (Get-Date '1900-01-01')) { $overallLatest } else { Get-Date }
  $lastLogStr = $lastLogTS.ToString('yyyyMMdd_HHmmss')
  $safe = { param($s) ([string]$s -replace '[^\w\.-]','_') }
  $fileName = ('CS-logreview-Host-{0}-Agendid-{1}-lastlogdate-{2}.html' `
              -f (&$safe $hostFrag), (&$safe $agentFrag), $lastLogStr)

  $htmlPath=Join-Path $collectDir $fileName
  $bytes = [System.Text.Encoding]::UTF8.GetPreamble() + [System.Text.Encoding]::UTF8.GetBytes($html.ToString())
  [System.IO.File]::WriteAllBytes($htmlPath, $bytes)
  Write-OK ("Wrote HTML report: $htmlPath")
  try{ Start-Process $htmlPath }catch{}
}

# -------- UI (loops back; Q runs launcher) --------
function Start-AgentLogReview {
  while ($true) {
    Clear-Host
    Show-Header -Title 'ConnectSecure Technicians Toolbox'
    Write-Host ' Tool: Agent Log Review' -ForegroundColor Cyan
    Write-Host ''
    Write-Host ' [1] Scan default agent log folder' -ForegroundColor White
    Write-Host ("     - {0}" -f $DefaultLogsRoot) -ForegroundColor DarkGray
    Write-Host ' [2] Scan another FOLDER' -ForegroundColor White
    Write-Host ' [Q] Quit to Toolbox Launcher' -ForegroundColor White
    Write-Host ''
    $choice=Read-Host 'Select an option (1/2/Q)'

    switch($choice.ToUpper()) {
      '1'{
        Collect-And-Report -Roots @($DefaultLogsRoot)
        Write-Host ''
        Read-Host 'Done. Press Enter to return to the menu...'
        continue
      }
      '2'{
        $folder = Read-Host ("Enter folder to scan (Enter for default: {0})" -f $DefaultLogsRoot)
        if ([string]::IsNullOrWhiteSpace($folder)) { $folder = $DefaultLogsRoot }
        $folder = Normalize-PathInput -Raw $folder
        $folderQ = '"' + $folder + '"'
        if (Test-Path -LiteralPath $folder -PathType Container) {
          Collect-And-Report -Roots @($folder)
        } else {
          Write-Warn ("Folder not found: {0}" -f $folderQ)
        }
        Write-Host ''
        Read-Host 'Done. Press Enter to return to the menu...'
        continue
      }
      'Q'{
        if (Test-Path -LiteralPath $LauncherPath) {
          Write-Info ("Launching: {0}" -f $LauncherPath)
          & $LauncherPath
        } else {
          Write-Warn ("Launcher not found: {0}" -f $LauncherPath)
        }
        return
      }
      Default{
        Write-Warn 'Invalid choice.'
        Start-Sleep -Milliseconds 900
        continue
      }
    }
  }
}

Start-AgentLogReview
