# ╔════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Update Agent Tool                             ║
# ║ Version: 1.1 | 2025-08-07                                     ║
# ║ Agent version check, update pull, and service restart logic   ║
# ╚════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-AgentUpdate {
    Show-Header "ConnectSecure Agent Updater"

    $agentPath    = "C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe"
    $agentFolder  = "C:\Program Files (x86)\CyberCNSAgent"
    $shouldUpdate = $true
    $logPath      = Join-Path $Global:ExportRoot "AgentUpdate-Log.txt"

    Write-Log "Stopping CyberCNS services..." $logPath
    Stop-Service -Name "cybercnsagent" -Force -ErrorAction SilentlyContinue
    Stop-Service -Name "cybercnsagentmonitor" -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 3

    if (Test-Path $agentPath) {
        try {
            $versionOutput = & $agentPath -v
            Write-Log "Detected version info: $versionOutput" $logPath

            $versionArray = $versionOutput -split '\s+'
            $version = $versionArray[-1]

            if ([version]$version -ge [version]"4.3.62") {
                Write-Log "CyberCNSAgent is already up to date (version $version)." $logPath
                Write-SessionSummary "Agent already up to date ($version)"
                $shouldUpdate = $false
            } else {
                Write-Log "Outdated version detected: $version. Proceeding with update..." $logPath
            }
        } catch {
            Write-Log "⚠️ Version check failed. Proceeding with update..." $logPath
        }
    } else {
        Write-Log "Agent executable not found. Proceeding with fresh install..." $logPath
    }

    if ($shouldUpdate) {
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            $source = (Invoke-RestMethod -Method "Get" -Uri "https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows")
            Write-Log "Downloading agent from: $source" $logPath

            Invoke-WebRequest -Uri $source -OutFile $agentPath -UseBasicParsing
            Write-Log "✅ Agent downloaded and replaced successfully." $logPath
            Write-SessionSummary "Agent updated from $source"
        } catch {
            Write-Log "❌ Download failed: $($_.Exception.Message)" $logPath
            Write-SessionSummary "❌ Agent update failed: $($_.Exception.Message)"
        }
    }

    Write-Log "Restarting CyberCNS services..." $logPath
    Start-Service -Name "cybercnsagent" -ErrorAction SilentlyContinue
    Start-Service -Name "cybercnsagentmonitor" -ErrorAction SilentlyContinue

    Write-ExportPath $logPath
    Pause-Script
}

# Run the updater
Run-AgentUpdate
