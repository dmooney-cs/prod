# ============================
# Agent-Update-Tool.ps1  (ASCII-only, PS 5.1 safe)
# ============================

# Logic per project note (2025-08-08/09):
# - Detect installed version via: cybercnsagent.exe -v (parse "CyberCNS Agent X.Y.Z")
# - Download latest via API link (no local EXE lookup)
# - Extract downloaded EXE version from file metadata
# - Compare; if newer, prompt Y/N to update
# - Stop services before update; start after
# - Pause and return to menu

# Load shared functions
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (-not (Test-Path $commonPath)) { Write-Host "[ERROR] Functions-Common.ps1 not found." -ForegroundColor Red; Pause-Script "Press any key..."; return }
try { . $commonPath } catch { Write-Host "[ERROR] Failed to load Functions-Common.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script "Press any key..."; return }
Ensure-ExportFolder

$Hostname        = $env:COMPUTERNAME
$Stamp           = Get-Date -Format "yyyyMMdd_HHmmss"
$ExportRoot      = "C:\CS-Toolbox-TEMP\Collected-Info"
$DownloadRoot    = "C:\CS-Toolbox-TEMP\Downloads"
$InstallerPath   = Join-Path $DownloadRoot "cybercnsagent.exe"
$TranscriptPath  = Join-Path $ExportRoot ("{0}-AgentUpdate-{1}.log" -f $Hostname,$Stamp)
$AgentApiUrl     = "https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows"
$AgentExe        = "C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe"

$TranscriptStarted = $false
try { Start-Transcript -Path $TranscriptPath -Append -ErrorAction Stop | Out-Null; $TranscriptStarted=$true } catch {}

function New-Folder([string]$Path){ if(-not(Test-Path -LiteralPath $Path)){ try{ New-Item -ItemType Directory -Path $Path -Force | Out-Null }catch{} } }

function Get-InstalledVersion {
    if (Test-Path -LiteralPath $AgentExe) {
        try {
            $tmp = Join-Path $env:TEMP "_agent_ver.txt"
            $p = Start-Process -FilePath $AgentExe -ArgumentList "-v" -NoNewWindow -RedirectStandardOutput $tmp -Wait -PassThru
            $out = Get-Content $tmp -ErrorAction SilentlyContinue
            Remove-Item $tmp -Force -ErrorAction SilentlyContinue
            if ($out) {
                $line = ($out | Select-Object -First 1)
                if ($line -match 'CyberCNS Agent\s+([0-9\.]+)') { return $matches[1] }
            }
        } catch {}
        try {
            $ver = (Get-Item $AgentExe).VersionInfo.ProductVersion
            if ($ver) { return $ver }
        } catch {}
    }
    return $null
}

function Get-AgentUrl {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
    try {
        $url = Invoke-RestMethod -Method Get -Uri $AgentApiUrl -ErrorAction Stop
        if ([string]::IsNullOrWhiteSpace($url)) { throw "API returned empty URL." }
        return $url
    } catch { Write-Host ("[ERROR] Failed to get agent URL: {0}" -f $_.Exception.Message) -ForegroundColor Red; return $null }
}

function Download-LatestInstaller {
    param([string]$Url,[string]$Destination)
    New-Folder (Split-Path -Parent $Destination)
    if(Test-Path -LiteralPath $Destination){ try{ Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue }catch{} }
    Write-Host ("Downloading latest installer to {0} ..." -f $Destination) -ForegroundColor Cyan
    try {
        Invoke-WebRequest -Uri $Url -OutFile $Destination -UseBasicParsing -ErrorAction Stop
        if(-not(Test-Path -LiteralPath $Destination)){ throw "Download completed but file not found." }
        Write-Host "[OK] Downloaded latest installer." -ForegroundColor Green
        return $true
    } catch { Write-Host ("[ERROR] Download failed: {0}" -f $_.Exception.Message) -ForegroundColor Red; return $false }
}

function Get-FileVersionString([string]$Path){
    try {
        if(Test-Path -LiteralPath $Path){
            $vi = (Get-Item $Path).VersionInfo
            # Prefer ProductVersion; fallback FileVersion
            $v = if($vi.ProductVersion){$vi.ProductVersion}else{$vi.FileVersion}
            if($v){ return $v }
        }
    } catch {}
    return $null
}

function Compare-Version {
    param([string]$A,[string]$B)
    # returns -1 if A<B, 0 if A==B, 1 if A>B
    if([string]::IsNullOrWhiteSpace($A) -and [string]::IsNullOrWhiteSpace($B)){ return 0 }
    if([string]::IsNullOrWhiteSpace($A)){ return -1 }
    if([string]::IsNullOrWhiteSpace($B)){ return 1 }
    try {
        $va = [Version]$A
        $vb = [Version]$B
        return $va.CompareTo($vb)
    } catch {
        # fallback string compare if parse fails
        return [System.String]::Compare($A,$B)
    }
}

function Stop-AgentServices{
    foreach($n in @("CyberCNSAgent","ConnectSecureAgentMonitor")){
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if($svc -and $svc.Status -ne 'Stopped'){
            Write-Host ("Stopping service {0} ..." -f $n) -ForegroundColor Yellow
            try { Stop-Service -Name $n -Force -ErrorAction Stop; $svc.WaitForStatus('Stopped','00:00:20'); Write-Host ("[OK] {0} stopped" -f $n) -ForegroundColor Green } catch { Write-Host ("[WARN] Could not stop {0}: {1}" -f $n, $_.Exception.Message) -ForegroundColor Yellow }
        }
    }
}
function Start-AgentServices{
    foreach($n in @("CyberCNSAgent","ConnectSecureAgentMonitor")){
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if($svc){
            if($svc.Status -ne 'Running'){
                Write-Host ("Starting service {0} ..." -f $n) -ForegroundColor Cyan
                try { Start-Service -Name $n -ErrorAction Stop; $svc.WaitForStatus('Running','00:00:25'); Write-Host ("[OK] {0} is Running" -f $n) -ForegroundColor Green } catch { Write-Host ("[ERROR] Failed to start {0}: {1}" -f $n, $_.Exception.Message) -ForegroundColor Red }
            } else { Write-Host ("[OK] {0} already Running" -f $n) -ForegroundColor Green }
        } else { Write-Host ("[INFO] Service {0} not found" -f $n) -ForegroundColor DarkGray }
    }
}

function Invoke-AgentUpdate {
    Show-Header "Agent Update Tool"

    $installed = Get-InstalledVersion
    Write-Host ("Installed Version: {0}" -f (if($installed){$installed}else{"Unknown"}))

    $url = Get-AgentUrl
    if(-not $url){ Pause-Script "Press any key to return..."; return }

    if(-not (Download-LatestInstaller -Url $url -Destination $InstallerPath)){ Pause-Script "Press any key to return..."; return }

    $latest = Get-FileVersionString -Path $InstallerPath
    Write-Host ("Latest Available: {0}" -f (if($latest){$latest}else{"Unknown"}))

    $cmp = Compare-Version -A $installed -B $latest
    if ($cmp -ge 0) {
        Write-Host "[INFO] No update needed. Installed version is current or newer." -ForegroundColor Green
        Pause-Script "Press any key to return..."
        return
    }

    $ans = Read-Host "Update available. Proceed with update now? (Y/N)"
    if ($ans -notmatch '^[Yy]$') {
        Write-Host "Update canceled." -ForegroundColor Yellow
        Pause-Script "Press any key to return..."
        return
    }

    Stop-AgentServices

    # Silent install/update flags are the same invocation as install; the agent handles update
    Write-Host "Running updater..." -ForegroundColor Cyan
    try {
        $proc = Start-Process -FilePath $InstallerPath -ArgumentList "-i" -Wait -PassThru -WindowStyle Hidden
        if($proc.ExitCode -eq 0){ Write-Host "[OK] Update completed successfully." -ForegroundColor Green }
        else { Write-Host ("[ERROR] Update failed (Exit Code: {0})." -f $proc.ExitCode) -ForegroundColor Red }
    } catch { Write-Host ("[ERROR] Failed to start updater: {0}" -f $_.Exception.Message) -ForegroundColor Red }

    Start-AgentServices
    Pause-Script "Press any key to return..."
}

try { Invoke-AgentUpdate } finally {
    if($TranscriptStarted){ try { Stop-Transcript | Out-Null; Write-Host ("Log saved to: {0}" -f $TranscriptPath) -ForegroundColor DarkGray } catch {} }
}
