# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════╗
# ║ 🔄 CS Toolbox – Agent Update Tool                           ║
# ║ Version: 1.1 | Update CyberCNS Agent Only                   ║
# ╚═════════════════════════════════════════════════════════════╝

Ensure-ExportFolder

function Get-AgentVersion {
    $logPath = "C:\Program Files (x86)\CyberCNSAgent\logs\cybercns.txt"
    if (Test-Path $logPath) {
        $versionLine = Select-String -Path $logPath -Pattern "Agent Version\s+:\s+(\S+)" | Select-Object -First 1
        if ($versionLine) {
            return ($versionLine.Matches.Groups[1].Value)
        }
    }
    return "Unknown"
}

function Run-AgentUpdate {
    Show-Header "Update CyberCNS Agent"

    $currentVersion = Get-AgentVersion
    Write-Host "📦 Current Agent Version: $currentVersion" -ForegroundColor Cyan

    $installerUrl = "https://cybercns-agent-installer.s3.amazonaws.com/CyberCNSAgentInstaller.exe"
    $installerPath = "$env:TEMP\CyberCNSAgentInstaller.exe"

    Write-Host "`n⬇ Downloading latest installer..."
    try {
        Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath -UseBasicParsing
        Write-Host "✅ Downloaded: $installerPath" -ForegroundColor Green
    } catch {
        Write-Host "❌ Failed to download installer: $_" -ForegroundColor Red
        Pause-Script
        return
    }

    Write-Host "`n🔄 Launching update installer..."
    try {
        Start-Process -FilePath $installerPath -ArgumentList "/SILENT" -Wait
        Write-Host "`n✅ Update process completed." -ForegroundColor Green
        Write-SessionSummary "Agent updated using latest installer"
    } catch {
        Write-Host "❌ Error running installer: $_" -ForegroundColor Red
        Write-SessionSummary "Agent update failed"
    }

    Pause-Script
}

function Show-AgentUpdateMenu {
    do {
        Clear-Host
        Show-Header "CS Toolbox – Agent Update Tool"

        Write-Host " [1] Update CyberCNS Agent"
        Write-Host ""
        Write-Host " [Q] Quit to Agent Menu"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice.ToUpper()) {
            "1" { Run-AgentUpdate }
            "Q" { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Pause-Script
            }
        }
    } while ($true)
}

Show-AgentUpdateMenu
