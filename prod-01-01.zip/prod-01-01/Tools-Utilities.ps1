# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Utilities                                   ║
# ║ Version: U.2 | Services + Disk Space                        ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-ServiceAudit {
    Show-Header "Running Services Audit"
    $services = Get-Service | Where-Object { $_.Status -eq 'Running' } |
        Select-Object DisplayName, Name, StartType, Status
    $outPath = Export-Data -Object $services -BaseName "RunningServices"
    Write-ExportPath $outPath
    Write-SessionSummary "Exported running services list"
    Pause-Script
}

function Run-DiskUsageReport {
    Show-Header "Disk Space Report"
    $disks = Get-PSDrive -PSProvider FileSystem | 
        Select-Object Name, @{Name="Size(GB)";Expression={"{0:N1}" -f ($_.Used + $_.Free)/1GB}},
                               @{Name="Used(GB)";Expression={"{0:N1}" -f $_.Used/1GB}},
                               @{Name="Free(GB)";Expression={"{0:N1}" -f $_.Free/1GB}},
                               @{Name="Free(%)";Expression={"{0:N0}" -f (($_.Free/($_.Used + $_.Free)) * 100)}}
    $outPath = Export-Data -Object $disks -BaseName "DiskSpaceReport"
    Write-ExportPath $outPath
    Write-SessionSummary "Disk space report generated"
    Pause-Script
}

function Run-AllUtilities {
    Show-Header "Running All Utility Tools"

    $services = Get-Service | Where-Object { $_.Status -eq 'Running' } |
        Select-Object DisplayName, Name, StartType, Status
    Export-Data -Object $services -BaseName "RunningServices"
    Write-SessionSummary "Running services exported"

    $disks = Get-PSDrive -PSProvider FileSystem | 
        Select-Object Name, @{Name="Size(GB)";Expression={"{0:N1}" -f ($_.Used + $_.Free)/1GB}},
                             @{Name="Used(GB)";Expression={"{0:N1}" -f $_.Used/1GB}},
                             @{Name="Free(GB)";Expression={"{0:N1}" -f $_.Free/1GB}},
                             @{Name="Free(%)";Expression={"{0:N0}" -f (($_.Free/($_.Used + $_.Free)) * 100)}}
    Export-Data -Object $disks -BaseName "DiskSpaceReport"
    Write-SessionSummary "Disk usage exported"

    Write-Host "`n✅ All utility checks completed." -ForegroundColor Green
    Pause-Script
}

function Run-ZipAndEmailResults {
    Show-Header "Zipping and Emailing Results"
    try {
        $zipPath = Zip-ExportFolder
        Send-ZipEmail -Attachment $zipPath
        Write-ExportPath $zipPath
        Write-SessionSummary "Zipped and launched email for results"
    } catch {
        Write-Host "❌ Error during ZIP/Email: $_" -ForegroundColor Red
        Write-SessionSummary "ZIP/email failed"
    }
    Pause-Script
}

function Run-CleanupExportFolder {
    Show-Header "Cleaning Up Export Folder"
    Cleanup-ExportFolder
    Write-SessionSummary "Export folder cleaned"
    Pause-Script
}

function Show-UtilitiesMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "           CS Toolbox – Utilities Menu"
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] List All Running Services"
        Write-Host " [2] Disk Space Report"
        Write-Host ""
        Write-Host " [5] Run All Utility Tools"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit to Main Menu"
        Write-Host ""
        $choice = Read-Host "Select an option"

        switch ($choice.ToUpper()) {
            '1' { Run-ServiceAudit }
            '2' { Run-DiskUsageReport }
            '5' { Run-AllUtilities }
            'Z' { Run-ZipAndEmailResults }
            'C' { Run-CleanupExportFolder }
            'Q' { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Pause-Script
            }
        }
    } while ($true)
}

# Run the utilities menu
Show-UtilitiesMenu
