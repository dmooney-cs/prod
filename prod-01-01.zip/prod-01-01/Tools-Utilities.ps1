# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ============================ Tools-Utilities.ps1 ============================
# CS Toolbox - Utilities
# Includes:
#  [1] Running Services
#  [2] Disk Space Usage
#  [3] Top Processes (CPU/Memory)
#  [4] Network Adapters & IP Config
#  [Q] Return to Launcher

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ExportRoot = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path $ExportRoot)) { New-Item -Path $ExportRoot -ItemType Directory | Out-Null }

function Get-Timestamp { (Get-Date).ToString("yyyy-MM-dd_HH-mm-ss") }
function New-ExportPath { param([Parameter(Mandatory)][string]$Prefix, [string]$Ext = "csv"); Join-Path $ExportRoot ("{0}_{1}.{2}" -f $Prefix, (Get-Timestamp), $Ext) }

# --------------------------- Running Services ---------------------------
function Invoke-RunningServices {
    Show-Header "Utilities - Running Services"
    $rows = Get-Service | Where-Object {$_.Status -eq 'Running'} | Select-Object Name, DisplayName, Status, StartType
    $outFile = New-ExportPath -Prefix "RunningServices"
    $rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    $rows | Format-Table Name, DisplayName, Status, StartType -AutoSize
    Write-Host ""
    Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green
    Pause-Script
}

# --------------------------- Disk Space ---------------------------
function Invoke-DiskSpace {
    Show-Header "Utilities - Disk Space Usage"
    try {
        $rows = Get-PSDrive -PSProvider FileSystem | ForEach-Object {
            [PSCustomObject]@{
                Name       = $_.Name
                Root       = $_.Root
                UsedGB     = [math]::Round(($_.Used/1GB),2)
                FreeGB     = [math]::Round(($_.Free/1GB),2)
                FreePct    = if ($_.Used -or $_.Free) { [math]::Round(($_.Free/($_.Used+$_.Free)*100),2) } else { 0 }
            }
        }
    } catch {
        Write-Host "Disk space query failed: $_" -ForegroundColor Yellow
        $rows = @()
    }

    $outFile = New-ExportPath -Prefix "DiskSpace"
    $rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    $rows | Format-Table Name, Root, UsedGB, FreeGB, FreePct -AutoSize
    Write-Host ""
    Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green
    Pause-Script
}

# --------------------------- Top Processes ---------------------------
function Invoke-TopProcesses {
    Show-Header "Utilities - Top Processes"
    try {
        $procs = Get-Process | Sort-Object CPU -Descending | Select-Object -First 20 `
            @{n='Name';e={$_.ProcessName}},
            @{n='CPU(s)';e={[math]::Round($_.CPU,2)}},
            @{n='MemoryMB';e={[math]::Round($_.WorkingSet/1MB,2)}},
            Id
    } catch {
        Write-Host "Process query failed: $_" -ForegroundColor Yellow
        $procs = @()
    }

    $outFile = New-ExportPath -Prefix "TopProcesses"
    $procs | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    $procs | Format-Table Name, 'CPU(s)', MemoryMB, Id -AutoSize
    Write-Host ""
    Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green
    Pause-Script
}

# --------------------------- Network Info ---------------------------
function Invoke-NetworkInfo {
    Show-Header "Utilities - Network Adapters"
    try {
        $rows = Get-NetIPAddress | Select-Object InterfaceAlias, IPAddress, AddressFamily, PrefixLength
    } catch {
        Write-Host "Network adapter query failed: $_" -ForegroundColor Yellow
        $rows = @()
    }

    $outFile = New-ExportPath -Prefix "NetworkInfo"
    $rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    $rows | Format-Table InterfaceAlias, IPAddress, AddressFamily, PrefixLength -AutoSize
    Write-Host ""
    Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green
    Pause-Script
}

# --------------------------- Menu ---------------------------
function Show-UtilitiesMenu {
    Clear-Host
    Show-Header "CS Tech Toolbox - Utilities"

    Write-Host ""
    Write-Host " [1] Running Services         - List of all running services"
    Write-Host " [2] Disk Space Usage         - Usage/free space for all drives"
    Write-Host " [3] Top Processes            - Top CPU/memory consuming processes"
    Write-Host " [4] Network Info             - Network adapters and IP config"
    Write-Host ""
    Write-Host " [Q] Return to Main Menu"
    Write-Host ""

    $choice = Read-Host "Enter choice"
    switch ($choice.Trim().ToUpperInvariant()) {
        '1' { Invoke-RunningServices; return $true }
        '2' { Invoke-DiskSpace; return $true }
        '3' { Invoke-TopProcesses; return $true }
        '4' { Invoke-NetworkInfo; return $true }
        'Q' { return $false }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
            return $true
        }
    }
}

# Entry point
do {
    $again = Show-UtilitiesMenu
} while ($again)
