# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    try {
        . $commonPath
    } catch {
        Write-Host "❌ ERROR: Exception occurred while loading Functions-Common.ps1"
        Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host "`nPress any key to exit..."
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        return
    }
} else {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "Expected path: $commonPath"
    Write-Host "`nThis script cannot continue without common functions."
    Write-Host "`nPress any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Utilities                                              ║
# ║ Version: U.2 | Running Services + Disk Space                               ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

Ensure-ExportFolder

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`nExported to: $Path" -ForegroundColor Cyan
}

function Get-RunningServices {
    Show-Header "Running Services"
    $services = Get-Service | Where-Object {$_.Status -eq 'Running'} |
        Select-Object DisplayName, Name, StartType, Status
    Export-Data -Object $services -BaseName "Running-Services"
    Pause-Script
}

function Get-DiskUsage {
    Show-Header "Disk Space Usage"
    $disks = Get-WmiObject Win32_LogicalDisk -Filter "DriveType=3" |
        Select-Object DeviceID, @{Name="Size(GB)";Expression={[math]::round($_.Size / 1GB, 2)}},
                      @{Name="Free(GB)";Expression={[math]::round($_.FreeSpace / 1GB, 2)}},
                      @{Name="Used(GB)";Expression={[math]::round(($_.Size - $_.FreeSpace) / 1GB, 2)}},
                      @{Name="Used(%)";Expression={[math]::Round((($_.Size - $_.FreeSpace)/$_.Size)*100, 2)}}
    Export-Data -Object $disks -BaseName "Disk-Space"
    Pause-Script
}

function Show-UtilitiesMenu {
    Clear-Host
    Write-Host "====================================================="
    Write-Host "     CS Toolbox - Utilities"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] List Running Services"
    Write-Host " [2] Check Disk Space Usage"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

# Main Loop
do {
    Show-UtilitiesMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Get-RunningServices }
        '2' { Get-DiskUsage }
        'Z' { Invoke-ZipAndEmailResults }
        'C' { Invoke-CleanupExport }
        'Q' { return }
        default {
            Write-Host "`nInvalid selection. Please choose again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
