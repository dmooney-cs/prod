# ╔═════════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – CyberCNS Agent V4 Uninstall Tool                            ║
# ║ Version: 1.2 | Multi-method Uninstaller + Service Cleanup + Export              ║
# ╚═════════════════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Show-UninstallMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "        CS Toolbox - Uninstall Agent V4 Tool"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Fully Uninstall CyberCNS Agent V4"
    Write-Host ""
    Write-Host " [C] Cleanup and Delete All Toolbox Data"
    Write-Host " [Q] Back to Agent Menu"
    Write-Host ""
}

function Run-AgentUninstall {
    Show-Header "Uninstalling CyberCNS Agent V4"
    $log = @()

    # 1. Run uninstall.bat
    $batPath = "C:\Program Files (x86)\CyberCNSAgent\uninstall.bat"
    if (Test-Path $batPath) {
        try {
            Start-Process -FilePath $batPath -Wait
            $log += [PSCustomObject]@{ Step = "Uninstall.bat"; Result = "✅ Executed: $batPath" }
        } catch {
            $log += [PSCustomObject]@{ Step = "Uninstall.bat"; Result = "❌ Failed: $_" }
        }
    } else {
        $log += [PSCustomObject]@{ Step = "Uninstall.bat"; Result = "⚠ Not found: $batPath" }
    }

    # 2. Try MSI uninstall
    $productName = "CyberCNS Agent"
    try {
        $package = Get-WmiObject -Class Win32_Product | Where-Object { $_.Name -like "*$productName*" }
        if ($package) {
            $package.Uninstall() | Out-Null
            $log += [PSCustomObject]@{ Step = "MSI Uninstall"; Result = "✅ Removed via WMI: $($package.Name)" }
        } else {
            $log += [PSCustomObject]@{ Step = "MSI Uninstall"; Result = "⚠ Not found: $productName" }
        }
    } catch {
        $log += [PSCustomObject]@{ Step = "MSI Uninstall"; Result = "❌ Error: $_" }
    }

    # 3. Run CyberCNSAgentUninstaller.exe
    $exePath = "C:\Program Files (x86)\CyberCNSAgent\CyberCNSAgentUninstaller.exe"
    if (Test-Path $exePath) {
        try {
            Start-Process -FilePath $exePath -ArgumentList "/S" -Wait
            $log += [PSCustomObject]@{ Step = "Uninstaller.exe"; Result = "✅ Ran: $exePath" }
        } catch {
            $log += [PSCustomObject]@{ Step = "Uninstaller.exe"; Result = "❌ Failed: $_" }
        }
    } else {
        $log += [PSCustomObject]@{ Step = "Uninstaller.exe"; Result = "⚠ Not found: $exePath" }
    }

    # 4. Stop & delete services
    $services = @("CyberCNSAgent", "CyberCNSAgentMonitor")
    foreach ($svc in $services) {
        try {
            if (Get-Service -Name $svc -ErrorAction SilentlyContinue) {
                Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue
                sc.exe delete $svc | Out-Null
                $log += [PSCustomObject]@{ Step = "Service: $svc"; Result = "✅ Stopped & Deleted" }
            } else {
                $log += [PSCustomObject]@{ Step = "Service: $svc"; Result = "⚠ Not installed" }
            }
        } catch {
            $log += [PSCustomObject]@{ Step = "Service: $svc"; Result = "❌ Failed: $_" }
        }
    }

    # 5. Remove leftover folder
    $folder = "C:\Program Files (x86)\CyberCNSAgent"
    try {
        if (Test-Path $folder) {
            Remove-Item $folder -Recurse -Force
            $log += [PSCustomObject]@{ Step = "Folder Cleanup"; Result = "✅ Removed $folder" }
        } else {
            $log += [PSCustomObject]@{ Step = "Folder Cleanup"; Result = "⚠ Not found" }
        }
    } catch {
        $log += [PSCustomObject]@{ Step = "Folder Cleanup"; Result = "❌ Failed: $_" }
    }

    # 6. Export uninstall log and session summary
    $outPath = Export-Data -Object $log -BaseName "UninstallLog"
    Write-ExportPath $outPath
    Write-SessionSummary "Uninstalled CyberCNS Agent V4"
    Pause-Script
}

do {
    Show-UninstallMenu
    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        '1' { Run-AgentUninstall }
        'C' { Run-CleanupExportFolder; Write-SessionSummary "Export folder cleaned" }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
