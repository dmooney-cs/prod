# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host ("ERROR: Failed to load Functions-Common.ps1: {0}" -f $_) -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder
Show-Header "Uninstall CyberCNS Agent v4"

function Stop-AgentServices {
    $names = @("CyberCNSAgent","CyberCNS Updater")
    foreach ($n in $names) {
        try {
            Write-Host ("Stopping service: {0}" -f $n)
            Stop-Service -Name $n -ErrorAction SilentlyContinue -Force
        } catch {}
    }
    Start-Sleep -Seconds 2
}

function Kill-AgentProcesses {
    $procs = @("cybercnsagent","cybercnsagent.exe","cybercnsupdater","cybercnsupdater.exe")
    foreach ($p in $procs) {
        try { Get-Process -Name $p -ErrorAction SilentlyContinue | Stop-Process -Force } catch {}
    }
}

function Get-UninstallEntry {
    $paths = @(
        "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
        "HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*"
    )
    foreach ($path in $paths) {
        try {
            $items = Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
            foreach ($i in $items) {
                $name = [string]$i.DisplayName
                if ($name -and ($name -match "CyberCNS")) {
                    return $i
                }
            }
        } catch {}
    }
    return $null
}

function Invoke-Uninstall {
    $entry = Get-UninstallEntry
    if ($null -eq $entry) {
        Write-Host "No uninstall entry for CyberCNS found in registry." -ForegroundColor Yellow
        return $false
    }

    $cmd = [string]$entry.UninstallString
    if (-not $cmd) {
        Write-Host "UninstallString missing in registry entry." -ForegroundColor Yellow
        return $false
    }

    Write-Host ("Executing uninstall: {0}" -f $cmd) -ForegroundColor Cyan
    try {
        if ($cmd -match "msiexec\.exe") {
            # Ensure quiet flags
            if ($cmd -notmatch "/quiet" -and $cmd -notmatch "/qn") { $cmd += " /qn" }
            Start-Process -FilePath "cmd.exe" -ArgumentList "/c", $cmd -Wait
        } else {
            Start-Process -FilePath "cmd.exe" -ArgumentList "/c", $cmd -Wait
        }
        return $true
    } catch {
        Write-Host ("ERROR during uninstall: {0}" -f $_.Exception.Message) -ForegroundColor Red
        return $false
    }
}

try {
    Stop-AgentServices
    Kill-AgentProcesses
    $ok = Invoke-Uninstall
    if ($ok) {
        Write-Host "Uninstall finished. It is recommended to reboot if services or files remain." -ForegroundColor Green
    } else {
        Write-Host "Uninstall not completed. Please review messages above." -ForegroundColor Yellow
    }
} catch {
    Write-Host ("ERROR: Unexpected failure: {0}" -f $_) -ForegroundColor Red
} finally {
    Pause-Script
}