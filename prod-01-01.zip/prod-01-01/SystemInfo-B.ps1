# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – System Info B                                          ║
# ║ Version: B.2 | Pending Reboot + Startup Programs + App Crash Logs          ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

Ensure-ExportFolder

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}

function Get-PendingRebootStatus {
    Show-Header "Pending Reboot Status"

    $result = @{
        "PendingFileRenameOperations" = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name "PendingFileRenameOperations" -ErrorAction SilentlyContinue).PendingFileRenameOperations
        "WindowsUpdate" = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired' -ErrorAction SilentlyContinue)
        "ComponentBasedServicing" = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending' -ErrorAction SilentlyContinue)
    }

    Export-Data -Object $result -BaseName "PendingRebootStatus"
    Pause-Script
}

function Get-StartupPrograms {
    Show-Header "Startup Programs"

    $startup = Get-CimInstance -ClassName Win32_StartupCommand |
        Select-Object Name, Command, Location, User

    Export-Data -Object $startup -BaseName "StartupPrograms"
    Pause-Script
}

function Get-AppCrashLogs {
    Show-Header "Application Crash Logs (Last 7 Days)"

    $startDate = (Get-Date).AddDays(-7)
    $crashEvents = Get-WinEvent -FilterHashtable @{
        LogName = 'Application'
        StartTime = $startDate
        Id = 1000
    } -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, ProviderName, Id, Message

    Export-Data -Object $crashEvents -BaseName "AppCrashLogs"
    Pause-Script
}

function Show-SystemInfoBMenu {
    Clear-Host
    Write-Host "====================================================="
    Write-Host "     CS Toolbox - System Info B"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Check Pending Reboot Status"
    Write-Host " [2] List Startup Programs"
    Write-Host " [3] View Application Crash Logs (7 Days)"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

# Main Loop
do {
    Show-SystemInfoBMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Get-PendingRebootStatus }
        '2' { Get-StartupPrograms }
        '3' { Get-AppCrashLogs }
        'Z' { Invoke-ZipAndEmailResults }
        'C' { Invoke-CleanupExport }
        'Q' { return }
        default { Write-Host "`nInvalid selection. Please choose again." -ForegroundColor Yellow }
    }
} while ($true)
