# ╔════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – System Info B                                     ║
# ║ Version: B.3 | Pending Reboot, App Logs, Autostart Audit + ZIP/Cleanup ║
# ╚════════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}

function Run-PendingRebootCheck {
    Show-Header "Pending Reboot Detector"
    $pending = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending" -ErrorAction SilentlyContinue
    $result = @{ RebootStatus = if ($pending) { "Reboot required" } else { "No reboot required" } }
    $outPath = Export-Data -Object $result -BaseName "PendingReboot" -Ext "txt"
    Write-ExportPath $outPath
    Write-SessionSummary "Checked for pending reboot"
    Pause-Script
}

function Run-EventLogSummary {
    Show-Header "Summarize Application Event Logs (Last 7 Days)"
    $since = (Get-Date).AddDays(-7)
    $logs = Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$since} |
        Select-Object TimeCreated, Id, LevelDisplayName, Message
    $outPath = Export-Data -Object $logs -BaseName "AppEventLog"
    Write-ExportPath $outPath
    Write-SessionSummary "Exported Application Event Logs"
    Pause-Script
}

function Run-StartupAudit {
    Show-Header "Startup / Autostart Audit"
    $startup = Get-CimInstance -ClassName Win32_StartupCommand |
        Select-Object Name, Command, Location, User
    $outPath = Export-Data -Object $startup -BaseName "StartupItems"
    Write-ExportPath $outPath
    Write-SessionSummary "Captured Startup/Autostart programs"
    Pause-Script
}

function Run-AllSystemChecks {
    Show-Header "Running All System Info Checks"

    $pending = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending" -ErrorAction SilentlyContinue
    $result = @{ RebootStatus = if ($pending) { "Reboot required" } else { "No reboot required" } }
    Export-Data -Object $result -BaseName "PendingReboot" -Ext "txt"
    Write-SessionSummary "Reboot status exported"

    $since = (Get-Date).AddDays(-7)
    $logs = Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$since} |
        Select-Object TimeCreated, Id, LevelDisplayName, Message
    Export-Data -Object $logs -BaseName "AppEventLog"
    Write-SessionSummary "App logs exported"

    $startup = Get-CimInstance -ClassName Win32_StartupCommand |
        Select-Object Name, Command, Location, User
    Export-Data -Object $startup -BaseName "StartupItems"
    Write-SessionSummary "Startup list exported"

    Write-Host "`n✅ All system checks completed." -ForegroundColor Green
    Pause-Script
}

# Main Menu
do {
    Show-Header "System Info Tool – Reboot, Logs, Startup"

    Write-Host " [1] Check for Pending Reboot"
    Write-Host " [2] Summarize Application Event Logs (Last 7 Days)"
    Write-Host " [3] Startup / Autostart Audit"
    Write-Host " [4] Run All System Checks"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""

    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        '1' { Run-PendingRebootCheck }
        '2' { Run-EventLogSummary }
        '3' { Run-StartupAudit }
        '4' { Run-AllSystemChecks }
        'Z' { Invoke-ZipAndEmailResults }
        'C' { Cleanup-ExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
