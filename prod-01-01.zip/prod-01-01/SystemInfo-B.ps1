# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ============================ SystemInfo-B.ps1 ============================
# CS Toolbox - System Info B
# Includes:
#  [1] Pending Reboot Status
#  [2] Application / Event Log Review (Warning/Error)
#  [3] Startup Program Audit
#  [Q] Return to Launcher

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$ExportRoot = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path $ExportRoot)) { New-Item -Path $ExportRoot -ItemType Directory | Out-Null }

function Get-Timestamp { (Get-Date).ToString("yyyy-MM-dd_HH-mm-ss") }
function New-ExportPath { param([Parameter(Mandatory)][string]$Prefix, [string]$Ext = "csv"); Join-Path $ExportRoot ("{0}_{1}.{2}" -f $Prefix, (Get-Timestamp), $Ext) }

# --------------------------- Pending Reboot ---------------------------
function Get-PendingRebootStatus {
    [CmdletBinding()]
    param()

    $status = @{
        ComputerName          = $env:COMPUTERNAME
        PendingFileRename     = $false
        ComponentBasedServicing= $false
        WindowsUpdate         = $false
        PendingReboot         = $false
    }

    try {
        $reg = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
        if (Get-ItemProperty -Path $reg -Name PendingFileRenameOperations -ErrorAction SilentlyContinue) {
            $status.PendingFileRename = $true
        }
    } catch {}

    try {
        $reg = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
        if (Test-Path $reg) { $status.ComponentBasedServicing = $true }
    } catch {}

    try {
        $reg = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
        if (Test-Path $reg) { $status.WindowsUpdate = $true }
    } catch {}

    $status.PendingReboot = ($status.PendingFileRename -or $status.ComponentBasedServicing -or $status.WindowsUpdate)
    return [PSCustomObject]$status
}

function Invoke-PendingRebootCheck {
    Show-Header "System Info B - Pending Reboot Status"
    $row = Get-PendingRebootStatus
    $outFile = New-ExportPath -Prefix "PendingReboot"
    $row | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    $row | Format-List
    Write-Host ""
    Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green

    if ($row.PendingReboot) {
        Write-Host "⚠ System reboot is pending." -ForegroundColor Yellow
    } else {
        Write-Host "✅ No reboot pending." -ForegroundColor DarkGreen
    }
    Pause-Script
}

# --------------------------- Application / Event Log ---------------------------
function Get-RecentEventLog {
    [CmdletBinding()]
    param(
        [string]$LogName = "Application",
        [int]$LastHours = 24
    )

    try {
        $since = (Get-Date).AddHours(-$LastHours)
        $entries = Get-WinEvent -FilterHashtable @{LogName=$LogName; StartTime=$since} -ErrorAction Stop |
            Where-Object { $_.LevelDisplayName -in @("Error","Warning") } |
            Select-Object TimeCreated, LevelDisplayName, Id, ProviderName, Message
        return $entries
    } catch {
        Write-Host "Failed to query event log: $_" -ForegroundColor Yellow
        return @()
    }
}

function Invoke-EventLogReview {
    Show-Header "System Info B - Application/Event Log Review"
    $hours = Read-Host "Enter hours back to scan (default 24)"
    if ([string]::IsNullOrWhiteSpace($hours)) { $hours = 24 } else { $hours = [int]$hours }

    $rows = Get-RecentEventLog -LogName "Application" -LastHours $hours
    $outFile = New-ExportPath -Prefix "EventLog_Application"
    $rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    if ($rows.Count -eq 0) {
        Write-Host "No warnings/errors found in Application log for last $hours hours." -ForegroundColor Green
    } else {
        Write-Host "=== Application Log Warnings/Errors (Last $hours hrs) ===" -ForegroundColor Cyan
        $rows | Format-Table TimeCreated, LevelDisplayName, Id, ProviderName -AutoSize
        Write-Host ""
        Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green
    }
    Pause-Script
}

# --------------------------- Startup Audit ---------------------------
function Get-StartupPrograms {
    [CmdletBinding()]
    param()

    $rows = @()
    try {
        $regPaths = @(
            "HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
            "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
        )
        foreach ($p in $regPaths) {
            if (Test-Path $p) {
                $vals = Get-ItemProperty -Path $p
                foreach ($name in $vals.PSObject.Properties.Name | Where-Object { $_ -ne "PSPath" -and $_ -ne "PSParentPath" -and $_ -ne "PSChildName" -and $_ -ne "PSDrive" -and $_ -ne "PSProvider" }) {
                    $rows += [PSCustomObject]@{
                        Location = $p
                        Name     = $name
                        Command  = $vals.$name
                    }
                }
            }
        }
    } catch {
        Write-Host "Startup registry query failed: $_" -ForegroundColor Yellow
    }

    try {
        $folderPaths = @(
            "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup",
            "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Startup"
        )
        foreach ($f in $folderPaths) {
            if (Test-Path $f) {
                Get-ChildItem -Path $f -File | ForEach-Object {
                    $rows += [PSCustomObject]@{
                        Location = $f
                        Name     = $_.Name
                        Command  = $_.FullName
                    }
                }
            }
        }
    } catch {
        Write-Host "Startup folder query failed: $_" -ForegroundColor Yellow
    }

    return ,$rows
}

function Invoke-StartupAudit {
    Show-Header "System Info B - Startup Audit"
    $rows = Get-StartupPrograms
    $outFile = New-ExportPath -Prefix "StartupPrograms"
    $rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    if ($rows.Count -eq 0) {
        Write-Host "No startup programs found." -ForegroundColor Green
    } else {
        Write-Host "=== Startup Programs ===" -ForegroundColor Cyan
        $rows | Format-Table Location, Name, Command -AutoSize
        Write-Host ""
        Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green
    }
    Pause-Script
}

# --------------------------- Menu ---------------------------
function Show-SystemInfoB-Menu {
    Clear-Host
    Show-Header "CS Tech Toolbox - System Info B"

    Write-Host ""
    Write-Host " [1] Pending Reboot Status     - Check registry & servicing flags"
    Write-Host " [2] Application/Event Log     - Warnings & Errors in last X hours"
    Write-Host " [3] Startup Audit             - Startup registry & folder items"
    Write-Host ""
    Write-Host " [Q] Return to Main Menu"
    Write-Host ""

    $choice = Read-Host "Enter choice"
    switch ($choice.Trim().ToUpperInvariant()) {
        '1' { Invoke-PendingRebootCheck; return $true }
        '2' { Invoke-EventLogReview; return $true }
        '3' { Invoke-StartupAudit; return $true }
        'Q' { return $false }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
            return $true
        }
    }
}

# Entry point
do {
    $again = Show-SystemInfoB-Menu
} while ($again)
