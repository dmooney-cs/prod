# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ======================
#  System Info B (Menu)
# ======================

$OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\SystemInfo'
if (-not (Test-Path $OutRoot)) {
    New-Item -Path $OutRoot -ItemType Directory | Out-Null
}

function Get-Timestamp { Get-Date -Format 'yyyyMMdd_HHmmss' }

# ---------------------------
# 1) Pending Reboot Status
# ---------------------------
function Test-RegKeyExists {
    param([string]$Path)
    try {
        $null = Get-Item -LiteralPath $Path -ErrorAction Stop
        return $true
    } catch { return $false }
}
function Test-RegValueExists {
    param([string]$Path, [string]$Name)
    try {
        $item = Get-ItemProperty -LiteralPath $Path -ErrorAction Stop
        return ($null -ne ($item.$Name))
    } catch { return $false }
}
function Run-PendingReboot {
    Show-Header "System Info B - Pending Reboot Status"
    $ts = Get-Timestamp
    $csv = Join-Path $OutRoot ("PendingReboot_" + $ts + ".csv")

    $checks = @()
    $checks += [PSCustomObject]@{
        Check = 'CBS RebootPending'
        Path  = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
        Result = Test-RegKeyExists 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
    }
    $checks += [PSCustomObject]@{
        Check = 'WindowsUpdate RebootRequired'
        Path  = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
        Result = Test-RegKeyExists 'HKLM:\Software\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
    }
    $checks += [PSCustomObject]@{
        Check = 'PendingFileRenameOperations'
        Path  = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
        Result = Test-RegValueExists 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' 'PendingFileRenameOperations'
    }
    $checks += [PSCustomObject]@{
        Check = 'ComputerName Rename Pending'
        Path  = 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName'
        Result = (Test-RegKeyExists 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName') -and
                 (Test-RegKeyExists 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName') -and
                 ((Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName' -ErrorAction SilentlyContinue).ComputerName -ne
                  (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName'      -ErrorAction SilentlyContinue).ComputerName)
    }
    $checks += [PSCustomObject]@{
        Check = 'Domain Join Pending (Netlogon)'
        Path  = 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\JoinDomain'
        Result = Test-RegValueExists 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon' 'JoinDomain'
    }
    $checks += [PSCustomObject]@{
        Check = 'Package Installer Pending'
        Path  = 'HKLM:\SOFTWARE\Microsoft\Updates'
        Result = (Get-ChildItem -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Updates' -ErrorAction SilentlyContinue | Measure-Object).Count -gt 0 -and
                 ($null -ne (Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Updates' -ErrorAction SilentlyContinue).Pending)
    }

    try {
        $checks | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
        $pending = ($checks | Where-Object { $_.Result -eq $true }).Count -gt 0
        Write-Host ("Pending reboot detected: {0}" -f ($pending)) -ForegroundColor (if ($pending) { 'Yellow' } else { 'Green' })
        $checks | Format-Table Check, Result, Path -AutoSize
        Write-Host "Saved: $csv" -ForegroundColor Green
    } catch {
        Write-Host "ERROR writing Pending Reboot CSV: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

# -----------------------------------------
# 2) Application & System Logs (last 7 days)
# -----------------------------------------
function Run-AppSystemLogs {
    Show-Header "System Info B - Application & System Logs (7 days)"
    $ts = Get-Timestamp
    $csvApp = Join-Path $OutRoot ("EventLog_Application_7d_" + $ts + ".csv")
    $csvSys = Join-Path $OutRoot ("EventLog_System_7d_" + $ts + ".csv")
    $evtxApp = Join-Path $OutRoot ("Application_" + $ts + ".evtx")
    $evtxSys = Join-Path $OutRoot ("System_" + $ts + ".evtx")

    $start = (Get-Date).AddDays(-7)

    try {
        # CSV exports via Get-WinEvent
        $app = Get-WinEvent -FilterHashtable @{ LogName='Application'; StartTime=$start } -ErrorAction SilentlyContinue
        $sys = Get-WinEvent -FilterHashtable @{ LogName='System';      StartTime=$start } -ErrorAction SilentlyContinue

        if ($app) {
            $app | Select-Object TimeCreated, Id, LevelDisplayName, ProviderName, MachineName, Message |
                Export-Csv -LiteralPath $csvApp -NoTypeInformation -Encoding UTF8
            Write-Host ("Application events exported: {0}" -f (($app | Measure-Object).Count)) -ForegroundColor Green
            Write-Host "Saved: $csvApp" -ForegroundColor Green
        } else {
            Write-Host "No Application events in last 7 days." -ForegroundColor Yellow
        }

        if ($sys) {
            $sys | Select-Object TimeCreated, Id, LevelDisplayName, ProviderName, MachineName, Message |
                Export-Csv -LiteralPath $csvSys -NoTypeInformation -Encoding UTF8
            Write-Host ("System events exported: {0}" -f (($sys | Measure-Object).Count)) -ForegroundColor Green
            Write-Host "Saved: $csvSys" -ForegroundColor Green
        } else {
            Write-Host "No System events in last 7 days." -ForegroundColor Yellow
        }

        # Also export raw EVTX using wevtutil if available (more portable for support)
        if (Get-Command wevtutil.exe -ErrorAction SilentlyContinue) {
            try {
                wevtutil epl Application "$evtxApp" | Out-Null
                Write-Host "Saved EVTX: $evtxApp" -ForegroundColor Green
            } catch { Write-Host "WARN: EVTX export (Application) failed: $($_.Exception.Message)" -ForegroundColor Yellow }

            try {
                wevtutil epl System "$evtxSys" | Out-Null
                Write-Host "Saved EVTX: $evtxSys" -ForegroundColor Green
            } catch { Write-Host "WARN: EVTX export (System) failed: $($_.Exception.Message)" -ForegroundColor Yellow }
        } else {
            Write-Host "wevtutil not available; EVTX export skipped." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR collecting event logs: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

# -----------------
# 3) Startup Audit
# -----------------
function Get-RegistryRunItems {
    param([string]$HivePath, [string]$View)
    $items = @()
    try {
        $base = "Registry::$HivePath"
        $keys = @('Software\Microsoft\Windows\CurrentVersion\Run','Software\Microsoft\Windows\CurrentVersion\RunOnce')
        foreach ($k in $keys) {
            $pth = Join-Path $base $k
            if (Test-Path $pth) {
                $props = Get-ItemProperty -LiteralPath $pth -ErrorAction SilentlyContinue
                if ($props) {
                    foreach ($p in $props.PSObject.Properties) {
                        if ($p.Name -in 'PSPath','PSParentPath','PSChildName','PSDrive','PSProvider') { continue }
                        $items += [PSCustomObject]@{
                            Hive     = $HivePath
                            View     = $View
                            Key      = $k
                            Name     = $p.Name
                            Command  = $p.Value
                        }
                    }
                }
            }
        }
    } catch {}
    return $items
}

function Run-StartupAudit {
    Show-Header "System Info B - Startup Audit"
    $ts = Get-Timestamp
    $csv = Join-Path $OutRoot ("Startup_Audit_" + $ts + ".csv")

    $all = @()

    # Startup folders (All Users and Current User)
    try {
        $paths = @(
            [Environment]::GetFolderPath('Startup'),
            "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Startup"
        )
        foreach ($p in $paths) {
            if (Test-Path $p) {
                Get-ChildItem -LiteralPath $p -File -ErrorAction SilentlyContinue | ForEach-Object {
                    $all += [PSCustomObject]@{
                        Hive    = 'Shell'
                        View    = 'N/A'
                        Key     = $p
                        Name    = $_.Name
                        Command = $_.FullName
                    }
                }
            }
        }
    } catch {}

    # Registry Run/RunOnce in HKCU and HKLM, both 64 and 32 views
    $origView = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, [Microsoft.Win32.RegistryView]::Default)
    try {
        $all += Get-RegistryRunItems -HivePath 'HKEY_CURRENT_USER' -View 'Default'
        $all += Get-RegistryRunItems -HivePath 'HKEY_LOCAL_MACHINE' -View 'Default'

        # 64-bit view
        $all += Get-RegistryRunItems -HivePath 'HKEY_LOCAL_MACHINE' -View '64-bit'
        # 32-bit view
        $all += Get-RegistryRunItems -HivePath 'HKEY_LOCAL_MACHINE' -View '32-bit'
    } catch {}

    try {
        if ($all.Count -gt 0) {
            $all | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
            Write-Host ("Startup entries exported: {0}" -f ($all.Count)) -ForegroundColor Green
            $all | Select-Object Hive, Key, Name, Command | Sort-Object Hive, Key, Name | Format-Table -AutoSize
            Write-Host "Saved: $csv" -ForegroundColor Green
        } else {
            Write-Host "No startup entries found." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR writing Startup CSV: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

function Show-Menu {
    Clear-Host
    Show-Header "System Info B"

    Write-Host ""
    Write-Host " [1] Pending Reboot Status      - Registry checks and summary" -ForegroundColor White
    Write-Host " [2] Application & System Logs  - Last 7 days, CSV + EVTX" -ForegroundColor White
    Write-Host " [3] Startup Audit              - Startup folders and Run keys" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# Main loop
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Run-PendingReboot }
        '2' { Run-AppSystemLogs }
        '3' { Run-StartupAudit }
        'Q' {
            # Relaunch main CS Toolbox Launcher in same window
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path $launcher) {
                & $launcher
            }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}
