# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ===========================
#  Network Tools Main Script
# ===========================
Show-Header "CS Toolbox - Network Tools"

function Test-TLS10 {
    param([string]$TargetHost)
    Write-Host "[*] Testing TLS 1.0 support on $TargetHost ..." -ForegroundColor Cyan
    try {
        $tcp = New-Object Net.Sockets.TcpClient
        $tcp.Connect($TargetHost, 443)
        $ssl = New-Object Net.Security.SslStream($tcp.GetStream(), $false, ({ $true }))
        $ssl.AuthenticateAsClient($TargetHost, $null, [System.Security.Authentication.SslProtocols]::Tls, $false)
        Write-Host "[OK] $TargetHost supports TLS 1.0" -ForegroundColor Green
        $ssl.Dispose()
        $tcp.Close()
    } catch {
        Write-Host "[NO] $TargetHost does not support TLS 1.0" -ForegroundColor Yellow
    }
}

function Validate-SMB {
    param([string]$TargetHost)
    Write-Host "[*] Testing SMB protocol on $TargetHost ..." -ForegroundColor Cyan
    try {
        $result = Test-NetConnection -ComputerName $TargetHost -Port 445 -InformationLevel Detailed
        if ($result.TcpTestSucceeded) {
            Write-Host "[OK] SMB port (445) open on $TargetHost" -ForegroundColor Green
        } else {
            Write-Host "[NO] SMB port (445) closed on $TargetHost" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "[ERR] SMB test failed: $_" -ForegroundColor Red
    }
}

function Run-NetworkScanMenu {
    do {
        Clear-Host
        Show-Header "Network Tools"
        Write-Host "[1] TLS 1.0 Scan" -ForegroundColor White
        Write-Host "[2] Validate SMB" -ForegroundColor White
        Write-Host "[Q] Quit to Main Menu" -ForegroundColor White
        Write-Host ""
        $choice = Read-Host "Enter choice"

        switch ($choice.ToUpper()) {
            '1' {
                $host = Read-Host "Enter target host"
                Test-TLS10 -TargetHost $host
                Pause-Script
            }
            '2' {
                $host = Read-Host "Enter target host"
                Validate-SMB -TargetHost $host
                Pause-Script
            }
            'Q' { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

# Start the menu
Run-NetworkScanMenu
