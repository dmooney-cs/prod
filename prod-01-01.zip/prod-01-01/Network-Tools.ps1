# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ======================
#   Network Tools Menu
# ======================
function Show-Menu {
    Clear-Host
    Show-Header "Network Tools"

    Write-Host ""
    Write-Host " [1] TLS 1.0 Scan                - Detect legacy TLS support" -ForegroundColor White
    Write-Host " [2] SMB Validation              - Verify SMB protocol and settings" -ForegroundColor White
    Write-Host " [3] Other Network Tests          - Miscellaneous network utilities" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# Example placeholder functions for actual tool logic
function Run-TlsScan {
    Write-Host "Running TLS 1.0 scan..." -ForegroundColor Cyan
    Pause-Script "Press any key to return to menu..."
}
function Run-SmbValidation {
    Write-Host "Running SMB validation..." -ForegroundColor Cyan
    Pause-Script "Press any key to return to menu..."
}
function Run-OtherNetworkTests {
    Write-Host "Running other network tests..." -ForegroundColor Cyan
    Pause-Script "Press any key to return to menu..."
}

# Main loop
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Run-TlsScan }
        '2' { Run-SmbValidation }
        '3' { Run-OtherNetworkTests }
        'Q' {
            # Relaunch main CS Toolbox Launcher in same window
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path $launcher) {
                & $launcher
            }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}
