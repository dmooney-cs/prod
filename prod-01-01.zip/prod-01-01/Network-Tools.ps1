# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════════════╗
# ║ 🌐 CS Tech Toolbox – Network Tools                                  ║
# ║ Version: N.5 | 2025-08-07                                           ║
# ║ TLS 1.0 Nmap Scan, Validate SMB Tool, Test Admin Share             ║
# ╚═════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-TLSScanWithNmap {
    Show-Header "TLS 1.0 Cipher Scan via Nmap"
    $nmapPath = "C:\Program Files (x86)\CyberCNSAgent\nmap\nmap.exe"

    if (!(Test-Path $nmapPath)) {
        Write-Host "Nmap not found at: $nmapPath" -ForegroundColor Red
        Pause-Script
        return
    }

    $target = Read-Host "Enter target IP address"
    $output = & $nmapPath --script ssl-enum-ciphers -p 3389 $target
    $file = Join-Path $Global:ExportRoot "TLS-Nmap-Scan.txt"
    $output | Out-File -FilePath $file -Encoding UTF8
    Write-ExportPath $file
    Write-SessionSummary "TLS scan completed for $target"
    Pause-Script
}

function Run-ValidateSMB {
    Show-Header "Validate SMB Access with validatesmb.exe"

    $exePath = Join-Path $PSScriptRoot "validatesmb.exe"
    if (!(Test-Path $exePath)) {
        try {
            Invoke-WebRequest -Uri "https://betadev.mycybercns.com/agents/validatesmb/validatesmb.exe" -OutFile $exePath
        } catch {
            Write-Host "❌ Failed to download validatesmb.exe" -ForegroundColor Red
            Write-SessionSummary "Failed SMB tool download"
            Pause-Script
            return
        }
    }

    $domain = Read-Host "Enter FQDN Domain"
    $user = Read-Host "Enter Domain Username"
    $password = Read-Host "Enter Password" -AsSecureString
    $ip = Read-Host "Enter Target IP"

    $cred = New-Object System.Management.Automation.PSCredential ($user, $password)
    $command = "& `"$exePath`" validatesmb $domain $($cred.UserName) $($cred.GetNetworkCredential().Password) $ip"
    $result = Invoke-Expression $command

    $outFile = Join-Path $Global:ExportRoot "SMB-Validation.txt"
    $result | Out-File -FilePath $outFile -Encoding UTF8
    Write-ExportPath $outFile
    Write-SessionSummary "SMB validation run on $ip"
    Pause-Script
}

function Run-TestAdminShare {
    Show-Header "Test Admin$ Share Access"

    $targetIP = Read-Host "Enter IP address to test \\<ip>\admin$"
    $adminPath = "\\$targetIP\admin$"

    if (Test-Path $adminPath) {
        Write-Host "✅ Access to $adminPath successful." -ForegroundColor Green
    } else {
        Write-Host "❌ Could not access $adminPath" -ForegroundColor Red
    }

    $filePath = Join-Path $Global:ExportRoot "AdminShare-Test.txt"
    "Tested: $adminPath | Result: $(if (Test-Path $adminPath) {'Success'} else {'Failure'})" |
        Out-File -FilePath $filePath -Encoding UTF8
    Write-ExportPath $filePath
    Write-SessionSummary "Admin$ share test for $targetIP"
    Pause-Script
}

function Run-ZipAndEmailResults {
    Show-Header "Zipping and Emailing Results"
    try {
        $zipPath = Zip-ExportFolder
        Send-ZipEmail -Attachment $zipPath
        Write-ExportPath $zipPath
        Write-SessionSummary "Results zipped and email window opened"
    } catch {
        Write-Host "❌ Error during ZIP/Email: $_" -ForegroundColor Red
        Write-SessionSummary "ZIP/email failed: $_"
    }
    Pause-Script
}

function Run-CleanupExportFolder {
    Show-Header "Cleaning Up Export Folder"
    Cleanup-ExportFolder
    Write-SessionSummary "Export folder cleaned"
    Pause-Script
}

function Show-NetworkMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "         CS Toolbox - Network Tools Menu             "
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] TLS 1.0 Scan with Nmap"
        Write-Host " [2] Validate SMB with credentials"
        Write-Host " [3] Test \\admin$ share access"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice) {
            "1" { Run-TLSScanWithNmap }
            "2" { Run-ValidateSMB }
            "3" { Run-TestAdminShare }
            "Z" { Run-ZipAndEmailResults }
            "C" { Run-CleanupExportFolder }
            "Q" { return }
            default { Write-Host "Invalid selection. Try again." -ForegroundColor Yellow; Start-Sleep -Seconds 1 }
        }
    } while ($true)
}

Show-NetworkMenu
