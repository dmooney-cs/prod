# =========================
# Functions-Common.ps1  (R4 – PS 5.1 safe, no early-return guard)
# =========================
# NOTE: This file intentionally has NO early-return guard.
# It can be dot-sourced multiple times safely.

# --- Globals / Paths ---
$global:CS_TempRoot    = 'C:\CS-Toolbox-TEMP'
$global:CS_ExportRoot  = Join-Path $global:CS_TempRoot 'Collected-Info'
$global:CS_SupportMail = 'support@connectsecure.com'   # default support mailbox
$global:CS_CommonTag   = 'Common-2025-08-12 R4'        # shown in header

# --- Simple logger ---
function Write-Log {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )
    try {
        if (-not (Test-Path $global:CS_ExportRoot)) { New-Item -ItemType Directory -Path $global:CS_ExportRoot -Force | Out-Null }
        $logFile = Join-Path $global:CS_ExportRoot ("ToolboxLog_{0}.log" -f (Get-Date -Format 'yyyyMMdd'))
        $line = "[{0}] [{1}] {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
        Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
    } catch { }
}

# --- Pause helper (host-safe) ---
function Pause-Script {
    param([string]$Prompt = "Press any key to continue...")
    try {
        Write-Host $Prompt
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        Start-Sleep -Seconds 2
    }
}

# --- Header banner (PS 5.1 safe) ---
function Show-Header {
    param([Parameter(Mandatory=$true)][string]$Title)
    $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    $adminStr = if ($isAdmin) { 'True' } else { 'False' }
    $hostName = $env:COMPUTERNAME
    $userName = $env:USERNAME
    Write-Host ""
    Write-Host ("   {0}" -f $Title)
    Write-Host ("{0}" -f ('=' * 57))
    Write-Host (" Host: {0}   User: {1}   Admin: {2}   Common: {3}" -f $hostName, $userName, $adminStr, $global:CS_CommonTag)
    Write-Host ""
}

# --- Ensure export folder exists ---
function Ensure-ExportFolder {
    if (-not (Test-Path $global:CS_TempRoot))   { New-Item -ItemType Directory -Path $global:CS_TempRoot   -Force | Out-Null }
    if (-not (Test-Path $global:CS_ExportRoot)) { New-Item -ItemType Directory -Path $global:CS_ExportRoot -Force | Out-Null }
}

# --- Session summary (one-liner) ---
function Write-SessionSummary {
    try {
        Ensure-ExportFolder
        $path = Join-Path $global:CS_ExportRoot ("SessionSummary_{0}.txt" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
        $lines = @(
            "CS Toolbox Session Summary",
            "Timestamp: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
            "User: $env:USERNAME",
            "Host: $env:COMPUTERNAME"
        )
        Set-Content -LiteralPath $path -Value $lines -Encoding UTF8
        Write-Log "Session summary written: $path"
        Write-Host ("[{0}] [INFO] Session summary written: {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $path)
    } catch { }
}

# --- Outlook path helper ---
function Resolve-OutlookPath {
    try {
        $candidates = @(
            "$Env:ProgramFiles\Microsoft Office\root\Office16\OUTLOOK.EXE",
            "$Env:ProgramFiles(x86)\Microsoft Office\root\Office16\OUTLOOK.EXE",
            "$Env:ProgramFiles\Microsoft Office\Office16\OUTLOOK.EXE",
            "$Env:ProgramFiles(x86)\Microsoft Office\Office16\OUTLOOK.EXE"
        )
        foreach ($p in $candidates) { if (Test-Path $p) { return $p } }
    } catch { }
    return $null
}

# --- Compose email with Outlook COM (attachments supported) ---
function Start-OutlookCompose {
    param(
        [Parameter(Mandatory=$true)][string]$To,
        [Parameter(Mandatory=$true)][string]$Subject,
        [Parameter(Mandatory=$false)][string]$Body = "",
        [Parameter(Mandatory=$false)][string[]]$Attachments
    )

    try {
        $ol = $null
        try { $ol = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application') }
        catch { $ol = New-Object -ComObject Outlook.Application }
        if ($null -eq $ol) { throw "Outlook COM unavailable." }

        $mail = $ol.CreateItem(0)
        $mail.To = $To
        $mail.Subject = $Subject
        $mail.Body = $Body

        if ($Attachments) {
            foreach ($a in $Attachments) {
                if ($a -and (Test-Path $a)) { $mail.Attachments.Add($a) | Out-Null }
            }
        }
        $mail.Display($true) | Out-Null
        Write-Log "Outlook COM compose created with fields + attachment."
        Write-Host ("[{0}] [INFO] Outlook COM compose created with fields + attachment." -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
        return
    } catch {
        # Fallback to launching Outlook with /a (single attachment) then COM
        $outlookPath = Resolve-OutlookPath
        $pathShown = if ($outlookPath) { $outlookPath } else { '<none>' }
        Write-Host ("[{0}] [INFO] Resolve-OutlookPath => {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $pathShown)
        if ($outlookPath -and (Test-Path $outlookPath)) {
            $firstAttachment = $null
            if ($Attachments -and $Attachments.Count -gt 0) {
                $firstAttachment = $Attachments | Where-Object { Test-Path $_ } | Select-Object -First 1
            }
            if ($firstAttachment) {
                Start-Process -FilePath $outlookPath -ArgumentList @('/c','ipm.note','/a',"`"$firstAttachment`"") | Out-Null
                Start-Sleep -Seconds 2
                try {
                    $ol2 = [Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application')
                    if ($ol2) {
                        $inspector = $ol2.ActiveInspector()
                        if ($inspector -and $inspector.CurrentItem) {
                            $mail2 = $inspector.CurrentItem
                            $mail2.To = $To
                            $mail2.Subject = $Subject
                            $mail2.Body = $Body
                            if ($Attachments.Count -gt 1) {
                                foreach ($a in ($Attachments | Where-Object { $_ -ne $firstAttachment }) ) {
                                    if (Test-Path $a) { $mail2.Attachments.Add($a) | Out-Null }
                                }
                            }
                        }
                    }
                } catch { }
                return
            } else {
                Start-Process -FilePath $outlookPath | Out-Null
                return
            }
        } else {
            # Last-ditch mailto fallback (cannot attach)
            $mailto = "mailto:$To?subject=$( [uri]::EscapeDataString($Subject) )&body=$( [uri]::EscapeDataString($Body) )"
            Start-Process $mailto | Out-Null
        }
    }
}

# --- Utility: Zip a folder (UTF-8, overwrite) ---
function Invoke-ZipFolder {
    param(
        [Parameter(Mandatory=$true)][string]$SourcePath,
        [Parameter(Mandatory=$true)][string]$ZipPath
    )
    if (-not (Test-Path $SourcePath)) { throw ("SourcePath not found: {0}" -f $SourcePath) }
    $zipDir = Split-Path -Parent $ZipPath
    if (-not (Test-Path $zipDir)) { New-Item -ItemType Directory -Path $zipDir -Force | Out-Null }
    if (Test-Path $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force -ErrorAction SilentlyContinue }
    Compress-Archive -Path (Join-Path $SourcePath '*') -DestinationPath $ZipPath -Force
    return $ZipPath
}

# --- Service control helpers (PS 5.1 safe) ---
function Get-ServiceIfExists { param([string]$Name) try { Get-Service -Name $Name -ErrorAction Stop } catch { $null } }
function Stop-ServiceIfRunning {
    param([string]$Name, [int]$TimeoutSec = 15)
    $svc = Get-ServiceIfExists -Name $Name
    if ($null -eq $svc) { return $false }
    if ($svc.Status -ne 'Stopped') {
        Write-Host ("Stopping service {0}..." -f $Name)
        try { Stop-Service -Name $Name -Force -ErrorAction Stop } catch { }
        $sw = [Diagnostics.Stopwatch]::StartNew()
        while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
            $svc.Refresh()
            if ($svc.Status -eq 'Stopped') { break }
            Start-Sleep -Milliseconds 300
        }
    }
    return $true
}
function Start-ServiceIfStopped {
    param([string]$Name, [int]$TimeoutSec = 20)
    $svc = Get-ServiceIfExists -Name $Name
    if ($null -eq $svc) { return $false }
    if ($svc.Status -ne 'Running') {
        Write-Host ("Starting service {0}..." -f $Name)
        try { Start-Service -Name $Name -ErrorAction Stop } catch { }
        $sw = [Diagnostics.Stopwatch]::StartNew()
        while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
            $svc.Refresh()
            if ($svc.Status -eq 'Running') { break }
            Start-Sleep -Milliseconds 300
        }
    }
    return $true
}

# --- Agent logs zip (stops services, stages files, returns file list) ---
function Compress-AgentLogs {
    # Returns: $null OR [pscustomobject] @{ ZipPath = <string>; Files = <object[]> }
    $logsFolder   = 'C:\Program Files (x86)\CyberCNSAgent\logs'
    $agentZip     = Join-Path $global:CS_ExportRoot 'agent-logs.zip'
    $stagingRoot  = Join-Path $global:CS_ExportRoot 'agent-logs_staging'

    if (-not (Test-Path $logsFolder)) { return $null }

    Write-Host ""
    $resp = Read-Host "ConnectSecure logs detected at '$logsFolder', include them in ZIP? (Enter=Yes / N=Skip)"
    if (-not ([string]::IsNullOrWhiteSpace($resp)) -and ($resp -match '^(n|no)$')) { return $null }

    $serviceCandidates = @('CyberCNSAgent','CyberCNSMonitoringAgent')
    $stopped = @()

    try {
        foreach ($svcName in $serviceCandidates) {
            $svc = Get-ServiceIfExists -Name $svcName
            if ($svc -and $svc.Status -ne 'Stopped') {
                if (Stop-ServiceIfRunning -Name $svcName) { $stopped += $svcName }
            }
        }

        # Snapshot file list
        $fileList = @()
        try {
            $items = Get-ChildItem -LiteralPath $logsFolder -Recurse -File -ErrorAction SilentlyContinue
            foreach ($f in $items) {
                $rel = $f.FullName.Substring($logsFolder.Length).TrimStart('\')
                $sizeKB = [math]::Round(($f.Length / 1KB), 1)
                $fileList += [pscustomobject]@{
                    RelativePath  = $rel
                    SizeKB        = $sizeKB
                    LastWriteTime = $f.LastWriteTime
                }
            }
        } catch { }

        # Stage files
        if (Test-Path $stagingRoot) { try { Remove-Item -LiteralPath $stagingRoot -Recurse -Force -ErrorAction SilentlyContinue } catch { } }
        New-Item -ItemType Directory -Path $stagingRoot -Force | Out-Null

        $robo = $env:SystemRoot + '\System32\robocopy.exe'
        $copiedOk = $false
        if (Test-Path $robo) {
            try { & $robo "$logsFolder" "$stagingRoot" *.* /E /NFL /NDL /NJH /NJS /NC /NS /R:1 /W:1 | Out-Null; $copiedOk = $true } catch { $copiedOk = $false }
        }
        if (-not $copiedOk) {
            try { Copy-Item -LiteralPath (Join-Path $logsFolder '*') -Destination $stagingRoot -Recurse -Force -ErrorAction Stop; $copiedOk = $true } catch { $copiedOk = $false }
        }
        if (-not $copiedOk) { throw "Failed to stage logs for zipping." }

        # Create zip
        if (Test-Path $agentZip) { Remove-Item -LiteralPath $agentZip -Force -ErrorAction SilentlyContinue }
        Compress-Archive -Path (Join-Path $stagingRoot '*') -DestinationPath $agentZip -Force
        Write-Host ("Created agent logs zip: {0}" -f $agentZip) -ForegroundColor Cyan
        Write-Log  ("Agent logs zipped: {0}" -f $agentZip)

        return [pscustomobject]@{ ZipPath = $agentZip; Files = $fileList }
    } catch {
        Write-Host ("⚠️  Failed to zip agent logs: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        Write-Log  ("WARN: Failed to zip agent logs: {0}" -f $_.Exception.Message)
        return $null
    } finally {
        try { if (Test-Path $stagingRoot) { Remove-Item -LiteralPath $stagingRoot -Recurse -Force -ErrorAction SilentlyContinue } } catch { }
        foreach ($svcName in $stopped) { Start-ServiceIfStopped -Name $svcName | Out-Null }
    }
}

# --- Zip results + optional agent logs + email support flow (lists files) ---
function Zip-Results {
    Ensure-ExportFolder

    # 1) Main zip
    $zipName = "CS-Toolbox-Results_{0}.zip" -f (Get-Date -Format 'yyyyMMdd_HHmmss')
    $zipPath = Join-Path $global:CS_TempRoot $zipName

    try {
        $zipOut = Invoke-ZipFolder -SourcePath $global:CS_ExportRoot -ZipPath $zipPath
        Write-Host ("Created: {0}" -f $zipOut) -ForegroundColor Cyan
        Write-Log  ("Created results zip: {0}" -f $zipOut)
    } catch {
        Write-Host ("❌ Failed to create zip: {0}" -f $_.Exception.Message) -ForegroundColor Red
        Write-Log  ("ERROR: Failed to create zip: {0}" -f $_.Exception.Message)
        return $null
    }

    # 2) Optional agent logs
    $agentLogsInfo = Compress-AgentLogs

    # 3) Email prompt
    $choice = Read-Host "Compose email to support with ZIP attached? (Enter for Yes / N for custom)"
    $toAddress = $global:CS_SupportMail
    if ($choice -match '^(n|no)$') {
        $toAddress = Read-Host "Enter recipient email (blank cancels email compose)"
        if ([string]::IsNullOrWhiteSpace($toAddress)) {
            Write-Host "Email compose skipped."
            return $zipOut
        }
    }

    # 4) Subject fields
    $company = Read-Host "Company (for subject)"
    $tenant  = Read-Host "Tenant (for subject)"
    $ticket  = Read-Host "Ticket (optional for subject)"
    $subjectParts = @($company, $tenant)
    if (-not [string]::IsNullOrWhiteSpace($ticket)) { $subjectParts += $ticket }
    $subject = ($subjectParts -join ' | ') + " | CS Toolbox Files"

    # 5) Body (with per-file listing)
    $artifactsLines = @()
    $artifactsLines += (" - Main ZIP: {0}" -f $zipOut)
    if ($agentLogsInfo -and $agentLogsInfo.ZipPath) {
        $artifactsLines += (" - Agent Logs: {0}" -f $agentLogsInfo.ZipPath)
        if ($agentLogsInfo.Files -and $agentLogsInfo.Files.Count -gt 0) {
            $artifactsLines += "   Files included:"
            foreach ($f in $agentLogsInfo.Files) {
                $ts = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm')
                $artifactsLines += ("    • {0}  ({1} KB, {2})" -f $f.RelativePath, $f.SizeKB, $ts)
            }
        }
    }

$body = @"
Please see attached CS Toolbox results.

Summary:
 - Company: $company
 - Tenant:  $tenant
 - Ticket:  $ticket

Artifacts:
$( $artifactsLines -join "`r`n" )
"@

    # 6) Attachments
    $attachments = @($zipOut)
    if ($agentLogsInfo -and $agentLogsInfo.ZipPath) { $attachments += $agentLogsInfo.ZipPath }

    # 7) Launch compose
    Start-OutlookCompose -To $toAddress -Subject $subject -Body $body -Attachments $attachments

    return $zipOut
}

# --- Cleanup and self-delete temp folder ---
function Invoke-FinalCleanupAndExit {
    try {
        $tempRoot = $global:CS_TempRoot
        if (-not (Test-Path $tempRoot)) { return }
        $cleanupScriptPath = Join-Path $tempRoot 'Toolbox-Cleanup-SelfDestruct.ps1'
@'
Start-Sleep -Seconds 5
$path = "C:\CS-Toolbox-TEMP"
try {
    Get-Process | Where-Object { $_.Path -and $_.Path -like "$path*" } | ForEach-Object {
        try { $_ | Stop-Process -Force -ErrorAction SilentlyContinue } catch {}
    }
} catch {}
try { Remove-Item -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue } catch {}
'@ | Set-Content -LiteralPath $cleanupScriptPath -Encoding UTF8

        for ($i=5; $i -ge 1; $i--) { Write-Host ("Cleaning up in {0}..." -f $i); Start-Sleep -Seconds 1 }
        Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList "-ExecutionPolicy Bypass -NoProfile -File `"$cleanupScriptPath`""
    } catch { }
}

# --- Launch a child tool from the launcher root ---
function Launch-Tool {
    param([Parameter(Mandatory=$true)][string]$ScriptName)
    $root = $global:CSLauncherRoot
    if (-not $root) { $root = Split-Path -Parent $MyInvocation.MyCommand.Definition }
    $path = Join-Path $root $ScriptName
    if (Test-Path $path) {
        & $path
    } else {
        Write-Host ("ERROR launching {0}: Not found." -f $ScriptName) -ForegroundColor Red
    }
}

# --- Legacy alias for older callers ---
Set-Alias EnsureExportFolder Ensure-ExportFolder -Force | Out-Null
