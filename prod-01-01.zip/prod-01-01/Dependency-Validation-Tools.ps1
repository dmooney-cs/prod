# =================================================================================================
# Dependency-Validation-Tools.ps1  (PS 5.1 Safe, Fully Inlined, Auto-Download + Force Overwrite)
# - Checks hardcoded path FIRST: C:\CS-Toolbox-TEMP\prod-01-01\Tools\DependencyWalker\depends.exe
# - If missing, tries local fallbacks, then auto-downloads; extraction uses temp dir + forced copy.
# - Runs Dependency Walker (depends.exe) in console mode IN THE SAME WINDOW
# - Includes an inlined VC++ Redistributable sweep
# - Exports -> C:\CS-Toolbox-TEMP\Collected-Info\DependencyWalker\  and  \Collected-Info\
# - Menu: [1] Dependency Walker, [2] VC++ Sweep, [Q] Quit
# =================================================================================================
$ErrorActionPreference = 'Continue'

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info'
$DepOutDir   = Join-Path $ExportRoot 'DependencyWalker'
$ToolsDir    = Join-Path $scriptRoot 'Tools\DependencyWalker'

# Hardcoded preferred path to check FIRST (per request)
$PreferredAbsolutePath = 'C:\CS-Toolbox-TEMP\prod-01-01\Tools\DependencyWalker\depends.exe'

# Candidate public URLs for Dependency Walker ZIPs (replace with internal mirror if needed)
$DepWalkerUrls = @(
  'https://www.dependencywalker.com/depends22_x64.zip',
  'https://www.dependencywalker.com/depends22_x86.zip'
)

# -------------------------------------------------------------------------------------------------
# Inline Helpers
# -------------------------------------------------------------------------------------------------
function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-ExportFolder {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $DepOutDir
    Ensure-Directory -Path $ToolsDir
}

function Get-IsAdmin {
    try {
        $id  = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pr  = New-Object Security.Principal.WindowsPrincipal($id)
        return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    try {
        Write-Host ""
        Write-Host "Press any key to continue..." -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch { $null = Read-Host "Press ENTER to continue" }
}

function Show-Header {
    param([string]$Title = $null)
    if ([string]::IsNullOrWhiteSpace($Title)) { $Title = "Dependency Validation Tools" }
    Clear-Host
    $hostName = $env:COMPUTERNAME
    $userName = "$env:USERDOMAIN\$env:USERNAME"
    $isAdmin  = if (Get-IsAdmin) { "True" } else { "False" }

    Write-Host "   ConnectSecure Technicians Toolbox" -ForegroundColor Cyan
    Write-Host "========================================================" -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, $isAdmin) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

function Return-ToLauncher {
    try {
        $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
        if (Test-Path -LiteralPath $launcher) { & $launcher }
        else { Write-Host "Launcher not found at $launcher. Exiting script..." -ForegroundColor Yellow }
    } catch { Write-Host "Failed to return to launcher: $($_.Exception.Message)" -ForegroundColor Red }
}

function Prompt-OpenFile {
    param([string]$Title="Select a file",[string]$Filter="All files|*.*")
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = $Title
    $dlg.Filter = $Filter
    $dlg.Multiselect = $false
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.FileName }
    return $null
}

function Ensure-Tls12 {
    try {
        [Net.ServicePointManager]::SecurityProtocol =
            [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    } catch {}
}

function Try-DownloadFile {
    param([Parameter(Mandatory)][string]$Uri, [Parameter(Mandatory)][string]$DestPath)
    Ensure-Tls12
    try {
        if (Get-Command Start-BitsTransfer -ErrorAction SilentlyContinue) {
            Start-BitsTransfer -Source $Uri -Destination $DestPath -ErrorAction Stop
            return $true
        } else {
            Invoke-WebRequest -Uri $Uri -OutFile $DestPath -UseBasicParsing -ErrorAction Stop
            return $true
        }
    } catch {
        Write-Host ("Download failed from {0}: {1}" -f $Uri, $_.Exception.Message) -ForegroundColor Yellow
        return $false
    }
}

function Expand-Zip {
    param([Parameter(Mandatory)][string]$ZipPath, [Parameter(Mandatory)][string]$DestDir)
    Ensure-Directory -Path $DestDir
    try {
        if (Get-Command Expand-Archive -ErrorAction SilentlyContinue) {
            Expand-Archive -LiteralPath $ZipPath -DestinationPath $DestDir -Force
        } else {
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            # Extract to an empty temp dir to avoid "file exists" errors
            if (Test-Path -LiteralPath $DestDir) {
                # Best-effort cleanup to ensure directory is empty for .NET extractor
                Get-ChildItem -LiteralPath $DestDir -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
            }
            [System.IO.Compression.ZipFile]::ExtractToDirectory($ZipPath, $DestDir)
        }
        return $true
    } catch {
        Write-Host ("Failed to extract ZIP: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        return $false
    }
}

function Copy-Depends-Force {
    param([Parameter(Mandatory)][string]$SourceExe, [Parameter(Mandatory)][string]$TargetExe)

    Ensure-Directory -Path (Split-Path -Parent $TargetExe)

    # If exists and might be read-only/locked, try to clear and remove then copy
    if (Test-Path -LiteralPath $TargetExe) {
        try {
            $fi = Get-Item -LiteralPath $TargetExe -ErrorAction SilentlyContinue
            if ($fi -and $fi.Attributes -band [IO.FileAttributes]::ReadOnly) {
                attrib -r $fi.FullName | Out-Null
            }
            Remove-Item -LiteralPath $TargetExe -Force -ErrorAction SilentlyContinue
        } catch {}
    }

    try {
        Copy-Item -LiteralPath $SourceExe -Destination $TargetExe -Force
        return $true
    } catch {
        Write-Host ("Failed to copy depends.exe to {0}: {1}" -f $TargetExe, $_.Exception.Message) -ForegroundColor Yellow
        return $false
    }
}

function Download-DepWalker {
    param([Parameter(Mandatory)][string]$TargetDir)

    Ensure-Directory -Path $TargetDir
    $zipTemp = [IO.Path]::Combine([IO.Path]::GetTempPath(), [IO.Path]::GetRandomFileName() + ".zip")
    $extractTemp = [IO.Path]::Combine([IO.Path]::GetTempPath(), "depwalk_" + ([guid]::NewGuid().ToString("N")))

    foreach ($url in $DepWalkerUrls) {
        Write-Host ("Attempting to download Dependency Walker: {0}" -f $url) -ForegroundColor Cyan
        # Clean temp paths
        if (Test-Path -LiteralPath $zipTemp) { Remove-Item -LiteralPath $zipTemp -Force -ErrorAction SilentlyContinue }
        if (Test-Path -LiteralPath $extractTemp) { Remove-Item -LiteralPath $extractTemp -Recurse -Force -ErrorAction SilentlyContinue }

        if (-not (Try-DownloadFile -Uri $url -DestPath $zipTemp)) { continue }
        if (-not (Expand-Zip -ZipPath $zipTemp -DestDir $extractTemp)) { continue }

        # Locate depends.exe in the extracted tree
        $found = Get-ChildItem -LiteralPath $extractTemp -Recurse -Filter 'depends.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found -and (Test-Path -LiteralPath $found.FullName)) {
            $dest = Join-Path $TargetDir 'depends.exe'
            if (Copy-Depends-Force -SourceExe $found.FullName -TargetExe $dest) {
                # Cleanup temp
                Remove-Item -LiteralPath $zipTemp -Force -ErrorAction SilentlyContinue
                Remove-Item -LiteralPath $extractTemp -Recurse -Force -ErrorAction SilentlyContinue
                return $dest
            }
        }
    }

    # Cleanup temp
    if (Test-Path -LiteralPath $zipTemp) { Remove-Item -LiteralPath $zipTemp -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $extractTemp) { Remove-Item -LiteralPath $extractTemp -Recurse -Force -ErrorAction SilentlyContinue }
    return $null
}

function Resolve-DepWalkerPath {
    # 1) Check hardcoded preferred absolute path FIRST
    if (Test-Path -LiteralPath $PreferredAbsolutePath) { return $PreferredAbsolutePath }

    # 2) Then check toolbox-relative preferred path
    $preferredRelative = Join-Path $ToolsDir 'depends.exe'
    if (Test-Path -LiteralPath $preferredRelative) { return $preferredRelative }

    # 3) Then check script root
    $rootCandidate = Join-Path $scriptRoot 'depends.exe'
    if (Test-Path -LiteralPath $rootCandidate) { return $rootCandidate }

    # 4) Attempt auto-download to the preferred relative tools folder
    Write-Host "Dependency Walker (depends.exe) not found locally. Attempting auto-download..." -ForegroundColor Yellow
    $downloaded = Download-DepWalker -TargetDir $ToolsDir
    if ($downloaded -and (Test-Path -LiteralPath $downloaded)) { return $downloaded }

    # 5) Fallback to manual selection
    Write-Host "Auto-download failed or was unavailable." -ForegroundColor Yellow
    $picked = Prompt-OpenFile -Title "Locate depends.exe" -Filter "depends.exe|depends.exe|Executables|*.exe"
    if ($picked -and (Test-Path -LiteralPath $picked)) { return $picked }

    return $null
}

# -------------------------------------------------------------------------------------------------
# VC++ Runtime Validation (Inlined)
# -------------------------------------------------------------------------------------------------
function Run-VcppValidation {
    param([switch]$PauseAfter)

    Show-Header "VC++ Redistributable Sweep"
    Ensure-ExportFolder

    $hives = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
    )

    function Get-VcYearFromName([string]$name) {
        if ($name -match '2005') { return '2005' }
        if ($name -match '2008') { return '2008' }
        if ($name -match '2010') { return '2010' }
        if ($name -match '2012') { return '2012' }
        if ($name -match '2013') { return '2013' }
        if ($name -match '2015|2017|2019|2022') { return '2015-2022' }
        'Unknown'
    }
    function Get-ArchFromName([string]$name) {
        if ($name -match 'x64|64-bit|amd64') { return 'x64' }
        if ($name -match 'x86|32-bit')       { return 'x86' }
        'Unknown'
    }

    $items = New-Object System.Collections.Generic.List[psobject]
    foreach ($root in $hives) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        Get-ChildItem -Path $root -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $p = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction Stop
                $name = $p.DisplayName
                if ([string]::IsNullOrWhiteSpace($name)) { return }
                if ($name -notmatch 'Visual C\+\+|VC\+\+|Microsoft Visual C') { return }

                $items.Add([pscustomobject]@{
                    DisplayName     = $name
                    DisplayVersion  = $p.DisplayVersion
                    Architecture    = Get-ArchFromName $name
                    Year            = Get-VcYearFromName $name
                    Publisher       = $p.Publisher
                    InstallDate     = $p.InstallDate
                    UninstallString = $p.UninstallString
                    KeyName         = $_.PSChildName
                    RegistryHive    = $root
                })
            } catch { }
        }
    }

    $items = $items | Sort-Object Year, Architecture, DisplayVersion, DisplayName
    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $csv   = Join-Path $ExportRoot ("VCpp-Runtime_Inventory_{0}.csv" -f $stamp)
    $items | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8

    Write-Host ""
    Write-Host ("VC++ runtimes found: {0}. CSV saved to:" -f $items.Count) -ForegroundColor Green
    Write-Host "  $csv" -ForegroundColor Yellow

    if ($PauseAfter) { Pause-Script }
}

# -------------------------------------------------------------------------------------------------
# Dependency Walker (console mode, same window)
# -------------------------------------------------------------------------------------------------
function Invoke-DepWalkerConsole {
    Show-Header "Dependency Walker - Console Analysis"

    $depExe = Resolve-DepWalkerPath
    if (-not $depExe) {
        Write-Host "ERROR: Dependency Walker executable not provided." -ForegroundColor Red
        Pause-Script
        return
    }

    $target = Read-Host "Enter FULL path to the target EXE or DLL (or press ENTER to browse)"
    if ([string]::IsNullOrWhiteSpace($target)) {
        $target = Prompt-OpenFile -Title "Select target EXE/DLL" -Filter "Executables/DLLs|*.exe;*.dll|All files|*.*"
        if (-not $target) {
            Write-Host "No target selected. Returning to menu..." -ForegroundColor Yellow
            Pause-Script
            return
        }
    }
    if (-not (Test-Path -LiteralPath $target)) {
        Write-Host "ERROR: Target not found: $target" -ForegroundColor Red
        Pause-Script
        return
    }

    Ensure-ExportFolder
    $stamp   = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $hostTag = $env:COMPUTERNAME
    $base    = "DependencyWalkerScan_{0}_{1}" -f $stamp, $hostTag

    $txtPath = Join-Path $DepOutDir ($base + ".txt")
    $csvPath = Join-Path $DepOutDir ($base + ".csv")
    $dwiPath = Join-Path $DepOutDir ($base + ".dwi")

    # Build arguments (order matters; target last)
    $depArgs = @(
        '/c',       # console mode (no GUI)
        '/pa:1',    # auto expand
        '/pb',      # build profile
        '/f:1',     # show full path
        '/u:1',     # undecorate
        "/oc:$csvPath",
        "/od:$dwiPath",
        $target
    )

    Write-Host ""
    Write-Host "Launching Dependency Walker (console mode)..." -ForegroundColor Cyan
    try {
        # Run in same window; capture output to TXT
        $null = (& $depExe @depArgs 2>&1 | Tee-Object -FilePath $txtPath)
    } catch {
        Write-Host "ERROR: Failed to run depends.exe: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Summary saved to:`n  $txtPath" -ForegroundColor Yellow
        Pause-Script
        return
    }

    # StrictMode-safe exit code retrieval
    $exitCode = $null
    try { $exitCode = (Get-Variable -Name LASTEXITCODE -ValueOnly -Scope Global -ErrorAction SilentlyContinue) } catch { }
    if ($null -eq $exitCode) { $exitCode = 0 }

    if ($exitCode -ne 0) {
        Write-Host ("depends.exe returned exit code {0}. Review output." -f $exitCode) -ForegroundColor Yellow
    } else {
        Write-Host "Dependency Walker completed." -ForegroundColor Green
    }

    Write-Host ""
    Write-Host "Summary saved to:" -ForegroundColor Green
    Write-Host "  $txtPath" -ForegroundColor Yellow
    Write-Host "Artifacts:" -ForegroundColor Green
    Write-Host "  CSV : $csvPath" -ForegroundColor Yellow
    Write-Host "  DWI : $dwiPath" -ForegroundColor Yellow

    Pause-Script
}

# -------------------------------------------------------------------------------------------------
# MENU
# -------------------------------------------------------------------------------------------------
do {
    Show-Header "Dependency Validation Tools"

    Write-Host " [1] Dependency Walker (console) - Analyze EXE/DLL" -ForegroundColor White
    Write-Host " [2] VC++ Redistributable Sweep  - Installed VC++ runtimes" -ForegroundColor White
    Write-Host " [Q] Quit (return to Launcher)"  -ForegroundColor Yellow
    Write-Host ""

    $choice = Read-Host "Enter your choice"
    switch -Regex ($choice) {
        '^(1)$' { Invoke-DepWalkerConsole; continue }
        '^(2)$' { Run-VcppValidation -PauseAfter; continue }
        '^(q|Q)$' { Return-ToLauncher; break }
        default  { Write-Host "Invalid selection. Please choose 1-2 or Q." -ForegroundColor Yellow; Start-Sleep -Milliseconds 800 }
    }
} while ($true)
