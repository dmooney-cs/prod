# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Agent Install Tool                          ║
# ║ Version: A.2 | Install, Reinstall, Detect, Status Check    ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-AgentCheckStatus {
    Show-Header "Agent Service Status"
    $svc1 = Get-Service -Name "CyberCNSAgent" -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name "CyberCNSAgentMonitor" -ErrorAction SilentlyContinue

    if ($svc1) {
        Write-Host "CyberCNSAgent: $($svc1.Status)" -ForegroundColor Green
    } else {
        Write-Host "CyberCNSAgent: Not Installed" -ForegroundColor Yellow
    }

    if ($svc2) {
        Write-Host "CyberCNSAgentMonitor: $($svc2.Status)" -ForegroundColor Green
    } else {
        Write-Host "CyberCNSAgentMonitor: Not Installed" -ForegroundColor Yellow
    }

    if ($svc1 -and $svc1.Status -ne "Running" -and $svc2 -and $svc2.Status -ne "Running") {
        $choice = Read-Host "Start both services now? (Y/N)"
        if ($choice -match '^[Yy]') {
            Start-Service CyberCNSAgent -ErrorAction SilentlyContinue
            Start-Service CyberCNSAgentMonitor -ErrorAction SilentlyContinue
            Write-Host "Attempted to start services." -ForegroundColor Cyan
        }
    }

    Write-SessionSummary "Checked agent status: CyberCNSAgent = $($svc1?.Status), Monitor = $($svc2?.Status)"
    Pause-Script
}

function Run-AgentInstall {
    Show-Header "Install CyberCNS Agent"
    $installer = "C:\Program Files (x86)\CyberCNSAgent\CyberCNSAgentSetup.exe"

    if (Test-Path $installer) {
        Write-Host "Launching: $installer" -ForegroundColor Cyan
        Start-Process -FilePath $installer -Wait
        Write-SessionSummary "Agent installer launched successfully"
    } else {
        Write-Host "Installer not found at $installer" -ForegroundColor Red
        Write-SessionSummary "❌ Installer not found at expected path"
    }

    Pause-Script
}

function Run-AgentReinstall {
    Show-Header "Reinstall CyberCNS Agent"
    $uninstall = "C:\Program Files (x86)\CyberCNSAgent\uninstall.bat"

    if (Test-Path $uninstall) {
        Write-Host "Uninstalling agent first..." -ForegroundColor Yellow
        Start-Process -FilePath $uninstall -Wait
        Write-SessionSummary "Agent uninstalled via uninstall.bat"
    } else {
        Write-Host "Uninstaller not found. Proceeding to install." -ForegroundColor DarkYellow
        Write-SessionSummary "⚠️ Uninstall.bat not found. Reinstall proceeding without removal."
    }

    Start-Sleep -Seconds 2
    Run-AgentInstall
}

function Run-ZipAndEmailResults {
    Invoke-ZipAndEmailResults
}

function Run-CleanupExportFolder {
    Run-CleanupExportFolder
}

function Show-AgentInstallMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "         CS Toolbox – Agent Install Tool"
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Check Agent Service Status"
        Write-Host " [2] Install CyberCNS Agent"
        Write-Host " [3] Reinstall CyberCNS Agent (Force)"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit to Main Menu"
        Write-Host ""
        $choice = Read-Host "Select an option"

        switch ($choice.ToUpper()) {
            '1' { Run-AgentCheckStatus }
            '2' { Run-AgentInstall }
            '3' { Run-AgentReinstall }
            'Z' { Run-ZipAndEmailResults }
            'C' { Run-CleanupExportFolder }
            'Q' { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Pause-Script
            }
        }
    } while ($true)
}

Show-AgentInstallMenu
