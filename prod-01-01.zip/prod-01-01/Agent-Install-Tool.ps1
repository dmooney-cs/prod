<#
.SYNOPSIS
    ConnectSecure (CyberCNS) Agent Install / Reinstall Helper

.NOTES
    Patched:
      - Quiet/Silent continue on uninstall errors (missing processes/files/keys)
      - Uninstall batch ignores taskkill/sc/reg/rmdir failures
      - Adds -ExportOnly for cookbook usage (no prompts/pauses)
      - Auto-load install codes from:
          C:\CS-Toolbox-TEMP\Collected-Info\installer-code.txt
          (Company ID line 1, Tenant ID line 2, Secret Key line 3)
#>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Reinstall,

    [Alias('c')]
    [string]$Company,

    [Alias('e')]
    [string]$Tenant,

    [Alias('j')]
    [string]$Secret,

    [switch]$Quiet,
    [switch]$Silent,

    # COOKBOOK CONTROL
    [switch]$ExportOnly
)

# ====================== Global behavior ======================
$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'

if ($Silent) {
    $Quiet     = $true
    $Reinstall = $true
}

if ($ExportOnly) {
    $Quiet     = $true
    $Reinstall = $true
}

# ====================== Setup / Logging ======================
$shortDate = Get-Date -Format "yyyy-MM-dd"
$shortTime = Get-Date -Format "HHmm"
$hostname  = $env:COMPUTERNAME

$exportDir = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path -LiteralPath $exportDir)) {
    New-Item -Path $exportDir -ItemType Directory -Force | Out-Null
}
$logFile = Join-Path $exportDir "$hostname-AgentInstall-$shortDate-$shortTime.txt"
try { Start-Transcript -Path $logFile -Append | Out-Null } catch {}

# ====================== Constants ============================
$AgentApiUrl      = "https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows"
$DownloadRoot     = "C:\CS-Toolbox-TEMP\Downloads"
$InstallerPath    = Join-Path $DownloadRoot "cybercnsagent.exe"

$AgentDir         = "C:\Program Files (x86)\CyberCNSAgent"
$UninstallBatPath = Join-Path $AgentDir "uninstall.bat"
$AgentLogPath     = Join-Path $AgentDir "logs\cybercns.log"

$InstallerCodeFile = Join-Path $exportDir "installer-code.txt"

# Raw uninstall fallback (batch) - patched to IGNORE errors
$RawUninstall = @"
@echo off
setlocal ENABLEEXTENSIONS
ping 127.0.0.1 -n 3 > nul 2>&1
cd /d "C:\PROGRA~2" 2>nul
sc stop ConnectSecureAgentMonitor >nul 2>&1
timeout /T 2 >nul 2>&1
sc delete ConnectSecureAgentMonitor >nul 2>&1
timeout /T 2 >nul 2>&1
sc stop CyberCNSAgent >nul 2>&1
timeout /T 2 >nul 2>&1
sc delete CyberCNSAgent >nul 2>&1
taskkill /IM osqueryi.exe /F >nul 2>&1
taskkill /IM nmap.exe /F >nul 2>&1
taskkill /IM cyberutilities.exe /F >nul 2>&1
if exist "CyberCNSAgent\cybercnsagent.exe" (
  "CyberCNSAgent\cybercnsagent.exe" --internalAssetArgument uninstallservice >nul 2>&1
)
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f >nul 2>&1
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f >nul 2>&1
rmdir "CyberCNSAgent" /s /q >nul 2>&1
exit /b 0
"@

# ====================== Helpers ==============================
function Enable-Tls12 {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
}

function Write-HostIfNotQuiet {
    param(
        [string]$Message,
        [string]$Color = 'Gray'
    )
    if ($Quiet -or $Silent) { return }

    if ([string]::IsNullOrEmpty($Message)) { Write-Host "" }
    else { Write-Host $Message -ForegroundColor $Color }
}

function Show-StepSummary {
    param(
        [int]$Index,
        [int]$Total,
        [string]$Message
    )
    if ($Silent) { return }
    if ([string]::IsNullOrEmpty($Message)) { $Message = "Phase $Index of $Total completed." }
    Write-Host ("[Step {0}/{1}] {2}" -f $Index, $Total, $Message) -ForegroundColor Cyan
}

function Get-InstallerCodesFromFile {
    param([Parameter(Mandatory=$true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { return $null }

    try {
        $raw = Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue
        if (-not $raw) { return $null }

        $lines = @()
        foreach ($l in $raw) {
            if ($null -eq $l) { continue }
            $t = $l.ToString().Trim()
            if ([string]::IsNullOrWhiteSpace($t)) { continue }
            if ($t.StartsWith('#') -or $t.StartsWith(';')) { continue }
            $lines += $t
        }

        if ($lines.Count -lt 3) { return $null }

        [PSCustomObject]@{
            Company = $lines[0]
            Tenant  = $lines[1]
            Secret  = $lines[2]
        }
    } catch {
        $null
    }
}

function Get-AgentIdsFromLog {
    if (-not (Test-Path -LiteralPath $AgentLogPath)) { return $null }
    try {
        $tenantLine  = Select-String -Path $AgentLogPath -Pattern 'Tenant ID\s*:-'  -ErrorAction SilentlyContinue | Select-Object -Last 1
        $companyLine = Select-String -Path $AgentLogPath -Pattern 'Company ID\s*:-' -ErrorAction SilentlyContinue | Select-Object -Last 1

        $tenantId  = $null
        $companyId = $null

        if ($tenantLine) {
            $m = [regex]::Match($tenantLine.Line, 'Tenant ID\s*:-\s*([0-9]+)')
            if ($m.Success) { $tenantId = $m.Groups[1].Value }
        }
        if ($companyLine) {
            $m = [regex]::Match($companyLine.Line, 'Company ID\s*:-\s*([0-9]+)')
            if ($m.Success) { $companyId = $m.Groups[1].Value }
        }

        if ($tenantId -or $companyId) {
            return [PSCustomObject]@{ TenantId = $tenantId; CompanyId = $companyId }
        }
    } catch {}
    $null
}

function Invoke-RestWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2,
        [string]$What = "agent link"
    )
    Enable-Tls12
    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        Write-HostIfNotQuiet ("Fetching {0}... Attempt {1}/{2}" -f $What, $attempt, $MaxAttempts) 'Cyan'
        try {
            $resp = Invoke-RestMethod -Method Get -Uri $Uri -ErrorAction Stop
            Write-HostIfNotQuiet "Request successful." 'Green'
            return $resp
        } catch {
            if ($attempt -eq $MaxAttempts) {
                if (-not $Silent) {
                    Write-Host ("ERROR: Failed to fetch {0} on attempt {1}/{2}: {3}" -f $What, $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Red
                }
                return $null
            }
            Write-HostIfNotQuiet ("Attempt {0}/{1} failed: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) 'Yellow'
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    $null
}

function Invoke-DownloadWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$OutFile,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2,
        [string]$What = "installer"
    )
    Enable-Tls12
    $outDir = Split-Path -Parent $OutFile
    if (-not (Test-Path -LiteralPath $outDir)) {
        New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    }

    if (Test-Path -LiteralPath $OutFile) {
        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
    }

    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        Write-HostIfNotQuiet ("Downloading {0}... Attempt {1}/{2}" -f $What, $attempt, $MaxAttempts) 'Cyan'
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
            if ((Test-Path -LiteralPath $OutFile) -and ((Get-Item -LiteralPath $OutFile).Length -gt 0)) {
                Write-HostIfNotQuiet "Download successful." 'Green'
                return $true
            }
            throw "Downloaded file is missing or empty."
        } catch {
            Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
            if ($attempt -eq $MaxAttempts) {
                if (-not $Silent) {
                    Write-Host ("ERROR: Download failed on attempt {0}/{1}: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Red
                }
                return $false
            }
            Write-HostIfNotQuiet ("Attempt {0}/{1} failed: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) 'Yellow'
            Start-Sleep -Seconds $DelaySeconds
        }
    }
    $false
}

function Get-DownloadUrl {
    param([Parameter(Mandatory=$true)][object]$Resp)

    if ($Resp -is [string] -and $Resp -match '^https?://') { return $Resp }

    try { if ($Resp.link        -and $Resp.link        -match '^https?://') { return [string]$Resp.link } } catch {}
    try { if ($Resp.url         -and $Resp.url         -match '^https?://') { return [string]$Resp.url } } catch {}
    try { if ($Resp.downloadUrl -and $Resp.downloadUrl -match '^https?://') { return [string]$Resp.downloadUrl } } catch {}
    try { if ($Resp.data -and $Resp.data.link -and $Resp.data.link -match '^https?://') { return [string]$Resp.data.link } } catch {}

    try {
        $json = $Resp | ConvertTo-Json -Depth 6 -Compress
        $m = [Regex]::Match($json, 'https?://[^"\\s]+?\.exe')
        if ($m.Success) { return $m.Value }
    } catch {}

    $null
}

function Get-ServiceRow {
    param([Parameter(Mandatory=$true)][string]$Name)

    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if ($null -eq $svc) {
        return [PSCustomObject]@{ Service=$Name; Installed='No'; Status='Not Installed'; StartType='N/A' }
    }

    $startMode = 'Unknown'
    try {
        $wmi = Get-WmiObject -Class Win32_Service -Filter ("Name='{0}'" -f $Name) -ErrorAction SilentlyContinue
        if ($wmi -and $wmi.StartMode) { $startMode = $wmi.StartMode }
    } catch {}

    [PSCustomObject]@{ Service=$Name; Installed='Yes'; Status=$svc.Status.ToString(); StartType=$startMode }
}

function Show-ServicesTable {
    param([string]$Phase = 'Current')

    $rows = @(
        Get-ServiceRow -Name 'CyberCNSAgent'
        Get-ServiceRow -Name 'ConnectSecureAgentMonitor'
    )

    if ($Quiet -and -not $Silent) {
        $tag = switch ($Phase) {
            'Initial'       { '[Initial Service Status]' }
            'PostUninstall' { '[Post-Uninstall Service Status]' }
            'Final'         { '[Final Service Status]' }
            default         { '[Service Status]' }
        }

        foreach ($row in $rows) {
            Write-Host ("{0} {1}: Installed={2}, Status={3}, StartType={4}" -f $tag, $row.Service, $row.Installed, $row.Status, $row.StartType) -ForegroundColor Cyan
        }
    }
    elseif (-not $Quiet -and -not $Silent) {
        Write-Host ""
        Write-Host "=== ConnectSecure Services ===" -ForegroundColor Cyan
        $rows | Format-Table Service, Installed, Status, StartType -AutoSize | Out-Host
        Write-Host ""
        Write-Host "Note: It is normal for only 'CyberCNSAgent' to be present immediately after the first install." -ForegroundColor Yellow
    }

    return ,$rows
}

function Any-ServiceRunning {
    $svc1 = Get-Service -Name 'CyberCNSAgent' -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name 'ConnectSecureAgentMonitor' -ErrorAction SilentlyContinue
    return (($svc1 -and $svc1.Status -eq 'Running') -or ($svc2 -and $svc2.Status -eq 'Running'))
}

function Run-Uninstall {
    Write-HostIfNotQuiet ""
    Write-HostIfNotQuiet "Starting uninstall process..." 'Yellow'

    $agentExe = Join-Path $AgentDir 'cybercnsagent.exe'
    if (Test-Path -LiteralPath $agentExe) {
        try {
            if ($Quiet -or $Silent) { & $agentExe -r *> $null } else { & $agentExe -r }
        } catch {}
    }

    $uninstallScript = if (Test-Path -LiteralPath $UninstallBatPath) {
        Write-HostIfNotQuiet "Found vendor uninstall.bat, using it." 'Green'
        try { Get-Content $UninstallBatPath -Raw -ErrorAction SilentlyContinue } catch { $null }
    } else {
        Write-HostIfNotQuiet "Vendor uninstall.bat not found. Using built-in fallback." 'Yellow'
        $null
    }

    if ([string]::IsNullOrWhiteSpace($uninstallScript)) {
        $uninstallScript = $RawUninstall
    } else {
        $uninstallScript = "@echo off`r`nsetlocal`r`n" + $uninstallScript + "`r`nexit /b 0`r`n"
    }

    $tempBat = Join-Path $env:TEMP "_agent_uninstall.bat"
    try {
        $uninstallScript | Out-File -FilePath $tempBat -Encoding ASCII -Force
        Write-HostIfNotQuiet "Executing uninstall script..." 'Cyan'

        if ($Quiet -or $Silent) { cmd /c "`"$tempBat`"" > $null 2>&1 }
        else { cmd /c "`"$tempBat`"" }

        $null = $LASTEXITCODE
    } catch {
    } finally {
        Remove-Item -LiteralPath $tempBat -Force -ErrorAction SilentlyContinue
    }

    Write-HostIfNotQuiet "Uninstall process completed (errors ignored if any)." 'Green'
    Show-StepSummary -Index 1 -Total 3 -Message "Uninstall phase completed (best-effort; missing items are expected and ignored)."
}

function Start-AgentServices {
    foreach ($n in @('CyberCNSAgent','ConnectSecureAgentMonitor')) {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne 'Running') {
            Write-HostIfNotQuiet ("Starting {0} ..." -f $n) 'Cyan'
            try {
                Start-Service -Name $n -ErrorAction SilentlyContinue
                try { $svc.WaitForStatus('Running','00:00:25') } catch {}
                $svc2 = Get-Service -Name $n -ErrorAction SilentlyContinue
                if ($svc2 -and $svc2.Status -eq 'Running') { Write-HostIfNotQuiet ("[OK] {0} is Running" -f $n) 'Green' }
                else { Write-HostIfNotQuiet ("[WARN] {0} did not report Running" -f $n) 'Yellow' }
            } catch {}
        } elseif ($svc) {
            Write-HostIfNotQuiet ("[OK] {0} already Running" -f $n) 'Green'
        }
    }
}

# ====================== Flow ================================
try {
    # Try installer-code.txt first if anything missing
    if ([string]::IsNullOrWhiteSpace($Company) -or
        [string]::IsNullOrWhiteSpace($Tenant)  -or
        [string]::IsNullOrWhiteSpace($Secret)) {

        $codes = Get-InstallerCodesFromFile -Path $InstallerCodeFile
        if ($codes) {
            if ([string]::IsNullOrWhiteSpace($Company) -and $codes.Company) { $Company = $codes.Company }
            if ([string]::IsNullOrWhiteSpace($Tenant)  -and $codes.Tenant)  { $Tenant  = $codes.Tenant }
            if ([string]::IsNullOrWhiteSpace($Secret)  -and $codes.Secret)  { $Secret  = $codes.Secret }

            if (-not $Silent) {
                Write-HostIfNotQuiet ("Detected installer codes file: {0}" -f $InstallerCodeFile) 'Green'
                Write-HostIfNotQuiet "Using values from installer-code.txt where CLI args were not provided." 'Green'
            }
        }
    }

    # Auto-resolve IDs from cybercns.log if Secret exists but IDs missing
    if (-not [string]::IsNullOrWhiteSpace($Secret) -and
        ([string]::IsNullOrWhiteSpace($Company) -or [string]::IsNullOrWhiteSpace($Tenant))) {

        $ids = Get-AgentIdsFromLog
        if ($ids) {
            if ([string]::IsNullOrWhiteSpace($Company) -and $ids.CompanyId) { $Company = $ids.CompanyId }
            if ([string]::IsNullOrWhiteSpace($Tenant)  -and $ids.TenantId)  { $Tenant  = $ids.TenantId }
        }
    }

    if ($Reinstall) {
        if ([string]::IsNullOrWhiteSpace($Company) -or
            [string]::IsNullOrWhiteSpace($Tenant)  -or
            [string]::IsNullOrWhiteSpace($Secret)) {

            if (-not $Silent) {
                Write-Host "[ERROR] -Reinstall (or -Silent/-ExportOnly) requires -c, -e, -j OR installer-code.txt (3 lines)." -ForegroundColor Red
                Write-Host ("        Expected: {0}" -f $InstallerCodeFile) -ForegroundColor Yellow
            }
            exit 1
        }
    }

    $null = Show-ServicesTable -Phase 'Initial'

    if ($Reinstall) {
        Write-HostIfNotQuiet ""
        Write-HostIfNotQuiet "Reinstall mode: forcing full uninstall before install (best-effort)." 'Yellow'
        Run-Uninstall
        $null = Show-ServicesTable -Phase 'PostUninstall'
    }
    else {
        if (Any-ServiceRunning) {
            if (-not $Silent) {
                Write-HostIfNotQuiet ""
                $ans = Read-Host "Uninstall ConnectSecure before reinstall?  (Press Enter to start uninstall, or type N to skip)"
                if ([string]::IsNullOrWhiteSpace($ans) -or $ans.Trim().ToUpperInvariant() -eq 'Y') {
                    Run-Uninstall
                    $null = Show-ServicesTable -Phase 'PostUninstall'
                } else {
                    Write-HostIfNotQuiet "Skipping uninstall." 'Yellow'
                    exit 0
                }
            } else {
                Run-Uninstall
                $null = Show-ServicesTable -Phase 'PostUninstall'
            }
        }
    }

    # Install values
    $companyId = $Company
    $tenantId  = $Tenant
    $secretKey = $Secret

    # If still missing, re-check file (in case created mid-run)
    if ([string]::IsNullOrWhiteSpace($companyId) -or
        [string]::IsNullOrWhiteSpace($tenantId)  -or
        [string]::IsNullOrWhiteSpace($secretKey)) {

        $codes2 = Get-InstallerCodesFromFile -Path $InstallerCodeFile
        if ($codes2) {
            if ([string]::IsNullOrWhiteSpace($companyId) -and $codes2.Company) { $companyId = $codes2.Company }
            if ([string]::IsNullOrWhiteSpace($tenantId)  -and $codes2.Tenant)  { $tenantId  = $codes2.Tenant }
            if ([string]::IsNullOrWhiteSpace($secretKey) -and $codes2.Secret)  { $secretKey = $codes2.Secret }
        }
    }

    # Prompt ONLY if still missing
    if (-not $Silent -and -not $ExportOnly) {
        if ([string]::IsNullOrWhiteSpace($companyId)) { $companyId = Read-Host "Enter Company ID" }
        if ([string]::IsNullOrWhiteSpace($tenantId))  { $tenantId  = Read-Host "Enter Tenant ID" }
        if ([string]::IsNullOrWhiteSpace($secretKey)) { $secretKey = Read-Host "Enter Secret Key" }
    }

    if ([string]::IsNullOrWhiteSpace($companyId) -or
        [string]::IsNullOrWhiteSpace($tenantId)  -or
        [string]::IsNullOrWhiteSpace($secretKey)) {

        if (-not $Silent) {
            Write-Host "[ERROR] Missing required install values (Company/Tenant/Secret)." -ForegroundColor Red
            Write-Host ("        Provide -c/-e/-j OR create: {0} (3 lines)" -f $InstallerCodeFile) -ForegroundColor Yellow
        }
        exit 1
    }

    Write-HostIfNotQuiet ""
    Write-HostIfNotQuiet "Using TLS 1.2 for secure agent link download..." 'Cyan'
    $resp = Invoke-RestWithRetry -Uri $AgentApiUrl -MaxAttempts 3 -DelaySeconds 2 -What "agent download URL"
    if (-not $resp) {
        if (-not $Silent) { Write-Host "[ERROR] Unable to retrieve agent link from API after 3 attempts." -ForegroundColor Red }
        exit 2
    }

    $source = Get-DownloadUrl -Resp $resp
    if (-not $source) {
        if (-not $Silent) { Write-Host "[ERROR] API response did not include a usable download URL." -ForegroundColor Red }
        exit 3
    }

    $ok = Invoke-DownloadWithRetry -Uri $source -OutFile $InstallerPath -MaxAttempts 3 -DelaySeconds 2 -What "agent installer"
    if (-not $ok) { exit 4 }

    Show-StepSummary -Index 2 -Total 3 -Message "Download phase completed (agent URL retrieved from API and installer binary downloaded)."

    if (-not $Silent) {
        $masked = if ($secretKey.Length -gt 6) { ('*' * ($secretKey.Length - 4)) + $secretKey.Substring($secretKey.Length - 4) } else { '****' }
        $preview = "$InstallerPath -c $companyId -e $tenantId -j $masked -i"
        Write-HostIfNotQuiet ""
        Write-HostIfNotQuiet "Executing:" 'Yellow'
        Write-HostIfNotQuiet "  $preview" 'White'
        if (-not $Quiet) { Start-Sleep -Seconds 2 }
    }

    if ($Quiet -or $Silent) {
        cmd /c "`"$InstallerPath`" -c $companyId -e $tenantId -j $secretKey -i" > $null 2>&1
    } else {
        cmd /c "`"$InstallerPath`" -c $companyId -e $tenantId -j $secretKey -i"
    }
    $exitCode = $LASTEXITCODE

    if ($exitCode -eq 0) { Write-HostIfNotQuiet "[OK] Agent installation completed successfully." 'Green' }
    else {
        if (-not $Silent) { Write-HostIfNotQuiet ("[ERROR] Agent installation failed (Exit Code: {0})." -f $exitCode) 'Red' }
    }

    Start-AgentServices
    $finalRows = Show-ServicesTable -Phase 'Final'
    $agentRow   = $finalRows | Where-Object { $_ -is [psobject] -and $_.Service -eq 'CyberCNSAgent' }
    $statusText = if ($agentRow) { $agentRow.Status } else { 'Unknown' }

    Show-StepSummary -Index 3 -Total 3 -Message ("Install phase completed (services started where possible; CyberCNSAgent status: {0})." -f $statusText)

    if ($agentRow -and $agentRow.Status -eq 'Running') {
        Write-HostIfNotQuiet ""
        Write-HostIfNotQuiet "ConnectSecure has been successfully installed." 'Green'
    }

    if (-not $Reinstall -and -not $Quiet -and -not $Silent -and -not $ExportOnly) {
        Read-Host -Prompt "Press Enter to exit"
    }

    if ($exitCode -ne 0) { exit $exitCode }
}
catch {
    if (-not $Silent) { Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red }
    exit 9
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
    if (-not $Silent) { Write-HostIfNotQuiet ("Log file saved to: {0}" -f $logFile) 'DarkGray' }
}
