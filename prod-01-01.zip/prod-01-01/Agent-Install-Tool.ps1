<#
.SYNOPSIS
    ConnectSecure (CyberCNS) Agent Install / Reinstall Helper

.DESCRIPTION
    - Logs to C:\CS-Toolbox-TEMP\Collected-Info
    - First shows current service state for CyberCNSAgent and ConnectSecureAgentMonitor
    - If either service is RUNNING, prompts: "Uninstall ConnectSecure before reinstall? (Press Enter to start)"
      - Enter = run uninstall (vendor uninstall.bat if present, else raw fallback)
      - Type N and Enter to skip uninstall  -> NOW returns to Agent Menu (no prompts)
    - Downloads latest agent link via API (TLS 1.2) with 3-try retry
    - Downloads installer with 3-try retry
    - Installs with: cybercnsagent.exe -c company -e tenant -j key -i   (NO quotes around values)
    - Shows post-install service table and success guidance
#>

# ====================== Setup / Logging ======================
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$shortDate = Get-Date -Format "yyyy-MM-dd"
$shortTime = Get-Date -Format "HHmm"
$hostname  = $env:COMPUTERNAME

$exportDir = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path -LiteralPath $exportDir)) {
    New-Item -Path $exportDir -ItemType Directory -Force | Out-Null
}
$logFile = Join-Path $exportDir "$hostname-AgentInstall-$shortDate-$shortTime.txt"
try { Start-Transcript -Path $logFile -Append | Out-Null } catch {}

# ====================== Constants ============================
$AgentApiUrl      = "https://configuration.myconnectsecure.com/api/v4/configuration/agentlink?ostype=windows"
$DownloadRoot     = "C:\CS-Toolbox-TEMP\Downloads"
$InstallerPath    = Join-Path $DownloadRoot "cybercnsagent.exe"

$AgentDir         = "C:\Program Files (x86)\CyberCNSAgent"
$UninstallBatPath = Join-Path $AgentDir "uninstall.bat"

# Raw uninstall fallback (batch)
$RawUninstall = @"
@echo off
ping 127.0.0.1 -n 6 > nul
cd "C:\PROGRA~2"
sc stop ConnectSecureAgentMonitor
timeout /T 5 > nul
sc delete ConnectSecureAgentMonitor
timeout /T 5 > nul
sc stop CyberCNSAgent
timeout /T 5 > nul
sc delete CyberCNSAgent
ping 127.0.0.1 -n 6 > nul
taskkill /IM osqueryi.exe /F
taskkill /IM nmap.exe /F
taskkill /IM cyberutilities.exe /F
if exist "CyberCNSAgent\cybercnsagent.exe" CyberCNSAgent\cybercnsagent.exe --internalAssetArgument uninstallservice
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f
rmdir "CyberCNSAgent" /s /q
"@

# ====================== Helpers ==============================
function Enable-Tls12 {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
}

function Return-ToAgentMenu {
    Write-Host ""
    Write-Host "Returning to Agent Menu..." -ForegroundColor Yellow
    exit 0
}

# --- Retry helpers ---
function Invoke-RestWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2,
        [string]$What = "agent link"
    )
    Enable-Tls12
    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        Write-Host ("Fetching {0}... Attempt {1}/{2}" -f $What, $attempt, $MaxAttempts) -ForegroundColor Cyan
        try {
            $resp = Invoke-RestMethod -Method Get -Uri $Uri -ErrorAction Stop
            Write-Host "Request successful." -ForegroundColor Green
            return $resp
        } catch {
            if ($attempt -eq $MaxAttempts) {
                Write-Host ("ERROR: Failed to fetch {0} on attempt {1}/{2}: {3}" -f $What, $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Red
                return $null
            } else {
                Write-Host ("Attempt {0}/{1} failed: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Yellow
                Write-Host ("Retrying in {0} seconds..." -f $DelaySeconds) -ForegroundColor Yellow
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }
    return $null
}

function Invoke-DownloadWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$OutFile,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2,
        [string]$What = "installer"
    )
    Enable-Tls12
    $outDir = Split-Path -Parent $OutFile
    if (-not (Test-Path -LiteralPath $outDir)) {
        New-Item -ItemType Directory -Path $outDir -Force | Out-Null
    }

    if (Test-Path -LiteralPath $OutFile) {
        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
    }

    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        Write-Host ("Downloading {0}... Attempt {1}/{2}" -f $What, $attempt, $MaxAttempts) -ForegroundColor Cyan
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
            if ((Test-Path -LiteralPath $OutFile) -and ((Get-Item -LiteralPath $OutFile).Length -gt 0)) {
                Write-Host "Download successful." -ForegroundColor Green
                return $true
            } else { throw "Downloaded file is missing or empty." }
        } catch {
            if (Test-Path -LiteralPath $OutFile) {
                Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
            }
            if ($attempt -eq $MaxAttempts) {
                Write-Host ("ERROR: Download failed on attempt {0}/{2}: {1}" -f $attempt, $_.Exception.Message, $MaxAttempts) -ForegroundColor Red
                return $false
            } else {
                Write-Host ("Attempt {0}/{2} failed: {1}" -f $attempt, $_.Exception.Message, $MaxAttempts) -ForegroundColor Yellow
                Write-Host ("Retrying in {0} seconds..." -f $DelaySeconds) -ForegroundColor Yellow
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }
    return $false
}
# --- end retry helpers ---

function Get-DownloadUrl {
    param([Parameter(Mandatory=$true)][object]$Resp)

    # Plain string?
    if ($Resp -is [string]) { if ($Resp -match '^https?://') { return $Resp } }

    # Common JSON shapes (best effort)
    try { if ($Resp.link        -and $Resp.link        -match '^https?://') { return [string]$Resp.link } } catch {}
    try { if ($Resp.url         -and $Resp.url         -match '^https?://') { return [string]$Resp.url } } catch {}
    try { if ($Resp.downloadUrl -and $Resp.downloadUrl -match '^https?://') { return [string]$Resp.downloadUrl } } catch {}
    try { if ($Resp.data -and $Resp.data.link -and $Resp.data.link -match '^https?://') { return [string]$Resp.data.link } } catch {}

    # Regex fallback: first https URL ending with .exe
    try {
        $json = $Resp | ConvertTo-Json -Depth 6 -Compress
        $m = [Regex]::Match($json, 'https?://[^"\\s]+?\.exe')
        if ($m.Success) { return $m.Value }
    } catch {}

    return $null
}

function Get-ServiceRow {
    param([Parameter(Mandatory=$true)][string]$Name)

    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if ($null -eq $svc) {
        return [PSCustomObject]@{
            Service   = $Name
            Installed = 'No'
            Status    = 'Not Installed'
            StartType = 'N/A'
        }
    }

    $startMode = 'Unknown'
    try {
        $wmi = Get-WmiObject -Class Win32_Service -Filter ("Name='{0}'" -f $Name) -ErrorAction SilentlyContinue
        if ($wmi -and $wmi.StartMode) { $startMode = $wmi.StartMode }
    } catch {}

    return [PSCustomObject]@{
        Service   = $Name
        Installed = 'Yes'
        Status    = $svc.Status.ToString()
        StartType = $startMode
    }
}

function Show-ServicesTable {
    $rows = @(
        Get-ServiceRow -Name 'CyberCNSAgent'
        Get-ServiceRow -Name 'ConnectSecureAgentMonitor'
    )
    Write-Host ""
    Write-Host "=== ConnectSecure Services ===" -ForegroundColor Cyan
    $rows | Format-Table Service, Installed, Status, StartType -AutoSize | Out-Host
    Write-Host ""
    Write-Host "Note: It is normal for only 'CyberCNSAgent' to be present immediately after the first install." -ForegroundColor Yellow
    return ,$rows
}

function Any-ServiceRunning {
    $svc1 = Get-Service -Name 'CyberCNSAgent' -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name 'ConnectSecureAgentMonitor' -ErrorAction SilentlyContinue
    return (($svc1 -and $svc1.Status -eq 'Running') -or ($svc2 -and $svc2.Status -eq 'Running'))
}

function Run-Uninstall {
    Write-Host ""
    Write-Host "Starting uninstall process..." -ForegroundColor Yellow

    # Pre-trigger if binary exists
    if (Test-Path (Join-Path $AgentDir 'cybercnsagent.exe')) {
        try { & (Join-Path $AgentDir 'cybercnsagent.exe') -r } catch {}
    }

    # Use vendor uninstall.bat if present, else fallback
    $uninstallScript = if (Test-Path -LiteralPath $UninstallBatPath) {
        Write-Host "Found vendor uninstall.bat, using it." -ForegroundColor Green
        Get-Content $UninstallBatPath -Raw
    } else {
        Write-Host "Vendor uninstall.bat not found. Using built-in fallback." -ForegroundColor Yellow
        $RawUninstall
    }

    $tempBat = Join-Path $env:TEMP "_agent_uninstall.bat"
    try {
        $uninstallScript | Out-File -FilePath $tempBat -Encoding ASCII -Force
        Write-Host "Executing uninstall script..." -ForegroundColor Cyan
        cmd /c $tempBat
    } finally {
        Remove-Item $tempBat -Force -ErrorAction SilentlyContinue
    }

    Write-Host "Uninstall process completed." -ForegroundColor Green
}

function Start-AgentServices {
    foreach ($n in @('CyberCNSAgent','ConnectSecureAgentMonitor')) {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne 'Running') {
            Write-Host ("Starting {0} ..." -f $n) -ForegroundColor Cyan
            try { Start-Service -Name $n -ErrorAction Stop; $svc.WaitForStatus('Running','00:00:25'); Write-Host ("[OK] {0} is Running" -f $n) -ForegroundColor Green }
            catch { Write-Host ("[WARN] Could not start {0}: {1}" -f $n, $_.Exception.Message) -ForegroundColor Yellow }
        } elseif ($svc) {
            Write-Host ("[OK] {0} already Running" -f $n) -ForegroundColor Green
        }
    }
}

# ====================== Flow ================================
try {
    # 0) Show current services up-front
    $preRows = Show-ServicesTable

    # 1) If either service is RUNNING, prompt to uninstall first
    if (Any-ServiceRunning) {
        Write-Host ""
        $ans = Read-Host "Uninstall ConnectSecure before reinstall?  (Press Enter to start uninstall, or type N to skip)"
        if ([string]::IsNullOrWhiteSpace($ans) -or $ans.Trim().ToUpperInvariant() -eq 'Y') {
            Run-Uninstall
            # After uninstall, re-show status
            $null = Show-ServicesTable
        } else {
            Write-Host "Skipping uninstall." -ForegroundColor Yellow
            Return-ToAgentMenu
        }
    }

    # 2) Collect install parameters
    $companyId = Read-Host "Enter Company ID"
    $tenantId  = Read-Host "Enter Tenant ID"
    $secretKey = Read-Host "Enter Secret Key"

    # 3) Get latest agent URL (TLS 1.2) with retries
    Write-Host ""
    Write-Host "Using TLS 1.2 for secure agent link download..." -ForegroundColor Cyan
    $resp = Invoke-RestWithRetry -Uri $AgentApiUrl -MaxAttempts 3 -DelaySeconds 2 -What "agent download URL"
    if (-not $resp) {
        Write-Host "[ERROR] Unable to retrieve agent link from API after 3 attempts." -ForegroundColor Red
        Read-Host -Prompt "Press Enter to exit"
        return
    }

    $source = Get-DownloadUrl -Resp $resp
    if (-not $source) {
        Write-Host "[ERROR] API response did not include a usable download URL." -ForegroundColor Red
        Read-Host -Prompt "Press Enter to exit"
        return
    }

    # 4) Download installer with retries
    $ok = Invoke-DownloadWithRetry -Uri $source -OutFile $InstallerPath -MaxAttempts 3 -DelaySeconds 2 -What "agent installer"
    if (-not $ok) {
        Read-Host -Prompt "Press Enter to exit"
        return
    }

    # 5) Build and run install command (NO quotes around values)
    $masked = if ($secretKey.Length -gt 6) { ('*' * ($secretKey.Length - 4)) + $secretKey.Substring($secretKey.Length - 4) } else { '****' }
    $preview = "$InstallerPath -c $companyId -e $tenantId -j $masked -i"
    Write-Host ""
    Write-Host "Executing:" -ForegroundColor Yellow
    Write-Host "  $preview" -ForegroundColor White
    Start-Sleep -Seconds 2

    cmd /c "$InstallerPath -c $companyId -e $tenantId -j $secretKey -i"
    $exit = $LASTEXITCODE

    if ($exit -eq 0) {
        Write-Host "[OK] Agent installation completed successfully." -ForegroundColor Green
    } else {
        Write-Host ("[ERROR] Agent installation failed (Exit Code: {0})." -f $exit) -ForegroundColor Red
    }

    # 6) Post-install: attempt to start services and show final table
    Start-AgentServices
    $finalRows = Show-ServicesTable

    $agentRow = $finalRows | Where-Object { $_ -is [psobject] -and $_.Service -eq 'CyberCNSAgent' }
    if ($agentRow -and $agentRow.Status -eq 'Running') {
        Write-Host ""
        Write-Host "ConnectSecure has been successfully installed, exit to Agent Menu" -ForegroundColor Green
    }

    Read-Host -Prompt "Press Enter to exit"
}
catch {
    Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red
    Read-Host -Prompt "Press Enter to exit"
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
    Write-Host ("Log file saved to: {0}" -f $logFile) -ForegroundColor DarkGray
}
