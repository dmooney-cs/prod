# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    try {
        . $commonPath
    } catch {
        Write-Host "❌ ERROR: Exception occurred while loading Functions-Common.ps1"
        Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host "`nPress any key to exit..."
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        return
    }
} else {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "Expected path: $commonPath"
    Write-Host "`nThis script cannot continue without common functions."
    Write-Host "`nPress any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Active Directory Tools                                 ║
# ║ Version: AD.2 | Users, Groups, OUs, GPO Links                               ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

Ensure-ExportFolder

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`nExported to: $Path" -ForegroundColor Cyan
}

function Get-ADUsers {
    Show-Header "Active Directory Users"
    try {
        $users = Get-ADUser -Filter * -Properties Name, SamAccountName, Enabled, LastLogonDate |
            Select-Object Name, SamAccountName, Enabled, LastLogonDate
        Export-Data -Object $users -BaseName "AD-Users"
    } catch {
        Write-Host "❌ Failed to query AD users. Ensure RSAT tools are installed and script is run as domain user." -ForegroundColor Red
    }
    Pause-Script
}

function Get-ADGroups {
    Show-Header "Active Directory Groups"
    try {
        $groups = Get-ADGroup -Filter * -Properties Name, GroupCategory, GroupScope |
            Select-Object Name, GroupCategory, GroupScope
        Export-Data -Object $groups -BaseName "AD-Groups"
    } catch {
        Write-Host "❌ Failed to query AD groups." -ForegroundColor Red
    }
    Pause-Script
}

function Get-ADOUs {
    Show-Header "Active Directory Organizational Units"
    try {
        $ous = Get-ADOrganizationalUnit -Filter * |
            Select-Object Name, DistinguishedName
        Export-Data -Object $ous -BaseName "AD-OUs"
    } catch {
        Write-Host "❌ Failed to query AD OUs." -ForegroundColor Red
    }
    Pause-Script
}

function Get-GPOLinks {
    Show-Header "Group Policy Object Links"
    try {
        $gpos = Get-GPO -All | Select-Object DisplayName, GpoStatus, CreationTime, ModificationTime
        Export-Data -Object $gpos -BaseName "AD-GPOs"
    } catch {
        Write-Host "❌ Failed to query GPOs." -ForegroundColor Red
    }
    Pause-Script
}

function Show-ADMenu {
    Clear-Host
    Write-Host "====================================================="
    Write-Host "     CS Toolbox - Active Directory Tools"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Export AD Users"
    Write-Host " [2] Export AD Groups"
    Write-Host " [3] Export AD Organizational Units"
    Write-Host " [4] Export Group Policy Objects"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

# Main Loop
do {
    Show-ADMenu
    $choice = Read-Host "Select an option"
    switch ($choice) {
        '1' { Get-ADUsers }
        '2' { Get-ADGroups }
        '3' { Get-ADOUs }
        '4' { Get-GPOLinks }
        'Z' { Invoke-ZipAndEmailResults }
        'C' { Invoke-CleanupExport }
        'Q' { return }
        default {
            Write-Host "`nInvalid selection. Please choose again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
