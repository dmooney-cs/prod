# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ============================ ValidationTool-AD.ps1 ============================
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# --- Paths / helpers
$ExportRoot = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path $ExportRoot)) { New-Item -Path $ExportRoot -ItemType Directory | Out-Null }
function Get-Timestamp { (Get-Date).ToString("yyyy-MM-dd_HH-mm-ss") }
function New-ExportPath { param([Parameter(Mandatory)][string]$Prefix, [string]$Ext = "csv"); Join-Path $ExportRoot ("{0}_{1}.{2}" -f $Prefix, (Get-Timestamp), $Ext) }

# --------------------------- Module checks ---------------------------
function Ensure-ADModule {
    if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
        throw "RSAT ActiveDirectory module not found. Install RSAT AD tools and try again."
    }
    Import-Module ActiveDirectory -ErrorAction Stop | Out-Null
}

function Ensure-GPModule {
    if (-not (Get-Module -ListAvailable -Name GroupPolicy)) {
        Write-Host "WARNING: GroupPolicy module not found. GPO listing will be skipped." -ForegroundColor Yellow
        return $false
    }
    Import-Module GroupPolicy -ErrorAction Stop | Out-Null
    return $true
}

# --------------------------- [1] Domain Summary ---------------------------
function Invoke-ADDomainSummary {
    Show-Header "AD Tools - Domain Summary"
    try {
        Ensure-ADModule
        $dom = Get-ADDomain
        $forest = Get-ADForest
        $row = [pscustomobject]@{
            DomainName              = $dom.DNSRoot
            NetBIOSName             = $dom.NetBIOSName
            ForestName              = $forest.Name
            FunctionalLevelDomain   = $dom.DomainMode
            FunctionalLevelForest   = $forest.ForestMode
            PDCEmulator             = $dom.PDCEmulator
            RIDMaster               = $dom.RIDMaster
            InfrastructureMaster    = $dom.InfrastructureMaster
            DomainControllers       = ($dom.ReplicaDirectoryServers -join ', ')
        }
        $out = New-ExportPath -Prefix "AD_DomainSummary"
        $row | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $out
        Write-Host ""
        $row | Format-List
        Write-Host ("Saved: {0}" -f $out) -ForegroundColor Green
    } catch {
        Write-Host "Domain summary failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

# --------------------------- [2] User Reports ---------------------------
function Invoke-ADUsersReport {
    Show-Header "AD Tools - Users (Locked/Disabled/Recent)"

    try {
        Ensure-ADModule
        $since = (Get-Date).AddDays(-30)

        $users = Get-ADUser -Filter * -Properties whenCreated, Enabled, LockedOut, LastLogonDate -ErrorAction Stop

        $locked   = $users | Where-Object { $_.LockedOut -eq $true }
        $disabled = $users | Where-Object { $_.Enabled -eq $false }
        $recent   = $users | Where-Object { $_.whenCreated -ge $since }

        $outLocked   = New-ExportPath -Prefix "AD_Users_Locked"
        $outDisabled = New-ExportPath -Prefix "AD_Users_Disabled"
        $outRecent   = New-ExportPath -Prefix "AD_Users_Recent30d"

        $locked   | Select-Object SamAccountName, Name, Enabled, LockedOut, LastLogonDate |
            Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outLocked
        $disabled | Select-Object SamAccountName, Name, Enabled, LockedOut, LastLogonDate |
            Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outDisabled
        $recent   | Select-Object SamAccountName, Name, whenCreated, Enabled |
            Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outRecent

        Write-Host ""
        Write-Host ("Locked out: {0} | Disabled: {1} | Recent(30d): {2}" -f ($locked.Count), ($disabled.Count), ($recent.Count)) -ForegroundColor Cyan
        Write-Host ("Saved: {0}" -f $outLocked)   -ForegroundColor Green
        Write-Host ("Saved: {0}" -f $outDisabled) -ForegroundColor Green
        Write-Host ("Saved: {0}" -f $outRecent)   -ForegroundColor Green
    } catch {
        Write-Host "User report failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

# --------------------------- [3] Group Reports ---------------------------
function Invoke-ADGroupReport {
    Show-Header "AD Tools - Groups (Admins and Critical)"

    try {
        Ensure-ADModule

        $groupsToCheck = @(
            'Domain Admins',
            'Enterprise Admins',
            'Schema Admins',
            'Administrators',
            'Account Operators',
            'Backup Operators',
            'Server Operators'
        )

        $rows = New-Object System.Collections.Generic.List[object]
        foreach ($g in $groupsToCheck) {
            try {
                $members = Get-ADGroupMember -Identity $g -Recursive -ErrorAction Stop | Select-Object -ExpandProperty SamAccountName
                if (-not $members) { $members = @() }
                $rows.Add([pscustomobject]@{ Group=$g; Members=($members -join ', ') })
            } catch {
                $rows.Add([pscustomobject]@{ Group=$g; Members="(group not found)" })
            }
        }

        $out = New-ExportPath -Prefix "AD_Group_Admins"
        $rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $out
        Write-Host ""
        $rows | Format-Table Group, Members -AutoSize
        Write-Host ("Saved: {0}" -f $out) -ForegroundColor Green
    } catch {
        Write-Host "Group report failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

# --------------------------- [4] OU Listing ---------------------------
function Invoke-ADOUList {
    Show-Header "AD Tools - Organizational Units"

    try {
        Ensure-ADModule
        $ous = Get-ADOrganizationalUnit -Filter * -Properties Name, DistinguishedName, ProtectedFromAccidentalDeletion, ManagedBy -ErrorAction Stop |
            Select-Object Name, DistinguishedName, ProtectedFromAccidentalDeletion, ManagedBy

        $out = New-ExportPath -Prefix "AD_OUs"
        $ous | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $out

        Write-Host ""
        $ous | Sort-Object Name | Format-Table Name, ProtectedFromAccidentalDeletion, ManagedBy -AutoSize
        Write-Host ("Saved: {0}" -f $out) -ForegroundColor Green
    } catch {
        Write-Host "OU list failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

# --------------------------- [5] GPO Listing ---------------------------
function Invoke-ADGPOList {
    Show-Header "AD Tools - Group Policy Objects"

    try {
        $gpok = Ensure-GPModule
        if (-not $gpok) { Pause-Script; return }

        $gpos = Get-GPO -All -ErrorAction Stop | Select-Object DisplayName, GpoStatus, CreationTime, ModificationTime, Id, Owner
        $out = New-ExportPath -Prefix "AD_GPOs"
        $gpos | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $out

        Write-Host ""
        $gpos | Sort-Object DisplayName | Format-Table DisplayName, GpoStatus, ModificationTime, Owner -AutoSize
        Write-Host ("Saved: {0}" -f $out) -ForegroundColor Green
    } catch {
        Write-Host "GPO list failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script
}

# --------------------------- Menu ---------------------------
function Show-ADMenu {
    Clear-Host
    Show-Header "Active Directory Tools"

    Write-Host ""
    Write-Host " [1] Domain Summary           - Domain/Forest details, FSMO roles"
    Write-Host " [2] User Reports             - Locked, Disabled, Recent(30d)"
    Write-Host " [3] Group Reports            - Admin and critical groups"
    Write-Host " [4] OU Listing               - Name, DN, Protected, ManagedBy"
    Write-Host " [5] GPO Listing              - All GPOs (requires GroupPolicy)"
    Write-Host ""
    Write-Host " [Q] Return to Main Menu"
    Write-Host ""

    $choice = (Read-Host "Enter choice").Trim().ToUpperInvariant()
    switch ($choice) {
        '1' { Invoke-ADDomainSummary; return $true }
        '2' { Invoke-ADUsersReport;   return $true }
        '3' { Invoke-ADGroupReport;   return $true }
        '4' { Invoke-ADOUList;        return $true }
        '5' { Invoke-ADGPOList;       return $true }
        'Q' { return $false }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
            return $true
        }
    }
}

do {
    $again = Show-ADMenu
} while ($again)
