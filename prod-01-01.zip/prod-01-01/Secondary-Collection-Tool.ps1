# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

<# ===================================================================
   Secondary Collection Tools
   - [1] Windows Patch Audit (WMI)
   - [2] VC++ Runtime Validation
   - [3] TLS/SSL Policy Audit (Local Host)
   - [4] Search Registry Uninstall Strings  <<< NEW
   - [Q] Return to Launcher (same window)
   Exports -> C:\CS-Toolbox-TEMP\Collected-Info\*
   =================================================================== #>

# ----------------------------
# Local helper fallbacks (safe if common funcs missing)
# ----------------------------
function _Ensure-ExportFolderLocal {
    param([string]$Base="C:\CS-Toolbox-TEMP\Collected-Info")
    try {
        if (-not (Test-Path $Base)) { New-Item -Path $Base -ItemType Directory -Force | Out-Null }
        return $Base
    } catch {
        Write-Host "❌ ERROR creating export folder: $($_.Exception.Message)" -ForegroundColor Red
        return "C:\CS-Toolbox-TEMP"
    }
}
function _PauseLocal {
    Write-Host "Press any key to continue..." -ForegroundColor DarkGray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
function _SanitizeFilePart([string]$name) {
    $invalid = [IO.Path]::GetInvalidFileNameChars() -join ''
    return ($name -replace "[${invalid}]", '_') -replace '\s+', '_'
}

# ----------------------------
# [4] Registry Uninstall Search (fully inlined)
# ----------------------------
function Invoke-RegistryUninstallSearch {
    <#
    .SYNOPSIS
        Search Windows registry "Uninstall" entries for a string and export results.

    .DESCRIPTION
        Scans these locations:
          - HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall            (64-bit)
          - HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall (32-bit)
          - HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall            (per-user)

        Matches $Pattern (wildcards OK) case-insensitively across:
          DisplayName, DisplayVersion, Publisher, UninstallString, QuietUninstallString,
          InstallLocation, ModifyPath, URLInfoAbout, EstimatedSize

        Outputs a formatted table to screen, returns objects to the pipeline,
        and saves CSV + JSON under C:\CS-Toolbox-TEMP\Collected-Info\Registry.

    .PARAMETER Pattern
        The search text. Supports wildcards (e.g., *chrome*). Case-insensitive.

    .PARAMETER Exact
        If supplied, performs exact, case-insensitive equality on DisplayName only (fast path).

    .PARAMETER PauseAfter
        If set (default), will pause at the end using Pause-Script if available.

    .EXAMPLE
        Invoke-RegistryUninstallSearch -Pattern "*microsoft edge*"

    .EXAMPLE
        Invoke-RegistryUninstallSearch -Pattern "7-Zip" -Exact
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Pattern,
        [switch]$Exact,
        [switch]$PauseAfter
    )

    # Use shared helpers if available
    if (Get-Command -Name Ensure-ExportFolder -ErrorAction SilentlyContinue) {
        try { Ensure-ExportFolder } catch {}
    }
    $exportRoot = if (Test-Path "C:\CS-Toolbox-TEMP\Collected-Info") {
        "C:\CS-Toolbox-TEMP\Collected-Info"
    } else {
        _Ensure-ExportFolderLocal
    }

    $regDir = Join-Path $exportRoot "Registry"
    if (-not (Test-Path $regDir)) { New-Item -ItemType Directory -Path $regDir -Force | Out-Null }

    $stamp    = (Get-Date).ToString("yyyyMMdd_HHmmss")
    $patPart  = _SanitizeFilePart($Pattern)
    $csvPath  = Join-Path $regDir ("Registry-UninstallSearch_{0}_{1}.csv" -f $stamp, $patPart)
    $jsonPath = Join-Path $regDir ("Registry-UninstallSearch_{0}_{1}.json" -f $stamp, $patPart)

    $targets = @(
        "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",             # 64-bit
        "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",# 32-bit
        "Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall"               # Current user
    )
    $fieldsToScan = @(
        'DisplayName','DisplayVersion','Publisher',
        'UninstallString','QuietUninstallString',
        'InstallLocation','ModifyPath','URLInfoAbout','EstimatedSize'
    )

    Write-Host ""
    Write-Host "🔎 Search Registry Uninstall Strings" -ForegroundColor Cyan
    Write-Host "    Pattern : $Pattern"
    Write-Host "    Scope   : HKLM (64/32-bit) + HKCU" -ForegroundColor DarkGray
    if ($Exact) { Write-Host "    Mode    : Exact (DisplayName only)" -ForegroundColor DarkGray }
    Write-Host ""

    $results = New-Object System.Collections.Generic.List[object]

    foreach ($root in $targets) {
        if (-not (Test-Path $root)) { continue }
        try {
            Get-ChildItem -Path $root -ErrorAction SilentlyContinue | ForEach-Object {
                $subKey = $_
                try {
                    $p = Get-ItemProperty -LiteralPath $subKey.PSPath -ErrorAction SilentlyContinue
                    if (-not $p) { return }

                    $obj = [pscustomobject]@{
                        Hive                 = $root
                        KeyName              = $subKey.PSChildName
                        DisplayName          = $p.DisplayName
                        DisplayVersion       = $p.DisplayVersion
                        Publisher            = $p.Publisher
                        InstallDate          = $p.InstallDate
                        InstallLocation      = $p.InstallLocation
                        EstimatedSizeKB      = $p.EstimatedSize
                        UninstallString      = $p.UninstallString
                        QuietUninstallString = $p.QuietUninstallString
                        ModifyPath           = $p.ModifyPath
                        URLInfoAbout         = $p.URLInfoAbout
                    }

                    $isMatch = $false
                    if ($Exact) {
                        if ([string]::IsNullOrEmpty($obj.DisplayName)) { $isMatch = $false }
                        else { $isMatch = ($obj.DisplayName -ieq $Pattern) }
                    } else {
                        foreach ($f in $fieldsToScan) {
                            $val = $obj.$f
                            if ($null -ne $val) {
                                if ($val -like $Pattern) { $isMatch = $true; break }
                                if ($Pattern -notmatch '[\*\?\[\]]') {
                                    if ($val.ToString().IndexOf($Pattern, 'InvariantCultureIgnoreCase') -ge 0) { $isMatch = $true; break }
                                }
                            }
                        }
                    }

                    if ($isMatch) { $results.Add($obj) | Out-Null }
                } catch { }
            }
        } catch {
            Write-Host "WARN: Failed scanning $root : $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }

    $count = $results.Count
    if ($count -eq 0) {
        Write-Host "No matching uninstall entries found for pattern: $Pattern" -ForegroundColor Yellow
    } else {
        Write-Host "Found $count matching uninstall entr$([string]::Concat(($count -eq 1) ? 'y' : 'ies')):`n" -ForegroundColor Green
        $results |
            Sort-Object DisplayName, DisplayVersion |
            Select-Object DisplayName, DisplayVersion, Publisher, InstallLocation, UninstallString, Hive, KeyName |
            Format-Table -AutoSize
        Write-Host ""
    }

    try {
        $results | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
        ($results | ConvertTo-Json -Depth 5) | Set-Content -LiteralPath $jsonPath -Encoding UTF8
        Write-Host "📄 Exported CSV : $csvPath" -ForegroundColor DarkCyan
        Write-Host "📄 Exported JSON: $jsonPath" -ForegroundColor DarkCyan
    } catch {
        Write-Host "❌ ERROR exporting results: $($_.Exception.Message)" -ForegroundColor Red
    }

    if (Get-Command -Name Write-SessionSummary -ErrorAction SilentlyContinue) {
        try { Write-SessionSummary -Note "Registry uninstall search for '$Pattern' found $count item(s)." | Out-Null } catch {}
    }

    if ($PauseAfter.IsPresent) {
        if (Get-Command -Name Pause-Script -ErrorAction SilentlyContinue) { Pause-Script } else { _PauseLocal }
    }

    return $results
}

# ----------------------------
# [1] Windows Patch Audit (WMI) – inlined light version
# ----------------------------
function Run-WMIPatchAudit {
    [CmdletBinding()]
    param([switch]$PauseAfter)

    $exportRoot = if (Test-Path "C:\CS-Toolbox-TEMP\Collected-Info") {"C:\CS-Toolbox-TEMP\Collected-Info"} else { _Ensure-ExportFolderLocal }
    $outDir = Join-Path $exportRoot "Patches"
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }

    $stamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
    $csv   = Join-Path $outDir ("WMI-PatchAudit_{0}.csv" -f $stamp)
    $json  = Join-Path $outDir ("WMI-PatchAudit_{0}.json" -f $stamp)

    Write-Host ""
    Write-Host "🛠  Windows Patch Audit (WMI)" -ForegroundColor Cyan

    try {
        $qfes = Get-CimInstance -ClassName Win32_QuickFixEngineering -ErrorAction Stop |
            Select-Object CSName, HotFixID, InstalledOn, Description, Caption, FixComments, InstalledBy

        if (-not $qfes) {
            Write-Host "No QFE entries returned." -ForegroundColor Yellow
        } else {
            $qfes | Sort-Object InstalledOn -Descending | Format-Table -AutoSize
        }

        $qfes | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
        ($qfes | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $json -Encoding UTF8
        Write-Host "📄 Exported CSV : $csv"  -ForegroundColor DarkCyan
        Write-Host "📄 Exported JSON: $json" -ForegroundColor DarkCyan
    } catch {
        Write-Host "❌ ERROR running WMI patch audit: $($_.Exception.Message)" -ForegroundColor Red
    }

    if ($PauseAfter.IsPresent) {
        if (Get-Command Pause-Script -ErrorAction SilentlyContinue) { Pause-Script } else { _PauseLocal }
    }
}

# ----------------------------
# [3] TLS/SSL Policy Audit (Local Host) – inlined
# ----------------------------
function Run-TlsPolicyAudit {
    [CmdletBinding()]
    param([switch]$PauseAfter)

    $exportRoot = if (Test-Path "C:\CS-Toolbox-TEMP\Collected-Info") {"C:\CS-Toolbox-TEMP\Collected-Info"} else { _Ensure-ExportFolderLocal }
    $outDir = Join-Path $exportRoot "TLS"
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }

    $stamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
    $json  = Join-Path $outDir ("TLS-Policy_{0}.json" -f $stamp)

    Write-Host ""
    Write-Host "🔐 TLS/SSL Policy Audit (Local Host)" -ForegroundColor Cyan

    $paths = @{
        'SCHANNEL\Protocols' = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols'
        '.NET v2.0.50727'    = 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v2.0.50727'
        '.NET v4.0.30319'    = 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319'
        'WinHTTP\DefaultSecureProtocols' = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp'
    }

    $report = [ordered]@{}
    foreach ($name in $paths.Keys) {
        $path = $paths[$name]
        $entry = New-Object System.Collections.Hashtable
        if (Test-Path $path) {
            try {
                if ($name -eq 'SCHANNEL\Protocols') {
                    $protocols = Get-ChildItem $path -ErrorAction SilentlyContinue | ForEach-Object {
                        $proto = $_.PSChildName
                        $modes = Get-ChildItem $_.PSPath -ErrorAction SilentlyContinue | ForEach-Object {
                            $mode = $_.PSChildName
                            $vals = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
                            [pscustomobject]@{
                                Protocol     = $proto
                                Mode         = $mode
                                Enabled      = $vals.Enabled
                                DisabledByDefault = $vals.DisabledByDefault
                            }
                        }
                        $modes
                    }
                    $entry['Protocols'] = $protocols
                } else {
                    $vals = Get-ItemProperty -LiteralPath $path -ErrorAction SilentlyContinue
                    $entry['Values'] = $vals.PSObject.Properties | Where-Object {$_.Name -notlike '*PS*'} | ForEach-Object {
                        [pscustomobject]@{ Name=$_.Name; Value=$_.Value }
                    }
                }
            } catch {
                $entry['Error'] = $_.Exception.Message
            }
        } else {
            $entry['Missing'] = $true
        }
        $report[$name] = $entry
    }

    # Display summary to screen
    if ($report['SCHANNEL\Protocols']['Protocols']) {
        $report['SCHANNEL\Protocols']['Protocols'] |
            Sort-Object Protocol, Mode |
            Format-Table Protocol, Mode, Enabled, DisabledByDefault -AutoSize
    } else {
        Write-Host "No SCHANNEL protocol info available (path missing or no subkeys)." -ForegroundColor Yellow
    }

    # Export JSON
    try {
        ($report | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath $json -Encoding UTF8
        Write-Host "📄 Exported JSON: $json" -ForegroundColor DarkCyan
    } catch {
        Write-Host "❌ ERROR exporting TLS report: $($_.Exception.Message)" -ForegroundColor Red
    }

    if ($PauseAfter.IsPresent) {
        if (Get-Command Pause-Script -ErrorAction SilentlyContinue) { Pause-Script } else { _PauseLocal }
    }
}

# ----------------------------
# Return to Launcher (same window)
# ----------------------------
function Return-ToLauncher {
    try {
        $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
        if (Test-Path $launcher) {
            Clear-Host
            & $launcher
        } else {
            Write-Host "Launcher not found at $launcher. Exiting script..." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "Failed to return to launcher: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ----------------------------
# Menu Loop
# ----------------------------
while ($true) {
    Clear-Host
    Show-Header "Secondary Collection Tools"

    Write-Host ""
    Write-Host " [1] Windows Patch Audit (WMI)           - Installed updates via WMI" -ForegroundColor White
    Write-Host " [2] VC++ Runtime Validation             - Detect & list Visual C++ runtimes" -ForegroundColor White
    Write-Host " [3] TLS/SSL Policy Audit (Local Host)   - Check local TLS/SSL registry policies" -ForegroundColor White
    Write-Host " [4] Search Registry Uninstall Strings   - Find uninstall entries by keyword" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
    $choice = Read-Host "Enter your choice"

    switch -Regex ($choice) {
        '^(1)$' {
            Run-WMIPatchAudit -PauseAfter
        }

        '^(2)$' {
            if (Get-Command -Name Run-VcppValidation -ErrorAction SilentlyContinue) {
                try { Run-VcppValidation -VerbosePreference SilentlyContinue } catch {
                    Write-Host "❌ ERROR running VC++ validation: $($_.Exception.Message)" -ForegroundColor Red
                    if (Get-Command Pause-Script -ErrorAction SilentlyContinue) { Pause-Script } else { _PauseLocal }
                }
            } else {
                Write-Host "Run-VcppValidation not available in Functions-Common.ps1." -ForegroundColor Yellow
                if (Get-Command Pause-Script -ErrorAction SilentlyContinue) { Pause-Script } else { _PauseLocal }
            }
        }

        '^(3)$' {
            Run-TlsPolicyAudit -PauseAfter
        }

        '^(4)$' {
            $pattern = Read-Host "Enter search text (wildcards OK, e.g. *chrome*)"
            if ([string]::IsNullOrWhiteSpace($pattern)) {
                Write-Host "No pattern entered. Returning to menu..." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            } else {
                Invoke-RegistryUninstallSearch -Pattern $pattern -PauseAfter
            }
        }

        '^(q|Q)$' {
            Return-ToLauncher
            break
        }

        default {
            Write-Host "Invalid selection. Please choose 1-4 or Q." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
        }
    }
}