# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

<# ===================================================================
   Secondary Collection Tools   (Secondary-Collection-Tool.ps1)
   [1] Windows Patch Audit (WMI)
   [2] VC++ Runtime Validation
   [3] TLS/SSL Policy Audit (Local Host)
   [4] Search Registry Uninstall Strings
   [Q] Return to Launcher (same window)

   Exports -> C:\CS-Toolbox-TEMP\Collected-Info\*
   =================================================================== #>

# ----------------------------
# Local helper fallbacks
# ----------------------------
function _Ensure-ExportFolderLocal {
    param([string]$Base="C:\CS-Toolbox-TEMP\Collected-Info")
    try {
        if (-not (Test-Path $Base)) { New-Item -Path $Base -ItemType Directory -Force | Out-Null }
        return $Base
    } catch {
        Write-Host "ERROR creating export folder: $($_.Exception.Message)" -ForegroundColor Red
        return "C:\CS-Toolbox-TEMP"
    }
}
function _PauseLocal {
    Write-Host "Press any key to continue..." -ForegroundColor DarkGray
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
function _SanitizeFilePart([string]$name) {
    $invalid = [IO.Path]::GetInvalidFileNameChars() -join ''
    return ($name -replace "[${invalid}]", '_') -replace '\s+', '_'
}

# ----------------------------
# [2] VC++ Runtime Validation (Fully Inlined)
# ----------------------------
function Run-VcppValidation {
    [CmdletBinding()]
    param([switch]$PauseAfter)

    if (Get-Command -Name Ensure-ExportFolder -ErrorAction SilentlyContinue) { try { Ensure-ExportFolder } catch {} }
    $exportRoot = if (Test-Path "C:\CS-Toolbox-TEMP\Collected-Info") { "C:\CS-Toolbox-TEMP\Collected-Info" } else { _Ensure-ExportFolderLocal }
    $outDir = Join-Path $exportRoot "VCpp"
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }

    $stamp    = (Get-Date).ToString("yyyyMMdd_HHmmss")
    $csvPath  = Join-Path $outDir ("VCpp-Runtime_Audit_{0}.csv" -f $stamp)
    $jsonPath = Join-Path $outDir ("VCpp-Runtime_Audit_{0}.json" -f $stamp)

    Write-Host ""
    Write-Host "VC++ Runtime Validation" -ForegroundColor Cyan
    Write-Host "Scanning HKLM/HKCU uninstall hives for Visual C++ Redistributables..." -ForegroundColor DarkGray
    Write-Host ""

    $targets = @(
        "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        "Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall"
    )

    function _Is-Vcpp([psobject]$p) {
        $dn = $p.DisplayName
        if ([string]::IsNullOrWhiteSpace($dn)) { return $false }
        return ($dn -match 'Microsoft\s+Visual\s+C\+\+' -and $dn -match 'Redistributable')
    }
    function _Get-Arch([string]$displayName, [string]$uninstallString) {
        if ($displayName -match '(x64|AMD64|64-bit)') { return 'x64' }
        if ($displayName -match '(x86|32-bit)')       { return 'x86' }
        if ($displayName -match 'ARM64')              { return 'ARM64' }
        if ($uninstallString -match 'amd64|x64')      { return 'x64' }
        if ($uninstallString -match 'x86|32')         { return 'x86' }
        return 'Unknown'
    }
    function _Get-Channel([string]$ver, [string]$displayName) {
        if ($displayName -match '2005') { return '2005' }
        if ($displayName -match '2008') { return '2008' }
        if ($displayName -match '2010') { return '2010' }
        if ($displayName -match '2012') { return '2012' }
        if ($displayName -match '2013') { return '2013' }
        if ($displayName -match '2015|2017|2019|2022') { return '2015-2022' }
        $maj = $null
        if ([Version]::TryParse($ver, [ref]$maj)) {
            switch ($maj.Major) {
                8  { return '2005' }
                9  { return '2008' }
                10 { return '2010' }
                11 { return '2012' }
                12 { return '2013' }
                14 { return '2015-2022' }
                default { return ("Other ({0})" -f $maj.Major) }
            }
        }
        return 'Unknown'
    }

    $items = New-Object System.Collections.Generic.List[psobject]
    foreach ($root in $targets) {
        if (-not (Test-Path $root)) { continue }
        try {
            Get-ChildItem -Path $root -ErrorAction SilentlyContinue | ForEach-Object {
                try {
                    $p = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
                    if (-not $p) { return }
                    if (-not (_Is-Vcpp $p)) { return }

                    $displayName    = $p.DisplayName
                    $displayVersion = [string]$p.DisplayVersion
                    $publisher      = $p.Publisher
                    $installDateRaw = [string]$p.InstallDate
                    $installDate    = $null
                    if ($installDateRaw -match '^\d{8}$') {
                        $installDate = [datetime]::ParseExact($installDateRaw, 'yyyyMMdd', $null)
                    } elseif ($installDateRaw) {
                        $tmp = $null
                        if ([datetime]::TryParse($installDateRaw, [ref]$tmp)) { $installDate = $tmp }
                    }
                    $estKB          = $p.EstimatedSize
                    $uninst         = $p.UninstallString
                    $quietUninst    = $p.QuietUninstallString
                    $installLoc     = $p.InstallLocation
                    $productCode    = $_.PSChildName

                    $arch    = _Get-Arch $displayName $uninst
                    $channel = _Get-Channel $displayVersion $displayName

                    $obj = [pscustomobject]@{
                        DisplayName          = $displayName
                        DisplayVersion       = $displayVersion
                        Channel              = $channel
                        Architecture         = $arch
                        Publisher            = $publisher
                        InstallDate          = $installDate
                        EstimatedSizeKB      = $estKB
                        InstallLocation      = $installLoc
                        UninstallString      = $uninst
                        QuietUninstallString = $quietUninst
                        ProductCode          = $productCode
                        Hive                 = $root
                        KeyName              = $_.PSChildName
                    }
                    [void]$items.Add($obj)
                } catch { }
            }
        } catch {
            Write-Host "WARN: Failed scanning $root : $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }

    $results = @($items.ToArray()) |
        Sort-Object @{e='Channel';a=$true}, @{e='Architecture';a=$true}, @{e='DisplayName';a=$true}, @{e='DisplayVersion';a=$true}

    $count = $results.Count
    $suffix = if ($count -eq 1) { 'y' } else { 'ies' }

    if ($count -eq 0) {
        Write-Host "No Microsoft Visual C++ Redistributables detected." -ForegroundColor Yellow
    } else {
        Write-Host ("Found {0} VC++ redistributable entr{1}:" -f $count, $suffix) -ForegroundColor Green
        $results |
            Select-Object Channel, Architecture, DisplayName, DisplayVersion, Publisher, InstallDate |
            Format-Table -AutoSize
        Write-Host ""
    }

    try {
        $projection = @(
            $results |
            Select-Object DisplayName, DisplayVersion, Channel, Architecture, Publisher, InstallDate,
                          EstimatedSizeKB, InstallLocation, UninstallString, QuietUninstallString,
                          ProductCode, Hive, KeyName
        )
        if ($projection.Count -gt 0) {
            $projection | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
            $projection | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
            Write-Host "Exported CSV : $csvPath" -ForegroundColor DarkCyan
            Write-Host "Exported JSON: $jsonPath" -ForegroundColor DarkCyan
        }
    } catch {
        Write-Host "ERROR exporting VC++ report: $($_.Exception.Message)" -ForegroundColor Red
    }

    if (Get-Command -Name Write-SessionSummary -ErrorAction SilentlyContinue) {
        try { Write-SessionSummary -Note ("VC++ runtime scan: {0} entr{1} found." -f $count, $suffix) | Out-Null } catch {}
    }

    if ($PauseAfter.IsPresent) {
        if (Get-Command -Name Pause-Script -ErrorAction SilentlyContinue) { Pause-Script } else { _PauseLocal }
    }

    return $results
}

# ----------------------------
# [4] Registry Uninstall Search (fully inlined; export verified)
# ----------------------------
function Invoke-RegistryUninstallSearch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Pattern,
        [switch]$Exact,
        [switch]$PauseAfter
    )

    $likePattern = $Pattern
    if (-not $Exact -and $likePattern -notmatch '[\*\?\[\]]') { $likePattern = "*$likePattern*" }

    if (Get-Command -Name Ensure-ExportFolder -ErrorAction SilentlyContinue) { try { Ensure-ExportFolder } catch {} }
    $exportRoot = if (Test-Path "C:\CS-Toolbox-TEMP\Collected-Info") { "C:\CS-Toolbox-TEMP\Collected-Info" } else { _Ensure-ExportFolderLocal }
    $regDir = Join-Path $exportRoot "Registry"
    if (-not (Test-Path $regDir)) { New-Item -ItemType Directory -Path $regDir -Force | Out-Null }

    $stamp    = (Get-Date).ToString("yyyyMMdd_HHmmss")
    $patPart  = _SanitizeFilePart($Pattern)
    $csvPath  = Join-Path $regDir ("Registry-UninstallSearch_{0}_{1}.csv" -f $stamp, $patPart)
    $jsonPath = Join-Path $regDir ("Registry-UninstallSearch_{0}_{1}.json" -f $stamp, $patPart)

    $targets = @(
        "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        "Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall"
    )

    $fieldsToScan = @(
        'DisplayName','DisplayVersion','Publisher',
        'UninstallString','QuietUninstallString',
        'InstallLocation','ModifyPath','URLInfoAbout','EstimatedSize'
    )

    Write-Host ""
    Write-Host "Search Registry Uninstall Strings" -ForegroundColor Cyan
    Write-Host ("Pattern : {0}" -f $Pattern)
    Write-Host ("Like    : {0}" -f $likePattern) -ForegroundColor DarkGray
    Write-Host "Scope   : HKLM (64/32-bit) + HKCU" -ForegroundColor DarkGray
    if ($Exact) { Write-Host "Mode    : Exact (DisplayName only)" -ForegroundColor DarkGray }
    Write-Host ""

    $list = New-Object System.Collections.Generic.List[psobject]
    foreach ($root in $targets) {
        if (-not (Test-Path $root)) { continue }
        try {
            Get-ChildItem -Path $root -ErrorAction SilentlyContinue | ForEach-Object {
                try {
                    $p = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
                    if (-not $p) { return }
                    $obj = [pscustomobject]@{
                        Hive                 = $root
                        KeyName              = $_.PSChildName
                        DisplayName          = $p.DisplayName
                        DisplayVersion       = $p.DisplayVersion
                        Publisher            = $p.Publisher
                        InstallDate          = $p.InstallDate
                        InstallLocation      = $p.InstallLocation
                        EstimatedSizeKB      = $p.EstimatedSize
                        UninstallString      = $p.UninstallString
                        QuietUninstallString = $p.QuietUninstallString
                        ModifyPath           = $p.ModifyPath
                        URLInfoAbout         = $p.URLInfoAbout
                    }
                    $isMatch = $false
                    if ($Exact) {
                        if ($obj.DisplayName) { $isMatch = ($obj.DisplayName -ieq $Pattern) }
                    } else {
                        foreach ($f in $fieldsToScan) {
                            $val = $obj.$f
                            if ($null -ne $val) {
                                if ($val -like $likePattern) { $isMatch = $true; break }
                                if ($Pattern -notmatch '[\*\?\[\]]') {
                                    if ($val.ToString().IndexOf($Pattern, 'InvariantCultureIgnoreCase') -ge 0) { $isMatch = $true; break }
                                }
                            }
                        }
                    }
                    if ($isMatch) { [void]$list.Add($obj) }
                } catch { }
            }
        } catch {
            Write-Host "WARN: Failed scanning $root : $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }

    $results = @($list.ToArray())
    $count = $results.Count
    $suffix = if ($count -eq 1) { 'y' } else { 'ies' }

    if ($count -eq 0) {
        Write-Host "No matching uninstall entries found for the given pattern." -ForegroundColor Yellow
    } else {
        Write-Host ("Found {0} matching uninstall entr{1}:" -f $count, $suffix) -ForegroundColor Green
        $results |
            Sort-Object DisplayName, DisplayVersion |
            Select-Object DisplayName, DisplayVersion, Publisher, InstallLocation, UninstallString, Hive, KeyName |
            Format-Table -AutoSize
        Write-Host ""
    }

    # Always materialize as array so Count works for single row
    $exportRows = @(
        $results |
        Select-Object Hive, KeyName, DisplayName, DisplayVersion, Publisher, InstallDate,
                      InstallLocation, EstimatedSizeKB, UninstallString, QuietUninstallString,
                      ModifyPath, URLInfoAbout
    )

    try {
        if ($exportRows.Count -gt 0) {
            $exportRows | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
            $exportRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $jsonPath -Encoding UTF8
            Write-Host ("Exported CSV : {0}" -f $csvPath) -ForegroundColor DarkCyan
            Write-Host ("Exported JSON: {0}" -f $jsonPath) -ForegroundColor DarkCyan
        } else {
            "{`"pattern`":`"$Pattern`",`"count`":0,`"note`":`"No matches`"}" | Set-Content -LiteralPath $jsonPath -Encoding UTF8
            Write-Host ("No rows to export. Wrote note to {0}" -f $jsonPath) -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR exporting results: $($_.Exception.Message)" -ForegroundColor Red
    }

    if (Get-Command -Name Write-SessionSummary -ErrorAction SilentlyContinue) {
        try { Write-SessionSummary -Note ("Registry uninstall search for '{0}' found {1} entr{2}." -f $Pattern, $count, $suffix) | Out-Null } catch {}
    }

    if ($PauseAfter.IsPresent) {
        if (Get-Command -Name Pause-Script -ErrorAction SilentlyContinue) { Pause-Script } else { _PauseLocal }
    }

    return $results
}

# ----------------------------
# [1] Windows Patch Audit (WMI)
# ----------------------------
function Run-WMIPatchAudit {
    [CmdletBinding()]
    param([switch]$PauseAfter)

    $exportRoot = if (Test-Path "C:\CS-Toolbox-TEMP\Collected-Info") {"C:\CS-Toolbox-TEMP\Collected-Info"} else { _Ensure-ExportFolderLocal }
    $outDir = Join-Path $exportRoot "Patches"
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }

    $stamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
    $csv   = Join-Path $outDir ("WMI-PatchAudit_{0}.csv" -f $stamp)
    $json  = Join-Path $outDir ("WMI-PatchAudit_{0}.json" -f $stamp)

    Write-Host ""
    Write-Host "Windows Patch Audit (WMI)" -ForegroundColor Cyan

    try {
        $qfes = Get-CimInstance -ClassName Win32_QuickFixEngineering -ErrorAction Stop |
            Select-Object CSName, HotFixID, InstalledOn, Description, Caption, FixComments, InstalledBy

        if (-not $qfes) {
            Write-Host "No QFE entries returned." -ForegroundColor Yellow
        } else {
            $qfes | Sort-Object InstalledOn -Descending | Format-Table -AutoSize
        }

        $qfes | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
        ($qfes | ConvertTo-Json -Depth 4) | Set-Content -LiteralPath $json -Encoding UTF8
        Write-Host ("Exported CSV : {0}" -f $csv)  -ForegroundColor DarkCyan
        Write-Host ("Exported JSON: {0}" -f $json) -ForegroundColor DarkCyan
    } catch {
        Write-Host "ERROR running WMI patch audit: $($_.Exception.Message)" -ForegroundColor Red
    }

    if ($PauseAfter.IsPresent) {
        if (Get-Command Pause-Script -ErrorAction SilentlyContinue) { Pause-Script } else { _PauseLocal }
    }
}

# ----------------------------
# [3] TLS/SSL Policy Audit (Local Host)
# ----------------------------
function Run-TlsPolicyAudit {
    [CmdletBinding()]
    param([switch]$PauseAfter)

    $exportRoot = if (Test-Path "C:\CS-Toolbox-TEMP\Collected-Info") {"C:\CS-Toolbox-TEMP\Collected-Info"} else { _Ensure-ExportFolderLocal }
    $outDir = Join-Path $exportRoot "TLS"
    if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir -Force | Out-Null }

    $stamp = (Get-Date).ToString("yyyyMMdd_HHmmss")
    $json  = Join-Path $outDir ("TLS-Policy_{0}.json" -f $stamp)

    Write-Host ""
    Write-Host "TLS/SSL Policy Audit (Local Host)" -ForegroundColor Cyan

    $paths = @{
        'SCHANNEL\Protocols' = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols'
        '.NET v2.0.50727'    = 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v2.0.50727'
        '.NET v4.0.30319'    = 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319'
        'WinHTTP\DefaultSecureProtocols' = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\WinHttp'
    }

    $report = [ordered]@{}
    foreach ($name in $paths.Keys) {
        $path = $paths[$name]
        $entry = New-Object System.Collections.Hashtable
        if (Test-Path $path) {
            try {
                if ($name -eq 'SCHANNEL\Protocols') {
                    $protocols = Get-ChildItem $path -ErrorAction SilentlyContinue | ForEach-Object {
                        $proto = $_.PSChildName
                        $modes = Get-ChildItem $_.PSPath -ErrorAction SilentlyContinue | ForEach-Object {
                            $mode = $_.PSChildName
                            $vals = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
                            [pscustomobject]@{
                                Protocol          = $proto
                                Mode              = $mode
                                Enabled           = $vals.Enabled
                                DisabledByDefault = $vals.DisabledByDefault
                            }
                        }
                        $modes
                    }
                    $entry['Protocols'] = $protocols
                } else {
                    $vals = Get-ItemProperty -LiteralPath $path -ErrorAction SilentlyContinue
                    $entry['Values'] = $vals.PSObject.Properties |
                        Where-Object {$_.Name -notlike '*PS*'} |
                        ForEach-Object { [pscustomobject]@{ Name=$_.Name; Value=$_.Value } }
                }
            } catch {
                $entry['Error'] = $_.Exception.Message
            }
        } else {
            $entry['Missing'] = $true
        }
        $report[$name] = $entry
    }

    if ($report['SCHANNEL\Protocols']['Protocols']) {
        $report['SCHANNEL\Protocols']['Protocols'] |
            Sort-Object Protocol, Mode |
            Format-Table Protocol, Mode, Enabled, DisabledByDefault -AutoSize
    } else {
        Write-Host "No SCHANNEL protocol info available (path missing or no subkeys)." -ForegroundColor Yellow
    }

    try {
        ($report | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath $json -Encoding UTF8
        Write-Host ("Exported JSON: {0}" -f $json) -ForegroundColor DarkCyan
    } catch {
        Write-Host "ERROR exporting TLS report: $($_.Exception.Message)" -ForegroundColor Red
    }

    if ($PauseAfter.IsPresent) {
        if (Get-Command -Name Pause-Script -ErrorAction SilentlyContinue) { Pause-Script } else { _PauseLocal }
    }
}

# ----------------------------
# Return to Launcher (same window)
# ----------------------------
function Return-ToLauncher {
    try {
        $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
        if (Test-Path $launcher) {
            Clear-Host
            & $launcher
        } else {
            Write-Host "Launcher not found at $launcher. Exiting script..." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "Failed to return to launcher: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# ----------------------------
# Menu Loop
# ----------------------------
while ($true) {
    Clear-Host
    Show-Header "Secondary Collection Tools"

    Write-Host ""
    Write-Host " [1] Windows Patch Audit (WMI)           - Installed updates via WMI" -ForegroundColor White
    Write-Host " [2] VC++ Runtime Validation             - Detect and list Visual C++ runtimes" -ForegroundColor White
    Write-Host " [3] TLS/SSL Policy Audit (Local Host)   - Check local TLS/SSL registry policies" -ForegroundColor White
    Write-Host " [4] Search Registry Uninstall Strings   - Find uninstall entries by keyword" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
    $choice = Read-Host "Enter your choice"

    switch -Regex ($choice) {
        '^(1)$' { Run-WMIPatchAudit -PauseAfter }
        '^(2)$' { Run-VcppValidation -PauseAfter }
        '^(3)$' { Run-TlsPolicyAudit -PauseAfter }
        '^(4)$' {
            $pattern = Read-Host "Enter search text (wildcards OK; plain text becomes *text*)"
            if ([string]::IsNullOrWhiteSpace($pattern)) {
                Write-Host "No pattern entered. Returning to menu..." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            } else {
                Invoke-RegistryUninstallSearch -Pattern $pattern -PauseAfter
            }
        }
        '^(q|Q)$' {
            Return-ToLauncher
            break
        }
        default {
            Write-Host "Invalid selection. Please choose 1-4 or Q." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
        }
    }
}
