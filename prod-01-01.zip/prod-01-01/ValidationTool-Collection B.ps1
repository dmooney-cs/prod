# Load shared functions first - required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { $null = Read-Host }
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") } catch { $null = Read-Host }
    return
}

Ensure-ExportFolder

# CS Tech Toolbox – Validation Tool B
# Patch audit (WMI/QFE) + VC++ runtime validation
# Exports -> C:\CS-Toolbox-TEMP\Collected-Info

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (-not (Test-Path $commonPath)) { Write-Host "ERROR: Functions-Common.ps1 missing." -ForegroundColor Red; Pause-Script; return }
try { Invoke-Expression (Get-Content $commonPath -Raw -Encoding UTF8) } catch { Write-Host ("ERROR loading common: {0}" -f $_) -ForegroundColor Red; Pause-Script; return }
Ensure-ExportFolder
$ErrorActionPreference = 'Continue'

function Write-Export { param([Parameter(Mandatory)][object]$Object,[Parameter(Mandatory)][string]$BaseName,[string]$Ext='csv')
    if (Get-Command Export-Data -ErrorAction SilentlyContinue) { Export-Data -Object $Object -BaseName $BaseName -Ext $Ext; return }
    $outDir="C:\CS-Toolbox-TEMP\Collected-Info"; if (-not (Test-Path $outDir)) { New-Item $outDir -ItemType Directory -Force | Out-Null }
    $ts=Get-Date -Format "yyyy-MM-dd_HH-mm-ss"; $file=Join-Path $outDir ("{0}_{1}.{2}" -f $BaseName,$ts,$Ext)
    try { if ($Ext -ieq 'csv'){ $Object|Export-Csv -NoTypeInformation -Encoding UTF8 -Path $file } elseif($Ext -ieq 'json'){ $Object|ConvertTo-Json -Depth 7|Out-File -Encoding UTF8 -FilePath $file } else { $Object|Out-File -Encoding UTF8 -FilePath $file } ; Write-Host ("Exported: {0}" -f $file) -ForegroundColor Green } catch { Write-Host ("Export failed: {0}" -f $_) -ForegroundColor Red }
}

function Run-WMIPatchAudit {
    try {
        Show-Header "Patch Audit (WMI / QFE)"
        $items=@()
        $qfe=Get-CimInstance -ClassName Win32_QuickFixEngineering -ErrorAction SilentlyContinue
        if (-not $qfe) { Write-Host "No QFE via CIM; falling back to Get-HotFix..." -ForegroundColor Yellow; $qfe=Get-HotFix -ErrorAction SilentlyContinue }
        if ($qfe) { foreach($r in $qfe){ $items += [pscustomobject]@{ ComputerName=$env:COMPUTERNAME; HotFixID=$r.HotFixID; Description=$r.Description; InstalledBy=$r.InstalledBy; InstalledOn=(try{[datetime]$r.InstalledOn}catch{$r.InstalledOn}); Caption=$r.Caption; CSName=$r.CSName } } }
        if (-not $items) { $items = ,[pscustomobject]@{ ComputerName=$env:COMPUTERNAME; HotFixID='(none)'; Description=''; InstalledBy=''; InstalledOn=''; Caption=''; CSName='' } }
        Write-Export -Object $items -BaseName 'Patches-WMI'
        Pause-Script
    } catch { Write-Host ("WMI Patch Audit error: {0}" -f $_) -ForegroundColor Red; Pause-Script }
}

function Run-VcppValidation-Local {
    try {
        Show-Header "VC++ Runtime Validation"
        $results=@(); $paths=@("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall","HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall")
        foreach($key in $paths){ if (Test-Path $key){ Get-ChildItem $key -ErrorAction SilentlyContinue | ForEach-Object { $p=Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue; if ($p.DisplayName -like "*Visual C++*Redistributable*"){ $results += [pscustomobject]@{ Type="Installed Redistributable"; Name=$p.DisplayName; Version=$p.DisplayVersion; Publisher=$p.Publisher; InstallDate=$p.InstallDate; Uninstall=$p.UninstallString; Arch=(if($p.DisplayName -match 'x64'){'x64'} elseif($p.DisplayName -match 'x86'){'x86'} else {''}) } } } } }
        if (-not $results){ $results = ,[pscustomobject]@{ Type="Info"; Name="No VC++ Redistributables detected"; Version=""; Publisher=""; InstallDate=""; Uninstall=""; Arch="" } }
        Write-Export -Object $results -BaseName 'VCpp-Validation'
        Pause-Script
    } catch { Write-Host ("VC++ validation error: {0}" -f $_) -ForegroundColor Red; Pause-Script }
}
function Invoke-RunVcpp { if (Get-Command Run-VcppValidation -ErrorAction SilentlyContinue){ try { Run-VcppValidation } catch { Write-Host ("Shared Run-VcppValidation error: {0} -> fallback" -f $_) -ForegroundColor Yellow; Run-VcppValidation-Local } } else { Run-VcppValidation-Local } }

function Show-Menu {
    Show-Header "Validation Tool B"
    Write-Host " [1] Patch Audit (WMI / QFE)"
    Write-Host " [2] VC++ Runtime Validation"
    Write-Host ""
    Write-Host " [Q] Return to Main Menu"
    Write-Host ""
}

do {
    Show-Menu
    $choice = (Read-Host "Enter your choice").ToUpper()
    switch ($choice) {
        '1' { Run-WMIPatchAudit }
        '2' { Invoke-RunVcpp }
        'Q' {
            & "C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1"
            return
        }
        default { Write-Host "Invalid selection. Try again." -ForegroundColor Yellow ; Start-Sleep 1 }
    }
} while ($true)

return
