# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ╔═══════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool B                                ║
# ║ Version: B.14 | Patch Collection + VC++ Audit + Z/C Options           ║
# ╚═══════════════════════════════════════════════════════════════════════╝

function Run-WMIPatchAudit {
    Show-Header "WMI Patch Inventory"
    $patches = Get-HotFix | Sort-Object InstalledOn -Descending
    if ($patches) {
        $path = Export-Data -Object $patches -BaseName "WMI_PatchAudit"
        Write-Host "📄 Exported file: $path" -ForegroundColor Cyan
    } else {
        Write-Host "No patch data found." -ForegroundColor Yellow
    }
    Pause-Script
}

function Run-OSQueryPatchAudit {
    Show-Header "OSQuery Patch Inventory"
    $query = "SELECT hotfix_id, description, installed_on FROM patches;"
    $results = Invoke-OSQuery -Query $query
    if ($results) {
        $path = Export-Data -Object $results -BaseName "OSQuery_PatchAudit"
        Write-Host "📄 Exported file: $path" -ForegroundColor Cyan
    } else {
        Write-Host "No OSQuery patch data found." -ForegroundColor Yellow
    }
    Pause-Script
}

function Run-VcppValidation {
    Clear-Host
    Write-Host "=== VC++ Redistributable & Dependency Validation ===" -ForegroundColor Cyan

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $hostname = $env:COMPUTERNAME
    $outputDir = "C:\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $outputDir)) {
        New-Item -Path $outputDir -ItemType Directory | Out-Null
    }
    $outputFile = "$outputDir\VCpp_ValidationReport_${timestamp}_$hostname.csv"

    $results = @()

    Write-Host "`n[1/2] Detecting installed Visual C++ Redistributables..." -ForegroundColor Yellow
    $vcKeys = @(
        "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
    )

    foreach ($key in $vcKeys) {
        Get-ChildItem $key -ErrorAction SilentlyContinue | ForEach-Object {
            $props = Get-ItemProperty $_.PSPath
            $dispName = $props.DisplayName 2>$null
            $version = $props.DisplayVersion 2>$null
            if ($dispName -like "*Visual C++*Redistributable*") {
                $results += [PSCustomObject]@{
                    Type        = "Installed Redistributable"
                    FilePath    = ""
                    Dependency  = $dispName
                    Version     = $version
                }
                Write-Host "  → $dispName`tVersion: $version"
            }
        }
    }

    Write-Host "`n[2/2] Scanning executables for VC++ runtime dependencies..." -ForegroundColor Yellow
    $vcDlls = @("msvcr", "msvcp", "vcruntime")
    $scanPaths = @(
        "$env:ProgramFiles",
        "$env:ProgramFiles(x86)",
        "$env:SystemRoot\System32",
        "$env:SystemRoot\SysWOW64"
    )

    foreach ($path in $scanPaths) {
        Write-Host "`nScanning: $path" -ForegroundColor DarkGray
        Get-ChildItem -Path $path -Recurse -Include *.exe, *.dll -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                $output = strings $_.FullName | Select-String -Pattern ($vcDlls -join "|")
                if ($output) {
                    $depList = ($output | ForEach-Object { $_.Line }) | Sort-Object -Unique
                    $results += [PSCustomObject]@{
                        Type        = "Binary Dependency"
                        FilePath    = $_.FullName
                        Dependency  = ($depList -join ", ")
                        Version     = ""
                    }
                }
            } catch {}
        }
    }

    $results | Export-Csv -Path $outputFile -NoTypeInformation -Encoding UTF8

    Write-Host "`n=== VC++ Validation Summary ===" -ForegroundColor Green
    Write-Host "Redistributables Found: $($results | Where-Object { $_.Type -eq 'Installed Redistributable' } | Measure-Object).Count"
    Write-Host "Binaries with VC++ Dependencies: $($results | Where-Object { $_.Type -eq 'Binary Dependency' } | Measure-Object).Count"
    Write-Host "`nValidation report saved to:" -ForegroundColor Yellow
    Write-Host "$outputFile" -ForegroundColor BrightGreen

    Write-Host "`nPress any key to return to the menu..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Show-Menu {
    Clear-Host
    Show-Header "Validation Tool B - Patch Collection + VC++ Audit"
    Write-Host " [1] Collect WMI Patch Inventory"
    Write-Host " [2] Collect OSQuery Patch Inventory"
    Write-Host " [3] Run All Patch Collection"
    Write-Host " [4] Collect VC++ Redistributables + Binary Dependencies"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Toolbox Data"
    Write-Host " [Q] Quit to Main Menu"
    Write-Host ""
}

do {
    Show-Menu
    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        '1' { Run-WMIPatchAudit }
        '2' { Run-OSQueryPatchAudit }
        '3' {
            Run-WMIPatchAudit
            Run-OSQueryPatchAudit
        }
        '4' { Run-VcppValidation }
        'Z' { Invoke-ZipAndEmailResults }
        'C' { Invoke-FinalCleanupAndExit }
        'Q' { return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
