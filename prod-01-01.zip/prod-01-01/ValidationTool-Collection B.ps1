# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    try {
        . $commonPath
    } catch {
        Write-Host "❌ ERROR: Exception occurred while loading Functions-Common.ps1"
        Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host "`nPress any key to exit..."
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        return
    }
} else {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool B                                      ║
# ║ Version: B.17 | Patch Collection via WMI + OSQuery + VC++ Runtime           ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

Ensure-ExportFolder

# ══════════════════════════════════════════════════════════════════════════════

function Run-WMIPatchAudit {
    Show-Header "WMI Patch Inventory"
    $patches = Get-HotFix |
        Select-Object Description, HotFixID, InstalledOn, InstalledBy, PSComputerName
    Export-Data -Object $patches -BaseName "WMI-Hotfixes"
    Pause-Script
}

function Run-OSQueryPatchAudit {
    Show-Header "OSQuery Patch Collection"
    $osqueryPath = "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe"
    if (-not (Test-Path $osqueryPath)) {
        Write-Host "❌ OSQuery not found at: $osqueryPath" -ForegroundColor Red
        Pause-Script
        return
    }

    $query = "SELECT * FROM patches;"
    try {
        $output = & "$osqueryPath" --json "$query"
        $results = $output | ConvertFrom-Json
        Export-Data -Object $results -BaseName "OSQuery-Patches"
    } catch {
        Write-Host "❌ OSQuery patch scan failed: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script
}

function Run-VCRuntimeAudit {
    Show-Header "VC++ Runtime Audit"

    $vcKeys = @(
        "HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes",
        "HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes"
    )

    $results = foreach ($key in $vcKeys) {
        if (Test-Path $key) {
            Get-ChildItem $key -ErrorAction SilentlyContinue | ForEach-Object {
                try {
                    $versionInfo = Get-ItemProperty -Path $_.PsPath
                    [PSCustomObject]@{
                        Name      = $_.PSChildName
                        Version   = $versionInfo.Version
                        Installed = $versionInfo.Installed
                    }
                } catch {
                    Write-Host "❌ Failed to query: $($_.PsPath)" -ForegroundColor DarkYellow
                }
            }
        }
    }

    Export-Data -Object $results -BaseName "VC-Runtime-Audit"
    Pause-Script
}

# ══════════════════════════════════════════════════════════════════════════════

function Show-Menu {
    do {
        Show-Header "Validation Tool B – Patches and Runtime Libraries"

        Write-Host " [1] Audit Patches via WMI"
        Write-Host " [2] Audit Patches via OSQuery"
        Write-Host " [3] Detect VC++ Runtime Libraries"
        Write-Host ""
        Write-Host " [R] Run All Checks Above"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice.ToUpper()) {
            "1" { Run-WMIPatchAudit }
            "2" { Run-OSQueryPatchAudit }
            "3" { Run-VCRuntimeAudit }
            "R" {
                Run-WMIPatchAudit
                Run-OSQueryPatchAudit
                Run-VCRuntimeAudit
            }
            "Z" {
                try {
                    Invoke-ZipAndEmailResults
                } catch {
                    Write-Host "❌ Error during ZIP/email: $($_.Exception.Message)" -ForegroundColor Red
                    Pause-Script
                }
            }
            "C" {
                try {
                    Invoke-CleanupExport
                } catch {
                    Write-Host "❌ Error during cleanup: $($_.Exception.Message)" -ForegroundColor Red
                    Pause-Script
                }
            }
            "Q" { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

# ══════════════════════════════════════════════════════════════════════════════

trap {
    Write-Host "`n❌ FATAL ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Pause-Script
    Write-Host "`nPress any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}

try {
    Show-Menu
} catch {
    Write-Host "`n❌ ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Pause-Script
    Write-Host "`nPress any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
