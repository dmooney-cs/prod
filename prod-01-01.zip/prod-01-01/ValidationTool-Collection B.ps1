# ╔═══════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool B                                ║
# ║ Version: B.10 | Patch Collection via WMI + OSQuery + ZIP/Email + Menu ║
# ╚═══════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Collect-Patches-WMI {
    Show-Header "Patch Collection via WMI"
    try {
        $hotfixes = Get-HotFix | Select-Object HotFixID, Description, InstalledOn, InstalledBy
        Export-Data -Object $hotfixes -BaseName "Hotfixes"
        Write-SessionSummary "Get-HotFix patches collected"
    } catch {
        Write-Host "❌ Error collecting patches via Get-HotFix: $_" -ForegroundColor Red
    }

    try {
        $wmiHotfixes = Get-WmiObject -Class Win32_QuickFixEngineering |
            Select-Object HotFixID, Description, InstalledOn
        Export-Data -Object $wmiHotfixes -BaseName "WMIHotfixes"
        Write-SessionSummary "WMI hotfixes collected"
    } catch {
        Write-Host "❌ Error collecting patches via WMI: $_" -ForegroundColor Red
    }

    Pause-Script
}

function Collect-Patches-OSQuery {
    Show-Header "Patch Collection via OSQuery"
    $paths = @(
        "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe",
        "C:\Program Files\CyberCNSAgent\osqueryi.exe",
        "$env:ProgramFiles\CyberCNSAgent\osqueryi.exe",
        "$env:ProgramFiles(x86)\CyberCNSAgent\osqueryi.exe"
    )

    $osqueryPath = $paths | Where-Object { Test-Path $_ } | Select-Object -First 1

    if (-not $osqueryPath) {
        Write-Host "⚠ OSQuery not found. Skipping OSQuery patch collection." -ForegroundColor Yellow
        Pause-Script
        return
    }

    $query = "SELECT * FROM patches;"
    try {
        $results = & "$osqueryPath" --json "$query" 2>$null | ConvertFrom-Json
        if ($results) {
            Export-Data -Object $results -BaseName "OSQuery-Patches"
            Write-SessionSummary "OSQuery patches collected"
        } else {
            Write-Host "❌ No results returned from OSQuery." -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ Error running OSQuery patch query: $_" -ForegroundColor Red
    }

    Pause-Script
}

function Show-ValidationMenuB {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "     Validation Tool B - Patch Collection"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Collect Patch Information (WMI + OSQuery)"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit to Main Menu"
    Write-Host ""
}

do {
    Show-ValidationMenuB
    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        '1' {
            Collect-Patches-WMI
            Collect-Patches-OSQuery
        }
        'Z' { Run-ZipAndEmailResults }
        'C' { Run-CleanupExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
