# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – Validation Tool B                                      ║
# ║ Version: B.13 | Patch Audit + VC++ Runtime Scan                             ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-WindowsPatchAudit {
    Show-Header "Windows Patch History Audit"

    $hotfixes = Get-HotFix | Sort-Object InstalledOn -Descending | Select-Object -Property Description, HotFixID, InstalledBy, InstalledOn
    Export-Data -Object $hotfixes -BaseName "WindowsHotfixAudit"
    Pause-Script
}

function Run-VCRuntimeAudit {
    Show-Header "VC++ Runtime Detection"

    $vcs = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*, `
                            HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -match "Visual C++" } |
            Select-Object DisplayName, DisplayVersion, Publisher, InstallDate

    Export-Data -Object $vcs -BaseName "VCRuntimeAudit"
    Pause-Script
}

function Run-All {
    Run-WindowsPatchAudit
    Run-VCRuntimeAudit
}

function Show-Menu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "     Validation Tool B – Patch and VC++ Audit"
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Audit Windows Hotfix History"
        Write-Host " [2] Detect VC++ Runtime Versions"
        Write-Host " [A] Run All Tasks"
        Write-Host ""
        Write-Host " [Q] Quit to Main Menu"
        Write-Host ""

        $choice = Read-Host "Select an option"
        switch ($choice.ToUpper()) {
            "1" { Run-WindowsPatchAudit }
            "2" { Run-VCRuntimeAudit }
            "A" { Run-All }
            "Q" { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Start-Sleep -Seconds 1.2
            }
        }
    } while ($true)
}

Show-Menu
