<# =====================================================================
 CS-Reload-Dependencies.ps1
 - Menu-driven OR silent mode
 - Logs all actions to: C:\CS-Toolbox-TEMP\Collected-Info
 - -Silent runs FULL reload with no screen output
 - Option 0 returns to CS-Toolbox-Launcher.ps1 in the SAME window
 ===================================================================== #>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Silent
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

# ------------------------- Paths -------------------------
$CollectedInfoDir = "C:\CS-Toolbox-TEMP\Collected-Info"
$LauncherPath     = "C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1"

# ------------------------- Helpers -------------------------
function Ensure-Folder {
    param([Parameter(Mandatory)] [string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

Ensure-Folder -Path $CollectedInfoDir

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogFile   = Join-Path $CollectedInfoDir "CS-Reload-Dependencies_$Timestamp.log"

function Write-Log {
    param(
        [Parameter(Mandatory)] [string]$Message,
        [ValidateSet("INFO","OK","WARN","ERR")] [string]$Level = "INFO"
    )

    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Add-Content -LiteralPath $LogFile -Value $line

    if (-not $Silent) {
        switch ($Level) {
            "OK"   { Write-Host $line -ForegroundColor Green }
            "WARN" { Write-Host $line -ForegroundColor Yellow }
            "ERR"  { Write-Host $line -ForegroundColor Red }
            default{ Write-Host $line }
        }
    }
}

function Invoke-NetService {
    param(
        [Parameter(Mandatory)] [string]$Name,
        [Parameter(Mandatory)] [ValidateSet("start","stop")] [string]$Action
    )

    $cmd = "net $Action $Name"
    try {
        Write-Log -Level INFO -Message "Running: $cmd"
        $out = & cmd.exe /c $cmd 2>&1
        Add-Content -LiteralPath $LogFile -Value ($out | Out-String)

        # net.exe can succeed with text even when service already in state; still treat as OK
        Write-Log -Level OK -Message ("Completed: {0} | {1}" -f $cmd, (($out | Select-Object -First 1) -as [string]))
        return $true
    } catch {
        Write-Log -Level ERR -Message ("FAILED: {0} | {1}" -f $cmd, $_.Exception.Message)
        return $false
    }
}

function Remove-DependencyFiles {
    $files = @(
        "last_dependency_check_time.txt",
        "dependency_details.cfg",
        "dependency.json"
    )

    Write-Log -Level INFO -Message "Deleting listed configuration files (searching common roots)..."

    $roots = @(
        "$env:ProgramData",
        "$env:ProgramFiles",
        "${env:ProgramFiles(x86)}",
        "C:\CyberCNS",
        "C:\CyberCNSAgent"
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique

    $anyFound = $false
    foreach ($root in $roots) {
        foreach ($file in $files) {
            try {
                $hits = Get-ChildItem -LiteralPath $root -Filter $file -Recurse -File -ErrorAction SilentlyContinue
                foreach ($h in $hits) {
                    $anyFound = $true
                    try {
                        Write-Log -Level INFO -Message "Deleting: $($h.FullName)"
                        Remove-Item -LiteralPath $h.FullName -Force -ErrorAction Stop
                        Write-Log -Level OK -Message "Deleted: $($h.FullName)"
                    } catch {
                        Write-Log -Level ERR -Message "Delete FAILED: $($h.FullName) | $($_.Exception.Message)"
                    }
                }
            } catch {
                # Ignore root traversal failures; log once per root/file is too noisy
            }
        }
    }

    if (-not $anyFound) {
        Write-Log -Level WARN -Message "No dependency files found to delete."
    }
}

function Run-FullReload {
    Write-Log -Level INFO -Message "=== FULL DEPENDENCY RELOAD START ==="
    Write-Log -Level INFO -Message "Log file: $LogFile"

    Invoke-NetService -Name "cybercnsagent"        -Action "stop" | Out-Null
    Invoke-NetService -Name "cybercnsagentmonitor" -Action "stop" | Out-Null

    Remove-DependencyFiles

    Invoke-NetService -Name "cybercnsagent"        -Action "start" | Out-Null
    Invoke-NetService -Name "cybercnsagentmonitor" -Action "start" | Out-Null

    Write-Log -Level INFO -Message "=== FULL DEPENDENCY RELOAD END ==="
    Write-Log -Level INFO -Message "Log saved to: $LogFile"
}

function Invoke-LauncherSameWindow {
    # Run the launcher IN THIS POWERSHELL PROCESS so it reuses the same window.
    if (Test-Path -LiteralPath $LauncherPath) {
        Write-Log -Level INFO -Message "Returning to launcher in same window: $LauncherPath"
        try {
            & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $LauncherPath
        } catch {
            Write-Log -Level ERR -Message "Failed to launch toolbox launcher: $($_.Exception.Message)"
        }
    } else {
        Write-Log -Level ERR -Message "Launcher not found at: $LauncherPath"
        if (-not $Silent) {
            Write-Host ""
            Write-Host "Launcher not found at: $LauncherPath" -ForegroundColor Red
            Read-Host "Press ENTER to exit" | Out-Null
        }
    }

    exit
}

# ------------------------- Silent Mode -------------------------
if ($Silent) {
    # No screen output; log only
    Run-FullReload
    exit
}

# ------------------------- Menu -------------------------
while ($true) {
    Clear-Host
    Write-Host "CS-Reload-Dependencies.ps1" -ForegroundColor Cyan
    Write-Host "Log export folder: $CollectedInfoDir"
    Write-Host "Current log file:   $LogFile"
    Write-Host ""
    Write-Host "Choose an option:"
    Write-Host "  1) Full reload (Stop services -> Delete files -> Start services)"
    Write-Host "  2) Stop services only"
    Write-Host "  3) Delete files only"
    Write-Host "  4) Start services only"
    Write-Host "  0) Return to Toolbox Launcher"
    Write-Host ""

    $choice = Read-Host "Enter selection"

    switch ($choice) {
        "1" {
            Run-FullReload
            Read-Host "Press ENTER to continue" | Out-Null
        }
        "2" {
            Write-Log -Level INFO -Message "=== STOP SERVICES ONLY ==="
            Invoke-NetService -Name "cybercnsagent"        -Action "stop" | Out-Null
            Invoke-NetService -Name "cybercnsagentmonitor" -Action "stop" | Out-Null
            Read-Host "Press ENTER to continue" | Out-Null
        }
        "3" {
            Write-Log -Level INFO -Message "=== DELETE FILES ONLY ==="
            Remove-DependencyFiles
            Read-Host "Press ENTER to continue" | Out-Null
        }
        "4" {
            Write-Log -Level INFO -Message "=== START SERVICES ONLY ==="
            Invoke-NetService -Name "cybercnsagent"        -Action "start" | Out-Null
            Invoke-NetService -Name "cybercnsagentmonitor" -Action "start" | Out-Null
            Read-Host "Press ENTER to continue" | Out-Null
        }
        "0" {
            Invoke-LauncherSameWindow
        }
        default {
            Write-Log -Level WARN -Message "Invalid selection: $choice"
            Read-Host "Press ENTER to continue" | Out-Null
        }
    }
}
