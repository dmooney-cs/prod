<# =====================================================================
  Functions-Common.ps1
  ConnectSecure Technicians Toolbox — shared helpers (STRICT-SAFE)
  - Initializes global paths without tripping strict mode
  - Restores legacy helpers for back-compat (Ensure-ExportFolder, etc.)
  - Provides Show-Header, logging, Unblock folder, and launch helpers
  - Safely seeds $script:OutRoot / $script:OutDir for callers that expect them
===================================================================== #>

#region ── Strict-safe global init ─────────────────────────────────────────────

# Probe for $global:CS_TempRoot without reading an unset var (strict-safe)
$__csTmp = Get-Variable -Name 'CS_TempRoot' -Scope Global -ErrorAction SilentlyContinue
if (-not $__csTmp -or -not $__csTmp.Value) {
    $global:CS_TempRoot = 'C:\CS-Toolbox-TEMP'
}

# Derivative common paths
$global:CS_ZipRoot     = Join-Path $global:CS_TempRoot 'ZIP'
$global:CS_LogsRoot    = Join-Path $global:CS_TempRoot 'LOGS'
$global:CS_Collected   = Join-Path $global:CS_TempRoot 'Collected-Info'
$global:CS_RunStamp    = (Get-Date).ToString('yyyyMMdd_HHmmss')
$global:CS_LogFile     = Join-Path $global:CS_LogsRoot ("Run_{0}.log" -f $global:CS_RunStamp)

# Ensure folders exist (no-op if already there)
foreach($p in @($global:CS_ZipRoot,$global:CS_LogsRoot,$global:CS_Collected)){
    if (-not (Test-Path -LiteralPath $p)) { New-Item -ItemType Directory -Path $p -Force | Out-Null }
}

# Many tools rely on $script:OutRoot / $script:OutDir. Seed them if missing.
# Because this file is dot-sourced, "script:" maps to the caller script’s scope.
try {
    if (-not (Get-Variable -Name 'OutRoot' -Scope Script -ErrorAction SilentlyContinue)) {
        Set-Variable -Name 'OutRoot' -Scope Script -Value $global:CS_Collected -Force
    }
    if (-not (Get-Variable -Name 'OutDir' -Scope Script -ErrorAction SilentlyContinue)) {
        Set-Variable -Name 'OutDir'  -Scope Script -Value $global:CS_Collected -Force
    }
} catch { } # Non-fatal if called from console scope

#endregion

#region ── Back-compat globals & shims (strict-safe) ──────────────────────────
# Some older scripts expect these. Define them without reading unset vars.

# $global:CSExportRoot → use CS_ZipRoot
$__csExport = Get-Variable -Name 'CSExportRoot' -Scope Global -ErrorAction SilentlyContinue
if (-not $__csExport -or -not $__csExport.Value) {
    $global:CSExportRoot = $global:CS_ZipRoot
}

# $global:CSLauncherRoot → default to prod folder
$__csLaunch = Get-Variable -Name 'CSLauncherRoot' -Scope Global -ErrorAction SilentlyContinue
if (-not $__csLaunch -or -not $__csLaunch.Value) {
    $global:CSLauncherRoot = 'C:\CS-Toolbox-TEMP\prod-01-01'
}

# Some tools call Ensure-Folders (legacy); map to CSx-EnsureFolders
if (-not (Get-Command Ensure-Folders -ErrorAction SilentlyContinue)) {
    function Ensure-Folders {
        [CmdletBinding()] param([Parameter(Mandatory)][string]$Path)
        CSx-EnsureFolders -Path $Path | Out-Null
    }
}

#endregion

#region ── Basic utilities: logging, pretty size, transcript ──────────────────

function Write-Log {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][ValidateSet('INFO','WARN','ERROR','OK','DEBUG')][string]$Level,
        [Parameter(Mandatory)][string]$Message
    )
    $ts = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[{0}] {1}  {2}" -f $Level,$ts,$Message
    switch ($Level) {
        'ERROR' { Write-Host $line -ForegroundColor Red }
        'WARN'  { Write-Host $line -ForegroundColor Yellow }
        'OK'    { Write-Host $line -ForegroundColor Green }
        'DEBUG' { Write-Host $line -ForegroundColor DarkGray }
        default { Write-Host $line }
    }
    try {
        Add-Content -LiteralPath $global:CS_LogFile -Value $line
    } catch { } # Swallow log write errors
}

function Write-Info  { param([Parameter(Mandatory)][string]$Message) Write-Log -Level INFO  -Message $Message }
function Write-Warn  { param([Parameter(Mandatory)][string]$Message) Write-Log -Level WARN  -Message $Message }
function Write-Ok    { param([Parameter(Mandatory)][string]$Message) Write-Log -Level OK    -Message $Message }
function Write-Err   { param([Parameter(Mandatory)][string]$Message) Write-Log -Level ERROR -Message $Message }
function Write-DebugCS { param([string]$Message) Write-Log -Level DEBUG -Message $Message }

function Get-PrettySize {
    [CmdletBinding()] param([Parameter(Mandatory)][long]$Bytes)
    $units = 'B','KB','MB','GB','TB'
    $i=0; $n=[double]$Bytes
    while($n -ge 1024 -and $i -lt $units.Length-1){ $n/=1024; $i++ }
    '{0:N2} {1}' -f $n,$units[$i]
}

function Start-CSxTranscript {
    [CmdletBinding()]
    param([string]$Path = $global:CS_LogFile)
    try {
        if (-not ($global:CS_TranscriptStarted)) {
            Start-Transcript -Path $Path -Append -ErrorAction Stop | Out-Null
            $global:CS_TranscriptStarted = $true
            Write-Info "Transcript started -> $Path"
        }
    } catch {
        Write-Warn "Transcript could not start: $($_.Exception.Message)"
    }
}

#endregion

#region ── Show-Header & environment info ─────────────────────────────────────

function Test-Admin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p  = New-Object Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Show-Header {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Title,
        [string]$SubTitle
    )
    $hostName = $env:COMPUTERNAME
    $userName = "{0}\{1}" -f $env:USERDOMAIN,$env:USERNAME
    $isAdmin  = if (Test-Admin) { "True" } else { "False" }
    $line     = ('=' * 58)

    Write-Host ""
    Write-Host " $Title" -ForegroundColor Cyan
    Write-Host $line
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName,$userName,$isAdmin)
    if ($SubTitle) { Write-Host (" {0}" -f $SubTitle) }
    Write-Host $line
    Write-Host ""
}

#endregion

#region ── Folder ensure / legacy wrappers ────────────────────────────────────

function CSx-EnsureFolders {
    [CmdletBinding()] param(
        [Parameter(Mandatory)][string]$Path
    )
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            New-Item -ItemType Directory -Path $Path -Force | Out-Null
        }
        return (Resolve-Path -LiteralPath $Path).Path
    } catch {
        throw "Failed to ensure folder '$Path': $($_.Exception.Message)"
    }
}

# Back-compat shim for older scripts
if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        [CmdletBinding()] param([Parameter(Mandatory)][string]$Path)
        CSx-EnsureFolders -Path $Path | Out-Null
    }
}

#endregion

#region ── Safe dot-source + unblock helpers ──────────────────────────────────

function Unblock-ToolingInFolder {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [switch]$Recurse
    )
    try {
        if (-not (Test-Path -LiteralPath $Path)) { return }
        $params = @{ LiteralPath = $Path; ErrorAction = 'SilentlyContinue' }
        if ($Recurse) {
            Get-ChildItem -LiteralPath $Path -Recurse -Include *.ps1,*.psm1 | ForEach-Object {
                Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue
            }
        } else {
            Get-ChildItem -LiteralPath $Path -Include *.ps1,*.psm1 | ForEach-Object {
                Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue
            }
        }
        Write-Ok "Unblocked scripts in: $Path"
    } catch {
        Write-Warn "Unblock skipped for '$Path': $($_.Exception.Message)"
    }
}

function Invoke-SafeDotSource {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path
    )
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            throw "Common file not found: $Path"
        }
        # Avoid interactive prompts by unblocking first
        Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue
        . $Path
        Write-Ok "Dot-sourced: $Path"
        $true
    } catch {
        Write-Err "Failed to dot-source '$Path' -> $($_.Exception.Message)"
        $false
    }
}

#endregion

#region ── Launch helpers (same window / new window) ──────────────────────────

function Run-ToolSameWindow {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Title
    )
    try {
        if (-not (Test-Path -LiteralPath $Path)) { throw "Not found: $Path" }
        Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue
        Write-Info "Launching (same window): $Title -> $Path"
        & $Path
    } catch {
        Write-Err ("Failed to run {0}: {1}" -f $Title, $_.Exception.Message)
        Write-Host "Press Enter to return to the menu:" -NoNewline
        [void][System.Console]::ReadLine()
    }
}

function Run-ToolNewWindow {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$Title = 'Tool'
    )
    try {
        if (-not (Test-Path -LiteralPath $Path)) { throw "Not found: $Path" }
        Unblock-File -LiteralPath $Path -ErrorAction SilentlyContinue
        $psi = @{
            FilePath = 'powershell.exe'
            ArgumentList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$Path`"")
            Verb = 'RunAs'
            WindowStyle = 'Normal'
        }
        Write-Info "Launching (new window): $Title -> $Path"
        Start-Process @psi | Out-Null
        $true
    } catch {
        Write-Err ("Failed to spawn {0} in new window: {1}" -f $Title, $_.Exception.Message)
        $false
    }
}

#endregion

#region ── Temp path resolver (C:\temp, %TEMP%, fallback) ─────────────────────

function Resolve-SafeTempPath {
    [CmdletBinding()]
    param([string[]]$Candidates = @('C:\temp', $env:TEMP, $global:CS_TempRoot))
    foreach($c in $Candidates){
        if (-not $c) { continue }
        try {
            if (-not (Test-Path -LiteralPath $c)) { New-Item -ItemType Directory -Path $c -Force | Out-Null }
            $t = Test-Path -LiteralPath $c -PathType Container
            if ($t) { return (Resolve-Path -LiteralPath $c).Path }
        } catch { }
    }
    throw "No writable temp path available."
}

#endregion

#region ── Convenience: default toolbox root unblocker ────────────────────────

function Unblock-DefaultToolRoot {
    [CmdletBinding()]
    param(
        [string]$Root = 'C:\CS-TOOLBOX-TEMP\prod-01-01',
        [switch]$Recurse
    )
    if (Test-Path -LiteralPath $Root) {
        Unblock-ToolingInFolder -Path $Root -Recurse:$Recurse
    }
}

#endregion

#region ── Compat shim for launcher: Preflight-Unblock ────────────────────────
function Preflight-Unblock {
    [CmdletBinding()]
    param(
        [string]$Root,
        [switch]$Recurse
    )
    try {
        # Default root if not provided by caller (PS 5.1-safe)
        if ([string]::IsNullOrWhiteSpace($Root)) {
            $tmpVar = Get-Variable -Name 'CSLauncherRoot' -Scope Global -ErrorAction SilentlyContinue
            if ($tmpVar -and $tmpVar.Value) {
                $Root = $tmpVar.Value
            } else {
                $Root = 'C:\CS-Toolbox-TEMP\prod-01-01'
            }
        }

        # Ensure current session can run scripts without prompts
        try { Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue } catch {}

        # Unblock .ps1/.psm1 payloads
        Unblock-ToolingInFolder -Path $Root -Recurse:$Recurse
        Write-Ok "Preflight unblock complete: $Root"
        return $true
    } catch {
        Write-Warn "Preflight-Unblock failed for '$Root': $($_.Exception.Message)"
        return $false
    }
}
#endregion

# EOF
