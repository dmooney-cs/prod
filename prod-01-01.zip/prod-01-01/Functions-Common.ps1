# ╔═════════════════════════════════════════════════════════════╗
# ║ 🔧 CS Toolbox – Shared Functions                            ║
# ║ Version: 3.4 | ZIP with log attach fallback, summary log   ║
# ╚═════════════════════════════════════════════════════════════╝

function Show-Header {
    param ([string]$Title)
    $width = 55
    $padded = "║   $Title".PadRight($width - 1) + "║"

    Clear-Host
    Write-Host ""
    Write-Host ("╔" + ("═" * ($width - 2)) + "╗") -ForegroundColor Cyan
    Write-Host $padded -ForegroundColor Cyan
    Write-Host ("╚" + ("═" * ($width - 2)) + "╝") -ForegroundColor Cyan
    Write-Host ""
}

function Pause-Script {
    Write-Host ""
    Write-Host "Press any key to continue..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Ensure-ExportFolder {
    $folder = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $folder)) {
        New-Item -Path $folder -ItemType Directory -Force | Out-Null
    }
}

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}

function Export-Data {
    param (
        [Parameter(Mandatory = $true)][object]$Object,
        [Parameter(Mandatory = $true)][string]$BaseName,
        [string]$Ext = "csv"
    )
    $folder = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    Ensure-ExportFolder
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $fileName = "$BaseName-$timestamp.$Ext"
    $path = Join-Path $folder $fileName

    switch ($Ext.ToLower()) {
        "csv" { $Object | Export-Csv -Path $path -NoTypeInformation -Force }
        "txt" { $Object | Out-File -FilePath $path -Encoding UTF8 }
        default { throw "Unsupported extension: $Ext" }
    }

    return $path
}

function Cleanup-ExportFolder {
    $root = "$env:SystemDrive\CS-Toolbox-TEMP"
    if (Test-Path $root) {
        Write-Host "`nThis will permanently delete the following:" -ForegroundColor Yellow
        Write-Host " - $root" -ForegroundColor Cyan
        $confirm = Read-Host "Are you sure you want to delete all toolbox data? (Y/N)"
        if ($confirm -eq "Y") {
            Remove-Item -Path $root -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "✅ Toolbox data deleted." -ForegroundColor Green
        } else {
            Write-Host "❌ Cleanup canceled." -ForegroundColor Red
        }
    } else {
        Write-Host "Nothing to delete." -ForegroundColor Yellow
    }
}

function Zip-ExportFolder {
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $exportFolder = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    $zipName = "CS-Toolbox-Export-$timestamp.zip"
    $zipPath = Join-Path $env:TEMP $zipName

    # Optional: include CyberCNS logs if available
    $logSource = "C:\Program Files (x86)\CyberCNSAgent\logs"
    if (Test-Path $logSource) {
        $logsZip = "$exportFolder\CyberCNSAgentLogs.zip"
        Compress-Archive -Path "$logSource\*" -DestinationPath $logsZip -Force
    }

    Compress-Archive -Path "$exportFolder\*" -DestinationPath $zipPath -Force
    return $zipPath
}

function Send-ZipEmail {
    param (
        [Parameter(Mandatory = $true)][string]$Attachment
    )
    try {
        $mail = New-Object -ComObject Outlook.Application
        $msg = $mail.CreateItem(0)
        $msg.To = ""
        $msg.Subject = "CS Toolbox Results"
        $msg.Body = "Attached are the collected results from CS Toolbox."
        $msg.Attachments.Add($Attachment) | Out-Null
        $msg.Display()
    } catch {
        Write-Host "❌ Outlook automation failed. Please attach manually." -ForegroundColor Red
    }
}

function Write-SessionSummary {
    param ([string]$Line)
    $path = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info\SessionSummary.txt"
    Add-Content -Path $path -Value "$(Get-Date -Format 'u') $Line"
}
