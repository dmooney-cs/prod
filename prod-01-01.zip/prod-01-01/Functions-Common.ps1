function Show-Header {
    param ([string]$Title)
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host ("         " + $Title)
    Write-Host "====================================================="
    Write-Host ""
}

function Pause-Script {
    Write-Host ""
    Write-Host "Press any key to continue..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Export-Data {
    param (
        [Parameter(Mandatory = $true)][object]$Object,
        [Parameter(Mandatory = $true)][string]$BaseName,
        [string]$Ext = "csv"
    )

    $folder = "C:\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $folder)) {
        New-Item -Path $folder -ItemType Directory -Force | Out-Null
    }

    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $filePath = Join-Path $folder "$BaseName-$timestamp.$Ext"

    try {
        if ($Ext -eq "csv") {
            $Object | Export-Csv -Path $filePath -NoTypeInformation -Encoding UTF8
        } elseif ($Ext -eq "txt") {
            $Object | Out-File -FilePath $filePath -Encoding UTF8
        } else {
            Write-Host "Unsupported export extension: $Ext" -ForegroundColor Red
            return $null
        }

        return $filePath
    } catch {
        Write-Host "❌ Failed to export data: $_" -ForegroundColor Red
        return $null
    }
}

function Invoke-ZipAndEmailResults {
    Show-Header "Prepare ZIP and Launch Email"
    $exportPath = "C:\CS-Toolbox-TEMP\Collected-Info"
    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $zipPath = "C:\CS-Toolbox-TEMP\CS-Toolbox-Results-$timestamp.zip"

    try {
        if (-not (Test-Path $exportPath)) {
            Write-Host "Nothing to zip. Export folder does not exist." -ForegroundColor Yellow
            Pause-Script
            return
        }

        Compress-Archive -Path "$exportPath\*" -DestinationPath $zipPath -Force
        Write-Host "✔ Results zipped to $zipPath"

        $outlook = New-Object -ComObject Outlook.Application
        $mail = $outlook.CreateItem(0)
        $mail.Subject = "CS Toolbox Results - $env:COMPUTERNAME"
        $mail.Body = "Attached are the results collected from the CS Toolbox."
        $mail.Attachments.Add($zipPath)
        $mail.Display()
    } catch {
        Write-Host "❌ Failed to create email or zip file: $_" -ForegroundColor Red
    }

    Pause-Script
}

function Invoke-FinalCleanupAndExit {
    Show-Header "Final Cleanup"
    $folder = "C:\CS-Toolbox-TEMP"

    try {
        Stop-Process -Name "OUTLOOK" -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1

        if (Test-Path $folder) {
            Remove-Item -Path $folder -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host "✔ Removed $folder"
        } else {
            Write-Host "Nothing to clean up." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "❌ Cleanup failed: $_" -ForegroundColor Red
    }

    Pause-Script
}
