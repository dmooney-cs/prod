function Show-Header {
    param ([string]$Title)
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host ("         " + $Title)
    Write-Host "====================================================="
    Write-Host ""
}

function Pause-Script {
    Write-Host ""
    Write-Host "Press any key to continue..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Export-Data {
    param (
        [Parameter(Mandatory = $true)][object]$Object,
        [Parameter(Mandatory = $true)][string]$BaseName,
        [string]$Ext = "csv"
    )

    $folder = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $folder)) {
        New-Item -Path $folder -ItemType Directory -Force | Out-Null
    }

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $file = Join-Path $folder "$BaseName`_$timestamp.$Ext"

    try {
        switch ($Ext.ToLower()) {
            "csv"   { $Object | Export-Csv -NoTypeInformation -Path $file -Force }
            "json"  { $Object | ConvertTo-Json -Depth 5 | Out-File -FilePath $file -Encoding UTF8 }
            "txt"   { $Object | Out-File -FilePath $file -Encoding UTF8 }
            default { Write-Host "Unsupported file extension: $Ext" }
        }
    } catch {
        Write-Host "Error exporting data: $_"
    }

    return $file
}

function Write-ExportPath {
    param ([string]$Path)
    Write-Host ""
    Write-Host "Exported to: $Path"
}

function Write-SessionSummary {
    param (
        [Parameter(Mandatory = $true)][string]$Message
    )

    $folder = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $folder)) {
        New-Item -Path $folder -ItemType Directory -Force | Out-Null
    }

    $logFile = Join-Path $folder "Session-Summary.txt"
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Add-Content -Path $logFile -Value "$timestamp - $Message"
}

function Invoke-ZipAndEmailResults {
    Show-Header "📦 ZIP and Email Collected Results"
    $exportRoot = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    $zipName = "CS-Toolbox-Results_{0}.zip" -f (Get-Date -Format "yyyyMMdd_HHmmss")
    $zipPath = Join-Path $env:TEMP $zipName

    # Check if logs folder exists and offer to include
    $logSource = "C:\Program Files (x86)\CyberCNSAgent\logs"
    if (Test-Path $logSource) {
        $includeLogs = Read-Host "CyberCNSAgent logs found. Include in export? (Y/N)"
        if ($includeLogs -match '^[Yy]') {
            $logZip = Join-Path $exportRoot "CyberCNSAgentLogs.zip"
            try {
                Compress-Archive -Path $logSource -DestinationPath $logZip -Force
                Write-Host "Zipped agent logs to: $logZip"
            } catch {
                Write-Host "❌ Failed to compress logs: $($_.Exception.Message)" -ForegroundColor Red
            }
        }
    }

    # Compress export folder
    try {
        if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
        Compress-Archive -Path "$exportRoot\*" -DestinationPath $zipPath -Force
        Write-Host "`n✅ Results compressed to: $zipPath" -ForegroundColor Cyan
    } catch {
        Write-Host "❌ Failed to create ZIP: $($_.Exception.Message)" -ForegroundColor Red
        Pause-Script
        return
    }

    # Try to launch email
    $outlook = Get-Process outlook -ErrorAction SilentlyContinue
    if (-not $outlook) {
        try { Start-Process "outlook.exe" -ErrorAction SilentlyContinue; Start-Sleep -Seconds 2 } catch {}
    }

    try {
        $OutlookApp = New-Object -ComObject Outlook.Application
        $Mail = $OutlookApp.CreateItem(0)
        $Mail.Subject = "CS Toolbox Results"
        $Mail.Body = "Attached are the collected results from the CS Toolbox."
        $Mail.Attachments.Add($zipPath)
        $Mail.Display()
    } catch {
        Write-Host "`n⚠️ Could not launch Outlook. Please manually send the ZIP file." -ForegroundColor Yellow
        Write-ExportPath $zipPath
        Pause-Script
        return
    }

    Write-Host "`n✅ Email draft created successfully." -ForegroundColor Green
    Pause-Script
}

function Run-CleanupExportFolder {
    Show-Header "🧹 Cleanup – Remove Toolbox Export Data"

    $rootPath = "$env:SystemDrive\CS-Toolbox-TEMP"
    $logZip = Join-Path $rootPath "Collected-Info\CyberCNSAgentLogs.zip"
    $zipExports = Get-ChildItem "$env:TEMP" -Filter "CS-Toolbox-Results_*.zip" -ErrorAction SilentlyContinue

    Write-Host "This will permanently delete the following:" -ForegroundColor Yellow
    Write-Host " - $rootPath"
    if (Test-Path $logZip) { Write-Host " - $logZip" }
    if ($zipExports) {
        foreach ($zip in $zipExports) { Write-Host " - $($zip.FullName)" }
    }

    $confirm = Read-Host "`nAre you sure you want to delete all toolbox data? (Y/N)"
    if ($confirm -notmatch '^[Yy]') {
        Write-Host "`n❌ Cleanup cancelled by user."
        Pause-Script
        return
    }

    # Remove CS-Toolbox-TEMP
    if (Test-Path $rootPath) {
        try {
            Remove-Item -Path $rootPath -Recurse -Force -ErrorAction Stop
            Write-Host "✅ Deleted: $rootPath"
        } catch {
            Write-Host "❌ Failed to delete $rootPath"
            Write-Host $_.Exception.Message
        }
    }

    # Remove ZIP exports
    foreach ($zip in $zipExports) {
        try {
            Remove-Item $zip.FullName -Force -ErrorAction Stop
            Write-Host "✅ Deleted ZIP: $($zip.FullName)"
        } catch {
            Write-Host "❌ Failed to delete $($zip.FullName)"
        }
    }

    Write-Host "`nCleanup completed."
    Pause-Script
}
