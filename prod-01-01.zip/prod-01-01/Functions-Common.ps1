<# =====================================================================
  Functions-Common.ps1
  Shared helpers for ConnectSecure Technicians Toolbox

  Provides:
    - Show-Header
    - Ensure-ExportFolder
    - Write-Utf8NoBom
    - Pause-Script
    - Launch-Tool
    - Zip-Results
    - Invoke-FinalCleanupAndExit (elevated, new window, verbose, auto-close)
    - Utility helpers (Test-IsAdmin, Resolve-ToolPath, Safe-RemoveTree)
===================================================================== #>

#region Basic environment helpers

function Test-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p  = New-Object Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Get-CommonVersion {
    try {
        $thisPath = $MyInvocation.MyCommand.Path
        $name = [IO.Path]::GetFileNameWithoutExtension($thisPath)
        if ($name -match 'Common[-_\s]*(\d{4}-\d{2}-\d{2})\s*(R\d+)?') {
            $d = $matches[1]
            $r = if ($matches[2]) { " " + $matches[2] } else { "" }
            return "Common-$d$r"
        } else {
            $dt = (Get-Item $thisPath).LastWriteTime.ToString('yyyy-MM-dd')
            return "Common-$dt"
        }
    } catch { return "Common-Unknown" }
}

function Show-Header {
    param([Parameter(Mandatory)][string]$Title)

    $hostName = $env:COMPUTERNAME
    $userName = "$($env:USERNAME)"
    $isAdmin  = Test-IsAdmin
    $commonV  = Get-CommonVersion

    $line = "=" * 57
    Clear-Host
    Write-Host ("   {0}" -f $Title) -ForegroundColor Cyan
    Write-Host $line
    Write-Host (" Host: {0}   User: {1}   Admin: {2}   Common: {3}" -f $hostName, $userName, $isAdmin, $commonV) -ForegroundColor Gray
    Write-Host ""
    Write-Host (" {0}" -f $Title) -ForegroundColor White
    Write-Host ""
}

#endregion

#region File system helpers

function Ensure-ExportFolder {
    $root = "C:\CS-Toolbox-TEMP"
    $info = Join-Path $root "Collected-Info"
    $dirs = @(
        $root,
        $info,
        (Join-Path $info "Patches")
    )
    foreach ($d in $dirs) {
        if (-not (Test-Path $d)) {
            New-Item -ItemType Directory -Path $d -Force | Out-Null
        }
    }
}

function Write-Utf8NoBom {
    [CmdletBinding()]
    param(
        [Parameter(ValueFromPipeline = $true)]
        [string] $InputObject,
        [Parameter(Mandatory)]
        [string] $Path
    )
    begin { $sb = New-Object System.Text.StringBuilder }
    process { if ($null -ne $InputObject) { [void]$sb.Append($InputObject) } }
    end {
        $enc = New-Object System.Text.UTF8Encoding($false) # no BOM
        [System.IO.File]::WriteAllText($Path, $sb.ToString(), $enc)
    }
}

function Pause-Script {
    param([string]$Message = "Press any key to continue...")
    try {
        if ($Host -and $Host.UI -and $Host.UI.RawUI) {
            if ($Message) { Write-Host $Message -ForegroundColor Gray }
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        } else {
            if ($Message) { Write-Host $Message -ForegroundColor Gray }
            [void][System.Console]::ReadKey($true)
        }
    } catch { Start-Sleep -Seconds 1 }
}

#endregion

#region Launching helpers

function Resolve-ToolPath {
    param([Parameter(Mandatory)][string]$ScriptName)
    $scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
    $cand = @(
        (Join-Path $scriptRoot $ScriptName),
        (Join-Path $scriptRoot ("{0}" -f $ScriptName.Trim('\"')))
    )
    foreach ($p in $cand) {
        if (Test-Path $p) { return (Resolve-Path $p).Path }
    }
    return $null
}

function Launch-Tool {
    [CmdletBinding(DefaultParameterSetName='ByName')]
    param(
        [Parameter(ParameterSetName='ByName', Position=0)]
        [Alias('Script')]
        [string]$ScriptName,

        [Parameter(ParameterSetName='ByPath')]
        [string]$Path
    )
    try {
        $target = if ($PSCmdlet.ParameterSetName -eq 'ByPath') { $Path } else { Resolve-ToolPath -ScriptName $ScriptName }
        if (-not $target) { throw "Could not resolve tool path." }
        $args = @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$target`"")
        Start-Process -FilePath "powershell.exe" -ArgumentList $args | Out-Null
    } catch {
        Write-Host ("ERROR launching tool: {0}" -f $_.Exception.Message) -ForegroundColor Red
        throw
    }
}

#endregion

#region Results packaging

function Zip-Results {
    [CmdletBinding()]
    param(
        [string]$Source = "C:\CS-Toolbox-TEMP\Collected-Info",
        [string]$OutputFolder = "C:\CS-Toolbox-TEMP"
    )
    if (-not (Test-Path $Source)) {
        Write-Host ("Nothing to zip; source not found: {0}" -f $Source) -ForegroundColor Yellow
        return $null
    }
    if (-not (Test-Path $OutputFolder)) {
        New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
    }

    $host = $env:COMPUTERNAME
    $ts   = Get-Date -Format "yyyyMMdd_HHmmss"
    $zip  = Join-Path $OutputFolder ("CS-Toolbox_{0}_{1}.zip" -f $host,$ts)

    try {
        if (Test-Path $zip) { Remove-Item $zip -Force }
        Compress-Archive -Path (Join-Path $Source '*') -DestinationPath $zip -Force
        Write-Host ("Zip created: {0}" -f $zip) -ForegroundColor Green
        return $zip
    } catch {
        Write-Host ("ERROR creating zip: {0}" -f $_.Exception.Message) -ForegroundColor Red
        return $null
    }
}

#endregion

#region Cleanup helpers

function Safe-RemoveTree {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path $Path)) { return $true }
    try {
        Get-ChildItem -Path $Path -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
            try { $_.Attributes = 'Normal' } catch {}
        }
        Remove-Item -Path $Path -Recurse -Force -ErrorAction Stop
        return -not (Test-Path $Path)
    } catch {
        Write-Host ("Remove failed: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
        return $false
    }
}

function Invoke-FinalCleanupAndExit {
    [CmdletBinding()]
    param(
        [int]$CountdownSeconds = 3
    )
    $tempRoot = "C:\CS-Toolbox-TEMP"

    try {
        # Write a one-time cleanup runner script to %TEMP%
        $runner = Join-Path $env:TEMP ("CS-Toolbox-Cleanup-{0}.ps1" -f ([guid]::NewGuid().ToString("N")))

        # Use a single-quoted here-string so $vars are not expanded here
        $cleanupScript = @'
param(
    [string]$Target,
    [int]$Retries = 6,
    [int]$Countdown = 5
)

try {
    if ($Host -and $Host.UI -and $Host.UI.RawUI) {
        $Host.UI.RawUI.WindowTitle = "ConnectSecure Toolbox Cleanup"
    }

    Write-Host ""
    Write-Host ("Cleaning: {0}" -f $Target) -ForegroundColor Yellow

    $filesDeleted = 0; $filesFailed = 0; $dirsDeleted = 0; $dirsFailed = 0

    for ($attempt = 1; $attempt -le $Retries; $attempt++) {
        if (-not (Test-Path -LiteralPath $Target)) { break }

        # Clear attributes first to avoid readonly/hidden issues
        Get-ChildItem -LiteralPath $Target -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
            try { $_.Attributes = 'Normal' } catch {}
        }

        $items = Get-ChildItem -LiteralPath $Target -Recurse -Force -ErrorAction SilentlyContinue
        $files = $items | Where-Object { -not $_.PSIsContainer }
        $dirs  = $items | Where-Object { $_.PSIsContainer } | Sort-Object FullName -Descending

        if ($files.Count -gt 0) { Write-Host ("Deleting {0} files..." -f $files.Count) -ForegroundColor Cyan }
        foreach ($f in $files) {
            try {
                Remove-Item -LiteralPath $f.FullName -Force -ErrorAction Stop
                Write-Host ("[OK] {0}" -f $f.FullName)
                $filesDeleted++
            } catch {
                Write-Host ("[FAIL] {0} -> {1}" -f $f.FullName, $_.Exception.Message) -ForegroundColor DarkYellow
                $filesFailed++
            }
        }

        if ($dirs.Count -gt 0) { Write-Host ("Deleting {0} folders..." -f $dirs.Count) -ForegroundColor Cyan }
        foreach ($d in $dirs) {
            try {
                Remove-Item -LiteralPath $d.FullName -Force -ErrorAction Stop
                Write-Host ("[OK] {0}" -f $d.FullName)
                $dirsDeleted++
            } catch {
                Write-Host ("[WAIT] {0} -> {1}" -f $d.FullName, $_.Exception.Message) -ForegroundColor DarkYellow
                $dirsFailed++
            }
        }

        try {
            if (Test-Path -LiteralPath $Target) {
                Remove-Item -LiteralPath $Target -Force -ErrorAction Stop
                Write-Host ("[OK] {0}" -f $Target)
            }
            break
        } catch {
            Write-Host ("Retry {0}: {1}" -f $attempt, $_.Exception.Message) -ForegroundColor DarkYellow
            Start-Sleep -Seconds 1
        }
    }

    # Summary
    Write-Host ""
    Write-Host "-------------------- Summary --------------------" -ForegroundColor White
    Write-Host ("Files deleted      : {0}" -f $filesDeleted) -ForegroundColor Green
    Write-Host ("Files failed       : {0}" -f $filesFailed)  -ForegroundColor Yellow
    Write-Host ("Folders deleted    : {0}" -f $dirsDeleted)  -ForegroundColor Green
    Write-Host ("Folders delete errs: {0}" -f $dirsFailed)   -ForegroundColor Yellow
    Write-Host ("Remaining path exists: {0}" -f (Test-Path -LiteralPath $Target)) -ForegroundColor Yellow
    Write-Host "-------------------------------------------------"

    # Auto-close countdown
    for ($c = $Countdown; $c -ge 1; $c--) {
        Write-Host ("Closing in {0}s..." -f $c) -ForegroundColor Gray
        Start-Sleep -Seconds 1
    }
} catch {
    Write-Host ("ERROR in cleanup runner: {0}" -f $_.Exception.Message) -ForegroundColor Red
} finally {
    exit
}
'@

        # Save the runner (UTF-8 no BOM)
        $enc = New-Object System.Text.UTF8Encoding($false)
        [IO.File]::WriteAllText($runner, $cleanupScript, $enc)

        # Small countdown so the user sees what's happening, then close this window
        Write-Host ""
        Write-Host ("Cleanup will remove {0} in a new elevated window..." -f $tempRoot) -ForegroundColor Yellow
        for ($i=$CountdownSeconds; $i -ge 1; $i--) {
            Write-Host ("Closing this window in {0}s..." -f $i)
            Start-Sleep -Seconds 1
        }

        # Launch elevated cleanup in a NEW window with progress
        $args = @(
            '-NoProfile','-ExecutionPolicy','Bypass',
            '-WindowStyle','Normal',
            '-File',"`"$runner`"",
            '-Target',"`"$tempRoot`"",
            '-Countdown','5'
        )
        Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList $args | Out-Null

        # Close current console so no locks remain on C:\CS-Toolbox-TEMP
        $host.SetShouldExit(0)
        Stop-Process -Id $PID
    } catch {
        Write-Host ("ERROR preparing elevated cleanup: {0}" -f $_.Exception.Message) -ForegroundColor Red
    }
}

#endregion
