function Show-Header {
    param ([string]$Title)
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host ("         " + $Title)
    Write-Host "====================================================="
    Write-Host ""
}

function Pause-Script {
    Write-Host ""
    Write-Host "Press any key to continue..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Export-Data {
    param (
        [Parameter(Mandatory = $true)][object]$Object,
        [Parameter(Mandatory = $true)][string]$BaseName,
        [string]$Ext = "csv"
    )

    $folder = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $folder)) {
        New-Item -Path $folder -ItemType Directory -Force | Out-Null
    }

    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $file = Join-Path $folder "$BaseName`_$timestamp.$Ext"

    try {
        switch ($Ext.ToLower()) {
            "csv"   { $Object | Export-Csv -NoTypeInformation -Path $file -Force }
            "json"  { $Object | ConvertTo-Json -Depth 5 | Out-File -FilePath $file -Encoding UTF8 }
            "txt"   { $Object | Out-File -FilePath $file -Encoding UTF8 }
            default { Write-Host "Unsupported file extension: $Ext" }
        }
    } catch {
        Write-Host "Error exporting data: $_"
    }

    return $file
}

function Write-ExportPath {
    param ([string]$Path)
    Write-Host ""
    Write-Host "Exported to: $Path"
}

function Run-ZipAndEmailResults {
    try {
        Show-Header "Zip and Email Results"

        $exportFolder = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
        $zipPath = "$env:SystemDrive\CS-Toolbox-TEMP\CS_Toolbox_Results.zip"

        if (-not (Test-Path $exportFolder)) {
            Write-Host "No export folder found at $exportFolder."
            Pause-Script
            return
        }

        if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

        Compress-Archive -Path "$exportFolder\*" -DestinationPath $zipPath -Force
        Write-Host "Results compressed to: $zipPath"

        if (Get-Command "Outlook" -ErrorAction SilentlyContinue) {
            Start-Process "Outlook.exe" "/a `"$zipPath`""
            Write-Host "Outlook opened with ZIP attached."
        } else {
            Write-Host "Outlook not found. Please attach the ZIP manually."
        }

        Pause-Script
    }
    catch {
        Write-Host "An error occurred during zip or email process:" -ForegroundColor Red
        Write-Host $_.Exception.Message
        Pause-Script
    }
}

function Run-CleanupExportFolder {
    Show-Header "Clean Up Export Folder"
    $path = "$env:SystemDrive\CS-Toolbox-TEMP"

    if (Test-Path $path) {
        try {
            Remove-Item -Path $path -Recurse -Force -ErrorAction Stop
            Write-Host "Cleaned up: $path"
        } catch {
            Write-Host "Failed to delete: $path"
            Write-Host $_.Exception.Message
        }
    } else {
        Write-Host "No export folder to delete."
    }

    Pause-Script
}
