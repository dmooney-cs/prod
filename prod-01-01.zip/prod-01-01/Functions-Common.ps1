﻿function Show-Header {
    param ([string]$Title)
    $width = 58
    $padded = "║   $Title".PadRight($width - 1) + "║"

    Clear-Host
    Write-Host ""
    Write-Host ("╔" + ("═" * ($width - 2)) + "╗") -ForegroundColor Cyan
    Write-Host $padded -ForegroundColor Cyan
    Write-Host ("╚" + ("═" * ($width - 2)) + "╝") -ForegroundColor Cyan
    Write-Host ""
}

function Pause-Script {
    Write-Host ""
    Write-Host "Press any key to continue..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`nExported to: $Path" -ForegroundColor Cyan
}

function Ensure-ExportFolder {
    $path = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $path)) {
        New-Item -Path $path -ItemType Directory -Force | Out-Null
    }
}

function Export-Data {
    param (
        [Parameter(Mandatory = $true)][object]$Object,
        [Parameter(Mandatory = $true)][string]$BaseName,
        [string]$Ext = "csv"
    )

    $folder = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $folder)) {
        New-Item -Path $folder -ItemType Directory -Force | Out-Null
    }

    $timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $filePath = Join-Path $folder "$BaseName-$timestamp.$Ext"

    if ($Object -is [System.Collections.IEnumerable] -and -not ($Object -is [string])) {
        $Object | Export-Csv -Path $filePath -NoTypeInformation -Encoding UTF8
    } else {
        $Object | Out-File -FilePath $filePath -Encoding UTF8
    }

    Write-ExportPath $filePath
}

function Invoke-ZipAndEmailResults {
    Show-Header "Zipping and Emailing Results"

    $exportPath = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    if (-not (Test-Path $exportPath)) {
        Write-Host "❌ Export folder not found at $exportPath"
        Pause-Script
        return
    }

    $files = Get-ChildItem -Path $exportPath -Recurse
    if ($files.Count -eq 0) {
        Write-Host "❌ No export data found to include in ZIP." -ForegroundColor Red
        Pause-Script
        return
    }

    $zipPath = "$env:SystemDrive\CS-Toolbox-TEMP\CS-Toolbox-Results.zip"
    if (Test-Path $zipPath) {
        Remove-Item $zipPath -Force
    }

    try {
        Compress-Archive -Path "$exportPath\*" -DestinationPath $zipPath -Force
        Write-Host "`n✅ Results zipped to: $zipPath" -ForegroundColor Cyan
    } catch {
        Write-Host "❌ Failed to create ZIP archive." -ForegroundColor Red
        Write-Host $_.Exception.Message
        Pause-Script
        return
    }

    try {
        $Outlook = New-Object -ComObject Outlook.Application
        $Mail = $Outlook.CreateItem(0)
        $Mail.Subject = "CS Toolbox Results"
        $Mail.Body = "Attached are the exported results from the CS Toolbox."
        $Mail.Attachments.Add($zipPath)
        $Mail.Display()
    } catch {
        Write-Host "`n⚠️ Outlook not available or failed to create email." -ForegroundColor Yellow
        Write-Host "You can manually attach the ZIP file located at:"
        Write-Host $zipPath -ForegroundColor Cyan
    }

    Pause-Script
}

function Invoke-CleanupExport {
    Show-Header "Cleaning Up Export Data"
    $path = "$env:SystemDrive\CS-Toolbox-TEMP\Collected-Info"
    if (Test-Path $path) {
        Remove-Item "$path\*" -Recurse -Force
        Write-Host "✅ Export folder cleaned up."
    } else {
        Write-Host "ℹ️ No export folder to clean."
    }

    $zip = "$env:SystemDrive\CS-Toolbox-TEMP\CS-Toolbox-Results.zip"
    if (Test-Path $zip) {
        Remove-Item $zip -Force
        Write-Host "✅ ZIP file removed."
    }

    Pause-Script
}

function Write-SessionSummary {
    param (
        [string]$Message
    )
    $logPath = "$env:SystemDrive\CS-Toolbox-TEMP\session-log.txt"
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$timestamp - $Message" | Out-File -FilePath $logPath -Append -Encoding UTF8
}
