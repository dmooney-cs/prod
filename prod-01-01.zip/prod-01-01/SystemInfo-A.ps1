# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ======================
#  System Info A (Menu)
# ======================

$OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\SystemInfo'
if (-not (Test-Path $OutRoot)) {
    New-Item -Path $OutRoot -ItemType Directory | Out-Null
}

function Get-Timestamp { Get-Date -Format 'yyyyMMdd_HHmmss' }

# ---------------------------
# 1) Windows Firewall Status
# ---------------------------
function Run-FirewallStatus {
    Show-Header "System Info A - Firewall Status"
    $ts = Get-Timestamp
    $csv = Join-Path $OutRoot ("Firewall_Status_" + $ts + ".csv")

    try {
        $profiles = Get-NetFirewallProfile -ErrorAction Stop | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction, NotifyOnListen, AllowInboundRules, AllowLocalFirewallRules, AllowLocalIPsecRules, LogFileName, LogMaxSizeKilobytes
        if ($profiles) {
            $profiles | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
            Write-Host ("Profiles exported: {0}" -f ($profiles.Count)) -ForegroundColor Green
            $profiles | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction | Format-Table -AutoSize
            Write-Host "Saved: $csv" -ForegroundColor Green
        } else {
            Write-Host "No firewall profiles returned." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR collecting firewall status: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

# ----------------------
# 2) Microsoft Defender
# ----------------------
function Run-DefenderStatus {
    Show-Header "System Info A - Microsoft Defender"
    $ts = Get-Timestamp
    $csv = Join-Path $OutRoot ("Defender_Status_" + $ts + ".csv")
    $json = Join-Path $OutRoot ("Defender_Status_" + $ts + ".json")

    $status = $null
    try {
        # Prefer Defender module if present
        if (Get-Command -Name Get-MpComputerStatus -ErrorAction SilentlyContinue) {
            $status = Get-MpComputerStatus -ErrorAction Stop
        } else {
            Write-Host "Get-MpComputerStatus not available. Checking security center via CIM..." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "WARN: Get-MpComputerStatus failed: $($_.Exception.Message)" -ForegroundColor Yellow
    }

    try {
        if (-not $status) {
            # Minimal fallback via SecurityProduct WMI (anti-virus)
            $sec = Get-CimInstance -Namespace root\SecurityCenter2 -ClassName AntiVirusProduct -ErrorAction SilentlyContinue
            if ($sec) {
                $status = [PSCustomObject]@{
                    RealTimeProtectionEnabled = $null
                    AntivirusEnabled         = ($sec.displayName -ne $null)
                    NISEnabled               = $null
                    AMProductVersion         = $null
                    EngineVersion            = $null
                    AntispywareSignatureAge  = $null
                    AntivirusSignatureAge    = $null
                    QuickScanAge             = $null
                    FullScanAge              = $null
                    LastQuickScanSource      = $null
                    LastFullScanSource       = $null
                    AVVendors                = ($sec | Select-Object -ExpandProperty displayName -ErrorAction SilentlyContinue) -join '; '
                }
            }
        }

        if ($status) {
            # Normalize to table-friendly output
            $out = $status | Select-Object `
                RealTimeProtectionEnabled, `
                AntivirusEnabled, `
                NISEnabled, `
                AMProductVersion, `
                EngineVersion, `
                AntivirusSignatureVersion, `
                AntispywareSignatureVersion, `
                AntivirusSignatureAge, `
                AntispywareSignatureAge, `
                LastQuickScanSource, `
                LastFullScanSource, `
                QuickScanAge, `
                FullScanAge, `
                AVVendors

            $out | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
            try { $out | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $json -Encoding UTF8 } catch {}

            Write-Host "Defender status saved." -ForegroundColor Green
            Write-Host "Saved: $csv" -ForegroundColor Green
            Write-Host "Saved: $json" -ForegroundColor Green

            $out | Format-List
        } else {
            Write-Host "No Defender or AV status could be retrieved." -ForegroundColor Yellow
        }
    } catch {
        Write-Host "ERROR collecting Defender status: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

# -----------------
# 3) Disk / SMART
# -----------------
function Run-DiskSmart {
    Show-Header "System Info A - Disk / SMART"
    $ts = Get-Timestamp
    $csvDisk   = Join-Path $OutRoot ("Disk_Devices_" + $ts + ".csv")
    $csvVol    = Join-Path $OutRoot ("Disk_Volumes_" + $ts + ".csv")
    $csvHealth = Join-Path $OutRoot ("Disk_S.M.A.R.T._" + $ts + ".csv")

    try {
        # Basic disk inventory
        $disks = Get-CimInstance -ClassName Win32_DiskDrive -ErrorAction SilentlyContinue |
                 Select-Object Index, Model, SerialNumber, InterfaceType, Size, Partitions, Status, FirmwareRevision
        if ($disks) {
            $disks | Export-Csv -LiteralPath $csvDisk -NoTypeInformation -Encoding UTF8
            Write-Host ("Disks exported: {0}" -f ($disks.Count)) -ForegroundColor Green
            $disks | Select-Object Index, Model, Size, Status | Format-Table -AutoSize
            Write-Host "Saved: $csvDisk" -ForegroundColor Green
        } else {
            Write-Host "No disk devices returned." -ForegroundColor Yellow
        }

        # Volumes / free space
        $vols = Get-CimInstance -ClassName Win32_Volume -Filter "DriveType=3" -ErrorAction SilentlyContinue |
                Select-Object DriveLetter, Label, FileSystem, Capacity, FreeSpace, BlockSize
        if ($vols) {
            $vols | Export-Csv -LiteralPath $csvVol -NoTypeInformation -Encoding UTF8
            Write-Host ("Volumes exported: {0}" -f ($vols.Count)) -ForegroundColor Green
            $vols | Select-Object DriveLetter, Label, Capacity, FreeSpace | Format-Table -AutoSize
            Write-Host "Saved: $csvVol" -ForegroundColor Green
        } else {
            Write-Host "No volumes returned." -ForegroundColor Yellow
        }

        # SMART health (best-effort; requires vendor support)
        $smartStatus = Get-WmiObject -Namespace root\wmi -Class MSStorageDriver_FailurePredictStatus -ErrorAction SilentlyContinue
        $smartData   = Get-WmiObject -Namespace root\wmi -Class MSStorageDriver_FailurePredictData   -ErrorAction SilentlyContinue
        $smartThresh = Get-WmiObject -Namespace root\wmi -Class MSStorageDriver_FailurePredictThresholds -ErrorAction SilentlyContinue

        $smartOut = @()

        if ($smartStatus) {
            foreach ($s in $smartStatus) {
                $smartOut += [PSCustomObject]@{
                    InstanceName = $s.InstanceName
                    PredictFailure = $s.PredictFailure
                    Reason = $s.Reason
                }
            }
        }

        if ($smartOut.Count -gt 0) {
            $smartOut | Export-Csv -LiteralPath $csvHealth -NoTypeInformation -Encoding UTF8
            Write-Host ("SMART entries exported: {0}" -f ($smartOut.Count)) -ForegroundColor Green
            $smartOut | Format-Table -AutoSize
            Write-Host "Saved: $csvHealth" -ForegroundColor Green
        } else {
            # If not available, still create an empty file so techs know we tried.
            "" | Out-File -LiteralPath $csvHealth -Encoding utf8
            Write-Host "SMART data not available on this system." -ForegroundColor Yellow
            Write-Host "Saved placeholder: $csvHealth" -ForegroundColor Yellow
        }

    } catch {
        Write-Host "ERROR collecting disk/SMART details: $($_.Exception.Message)" -ForegroundColor Red
    }

    Pause-Script "Press any key to return to the menu..."
}

function Show-Menu {
    Clear-Host
    Show-Header "System Info A"

    Write-Host ""
    Write-Host " [1] Firewall Status            - Profiles, defaults, logging" -ForegroundColor White
    Write-Host " [2] Microsoft Defender         - Protection state and signatures" -ForegroundColor White
    Write-Host " [3] Disk / SMART               - Disks, volumes, health (best-effort)" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# Main loop
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Run-FirewallStatus }
        '2' { Run-DefenderStatus }
        '3' { Run-DiskSmart }
        'Q' {
            # Relaunch main CS Toolbox Launcher in same window
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path $launcher) {
                & $launcher
            }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}
