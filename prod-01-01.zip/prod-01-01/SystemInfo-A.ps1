# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ============================ SystemInfo-A.ps1 ============================
# CS Toolbox - System Info A
# Includes:
#  [1] Windows Firewall Status (Domain/Private/Public)
#  [2] Microsoft Defender Status (Engine/Realtime/Signatures)
#  [3] Disk & SMART / Health (multi-provider fallback)
#  [Q] Return to Launcher
# Exports saved to: C:\CS-Toolbox-TEMP\Collected-Info

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# --- Constants
$ExportRoot = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path $ExportRoot)) { New-Item -Path $ExportRoot -ItemType Directory | Out-Null }

function Get-Timestamp { (Get-Date).ToString("yyyy-MM-dd_HH-mm-ss") }
function New-ExportPath { param([Parameter(Mandatory)][string]$Prefix, [string]$Ext = "csv"); Join-Path $ExportRoot ("{0}_{1}.{2}" -f $Prefix, (Get-Timestamp), $Ext) }

# --------------------------- Firewall Status ---------------------------
function Get-FirewallStatus {
    [CmdletBinding()]
    param()

    $rows = @()
    try {
        $profiles = Get-NetFirewallProfile -ErrorAction Stop
        foreach ($p in $profiles) {
            $rows += [PSCustomObject]@{
                ComputerName   = $env:COMPUTERNAME
                Profile        = [string]$p.Name
                Enabled        = [bool]$p.Enabled
                DefaultInbound = [string]$p.DefaultInboundAction
                DefaultOutbound= [string]$p.DefaultOutboundAction
                NotifyOnListen = [bool]$p.NotifyOnListen
                AllowInboundRdp = [bool]$p.AllowInboundRemoteDesktop
            }
        }
    } catch {
        $rows += [PSCustomObject]@{
            ComputerName   = $env:COMPUTERNAME
            Profile        = "ERROR"
            Enabled        = $false
            DefaultInbound = ""
            DefaultOutbound= ""
            NotifyOnListen = $false
            AllowInboundRdp= $false
        }
        Write-Host "Firewall query failed: $_" -ForegroundColor Yellow
    }
    return ,$rows
}

function Invoke-FirewallStatus {
    Show-Header "System Info A - Windows Firewall Status"
    $rows = Get-FirewallStatus
    $outFile = New-ExportPath -Prefix "Firewall-Status"
    $rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    Write-Host "=== Windows Firewall Profiles ===" -ForegroundColor Cyan
    $rows | Format-Table Profile, Enabled, DefaultInbound, DefaultOutbound, NotifyOnListen, AllowInboundRdp -AutoSize
    Write-Host ""
    Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green

    if ($rows | Where-Object { $_.Enabled -eq $false -and $_.Profile -ne "ERROR" }) {
        Write-Host "⚠ One or more firewall profiles are disabled." -ForegroundColor Yellow
    } else {
        Write-Host "✅ All queried firewall profiles are enabled." -ForegroundColor DarkGreen
    }
    Pause-Script
}

# --------------------------- Defender Status ---------------------------
function Get-DefenderStatus {
    [CmdletBinding()]
    param()

    $row = $null
    try {
        if (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue) {
            $mp = Get-MpComputerStatus -ErrorAction Stop
            $row = [PSCustomObject]@{
                ComputerName        = $env:COMPUTERNAME
                AMServiceEnabled    = $mp.AMServiceEnabled
                AntispywareEnabled  = $mp.AntispywareEnabled
                AntivirusEnabled    = $mp.AntivirusEnabled
                RealTimeProtection  = $mp.RealTimeProtectionEnabled
                BehaviorMonitor     = $mp.BehaviorMonitorEnabled
                IoavProtection      = $mp.IoavProtectionEnabled
                NISEnabled          = $mp.NISEnabled
                EngineVersion       = $mp.AMEngineVersion
                AntispywareSig      = $mp.AntispywareSignatureVersion
                AntivirusSig        = $mp.AntivirusSignatureVersion
                LastQuickScan       = $mp.LastQuickScanEndTime
                LastFullScan        = $mp.LastFullScanEndTime
            }
        } else {
            $row = [PSCustomObject]@{
                ComputerName        = $env:COMPUTERNAME
                AMServiceEnabled    = $null
                AntispywareEnabled  = $null
                AntivirusEnabled    = $null
                RealTimeProtection  = $null
                BehaviorMonitor     = $null
                IoavProtection      = $null
                NISEnabled          = $null
                EngineVersion       = ""
                AntispywareSig      = ""
                AntivirusSig        = ""
                LastQuickScan       = $null
                LastFullScan        = $null
            }
        }
    } catch {
        $row = [PSCustomObject]@{
            ComputerName        = $env:COMPUTERNAME
            AMServiceEnabled    = $false
            AntispywareEnabled  = $false
            AntivirusEnabled    = $false
            RealTimeProtection  = $false
            BehaviorMonitor     = $false
            IoavProtection      = $false
            NISEnabled          = $false
            EngineVersion       = "ERROR"
            AntispywareSig      = "ERROR"
            AntivirusSig        = "ERROR"
            LastQuickScan       = $null
            LastFullScan        = $null
        }
        Write-Host "Defender query failed: $_" -ForegroundColor Yellow
    }
    return ,$row
}

function Invoke-DefenderStatus {
    Show-Header "System Info A - Microsoft Defender Status"
    $row = Get-DefenderStatus
    $outFile = New-ExportPath -Prefix "Defender-Status"
    $row | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    Write-Host "=== Defender Status ===" -ForegroundColor Cyan
    $row | Format-List
    Write-Host ""
    Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green

    if ($row.AntivirusEnabled -eq $true -and $row.RealTimeProtection -eq $true) {
        Write-Host "✅ Defender AV & Real-time protection are enabled." -ForegroundColor DarkGreen
    } else {
        Write-Host "⚠ Defender AV and/or Real-time protection appear disabled." -ForegroundColor Yellow
    }
    Pause-Script
}

# --------------------------- Disk & SMART ---------------------------
function Get-DiskSmartInfo {
    [CmdletBinding()]
    param()

    $rows = New-Object System.Collections.Generic.List[object]

    # WMI MSFT_PhysicalDisk via CIM (Win10/11)
    try {
        $pd = Get-PhysicalDisk -ErrorAction Stop
        foreach ($d in $pd) {
            $rows.Add([PSCustomObject]@{
                ComputerName   = $env:COMPUTERNAME
                Source         = "Get-PhysicalDisk"
                FriendlyName   = $d.FriendlyName
                SerialNumber   = $d.SerialNumber
                MediaType      = [string]$d.MediaType
                SizeGB         = [math]::Round($d.Size/1GB,2)
                HealthStatus   = [string]$d.HealthStatus
                Operational    = ($d.OperationalStatus -join ",")
                Firmware       = $d.FirmwareVersion
                BusType        = [string]$d.BusType
            })
        }
    } catch {
        # Not fatal; continue with other sources
    }

    # WMI: Win32_DiskDrive (basic)
    try {
        $wdd = Get-CimInstance -ClassName Win32_DiskDrive -ErrorAction Stop
        foreach ($d in $wdd) {
            $rows.Add([PSCustomObject]@{
                ComputerName   = $env:COMPUTERNAME
                Source         = "Win32_DiskDrive"
                FriendlyName   = $d.Model
                SerialNumber   = $d.SerialNumber
                MediaType      = $d.MediaType
                SizeGB         = [math]::Round(($d.Size/1GB),2)
                HealthStatus   = ""
                Operational    = ""
                Firmware       = $d.FirmwareRevision
                BusType        = $d.InterfaceType
            })
        }
    } catch { }

    # SMART status (may require admin / supported drivers)
    try {
        $smart = Get-WmiObject -Namespace root\wmi -Class MSStorageDriver_FailurePredictStatus -ErrorAction Stop
        $smart | ForEach-Object {
            $rows.Add([PSCustomObject]@{
                ComputerName   = $env:COMPUTERNAME
                Source         = "SMART-Status"
                FriendlyName   = ""
                SerialNumber   = ""
                MediaType      = ""
                SizeGB         = ""
                HealthStatus   = if ($_.PredictFailure -eq $true) { "Predicted Failure" } else { "OK" }
                Operational    = ""
                Firmware       = ""
                BusType        = ""
            })
        }
    } catch {
        # If SMART WMI not available, skip silently
    }

    if ($rows.Count -eq 0) {
        $rows.Add([PSCustomObject]@{
            ComputerName   = $env:COMPUTERNAME
            Source         = "ERROR"
            FriendlyName   = ""
            SerialNumber   = ""
            MediaType      = ""
            SizeGB         = ""
            HealthStatus   = "No disk data available"
            Operational    = ""
            Firmware       = ""
            BusType        = ""
        })
    }

    return ,$rows
}

function Invoke-DiskSmart {
    Show-Header "System Info A - Disk & SMART"
    $rows = Get-DiskSmartInfo
    $outFile = New-ExportPath -Prefix "DiskSMART"
    $rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $outFile

    Write-Host ""
    Write-Host "=== Disk / SMART Summary ===" -ForegroundColor Cyan
    $rows | Format-Table Source, FriendlyName, SizeGB, HealthStatus, Operational, Firmware, BusType -AutoSize
    Write-Host ""
    Write-Host ("Saved: {0}" -f $outFile) -ForegroundColor Green

    if ($rows | Where-Object { $_.HealthStatus -match 'Predicted Failure' }) {
        Write-Host "⚠ SMART indicates a predicted failure on at least one device." -ForegroundColor Yellow
    }
    Pause-Script
}

# --------------------------- Menu ---------------------------
function Show-SystemInfoA-Menu {
    Clear-Host
    Show-Header "CS Tech Toolbox - System Info A"

    Write-Host ""
    Write-Host " [1] Windows Firewall Status    - Domain / Private / Public profiles"
    Write-Host " [2] Microsoft Defender Status  - AV engine, realtime, signatures"
    Write-Host " [3] Disk & SMART / Health      - PhysicalDisk, Win32_DiskDrive, SMART"
    Write-Host ""
    Write-Host " [Q] Return to Main Menu"
    Write-Host ""

    $choice = Read-Host "Enter choice"
    switch ($choice.Trim().ToUpperInvariant()) {
        '1' { Invoke-FirewallStatus; return $true }
        '2' { Invoke-DefenderStatus; return $true }
        '3' { Invoke-DiskSmart; return $true }
        'Q' { return $false }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
            return $true
        }
    }
}

# Entry point
do {
    $again = Show-SystemInfoA-Menu
} while ($again)
