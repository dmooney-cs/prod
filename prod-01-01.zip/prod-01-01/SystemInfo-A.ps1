# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Tech Toolbox – System Info A                                          ║
# ║ Version: A.4 | Firewall, Defender Status, SMART/Disk Info + ZIP + Cleanup  ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Write-ExportPath {
    param ([string]$Path)
    Write-Host "`n📄 Exported to: $Path" -ForegroundColor Cyan
}

function Check-FirewallStatus {
    Show-Header "Windows Firewall Status"
    $profiles = Get-NetFirewallProfile | Select-Object Name, Enabled, DefaultInboundAction, DefaultOutboundAction
    $outPath = Export-Data -Object $profiles -BaseName "FirewallStatus"
    Write-ExportPath $outPath
    Pause-Script
}

function Check-DefenderStatus {
    Show-Header "Windows Defender Status"
    try {
        $status = Get-MpComputerStatus | Select-Object AMServiceEnabled, RealTimeProtectionEnabled, AntivirusEnabled, AntispywareEnabled, NISEnabled
        $outPath = Export-Data -Object $status -BaseName "DefenderStatus"
        Write-ExportPath $outPath
    } catch {
        Write-Host "❌ Windows Defender not available or not accessible." -ForegroundColor Red
    }
    Pause-Script
}

function Check-DiskSMARTStatus {
    Show-Header "Disk SMART and Health Info"
    $disks = Get-PhysicalDisk | Select-Object DeviceId, MediaType, OperationalStatus, HealthStatus, Size
    $outPath = Export-Data -Object $disks -BaseName "DiskHealth"
    Write-ExportPath $outPath
    Pause-Script
}

function Run-AllChecks {
    Check-FirewallStatus
    Check-DefenderStatus
    Check-DiskSMARTStatus
}

function Show-SystemInfoMenuA {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "       System Info A - Firewall + Defender + Disk"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Check Windows Firewall Status"
    Write-Host " [2] Check Windows Defender Status"
    Write-Host " [3] Check Disk SMART and Health"
    Write-Host " [4] Run All"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results"
    Write-Host " [C] Cleanup Export Folder"
    Write-Host " [Q] Quit"
    Write-Host ""
}

do {
    Show-SystemInfoMenuA
    $choice = Read-Host "Select an option"
    switch ($choice.ToUpper()) {
        '1' { Check-FirewallStatus }
        '2' { Check-DefenderStatus }
        '3' { Check-DiskSMARTStatus }
        '4' { Run-AllChecks }
        'Z' { Invoke-ZipAndEmailResults }
        'C' { Cleanup-ExportFolder }
        'Q' { Pause-Script; return }
        default {
            Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
            Pause-Script
        }
    }
} while ($true)
