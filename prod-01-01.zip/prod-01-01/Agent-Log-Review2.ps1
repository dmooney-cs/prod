# =====================================================================
# agent-msg-correlator.ps1
# ---------------------------------------------------------------------
# - PS 5.1 compatible, ASCII-only
# - Tries Primary (DL1) then Secondary (DL2) download URLs, up to 3x each
# - Compares remote "Last-Modified" vs local LastWriteTime
# - Optional hash verification via separate hash URLs
# - Keeps a local CSV index; deletes/re-downloads if remote newer
# - Scans agent log files for known messages from CSV
# - Shows:
#     * Top 5 most recent severities (with total frequency +
#       "X minutes/hours ago" based on most recent occurrence per severity)
#     * All matched messages (any age) with frequency + "X minutes/hours ago"
#     * Full CSV row for each matched item (all columns) directly in console
# - Asks whether to use default agent log path or a custom folder
# =====================================================================

# -----------------------------
# Configurable Paths & URLs
# -----------------------------
$Global:MsgIndexPrimaryUrl     = 'https://cybercns-my.sharepoint.com/:x:/g/personal/dougm_connectsecure_com/IQAJIr1d3NG3TYiKewwM2oS3AUsRrjB-IwRF5Xi2zlMVuxo'
$Global:MsgIndexSecondaryUrl   = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/cs-message-index.csv'

# Optional hash URLs (plain text SHA256). Leave $null if not used.
$Global:MsgIndexPrimaryHashUrl   = $null
$Global:MsgIndexSecondaryHashUrl = $null

# Local storage root for the message index
$Global:MsgIndexLocalRoot     = 'C:\CS-Toolbox-TEMP\prod-01-01\KnownIssues'
$Global:MsgIndexLocalFileName = 'cs-message-index.csv'

# Default agent log root path
$Global:DefaultAgentLogRoot   = 'C:\Program Files (x86)\CyberCNSAgent\logs'

# -----------------------------
# Script Settings
# -----------------------------
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# -----------------------------
# Helper: Logging
# -----------------------------
function Write-LogInfo {
    param([string]$Message)
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "[INFO]  $ts  $Message"
}

function Write-LogWarn {
    param([string]$Message)
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "[WARN]  $ts  $Message" -ForegroundColor Yellow
}

function Write-LogErrorLine {
    param([string]$Message)
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    Write-Host "[ERROR] $ts  $Message" -ForegroundColor Red
}

# -----------------------------
# Helper: Ensure directory
# -----------------------------
function Ensure-Directory {
    param(
        [Parameter(Mandatory = $true)][string]$Path
    )
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-LogInfo "Creating directory: $Path"
        New-Item -Path $Path -ItemType Directory -Force | Out-Null
    }
}

# -----------------------------
# Helper: Get remote HEAD info
# -----------------------------
function Get-RemoteHeadInfo {
    param(
        [Parameter(Mandatory = $true)][string]$Url
    )
    try {
        $resp = Invoke-WebRequest -Uri $Url -Method Head -UseBasicParsing -ErrorAction Stop

        $lastMod = $null
        if ($resp.Headers['Last-Modified']) {
            try {
                $lastMod = [datetime]$resp.Headers['Last-Modified']
            }
            catch {
                $lastMod = $null
            }
        }

        $len = $null
        if ($resp.Headers['Content-Length']) {
            $len = $resp.Headers['Content-Length']
        }

        return [pscustomobject]@{
            Url           = $Url
            LastModified  = $lastMod
            ContentLength = $len
            Success       = $true
        }
    }
    catch {
        Write-LogWarn "HEAD request failed for $Url : $($_.Exception.Message)"
        return [pscustomobject]@{
            Url           = $Url
            LastModified  = $null
            ContentLength = $null
            Success       = $false
        }
    }
}

# -----------------------------
# Helper: Detect HTML masquerading as CSV
# -----------------------------
function Test-FileLooksLikeHtml {
    param(
        [Parameter(Mandatory = $true)][string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }

    try {
        $lines  = Get-Content -LiteralPath $Path -TotalCount 5 -ErrorAction Stop
        $joined = ($lines -join "`n").TrimStart()

        if ($joined.StartsWith('<!DOCTYPE html', 'OrdinalIgnoreCase')) { return $true }
        if ($joined.StartsWith('<html', 'OrdinalIgnoreCase'))          { return $true }

        return $false
    }
    catch {
        # If we can't read it at all, don't call it HTML; let caller handle errors separately
        return $false
    }
}

# -----------------------------
# Helper: Download with retries
# -----------------------------
function Download-IndexFromSource {
    param(
        [Parameter(Mandatory = $true)][string]$Label,          # "DL1" / "DL2"
        [Parameter(Mandatory = $true)][string]$CsvUrl,
        [string]$HashUrl,
        [Parameter(Mandatory = $true)][string]$TargetPath,
        [DateTime]$LocalLastWriteTime = $null
    )

    Write-Host ''
    Write-Host "------------------------------------------------------------"
    Write-Host "  Checking index from $Label ($CsvUrl)"
    Write-Host "------------------------------------------------------------"

    $headInfo = Get-RemoteHeadInfo -Url $CsvUrl
    if (-not $headInfo.Success) {
        Write-LogWarn "Unable to retrieve remote metadata from $Label."
    }
    elseif ($headInfo.LastModified) {
        Write-LogInfo ("Remote last-modified (UTC): {0:u}" -f $headInfo.LastModified.ToUniversalTime())
        if ($LocalLastWriteTime) {
            Write-LogInfo ("Local index timestamp  : {0:u}" -f $LocalLastWriteTime.ToUniversalTime())
        }
    }

    # Only compare dates if we actually got a Last-Modified header AND we have a local file
    if ($headInfo.LastModified -and $LocalLastWriteTime -and $headInfo.LastModified -le $LocalLastWriteTime) {
        Write-LogInfo "Remote index from $Label is not newer than local copy. Skipping download."
        return [pscustomobject]@{
            Source        = $Label
            Updated       = $false
            LastModified  = $headInfo.LastModified
            Hash          = $null
            Success       = $true
        }
    }

    $attemptMax = 3
    $hashValue  = $null
    $success    = $false

    Ensure-Directory -Path (Split-Path -Parent $TargetPath)

    for ($i = 1; $i -le $attemptMax -and -not $success; $i++) {
        Write-LogInfo "Attempt $i of $attemptMax to download index from $Label..."

        $tmpPath = "$TargetPath.download"
        if (Test-Path -LiteralPath $tmpPath) {
            Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
        }

        try {
            Invoke-WebRequest -Uri $CsvUrl -OutFile $tmpPath -UseBasicParsing -ErrorAction Stop

            # Detect HTML masquerading as CSV (SharePoint/Office viewer case)
            if (Test-FileLooksLikeHtml -Path $tmpPath) {
                Write-LogWarn "Downloaded content from $Label appears to be HTML, not CSV. Discarding and retrying..."
                Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
                continue
            }

            # Regular CSV path: compute hash
            $hashObj   = Get-FileHash -Path $tmpPath -Algorithm SHA256
            $hashValue = $hashObj.Hash
            Write-LogInfo "Downloaded index from $Label. SHA256: $hashValue"

            if ($HashUrl -and $HashUrl.Trim().Length -gt 0) {
                Write-LogInfo "Retrieving expected hash from: $HashUrl"
                try {
                    $expected = (Invoke-WebRequest -Uri $HashUrl -UseBasicParsing -ErrorAction Stop).Content.Trim()
                    Write-LogInfo "Expected SHA256: $expected"
                    if ($expected -and $expected -ne $hashValue) {
                        Write-LogWarn "Hash mismatch on attempt $i from $Label. Retrying..."
                        Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
                        continue
                    }
                }
                catch {
                    Write-LogWarn "Failed to retrieve or read hash from $HashUrl : $($_.Exception.Message)"
                }
            }
            else {
                Write-LogInfo "No remote hash URL configured for $Label; local SHA256 shown for reference only."
            }

            if (Test-Path -LiteralPath $TargetPath) {
                Remove-Item -LiteralPath $TargetPath -Force -ErrorAction SilentlyContinue
            }
            Move-Item -Path $tmpPath -Destination $TargetPath -Force
            Write-LogInfo "Index downloaded and saved to: $TargetPath"
            $success = $true
        }
        catch {
            Write-LogWarn "Download attempt $i from $Label failed: $($_.Exception.Message)"
            if (Test-Path -LiteralPath $tmpPath) {
                Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
            }
        }
    }

    if (-not $success) {
        Write-LogWarn "All attempts to download from $Label failed."
        return [pscustomobject]@{
            Source        = $Label
            Updated       = $false
            LastModified  = $headInfo.LastModified
            Hash          = $hashValue
            Success       = $false
        }
    }

    return [pscustomobject]@{
        Source        = $Label
        Updated       = $true
        LastModified  = $headInfo.LastModified
        Hash          = $hashValue
        Success       = $true
    }
}

# -----------------------------
# Helper: Decide which index to use
# -----------------------------
function Get-LatestMessageIndex {
    param(
        [string]$PrimaryUrl,
        [string]$SecondaryUrl,
        [string]$PrimaryHashUrl,
        [string]$SecondaryHashUrl,
        [string]$LocalRoot,
        [string]$LocalFileName
    )

    Ensure-Directory -Path $LocalRoot
    $localPath = Join-Path $LocalRoot $LocalFileName

    $localExists = Test-Path -LiteralPath $localPath
    $localTime   = $null
    if ($localExists) {
        $localInfo = Get-Item -LiteralPath $localPath
        $localTime = $localInfo.LastWriteTime
        Write-LogInfo ("Local index found: {0}  (LastWriteTime: {1:u})" -f $localPath, $localTime.ToUniversalTime())
    }
    else {
        Write-LogInfo ("No local index found at: {0}" -f $localPath)
    }

    # Try DL1 first
    $primaryResult = $null
    if ($PrimaryUrl -and $PrimaryUrl.Trim().Length -gt 0) {
        $primaryResult = Download-IndexFromSource -Label 'DL1' `
            -CsvUrl $PrimaryUrl `
            -HashUrl $PrimaryHashUrl `
            -TargetPath $localPath `
            -LocalLastWriteTime $localTime
    }

    if ($primaryResult -and $primaryResult.Success) {
        return $localPath
    }

    # Fallback to DL2
    $secondaryResult = $null
    if ($SecondaryUrl -and $SecondaryUrl.Trim().Length -gt 0) {
        $secondaryResult = Download-IndexFromSource -Label 'DL2' `
            -CsvUrl $SecondaryUrl `
            -HashUrl $SecondaryHashUrl `
            -TargetPath $localPath `
            -LocalLastWriteTime $localTime
    }

    if ($secondaryResult -and $secondaryResult.Success) {
        return $localPath
    }

    # If both sources failed, fall back to existing local file if present
    if (Test-Path -LiteralPath $localPath) {
        Write-LogWarn "Using existing local index because remote sources are unavailable."
        return $localPath
    }

    throw "Unable to obtain index file from DL1 or DL2, and no local copy is available."
}

# -----------------------------
# Helper: Extract CSV (if ZIP)
# -----------------------------
function Get-IndexCsvPath {
    param(
        [Parameter(Mandatory = $true)][string]$IndexFilePath
    )

    $ext = [System.IO.Path]::GetExtension($IndexFilePath)
    if ($ext -ieq '.zip') {
        $tempDir = Join-Path ([System.IO.Path]::GetDirectoryName($IndexFilePath)) 'agent-msg-index-unzipped'
        Ensure-Directory -Path $tempDir
        Write-LogInfo "Index appears to be a ZIP. Extracting to: $tempDir"
        Get-ChildItem -LiteralPath $tempDir -File -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Expand-Archive -LiteralPath $IndexFilePath -DestinationPath $tempDir -Force

        $csv = Get-ChildItem -Path $tempDir -Filter *.csv -File -Recurse | Select-Object -First 1
        if (-not $csv) {
            throw "No CSV file found inside index archive: $IndexFilePath"
        }
        Write-LogInfo "Using CSV from archive: $($csv.FullName)"
        return $csv.FullName
    }
    else {
        Write-LogInfo "Index treated as CSV: $IndexFilePath"
        return $IndexFilePath
    }
}

# -----------------------------
# Severity detection from log line (like Agent-Log-Review)
# -----------------------------
$Global:LevelRegex = '(?i)\b(ERROR|FATAL|EXCEPTION|WARN|WARNING|FAIL(?:ED)?|TIMEOUT|ACCESS DENIED|UNAUTHORIZED)\b'

function Get-SeverityFromLine {
    param(
        [string]$Line
    )

    if ([string]::IsNullOrWhiteSpace($Line)) { return 'Unknown' }

    if ($Line -match $Global:LevelRegex) {
        $upper = $Matches[1].ToUpperInvariant()
        switch -Regex ($upper) {
            '^FAIL(ED)?$' { return 'FAIL' }
            default       { return $upper }
        }
    }

    return 'Unknown'
}

# -----------------------------
# Helper: Find CSV column by candidate names
# -----------------------------
function Find-CsvColName {
    param(
        [string[]]$Props,
        [string[]]$Candidates
    )
    foreach ($cand in $Candidates) {
        foreach ($p in $Props) {
            if ($p -and $p.Trim().ToLowerInvariant() -eq $cand.Trim().ToLowerInvariant()) {
                return $p
            }
        }
    }
    return $null
}

# -----------------------------
# Helper: Import Known Issues from CSV
# -----------------------------
function Import-KnownIssuePatterns {
    param(
        [Parameter(Mandatory = $true)][string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Index CSV not found at: $Path"
    }

    Write-LogInfo ("Importing Known Issues from CSV: {0}" -f $Path)

    $rows = @()
    try {
        $rows = Import-Csv -LiteralPath $Path -ErrorAction Stop
    }
    catch {
        throw "Failed to read index CSV: $($_.Exception.Message)"
    }

    if (-not $rows -or @($rows).Count -eq 0) {
        throw "Index CSV is empty: $Path"
    }

    $first     = $rows[0]
    $propNames = @($first.PSObject.Properties.Name)

    $colError = Find-CsvColName -Props $propNames -Candidates @('ERROR','Error','Message','Log Message','LogMessage')

    if (-not $colError) {
        Write-LogWarn "Index CSV does not have a recognizable ERROR / Message column; falling back to first non-empty property per row."
    }
    else {
        Write-LogInfo ("Using column '{0}' as Error/Message source." -f $colError)
    }

    $patterns = New-Object System.Collections.Generic.List[object]

    foreach ($row in $rows) {

        $errorText = $null

        if ($colError) {
            $errorText = [string]$row.$colError
        }

        # Fallback: first non-empty property in the row
        if ([string]::IsNullOrWhiteSpace($errorText)) {
            foreach ($p in $row.PSObject.Properties) {
                $s = [string]$p.Value
                if (-not [string]::IsNullOrWhiteSpace($s)) {
                    $errorText = $s
                    break
                }
            }
        }

        if ([string]::IsNullOrWhiteSpace($errorText)) { continue }

        $errorText = $errorText.Trim()

        # Skip very short tokens that cause massive false positives
        if ($errorText.Length -lt 5) { continue }

        $patterns.Add([pscustomobject]@{
            CsvRow    = $row
            ErrorText = $errorText
        })
    }

    if ($patterns.Count -eq 0) {
        throw "No usable error patterns could be derived from the index CSV."
    }

    Write-LogInfo ("Prepared {0} error pattern(s) from index." -f $patterns.Count)
    return @($patterns)
}

# -----------------------------
# Helper: Parse timestamp from a log line
# -----------------------------
function Get-LogLineTimestamp {
    param(
        [Parameter(Mandatory = $true)][string]$Line
    )

    $regex1 = '(\d{4}-\d{2}-\d{2}[\sT]\d{2}:\d{2}:\d{2})'
    $m1 = [regex]::Match($Line, $regex1)
    if ($m1.Success) {
        $dtStr = $m1.Groups[1].Value
        try {
            $dt = [datetime]$dtStr
            return $dt
        }
        catch { }
    }

    $regex2 = '(\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}:\d{2}\s*(AM|PM)?)'
    $m2 = [regex]::Match($Line, $regex2)
    if ($m2.Success) {
        $dtStr2 = $m2.Groups[1].Value
        try {
            $dt2 = [datetime]$dtStr2
            return $dt2
        }
        catch { }
    }

    if ($Line.Length -ge 19) {
        $front = $Line.Substring(0, 19)
        try {
            $dt3 = [datetime]$front
            return $dt3
        }
        catch { }
    }

    return $null
}

# -----------------------------
# Helper: Format "X minutes/hours ago"
# -----------------------------
function Format-TimeAgo {
    param(
        [Parameter(Mandatory = $true)][DateTime]$LastTime,
        [Parameter(Mandatory = $true)][DateTime]$Now
    )

    $span = $Now - $LastTime
    if ($span.TotalMinutes -lt 120) {
        $mins = [int][Math]::Round($span.TotalMinutes)
        if ($mins -le 1) { return "1 minute ago" }
        return "$mins minutes ago"
    }
    else {
        $hours = [int][Math]::Round($span.TotalHours)
        if ($hours -le 1) { return "1 hour ago" }
        return "$hours hours ago"
    }
}

# -----------------------------
# Helper: Choose log root
# -----------------------------
function Get-AgentLogRootPath {
    param(
        [string]$DefaultRoot
    )

    Write-Host ''
    Write-Host '============================================================'
    Write-Host '  Agent Message Correlator - Log Root Selection'
    Write-Host '============================================================'
    Write-Host ''
    Write-Host ("Default agent log path: {0}" -f $DefaultRoot)
    Write-Host ''

    $useDefault = $true
    $answer = Read-Host "Use default agent log path? (Y = default / N = specify another folder)"
    if ($answer -and $answer.Trim().ToUpper() -eq 'N') {
        $useDefault = $false
    }

    if ($useDefault) {
        $root = $DefaultRoot
    }
    else {
        $root = Read-Host "Enter the full folder path to scan for agent logs"
    }

    if (-not (Test-Path -LiteralPath $root)) {
        throw "The specified log root path does not exist: $root"
    }

    Write-LogInfo ("Using agent log root: {0}" -f $root)
    return $root
}

# -----------------------------
# Helper: Show full CSV row
# -----------------------------
function Show-CsvRowDetails {
    param(
        [Parameter(Mandatory = $true)][psobject]$Row
    )

    foreach ($prop in $Row.PSObject.Properties) {
        $name  = $prop.Name
        $value = $prop.Value
        if ($null -eq $value) {
            $value = ''
        }
        Write-Host ("  {0}: {1}" -f $name, $value)
    }
}

# -----------------------------
# MAIN
# -----------------------------
Write-Host '============================================================'
Write-Host '  Agent Message Correlator'
Write-Host '============================================================'
Write-Host ''
$now = Get-Date
Write-LogInfo ("Local machine time: {0:u}" -f $now.ToUniversalTime())
Write-Host ''

try {
    # 1. Get latest index file (DL1 -> DL2 -> local fallback)
    $indexFile = Get-LatestMessageIndex `
        -PrimaryUrl $Global:MsgIndexPrimaryUrl `
        -SecondaryUrl $Global:MsgIndexSecondaryUrl `
        -PrimaryHashUrl $Global:MsgIndexPrimaryHashUrl `
        -SecondaryHashUrl $Global:MsgIndexSecondaryHashUrl `
        -LocalRoot $Global:MsgIndexLocalRoot `
        -LocalFileName $Global:MsgIndexLocalFileName

    Write-Host ''
    Write-Host "------------------------------------------------------------"
    Write-Host "  Index Ready"
    Write-Host "------------------------------------------------------------"
    Write-LogInfo ("Using index file: {0}" -f $indexFile)

    # 2. Get CSV path (handle ZIP vs CSV)
    $csvPath = Get-IndexCsvPath -IndexFilePath $indexFile
    Write-LogInfo ("Importing CSV from: {0}" -f $csvPath)

    # 3. Import known-issue patterns with proper ERROR column detection
    $patternEntries = Import-KnownIssuePatterns -Path $csvPath

    # 4. Confirm log root path (default vs custom)
    $logRoot = Get-AgentLogRootPath -DefaultRoot $Global:DefaultAgentLogRoot
    Write-Host ''
    Write-Host "------------------------------------------------------------"
    Write-Host "  Scanning Agent Log Files"
    Write-Host "------------------------------------------------------------"
    Write-LogInfo ("Enumerating *.log files under: {0}" -f $logRoot)

    $logFiles = Get-ChildItem -Path $logRoot -Filter *.log -File -Recurse -ErrorAction SilentlyContinue
    if (-not $logFiles -or $logFiles.Count -eq 0) {
        throw "No *.log files found under: $logRoot"
    }

    Write-LogInfo ("Found {0} log file(s)." -f $logFiles.Count)

    # 5. Correlate patterns against logs
    Write-Host ''
    Write-Host "------------------------------------------------------------"
    Write-Host "  Correlating Known Messages Against Agent Logs"
    Write-Host "------------------------------------------------------------"

    $matchesSummary = @()

    foreach ($entry in $patternEntries) {
        $pattern = $entry.ErrorText
        if (-not $pattern -or $pattern.Trim().Length -eq 0) {
            continue
        }

        $matches = Select-String -Path ($logFiles.FullName) -SimpleMatch -Pattern $pattern -ErrorAction SilentlyContinue
        if (-not $matches) {
            continue
        }

        $count          = $matches.Count
        $lastSeen       = $null
        $severityCounts = @{}

        foreach ($m in $matches) {
            $line = $m.Line
            $sev  = Get-SeverityFromLine -Line $line

            if (-not $severityCounts.ContainsKey($sev)) {
                $severityCounts[$sev] = 0
            }
            $severityCounts[$sev]++

            $ts = Get-LogLineTimestamp -Line $line
            if ($ts -and (-not $lastSeen -or $ts -gt $lastSeen)) {
                $lastSeen = $ts
            }
        }

        $timeAgo = if ($lastSeen) { Format-TimeAgo -LastTime $lastSeen -Now $now } else { 'N/A' }

        # Choose primary severity for this pattern (highest priority)
        $sevOrder = @('FATAL','ERROR','EXCEPTION','FAIL','TIMEOUT','UNAUTHORIZED','ACCESS DENIED','WARN','WARNING','Unknown')
        $primarySeverity = 'Unknown'
        foreach ($s in $sevOrder) {
            if ($severityCounts.ContainsKey($s) -and $severityCounts[$s] -gt 0) {
                $primarySeverity = $s
                break
            }
        }

        $matchesSummary += [pscustomobject]@{
            Severity          = $primarySeverity
            SeverityBreakdown = $severityCounts
            Message           = $pattern
            CsvRow            = $entry.CsvRow
            Frequency         = $count
            LastSeen          = $lastSeen
            LastSeenAgo       = $timeAgo
        }
    }

    if (-not $matchesSummary -or $matchesSummary.Count -eq 0) {
        Write-Host ''
        Write-Host "------------------------------------------------------------"
        Write-Host "  No matches from the index were found in the agent logs."
        Write-Host "------------------------------------------------------------"
        return
    }

    # 6. Top 5 most recent severities
    Write-Host ''
    Write-Host '============================================================'
    Write-Host '  Top 5 Most Recent Severities (with Total Frequency)'
    Write-Host '============================================================'
    Write-Host ''

    $severityAgg = $matchesSummary |
        Where-Object { $_.LastSeen -ne $null } |
        Group-Object -Property Severity |
        ForEach-Object {
            $sev   = $_.Name
            $items = $_.Group
            $totalFreq = ($items | Measure-Object -Property Frequency -Sum).Sum
            $lastItem  = $items |
                Where-Object { $_.LastSeen -ne $null } |
                Sort-Object -Property LastSeen -Descending |
                Select-Object -First 1

            [pscustomobject]@{
                Severity       = $sev
                TotalFrequency = $totalFreq
                LastSeen       = $lastItem.LastSeen
                LastSeenAgo    = $lastItem.LastSeenAgo
            }
        } |
        Sort-Object -Property LastSeen -Descending

    if ($severityAgg) {
        $severityAgg |
            Select-Object -First 5 |
            Select-Object Severity,
                          @{Name='TotalFrequency'; Expression = { $_.TotalFrequency }},
                          @{Name='LastSeen';        Expression = { if ($_.LastSeen) { $_.LastSeen.ToString('yyyy-MM-dd HH:mm:ss') } else { '' } }},
                          LastSeenAgo |
            Format-Table -AutoSize
    }
    else {
        Write-Host "No recent (timestamped) matches found."
    }

    # 7. All matches (any age) with frequency + "X minutes/hours ago"
    Write-Host ''
    Write-Host '============================================================'
    Write-Host '  All Matched Messages (Any Age) with Frequency'
    Write-Host '============================================================'
    Write-Host ''

    $allSorted = $matchesSummary |
        Sort-Object -Property @{Expression='Frequency';Descending=$true},
                               @{Expression='LastSeen';Descending=$true}

    $allSorted |
        Select-Object Severity, Frequency,
                      @{Name='LastSeen';   Expression={ if ($_.LastSeen) { $_.LastSeen.ToString('yyyy-MM-dd HH:mm:ss') } else { '' } }},
                      @{Name='LastSeenAgo';Expression={ $_.LastSeenAgo }},
                      @{Name='Message';    Expression={ $_.Message }} |
        Format-Table -AutoSize

    # 8. Show full CSV row details for each matched item
    Write-Host ''
    Write-Host '============================================================'
    Write-Host '  Detailed CSV Rows for Each Matched Message'
    Write-Host '============================================================'
    Write-Host ''

    $indexCounter = 0
    foreach ($item in $allSorted) {
        $indexCounter++
        $lastSeenText = if ($item.LastSeen) {
            $item.LastSeen.ToString('yyyy-MM-dd HH:mm:ss')
        }
        else {
            'N/A'
        }

        Write-Host '------------------------------------------------------------'
        Write-Host ("Match #{0}" -f $indexCounter)
        Write-Host '------------------------------------------------------------'
        Write-Host ("Severity     : {0}" -f $item.Severity)
        Write-Host ("Frequency    : {0}" -f $item.Frequency)
        Write-Host ("LastSeen     : {0}" -f $lastSeenText)
        Write-Host ("LastSeenAgo  : {0}" -f $item.LastSeenAgo)
        Write-Host ("Message Text : {0}" -f $item.Message)
        Write-Host ''
        Write-Host 'CSV Row Columns:'
        Show-CsvRowDetails -Row $item.CsvRow
        Write-Host ''
    }

    Write-Host ''
    Write-Host '============================================================'
    Write-Host '  Correlation Complete'
    Write-Host '============================================================'
}
catch {
    Write-LogErrorLine "Agent Message Correlator encountered an error: $($_.Exception.Message)"
    Write-Host ''
    Write-Host 'Press Enter to exit...'
    [void][System.Console]::ReadLine()
}
