#requires -version 5.1

[CmdletBinding()]
param(
    [string]$OutPath = $null,
    [switch]$Quiet,
    [switch]$ExportOnly
)

# If -ExportOnly is supplied, force quiet output (still writes JSON).
if ($ExportOnly) { $Quiet = $true }

# Reduce non-essential console output when quiet
if ($Quiet) {
    $WarningPreference     = 'SilentlyContinue'
    $InformationPreference = 'SilentlyContinue'
}


# ---- Standard output directory bootstrap----
$CS_OutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\AD'
New-Item -Path $CS_OutRoot -ItemType Directory -Force -ErrorAction Stop | Out-Null

if ([string]::IsNullOrWhiteSpace($OutPath)) {
    $OutPath = Join-Path $CS_OutRoot 'AD-Users_data.json'
}

# Ensure the parent folder of the final path exists (covers custom -OutPath values too)
$__parent = Split-Path -Parent $OutPath
if ($__parent) { New-Item -Path $__parent -ItemType Directory -Force -ErrorAction Stop | Out-Null }
# ---- end standard block ----

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

function Write-ResultJson {
    param([hashtable]$Payload, [string]$Path)

    $dir = Split-Path -Path $Path -Parent
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

    $Payload | ConvertTo-Json -Depth 10 -Compress |
        Out-File -FilePath $Path -Encoding UTF8

    try { $resolved = (Resolve-Path -Path $Path).Path } catch { $resolved = $Path }
    if (-not $Quiet) { Write-Host "" }
    if (-not $Quiet) { Write-Host "JSON saved to: $resolved" -ForegroundColor Cyan }
}

function HandleString($value) {
    if ($null -eq $value) { return "-" }
    return ($value -replace '"','\"')
}

function Get-PasswordExpireDate($user){
    try {
        if ($null -eq $user) { return "-" }
        $cmp = $user.'msDS-UserPasswordExpiryTimeComputed'
        if ($user.Enabled -and -not $user.PasswordNeverExpires -and $cmp -gt 0) {
            try { return ([datetime]::FromFileTime($cmp)).ToString('dd-MM-yyyy HH:mm:ss') } catch { return "-" }
        } else {
            return "-"
        }
    } catch { return "-" }
}

try {
    try { Import-Module ActiveDirectory -ErrorAction Stop } catch { throw "ActiveDirectory module not found. Install RSAT/AD tools." }

    # Domain/forest context for header
    $domain = (Get-ADDomain).DNSRoot
    $forest = (Get-ADForest).Name

    # Build admin membership sets
    $domainAdmins = @()
    try {
        foreach ($m in Get-ADGroupMember -Identity 'Domain Admins' -Recursive | Select-Object -ExpandProperty SamAccountName) {
            $domainAdmins += $m
        }
    } catch {
        try {
            $daSid = (Get-ADDomain).DomainSID.Value + '-512'
            foreach ($m in Get-ADGroupMember -Identity $daSid -Recursive | Select-Object -ExpandProperty SamAccountName) {
                $domainAdmins += $m
            }
        } catch { }
    }

    $enterpriseAdmins = @()
    try {
        foreach ($m in Get-ADGroupMember -Identity 'Enterprise Admins' -Recursive | Select-Object -ExpandProperty SamAccountName) {
            $enterpriseAdmins += $m
        }
    } catch { }

    $properties = @(
        'LockedOut','EmailAddress','Department','BadLogonCount','PasswordNeverExpires','PasswordExpired',
        'isCriticalSystemObject','PasswordNotRequired','CannotChangePassword','PasswordLastSet',
        'msDS-UserPasswordExpiryTimeComputed','Created','Modified','LogonCount','Enabled',
        'AccountExpirationDate','accountExpires','LastLogonTimestamp','LastLogonDate','MemberOf',
        'Office','DisplayName','SID','AccountLockoutTime','LastBadPasswordAttempt','DistinguishedName',
        'HomeDrive','description','HomeDirectory','City','Country','ObjectGUID','UserPrincipalName','Name','SamAccountName'
    )

    $adUsers = foreach ($user in Get-ADUser -Filter '*' -Properties $properties) {
        if ($null -eq $user) { continue }

        # Dates (safe formatting)
        $llt = "-"
        if (($null -ne $user.LastLogonTimestamp) -and ($user.LastLogonTimestamp -ne 0)) {
            $llt = [datetime]::FromFileTime($user.LastLogonTimestamp).ToString('dd-MM-yyyy HH:mm:ss')
        }
        $lld = if ($null -eq $user.LastLogonDate -or $user.LastLogonDate -eq "") { "-" } else { $user.LastLogonDate.ToString('dd-MM-yyyy HH:mm:ss') }
        $badp = if ($null -eq $user.LastBadPasswordAttempt) { "-" } else { $user.LastBadPasswordAttempt.ToString('dd-MM-yyyy HH:mm:ss') }
        $pls  = if ($null -eq $user.PasswordLastSet -or $user.PasswordLastSet -eq "") { "-" } else { $user.PasswordLastSet.ToString('dd-MM-yyyy HH:mm:ss') }
        $crt  = if ($null -eq $user.Created) { "-" } else { $user.Created.ToString('dd-MM-yyyy HH:mm:ss') }
        $mod  = if ($null -eq $user.Modified) { "-" } else { $user.Modified.ToString('dd-MM-yyyy HH:mm:ss') }
        $accExp = if ($user.accountExpires -gt 0 -and $user.accountExpires -ne 9223372036854775807) {
            [datetime]::FromFileTime($user.accountExpires).ToString('dd-MM-yyyy HH:mm:ss')
        } else { 'Never Expires' }

        [pscustomobject][ordered]@{
            name                    = HandleString $user.Name
            samaccountname          = HandleString $user.SamAccountName
            userprincipalname       = HandleString $user.UserPrincipalName
            domain                  = $domain
            office                  = HandleString $user.Office
            lockout                 = $user.LockedOut
            accountLockoutTime      = if ($null -eq $user.AccountLockoutTime) { "-" } else { $user.AccountLockoutTime.ToString('dd-MM-yyyy HH:mm:ss') }
            objectsid               = HandleString $user.SID
            mail                    = HandleString $user.EmailAddress
            department              = HandleString $user.Department
            bad_logon_count         = $user.BadLogonCount
            objectguid              = HandleString $user.ObjectGUID
            lastlogontimestamppshell= $llt
            lastLogonDate           = $lld
            badpassword             = $badp
            password_never_expires  = $user.PasswordNeverExpires
            is_critical_system_object = [bool]$user.isCriticalSystemObject
            password_expired        = $user.PasswordExpired
            password_not_required   = $user.PasswordNotRequired
            cannot_change_password  = $user.CannotChangePassword
            pwdlastsettime          = $pls
            password_expiry_date    = Get-PasswordExpireDate $user
            logonCount              = $user.LogonCount
            createdwhen             = $crt
            modifiedwhen            = $mod
            account_expire_date     = $accExp
            account_disabled        = -not $user.Enabled
            memberOf                = @($user.MemberOf | Where-Object { $_ } | ForEach-Object { HandleString $_ })
            displayName             = HandleString $user.DisplayName
            distinguishedname       = HandleString $user.DistinguishedName
            domainAdmin             = ($domainAdmins -contains $user.SamAccountName)
            enterpriseAdmin         = ($enterpriseAdmins -contains $user.SamAccountName)
            buildInAdmin            = ($user.Name -eq 'Administrator')
            homeDrive               = HandleString $user.HomeDrive
            homeDirectory           = HandleString $user.HomeDirectory
            description             = HandleString $user.Description
            city                    = HandleString $user.City
            country                 = HandleString $user.Country
        }
    }

    $count = ($adUsers | Measure-Object).Count

    # On-screen summary + compact, readable table
    if (-not $Quiet) { Write-Host "" }
    if (-not $Quiet) { Write-Host ("Discovered {0} user account(s)  |  Domain: {1}  |  Forest: {2}" -f $count, $domain, $forest) -ForegroundColor Green }

    if (-not $Quiet) {
        $adUsers |
        Select-Object name, samaccountname, account_disabled, lastLogonDate, pwdlastsettime, password_expiry_date, domainAdmin, enterpriseAdmin, distinguishedname |
        Sort-Object account_disabled, name |
        Format-Table -Wrap -AutoSize
    }

    # Persist and echo path
    $payloadOk = @{
        status = $true
        domain = $domain
        forest = $forest
        count  = $count
        data   = $adUsers
    }
    Write-ResultJson -Payload $payloadOk -Path $OutPath
}
catch {
    $err = $_
    if (-not $Quiet) { Write-Warning $err.Exception.Message }

    $payloadFail = @{
        status     = $false
        msg        = $err.Exception.Message
        stackTrace = ($err | Out-String)
    }

    try {
        Write-ResultJson -Payload $payloadFail -Path $OutPath
    } catch {
        if (-not $Quiet) { Write-Host "" }
        if (-not $Quiet) { Write-Host "Failed to write JSON to: $OutPath" -ForegroundColor Red }
        if (-not $Quiet) { Write-Host ($payloadFail | ConvertTo-Json -Depth 5) -ForegroundColor Yellow }
    }
}