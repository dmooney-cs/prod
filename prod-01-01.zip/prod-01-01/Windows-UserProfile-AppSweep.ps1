﻿# Windows-UserProfile-AppSweep.ps1
# User Profile App Folder Sweep (Legacy)
# Progress, ETA, summary, interactive paging (10 at a time), path wrapping, ASCII-safe

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Continue'

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info'

# ---------------- Bootstrap shared helpers ----------------
if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ---------------- Safety shims ----------------
if (-not (Get-Command Write-SessionSummary -ErrorAction SilentlyContinue)) {
    function Write-SessionSummary {
        param([string]$Notes)
        if ($Notes) { Write-Host "[SESSION] $Notes" -ForegroundColor DarkGray }
    }
}

if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
    function Show-Header {
        param([string]$Title = "ConnectSecure Technicians Toolbox")
        Write-Host ""
        Write-Host $Title -ForegroundColor Cyan
        Write-Host ("=" * [Math]::Max($Title.Length, 30)) -ForegroundColor Cyan
        Write-Host ""
    }
}

if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        param([Alias('Path')][string]$Base = 'C:\CS-Toolbox-TEMP\Collected-Info')
        try {
            if (-not (Test-Path $Base)) { New-Item -ItemType Directory -Path $Base | Out-Null }
        } catch {}
    }
}

function Invoke-EnsureExportFolder {
    param([string]$Root = $ExportRoot)
    $cmd = Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue
    if ($cmd) {
        try {
            if     ($cmd.Parameters.ContainsKey('Path')) { Ensure-ExportFolder -Path $Root }
            elseif ($cmd.Parameters.ContainsKey('Base')) { Ensure-ExportFolder -Base $Root }
            else {
                try { Ensure-ExportFolder $Root } catch {}
                if (-not (Test-Path $Root)) { New-Item -ItemType Directory -Path $Root | Out-Null }
            }
        } catch {
            if (-not (Test-Path $Root)) { New-Item -ItemType Directory -Path $Root | Out-Null }
        }
    } else {
        if (-not (Test-Path $Root)) { New-Item -ItemType Directory -Path $Root | Out-Null }
    }
}
Invoke-EnsureExportFolder -Root $ExportRoot

# ---------------- Helpers ----------------
function FormatETA([TimeSpan]$remaining) {
    if ($remaining.TotalSeconds -lt 1) { return "now" }
    if ($remaining.TotalMinutes -lt 1) { return ("{0:N0}s" -f [Math]::Ceiling($remaining.TotalSeconds)) }
    if ($remaining.TotalHours  -lt 1)  { return ("{0:N0}m {1:N0}s" -f [Math]::Floor($remaining.TotalMinutes), [Math]::Ceiling($remaining.Seconds)) }
    return ("{0:N0}h {1:N0}m" -f [Math]::Floor($remaining.TotalHours), [Math]::Round($remaining.Minutes))
}

function Wrap-Path([string]$text, [int]$width, [int]$indent = 0) {
    if (-not $text) { return @("") }
    $segments  = @()
    $remaining = $text
    while ($remaining.Length -gt $width) {
        $segments += $remaining.Substring(0, $width)
        $remaining = $remaining.Substring($width)
    }
    $segments += $remaining
    if ($indent -gt 0 -and $segments.Count -gt 1) {
        for ($i = 1; $i -lt $segments.Count; $i++) {
            $segments[$i] = (" " * $indent) + $segments[$i]
        }
    }
    return $segments
}

function Show-ResultsHeader {
    Write-Host ""
    Write-Host ("{0,-20}  {1,-35}  {2,-15}  {3,-20}  {4}" -f "ProfileName","Application","Version","Publisher","FilePath") -ForegroundColor Cyan
    Write-Host ("{0}" -f ("-" * 120)) -ForegroundColor Cyan
}

function Show-ResultsRows($rows) {
    foreach ($r in $rows) {
        $pname = if ($r.ProfileName) { $r.ProfileName.Substring(0, [Math]::Min($r.ProfileName.Length,20)) } else { "" }
        $app   = if ($r.Application) { $r.Application.Substring(0, [Math]::Min($r.Application.Length,35)) } else { "" }
        $ver   = if ($r.Version)    { $r.Version.Substring(0, [Math]::Min($r.Version.Length,15)) } else { "" }
        $pub   = if ($r.Publisher)  { $r.Publisher.Substring(0, [Math]::Min($r.Publisher.Length,20)) } else { "" }

        # FORCE array so .Count is always valid
        $pathLines = @(Wrap-Path $r.FilePath 80)
        $firstPath = $pathLines[0]

        # First line: all columns
        Write-Host ("{0,-20}  {1,-35}  {2,-15}  {3,-20}  {4}" -f $pname, $app, $ver, $pub, $firstPath)

        # Additional lines: only path, aligned under FilePath column
        if ($pathLines.Count -gt 1) {
            for ($i = 1; $i -lt $pathLines.Count; $i++) {
                Write-Host ("{0,-20}  {1,-35}  {2,-15}  {3,-20}  {4}" -f "", "", "", "", $pathLines[$i])
            }
        }
    }
}

function Show-PagedResults($items, [int]$PageSize = 10) {
    $total = $items.Count
    if ($total -eq 0) {
        Write-Host "No results to display." -ForegroundColor Yellow
        return
    }

    $index = 0
    Show-ResultsHeader
    while ($index -lt $total) {
        $take  = [Math]::Min($PageSize, $total - $index)
        $slice = $items[$index..($index + $take - 1)]
        Show-ResultsRows -rows $slice
        $index += $take

        if ($index -ge $total) {
            Write-Host ""
            Write-Host ("End of results ({0} total)." -f $total) -ForegroundColor DarkGray
            break
        }

        $remaining = $total - $index
        $prompt = ("Showing {0}/{1}. N=next {2}, A=all remaining ({3}), Q=stop [default: N]" -f $index, $total, $PageSize, $remaining)
        $choice = Read-Host $prompt
        if ([string]::IsNullOrWhiteSpace($choice)) {
            $choice = "N"
        } else {
            $choice = $choice.Trim().ToUpperInvariant()
        }

        switch ($choice) {
            "N" { continue }
            "A" {
                Show-ResultsRows -rows $items[$index..($total-1)]
                Write-Host ""
                Write-Host ("End of results ({0} total)." -f $total) -ForegroundColor DarkGray
                break
            }
            "Q" {
                Write-Host "(stopped listing early)" -ForegroundColor DarkGray
                break
            }
            default { continue }
        }
    }
}

# ---------------- Main ----------------
function Run-UserProfileFolderSweep {
    Show-Header -Title "User Profile App Folder Sweep (Legacy)"

    Write-Host "This scan will:" -ForegroundColor Cyan
    Write-Host " - Enumerate ALL local user profiles (loaded + stale)"
    Write-Host " - Search under AppData\Local (skipping Temp) for .exe files (no limit)"
    Write-Host " - Read file ProductName/Version from EXE metadata (portable/user-space installs)"
    Write-Host " - Export results to CSV and JSON in Collected-Info\UserProfiles"
    Write-Host ""
    $resp = Read-Host "Press ENTER to start the scan, or type Q to cancel"
    if ($resp -and $resp.Trim().ToLower() -eq 'q') {
        Write-Host "Scan cancelled by user." -ForegroundColor Yellow
        return
    }

    # Export setup
    $exportDir = Join-Path $ExportRoot "UserProfiles"
    if (-not (Test-Path $exportDir)) { New-Item -ItemType Directory -Path $exportDir | Out-Null }
    $ts       = Get-Date -Format "yyyyMMdd_HHmmss"
    $compName = $env:COMPUTERNAME
    $csvPath  = Join-Path $exportDir "UserProfile-FolderSweep_${compName}_${ts}.csv"
    $jsonPath = Join-Path $exportDir "UserProfile-FolderSweep_${compName}_${ts}.json"

    $results = @()
    $warns   = @()

    # Enumerate profiles safely
    try {
        $profiles = @(Get-CimInstance Win32_UserProfile | Where-Object { $_.LocalPath -and -not $_.Special })
    } catch {
        $warns += "Could not enumerate Win32_UserProfile: $($_.Exception.Message)"
        $profiles = @()
    }
    if ($profiles.Count -eq 0) {
        Write-Host "No user profiles found." -ForegroundColor Yellow
    }

    # Build directory worklist
    $globalWork = New-Object System.Collections.Generic.List[pscustomobject]
    foreach ($p in $profiles) {
        try {
            $profilePath = $p.LocalPath
            $profileName = Split-Path $profilePath -Leaf
            $localRoot   = Join-Path $profilePath 'AppData\Local'
            if (-not (Test-Path -LiteralPath $localRoot)) { continue }

            $dirs = @()
            try {
                $dirs = @(Get-ChildItem -LiteralPath $localRoot -Directory -Recurse -ErrorAction SilentlyContinue |
                          Where-Object { $_.FullName -notmatch '\\Temp\\' })
            } catch {}
            if ($localRoot -notmatch '\\Temp\\') {
                try { $dirs = ,(Get-Item -LiteralPath $localRoot) + $dirs } catch {}
            }

            foreach ($d in $dirs) {
                $globalWork.Add([pscustomobject]@{
                    ProfileName = $profileName
                    ProfilePath = $profilePath
                    Dir         = $d.FullName
                    SID         = $p.SID
                    LastUseTime = $p.LastUseTime
                })
            }
        } catch {
            $warns += "Failed to prepare list for $($p.SID): $($_.Exception.Message)"
        }
    }

    $totalDirs       = $globalWork.Count
    $scanStart       = Get-Date
    $perProfileFinds = @{}

    if ($totalDirs -eq 0) {
        Write-Host "No AppData\Local folders to scan." -ForegroundColor Yellow
    }

    # Scan loop with progress + ETA
    $i = 0
    foreach ($item in $globalWork) {
        $i++
        $profileName = $item.ProfileName
        $profilePath = $item.ProfilePath
        $dirPath     = $item.Dir
        $sid         = $item.SID

        $lastUse = $null
        if ($item.LastUseTime) {
            try { $lastUse = [Management.ManagementDateTimeConverter]::ToDateTime($item.LastUseTime) } catch {}
        }
        $isStale = $false
        if ($lastUse) { $isStale = ($lastUse -lt (Get-Date).AddDays(-30)) }

        # Scan .exe in directory (non-recursive)
        $exeList = @()
        try {
            $exeList = Get-ChildItem -LiteralPath $dirPath -File -Filter *.exe -ErrorAction SilentlyContinue
        } catch {
            $warns += "Enumeration failed under $dirPath for $profileName ($sid): $($_.Exception.Message)"
        }

        foreach ($exe in $exeList) {
            $vi = $null
            try { $vi = (Get-Item $exe.FullName).VersionInfo } catch {}
            $product   = $vi.ProductName
            $version   = $vi.ProductVersion
            $publisher = $vi.CompanyName
            $displayName = if ($product) { $product } else { [IO.Path]::GetFileNameWithoutExtension($exe.Name) }

            $results += [pscustomobject]@{
                SID             = $sid
                UserName        = $null
                ProfileName     = $profileName
                ProfilePath     = $profilePath
                LastUseTime     = $lastUse
                StaleProfile    = $isStale
                Source          = 'Directory'
                Application     = $displayName
                Version         = $version
                Publisher       = $publisher
                InstallLocation = $exe.DirectoryName
                FilePath        = $exe.FullName
            }
            if (-not $perProfileFinds.ContainsKey($profileName)) { $perProfileFinds[$profileName] = 0 }
            $perProfileFinds[$profileName]++
        }

        # Progress and ETA
        $left    = $totalDirs - $i
        $elapsed = (Get-Date) - $scanStart
        $rate    = if ($elapsed.TotalSeconds -gt 0) { $i / $elapsed.TotalSeconds } else { 0 }
        $etaSpan = if ($rate -gt 0) { [TimeSpan]::FromSeconds([double]$left / $rate) } else { [TimeSpan]::Zero }
        $pct     = if ($totalDirs -gt 0) { [int]([Math]::Round(100 * $i / $totalDirs)) } else { 100 }

        $status  = "Scanning: $profileName | Dir $i of $totalDirs | Left: $left | ETA: $(FormatETA $etaSpan)"
        Write-Progress -Activity "User Profile App Folder Sweep" -Status $status -PercentComplete $pct
        if ($i % 250 -eq 0 -or $i -eq $totalDirs) {
            Write-Host ("[PROGRESS] {0}%  ({1}/{2})   Left: {3}   ETA: {4}" -f $pct, $i, $totalDirs, $left, (FormatETA $etaSpan)) -ForegroundColor DarkCyan
        }
    }
    Write-Progress -Activity "User Profile App Folder Sweep" -Completed

    # Resolve usernames
    $sidGroups = $results | Group-Object SID
    foreach ($g in $sidGroups) {
        $u = $null
        try {
            $u = (New-Object System.Security.Principal.SecurityIdentifier($g.Name)).Translate([System.Security.Principal.NTAccount]).Value
        } catch {}
        foreach ($r in $g.Group) { $r.UserName = $u }
    }

    # De-dupe for exports/display
    $dedup = $results | Sort-Object SID, Application, FilePath -Unique

    # Exports
    try { $dedup | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8 } catch {
        Write-Host "ERROR writing CSV: $($_.Exception.Message)" -ForegroundColor Red
    }
    try { $dedup | ConvertTo-Json -Depth 4 | Out-File -FilePath $jsonPath -Encoding UTF8 } catch {
        Write-Host "ERROR writing JSON: $($_.Exception.Message)" -ForegroundColor Red
    }

    # Summary
    Write-Host ""
    if ($dedup.Count -eq 0) {
        Write-Host "No applications discovered under AppData\Local." -ForegroundColor Yellow
    } else {
        Write-Host ("Discovered {0} application entries (folder-only scan)." -f $dedup.Count) -ForegroundColor Cyan
        Write-Host ""
        Write-Host "Summary by profile:" -ForegroundColor Cyan
        $perProfileFinds.GetEnumerator() | Sort-Object Value -Descending | ForEach-Object {
            "{0,-30}  {1,6}" -f $_.Key, $_.Value
        } | Write-Host
    }

    # Display results interactively
    if ($dedup.Count -gt 0) {
        Write-Host ""
        Write-Host "Results:" -ForegroundColor Green
        $toShow = $dedup | Select-Object ProfileName, Application, Version, Publisher, FilePath
        Show-PagedResults -items $toShow -PageSize 10
    }

    # Warnings and export paths
    if ($warns.Count -gt 0) {
        Write-Host ""
        Write-Host "Warnings:" -ForegroundColor Yellow
        $warns | Select-Object -Unique | ForEach-Object {
            Write-Host (" - {0}" -f $_) -ForegroundColor Yellow
        }
    }

    Write-Host ""
    Write-Host "Exports:" -ForegroundColor Green
    Write-Host " - CSV : $csvPath"
    Write-Host " - JSON: $jsonPath"
    Write-Host ""

    Write-SessionSummary -Notes ("UserProfile Folder Sweep completed. Items: {0}. CSV: {1}" -f $dedup.Count, $csvPath)

    [void](Read-Host "Press ENTER to return to the main menu")
    $launcher = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'
    if (Test-Path -LiteralPath $launcher) {
        try {
            & $launcher
        } catch {
            Write-Host ("ERROR launching {0}: {1}" -f $launcher, $_.Exception.Message) -ForegroundColor Red
        }
    }
}

Run-UserProfileFolderSweep
