# Windows-UserProfile-AppSweep.ps1
# User Profile App Folder Sweep (Legacy) — with safe shims for missing common funcs

# ---------------- Bootstrap shared helpers ----------------
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ---------------- Safety shims (no-ops if common didn't define them) ----------------
if (-not (Get-Command Write-SessionSummary -ErrorAction SilentlyContinue)) {
    function Write-SessionSummary {
        param(
            [string]$Notes
        )
        # Minimal, non-failing fallback: print to console only
        if ($Notes) {
            Write-Host "[SESSION] $Notes" -ForegroundColor DarkGray
        }
    }
}

if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
    function Show-Header {
        param([string]$Title = "ConnectSecure Technicians Toolbox")
        Write-Host ""
        Write-Host $Title -ForegroundColor Cyan
        Write-Host ("=" * [Math]::Max($Title.Length, 30)) -ForegroundColor Cyan
        Write-Host ""
    }
}

# Ensure export folder helper is expected to exist in common; if not, stub it
if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        param(
            [string]$Base = 'C:\CS-Toolbox-TEMP\Collected-Info'
        )
        try { if (-not (Test-Path $Base)) { New-Item -ItemType Directory -Path $Base | Out-Null } } catch { }
    }
}

Ensure-ExportFolder
$ErrorActionPreference = 'Continue'  # don't abort on non-terminating errors

# ---------------- Main ----------------
function Run-UserProfileFolderSweep {
    Show-Header -Title "User Profile App Folder Sweep (Legacy)"

    # --- Explain what will be scanned & confirm ---
    Write-Host "This scan will:" -ForegroundColor Cyan
    Write-Host " • Enumerate ALL local user profiles (loaded + stale)" 
    Write-Host " • Search under AppData\Local (skipping Temp) for .exe files (cap 400 per profile)"
    Write-Host " • Read file ProductName/Version from EXE metadata (portable/user-space installs)"
    Write-Host " • Export results to CSV and JSON in Collected-Info\UserProfiles" 
    Write-Host ""
    $resp = Read-Host "Press ENTER to start the scan, or type Q to cancel"
    if ($resp -and $resp.Trim().ToLower() -eq 'q') {
        Write-Host "Scan cancelled by user." -ForegroundColor Yellow
        return
    }

    # Standardized export dir
    $exportDir = Join-Path "C:\CS-Toolbox-TEMP\Collected-Info" "UserProfiles"
    if (-not (Test-Path $exportDir)) { New-Item -ItemType Directory -Path $exportDir | Out-Null }

    $ts       = Get-Date -Format "yyyyMMdd_HHmmss"
    $compName = $env:COMPUTERNAME
    $csvPath  = Join-Path $exportDir "UserProfile-FolderSweep_${compName}_${ts}.csv"
    $jsonPath = Join-Path $exportDir "UserProfile-FolderSweep_${compName}_${ts}.json"

    $results = @()
    $warns   = @()

    # Enumerate profiles via CIM, exclude special and null paths
    try {
        $profiles = Get-CimInstance Win32_UserProfile | Where-Object { $_.LocalPath -and -not $_.Special }
    } catch {
        $warns += "Could not enumerate Win32_UserProfile via CIM: $($_.Exception.Message)"
        $profiles = @()
    }

    foreach ($p in $profiles) {
        try {
            $profilePath = $p.LocalPath
            $profileName = Split-Path $profilePath -Leaf

            # Resolve SID and display name (best effort)
            $sid = $p.SID
            $userName = $null
            try {
                $sidObj = New-Object System.Security.Principal.SecurityIdentifier($sid)
                $userName = $sidObj.Translate([System.Security.Principal.NTAccount]).Value
            } catch { $userName = $null }

            # Last use + stale heuristic (30+ days)
            $lastUse = $null
            if ($p.LastUseTime) {
                try { $lastUse = [Management.ManagementDateTimeConverter]::ToDateTime($p.LastUseTime) } catch {}
            }
            $isStale = $false
            if ($lastUse) { $isStale = ($lastUse -lt (Get-Date).AddDays(-30)) }

            # AppData\Local root
            $localRoot = Join-Path $profilePath 'AppData\Local'
            if (-not (Test-Path -LiteralPath $localRoot)) {
                $warns += "No AppData\Local for $profileName ($sid)"
                continue
            }

            # Enumerate EXE files (cap for perf; skip Temp)
            $exeList = @()
            try {
                $exeList = Get-ChildItem -LiteralPath $localRoot -Recurse -File -Include *.exe -ErrorAction SilentlyContinue |
                           Where-Object { $_.FullName -notmatch '\\Temp\\' } |
                           Select-Object -First 400
            } catch {
                $warns += "Enumeration failed under $localRoot for $profileName ($sid): $($_.Exception.Message)"
                continue
            }

            foreach ($exe in $exeList) {
                # Pull file version info
                $vi = $null
                try { $vi = (Get-Item $exe.FullName).VersionInfo } catch {}
                $product   = $vi.ProductName
                $version   = $vi.ProductVersion
                $publisher = $vi.CompanyName

                # Name guess: prefer product name; fall back to exe filename (no extension)
                $displayName = if ($product) { $product } else { [IO.Path]::GetFileNameWithoutExtension($exe.Name) }

                $results += [pscustomobject]@{
                    SID             = $sid
                    UserName        = $userName
                    ProfileName     = $profileName
                    ProfilePath     = $profilePath
                    LastUseTime     = $lastUse
                    StaleProfile    = $isStale
                    Source          = 'Directory'
                    Application     = $displayName
                    Version         = $version
                    Publisher       = $publisher
                    InstallLocation = $exe.DirectoryName
                    FilePath        = $exe.FullName
                }
            }
        } catch {
            $warns += "Unhandled error while scanning profile $($p.SID): $($_.Exception.Message)"
        }
    }

    # De-dupe by SID + Application + FilePath
    $dedup = $results | Sort-Object SID, Application, FilePath -Unique

    # Exports
    $csvOk = $true; $jsonOk = $true
    try { $dedup | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8 } catch {
        Write-Host "❌ ERROR writing CSV: $($_.Exception.Message)" -ForegroundColor Red
        $csvOk = $false
    }
    try { $dedup | ConvertTo-Json -Depth 4 | Out-File -FilePath $jsonPath -Encoding UTF8 } catch {
        Write-Host "❌ ERROR writing JSON: $($_.Exception.Message)" -ForegroundColor Red
        $jsonOk = $false
    }

    # Console summary
    Write-Host ""
    if ($dedup.Count -eq 0) {
        Write-Host "No applications discovered under AppData\Local across user profiles." -ForegroundColor Yellow
    } else {
        Write-Host ("Discovered {0} application entries (folder-only scan)." -f $dedup.Count) -ForegroundColor Cyan
    }
    if ($warns.Count -gt 0) {
        Write-Host "Warnings:" -ForegroundColor Yellow
        $warns | Select-Object -Unique | ForEach-Object { Write-Host (" - {0}" -f $_) -ForegroundColor Yellow }
    }
    Write-Host ""
    Write-Host "Exports:" -ForegroundColor Green
    if ($csvOk)  { Write-Host " - CSV : $csvPath" }
    if ($jsonOk) { Write-Host " - JSON: $jsonPath" }
    Write-Host ""

    # Safe even if the real function isn't present (shim above)
    Write-SessionSummary -Notes ("UserProfile Folder Sweep (legacy) completed. Items: {0}. CSV: {1}" -f $dedup.Count, $csvPath)

    # Wait for ENTER before returning to the menu (legacy behavior)
    [void](Read-Host "Press ENTER to return to the main menu")
    $launcher = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Toolbox-Launcher.ps1'
    if (Test-Path -LiteralPath $launcher) {
        try { & $launcher } catch { Write-Host ("ERROR launching {0}: {1}" -f $launcher, $_.Exception.Message) -ForegroundColor Red }
    }
}

Run-UserProfileFolderSweep
