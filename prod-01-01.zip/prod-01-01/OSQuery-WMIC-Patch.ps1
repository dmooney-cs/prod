#requires -version 5.1
#requires -RunAsAdministrator
<#
=======================================================================================
  OSQuery-WMIC-Patch.ps1

  -ExportOnly = absolutely silent (NO banners, NO headers, NO output)
=======================================================================================
#>

param(
    [switch]$ExportOnly
)

# -----------------------------
# Strict + silence
# -----------------------------
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'
$script:ExportOnly     = $ExportOnly

# -----------------------------
# Hard-disable ALL UI when ExportOnly
# -----------------------------
if ($ExportOnly) {
    function Show-Header { }
    function Pause-Script { }
}

# -----------------------------
# Helpers
# -----------------------------
function Ensure-Folder {
    param([string]$Path)
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            New-Item -Path $Path -ItemType Directory -Force | Out-Null
        }
        $true
    } catch {
        $false
    }
}

function Write-TextFile {
    param([string]$Path,[string[]]$Lines)
    ($Lines -join [Environment]::NewLine) |
        Set-Content -LiteralPath $Path -Encoding UTF8
}

# -----------------------------
# DO NOT LOAD Functions-Common in ExportOnly
# -----------------------------
if (-not $ExportOnly) {
    $scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
    $commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
    if (Test-Path -LiteralPath $commonPath) {
        . $commonPath
    }
}

# -----------------------------
# Paths
# -----------------------------
$exportRoot   = 'C:\CS-Toolbox-TEMP\Collected-Info'
$patchOutRoot = Join-Path $exportRoot 'Patches'

if (-not (Ensure-Folder $exportRoot)) { exit 1 }
if (-not (Ensure-Folder $patchOutRoot)) { exit 1 }

# -----------------------------
# Output files
# -----------------------------
$ts      = Get-Date -Format 'yyyyMMdd_HHmmss'
$csvPath = Join-Path $patchOutRoot "WMIC_QFE_$ts.csv"
$txtPath = Join-Path $patchOutRoot "WMIC_QFE_$ts.txt"

# -----------------------------
# WMIC detection
# -----------------------------
$wmic = @(
    "$env:SystemRoot\System32\wbem\wmic.exe",
    "$env:SystemRoot\SysWOW64\wbem\wmic.exe",
    "$env:SystemRoot\Sysnative\wbem\wmic.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1

# -----------------------------
# Collect
# -----------------------------
if ($wmic) {
    $tmpCsv = [IO.Path]::GetTempFileName()
    $tmpTxt = [IO.Path]::GetTempFileName()

    Start-Process $wmic 'qfe list full /format:csv' -NoNewWindow -RedirectStandardOutput $tmpCsv -Wait
    Start-Process $wmic 'qfe list brief'             -NoNewWindow -RedirectStandardOutput $tmpTxt -Wait

    Write-TextFile $csvPath (Get-Content $tmpCsv)
    Write-TextFile $txtPath (Get-Content $tmpTxt)
}
else {
    $all = @()

    try { $all += Get-CimInstance Win32_QuickFixEngineering } catch {}
    try { $all += Get-HotFix } catch {}

    $all |
        Where-Object HotFixID |
        Sort-Object HotFixID -Unique |
        Select-Object HotFixID, InstalledOn, Description |
        Export-Csv $csvPath -NoTypeInformation -Encoding UTF8

    $all | ForEach-Object {
        "{0} {1} {2}" -f $_.HotFixID,$_.InstalledOn,$_.Description
    } | Set-Content $txtPath -Encoding UTF8
}

# -----------------------------
# Render ONLY if interactive
# -----------------------------
if (-not $ExportOnly) {
    Show-Header "Windows Patches (QFE Inventory)"
    Import-Csv $csvPath |
        Sort-Object InstalledOn -Descending |
        Format-Table -AutoSize
    Pause-Script
}

exit 0
