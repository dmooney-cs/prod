# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# =========================
#   OSQuery Data Collection
# =========================

$Global:OsqBinPath = 'C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe'
$Global:OsqOutRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\OSQuery'

function Initialize-OsqOutput {
    if (-not (Test-Path $Global:OsqOutRoot)) {
        New-Item -Path $Global:OsqOutRoot -ItemType Directory | Out-Null
    }
}

function Test-OsqueryPresent {
    if (-not (Test-Path $Global:OsqBinPath)) {
        Write-Host ""
        Write-Host "osqueryi.exe not found:" -ForegroundColor Red
        Write-Host "  $Global:OsqBinPath" -ForegroundColor Yellow
        Write-Host "This tool requires ConnectSecure's osquery installation." -ForegroundColor Yellow
        Pause-Script "Press any key to return to the menu..."
        return $false
    }
    return $true
}

function Invoke-OsqueryJson {
    param(
        [Parameter(Mandatory=$true)][string]$Sql,
        [Parameter(Mandatory=$true)][string]$BaseName
    )
    Initialize-OsqOutput

    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $jsonPath = Join-Path $Global:OsqOutRoot ($BaseName + '_' + $ts + '.json')
    $csvPath  = Join-Path $Global:OsqOutRoot ($BaseName + '_' + $ts + '.csv')

    Write-Host ""
    Write-Host "Running osquery query:" -ForegroundColor Cyan
    Write-Host "  $Sql" -ForegroundColor DarkGray

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName  = $Global:OsqBinPath
    $psi.Arguments = "--json `"$Sql`""
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    [void]$p.Start()

    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    if ($stderr -and $stderr.Trim().Length -gt 0) {
        Write-Host "osquery stderr:" -ForegroundColor Yellow
        Write-Host "  $stderr" -ForegroundColor DarkYellow
    }

    if (-not $stdout) {
        Write-Host "No output received from osquery." -ForegroundColor Red
        return @()
    }

    try { $stdout | Set-Content -LiteralPath $jsonPath -Encoding UTF8 } catch {}

    $objs = @()
    try { $objs = $stdout | ConvertFrom-Json } catch { return @() }

    try {
        if (@($objs).Count -gt 0) {
            $objs | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
            Write-Host ""
            Write-Host "Saved:" -ForegroundColor Green
            Write-Host "  JSON: $jsonPath" -ForegroundColor Green
            Write-Host "  CSV : $csvPath"  -ForegroundColor Green
        } else {
            Write-Host "No rows returned from query." -ForegroundColor DarkCyan
            Write-Host "  JSON saved: $jsonPath" -ForegroundColor DarkCyan
        }
    } catch {}

    return $objs
}

function Run-OsqApplicationsFull {
    if (-not (Test-OsqueryPresent)) { return }
    Show-Header "OSQuery - Applications (Full Inventory)"

$sql = @'
SELECT
  name,
  version,
  publisher,
  install_location,
  install_source,
  uninstall_string,
  install_date
FROM programs
ORDER BY name;
'@

    $objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Applications'
    if (@($objs).Count -gt 0) {
        $objs | Select-Object name, version, publisher | Sort-Object name | Format-Table -AutoSize
    }
    Pause-Script "Press any key to return to the menu..."
}

function Run-OsqApplicationsSearch {
    if (-not (Test-OsqueryPresent)) { return }
    Show-Header "OSQuery - Search Applications"

    $term = Read-Host "Enter name or publisher (partial OK)"
    if (-not $term) {
        Write-Host "No search term entered." -ForegroundColor Yellow
        Pause-Script "Press any key to return to the menu..."
        return
    }

    $like = $term.Replace('[','[[]').Replace('%','[%]').Replace('_','[_]')

$sql = @'
SELECT
  name,
  version,
  publisher,
  install_location,
  uninstall_string,
  install_date
FROM programs
WHERE name LIKE '%LIKE_PLACEHOLDER%' OR publisher LIKE '%LIKE_PLACEHOLDER%'
ORDER BY name;
'@
    $sql = $sql.Replace('LIKE_PLACEHOLDER',$like)

    $objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Applications_Search'
    if (@($objs).Count -gt 0) {
        $objs | Select-Object name, version, publisher | Sort-Object name | Format-Table -AutoSize
    } else {
        Write-Host "No matches." -ForegroundColor Yellow
    }
    Pause-Script "Press any key to return to the menu..."
}

function Run-OsqBrowserExtensions {
    if (-not (Test-OsqueryPresent)) { return }
    Show-Header "OSQuery - Browser Extensions"

    $results = @()

$qEdge = @'
SELECT uid AS user_sid, name, version, description, persistent, path, identifier AS id
FROM edge_extensions;
'@

$qChr = @'
SELECT uid AS user_sid, name, version, description, persistent, path, identifier AS id
FROM chrome_extensions;
'@

$qFf = @'
SELECT uid AS user_sid, name, version, description, '' AS persistent, path, identifier AS id
FROM firefox_addons;
'@

    $edge = Invoke-OsqueryJson -Sql $qEdge -BaseName 'OSQ_Edge_Extensions'
    if ($edge) { $edge | ForEach-Object { $_ | Add-Member -NotePropertyName browser -NotePropertyValue 'Edge' -Force; $results += $_ } }

    $chr  = Invoke-OsqueryJson -Sql $qChr  -BaseName 'OSQ_Chrome_Extensions'
    if ($chr)  { $chr  | ForEach-Object { $_ | Add-Member -NotePropertyName browser -NotePropertyValue 'Chrome' -Force; $results += $_ } }

    $ff   = Invoke-OsqueryJson -Sql $qFf   -BaseName 'OSQ_Firefox_Addons'
    if ($ff)   { $ff   | ForEach-Object { $_ | Add-Member -NotePropertyName browser -NotePropertyValue 'Firefox' -Force; $results += $_ } }

    if (@($results).Count -gt 0) {
        $results | Select-Object browser, name, version, user_sid, id | Sort-Object browser, name | Format-Table -AutoSize
    } else {
        Write-Host "No extensions returned (or osquery tables not available)." -ForegroundColor Yellow
    }
    Pause-Script "Press any key to return to the menu..."
}

function Run-OsqPatchAudit {
    if (-not (Test-OsqueryPresent)) { return }
    Show-Header "OSQuery - Windows Update History (Patch Audit)"

$sql = @'
SELECT * FROM windows_update_history
ORDER BY date DESC;
'@

    $objs = Invoke-OsqueryJson -Sql $sql -BaseName 'OSQ_Windows_Update_History'

    if (@($objs).Count -gt 0) {
        $preferred = 'date','title','operation','result_code','error_code','support_url','server_selection'
        $cols = @()
        foreach ($c in $preferred) {
            if ($objs[0].PSObject.Properties.Name -contains $c) { $cols += $c }
        }
        foreach ($c in $objs[0].PSObject.Properties.Name) {
            if ($cols -notcontains $c) { $cols += $c }
        }
        $objs | Select-Object -Property $cols | Format-Table -AutoSize
    } else {
        Write-Host "No update history returned by osquery." -ForegroundColor Yellow
    }

    Pause-Script "Press any key to return to the menu..."
}

function Show-Menu {
    Clear-Host
    Show-Header "OSQuery Data Collection"

    Write-Host ""
    Write-Host " [1] Applications (Full Inventory)    - Full software list from osquery 'programs'" -ForegroundColor White
    Write-Host " [2] Search for Specific Application  - Filter by name/publisher via LIKE" -ForegroundColor White
    Write-Host " [3] Browser Extensions               - Chrome / Edge / Firefox" -ForegroundColor White
    Write-Host " [4] Windows Update History (OSQuery Patch Audit)" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# Main loop
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Run-OsqApplicationsFull }
        '2' { Run-OsqApplicationsSearch }
        '3' { Run-OsqBrowserExtensions }
        '4' { Run-OsqPatchAudit }
        'Q' {
            # Explicitly relaunch the main CS Toolbox Launcher in the SAME window
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path $launcher) {
                & $launcher
            }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}
