# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# =============================
#  OSQuery Data Collection Tool
# =============================

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Run-OsqueryCommand {
    param(
        [Parameter(Mandatory)][string]$Query,
        [Parameter(Mandatory)][string]$OutputFile
    )

    $osqueryPath = "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe"
    if (-not (Test-Path $osqueryPath)) {
        Write-Host "❌ osqueryi.exe not found at: $osqueryPath" -ForegroundColor Red
        return
    }

    $fullOutputPath = Join-Path "C:\CS-Toolbox-TEMP\Collected-Info" $OutputFile
    try {
        & $osqueryPath --json "$Query" | Out-File -FilePath $fullOutputPath -Encoding utf8
        Write-Host "✅ Saved results to $fullOutputPath" -ForegroundColor Green
    } catch {
        Write-Host "❌ ERROR running osquery: $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Show-OsqueryMenu {
    Clear-Host
    Show-Header "OSQuery Data Collection"

    Write-Host ""
    Write-Host " [1] Applications (Full Inventory)"
    Write-Host " [2] Search for Specific Application"
    Write-Host " [3] Browser Extensions"
    Write-Host ""
    Write-Host " [Q] Quit to Main Menu"
    Write-Host ""
}

while ($true) {
    Show-OsqueryMenu
    $choice = Read-Host "Enter your choice"

    switch ($choice.Trim().ToUpperInvariant()) {
        '1' {
            Write-Host "Collecting full installed applications inventory..." -ForegroundColor Cyan
            Run-OsqueryCommand `
                "SELECT name, version, install_date, publisher FROM programs;" `
                ("osquery_apps_full_{0}.json" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
            Pause-Script
        }
        '2' {
            $search = Read-Host "Enter partial app name or publisher to search"
            if (-not $search) {
                Write-Host "⚠ Search term is required." -ForegroundColor Yellow
            } else {
                Write-Host "Searching for applications matching '$search'..." -ForegroundColor Cyan
                Run-OsqueryCommand `
                    "SELECT name, version, install_date, publisher FROM programs WHERE name LIKE '%$search%' OR publisher LIKE '%$search%';" `
                    ("osquery_apps_search_{0}.json" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
            }
            Pause-Script
        }
        '3' {
            Write-Host "Collecting browser extensions..." -ForegroundColor Cyan
            Run-OsqueryCommand `
                "SELECT browser_type, name, version, description, permissions FROM browser_extensions;" `
                ("osquery_browser_ext_{0}.json" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
            Pause-Script
        }
        'Q' {
            try {
                Launch-Tool "CS-Toolbox-Launcher.ps1"
            } catch {
                Write-Host "⚠ Could not relaunch main menu: $($_.Exception.Message)" -ForegroundColor Yellow
            }
            break
        }
        default {
            Write-Host "Unknown choice. Please try again." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
        }
    }
}
