<#
Patch-SubTools-ReloadLauncher.ps1
- Replaces [Q] Quit handling in sub-tools so it relaunches CS-Toolbox-Launcher.ps1
- Creates .bak backups
#>

[CmdletBinding()]
param(
    [string]$LauncherName = 'CS-Toolbox-Launcher.ps1',
    [switch]$Revert
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

$excludeNames = @(
    $LauncherName,
    'Functions-Common.ps1',
    'Toolbox-Cleanup-SelfDestruct.ps1'
)

$files = Get-ChildItem -Path . -Filter '*.ps1' -File |
    Where-Object { $excludeNames -notcontains $_.Name -and $_.Name -notmatch 'SelfDestruct|Cleanup' }

if ($Revert) {
    foreach ($f in $files) {
        $bak = "$($f.FullName).bak"
        if (Test-Path $bak) {
            Copy-Item -Path $bak -Destination $f.FullName -Force
            Write-Host "Restored $($f.Name)" -ForegroundColor Cyan
        }
    }
    exit
}

foreach ($f in $files) {
    $orig = Get-Content -Path $f.FullName -Raw -Encoding UTF8
    $text = $orig

    # Replace case for 'Q' (switch) or if/elseif handling
    # Regex replaces Q case to relaunch launcher
    $pattern = "(?ms)(['""]Q['""]\s*\{)(.*?)(\})"
    $replacement = {
        param($m)
        return "$($m.Groups[1].Value)
            & `"$here\$LauncherName`"
            return
        $($m.Groups[3].Value)"
    }

    $newText = [regex]::Replace($text, $pattern, $replacement)

    if ($newText -ne $orig) {
        $bak = "$($f.FullName).bak"
        if (-not (Test-Path $bak)) {
            Copy-Item -Path $f.FullName -Destination $bak
        }
        $utf8 = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($f.FullName, $newText, $utf8)
        Write-Host "Patched $($f.Name)" -ForegroundColor Green
    } else {
        Write-Host "No Q case found in $($f.Name)" -ForegroundColor DarkGray
    }
}

Write-Host ""
Write-Host "Patch complete. Press Q in any sub-tool to reload $LauncherName." -ForegroundColor Cyan
Write-Host "To undo, run: .\Patch-SubTools-ReloadLauncher.ps1 -Revert" -ForegroundColor DarkGray
