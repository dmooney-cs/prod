# ============================
# Agent-Status-Tool.ps1  (ASCII-only, PS 5.1 safe)
# ============================

# Load shared functions
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (-not (Test-Path $commonPath)) { Write-Host "[ERROR] Functions-Common.ps1 not found." -ForegroundColor Red; Pause-Script "Press any key..."; return }
try { . $commonPath } catch { Write-Host "[ERROR] Failed to load Functions-Common.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script "Press any key..."; return }
Ensure-ExportFolder

$Hostname       = $env:COMPUTERNAME
$Stamp          = Get-Date -Format "yyyyMMdd_HHmmss"
$ExportRoot     = "C:\CS-Toolbox-TEMP\Collected-Info"
$TranscriptPath = Join-Path $ExportRoot ("{0}-AgentStatus-{1}.log" -f $Hostname,$Stamp)
$AgentExe       = "C:\Program Files (x86)\CyberCNSAgent\cybercnsagent.exe"

$TranscriptStarted = $false
try { Start-Transcript -Path $TranscriptPath -Append -ErrorAction Stop | Out-Null; $TranscriptStarted=$true } catch {}

function Get-AgentVersionInstalled {
    if (Test-Path -LiteralPath $AgentExe) {
        try {
            $p = Start-Process -FilePath $AgentExe -ArgumentList "-v" -NoNewWindow -RedirectStandardOutput "$env:TEMP\_agent_ver.txt" -Wait -PassThru
            $out = Get-Content "$env:TEMP\_agent_ver.txt" -ErrorAction SilentlyContinue
            Remove-Item "$env:TEMP\_agent_ver.txt" -Force -ErrorAction SilentlyContinue
            if ($out) {
                $line = ($out | Select-Object -First 1)
                # Expect something like: "CyberCNS Agent 4.3.67"
                if ($line -match 'CyberCNS Agent\s+([0-9\.]+)') { return $matches[1] }
            }
        } catch {}
        # Fallback to file version
        try {
            $ver = (Get-Item $AgentExe).VersionInfo.ProductVersion
            if ($ver) { return $ver }
        } catch {}
    }
    return $null
}

function Show-Status {
    Show-Header "Agent Status"
    $svc1 = Get-Service -Name "CyberCNSAgent" -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name "ConnectSecureAgentMonitor" -ErrorAction SilentlyContinue
    Write-Host "Services:" -ForegroundColor Gray
    if ($svc1) { Write-Host (" - CyberCNSAgent: {0}" -f $svc1.Status) } else { Write-Host " - CyberCNSAgent: Not Found" }
    if ($svc2) { Write-Host (" - ConnectSecureAgentMonitor: {0}" -f $svc2.Status) } else { Write-Host " - ConnectSecureAgentMonitor: Not Found" }

    $proc = Get-Process -Name "cybercnsagent" -ErrorAction SilentlyContinue
    Write-Host ("Process: {0}" -f (if($proc){"Running"}else{"Not Running"}))

    $ver = Get-AgentVersionInstalled
    Write-Host ("Installed Version: {0}" -f (if($ver){$ver}else{"Unknown"}))
    Write-Host ""
    Pause-Script "Press any key to return..."
}

try { Show-Status } finally {
    if($TranscriptStarted){ try { Stop-Transcript | Out-Null; Write-Host ("Log saved to: {0}" -f $TranscriptPath) -ForegroundColor DarkGray } catch {} }
}
