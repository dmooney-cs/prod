<# =======================================================================================
  OSQuery-WMIC-Patch-Audit.ps1
  - No prompts; auto-creates output folders
  - Uses WMIC if present; otherwise falls back to CIM/Get-HotFix (PS5.1 compatible)
  - Saves UTF-8 CSV/TXT to C:\CS-Toolbox-TEMP\Collected-Info\Patches
  - Prints a concise on-screen table
======================================================================================= #>

#Requires -RunAsAdministrator
Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# -----------------------------
# Fallback helpers (local stubs)
# -----------------------------
function _Ensure-Folder {
    param([Parameter(Mandatory)][string]$Path)
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            $null = New-Item -Path $Path -ItemType Directory -Force -ErrorAction Stop
        }
        return $true
    } catch {
        Write-Host "ERROR: Unable to create/access folder: $Path`n$($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

function _Show-Header {
    param([string]$Title="Task")
    $line=('='*[Math]::Max(20,$Title.Length+8))
    Write-Host ""
    Write-Host $line -ForegroundColor DarkCyan
    Write-Host ("   {0}" -f $Title) -ForegroundColor Cyan
    Write-Host $line -ForegroundColor DarkCyan
    Write-Host ""
}

function _Pause-Here { param([string]$Message="Press Enter to return...")
    try {
        if ($Host -and $Host.UI -and $Host.UI.RawUI) {
            Write-Host $Message -ForegroundColor DarkGray
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            return
        }
    } catch {}
    Read-Host $Message | Out-Null
}

function Write-TextFile([string]$Path,[string[]]$Lines){
    if (Get-Command -Name Write-Utf8NoBom -ErrorAction SilentlyContinue) {
        Write-Utf8NoBom -Path $Path -Content ($Lines -join [Environment]::NewLine)
    } else {
        ($Lines -join [Environment]::NewLine) | Set-Content -LiteralPath $Path -Encoding UTF8
    }
}

function SafeStr([object]$v) { if ($null -eq $v) { '' } else { [string]$v } }

# ---------------------------------------
# Try to load shared functions (if present)
# ---------------------------------------
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (Test-Path -LiteralPath $commonPath) {
    try {
        $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
        Invoke-Expression $code
    } catch {
        Write-Host "WARN: Failed to load Functions-Common.ps1; using local fallbacks. $_" -ForegroundColor Yellow
    }
} else {
    Write-Host "INFO: Functions-Common.ps1 not found; using local fallbacks." -ForegroundColor DarkYellow
}
if (-not (Get-Command -Name Show-Header -ErrorAction SilentlyContinue)) { Set-Alias Show-Header _Show-Header -Scope Script }
if (-not (Get-Command -Name Pause-Script -ErrorAction SilentlyContinue)) { Set-Alias Pause-Script _Pause-Here -Scope Script }

# -----------------------------
# Output roots (auto-created)
# -----------------------------
$exportRoot   = 'C:\CS-Toolbox-TEMP\Collected-Info'
$patchOutRoot = Join-Path $exportRoot 'Patches'
foreach ($p in @($exportRoot, $patchOutRoot)) {
    if (-not (_Ensure-Folder -Path $p)) { Pause-Script "Press any key to exit..."; return }
}

# ==============================
#   Windows Patches (QFE list)
# ==============================
Show-Header "Windows Patches (QFE Inventory)"

$ts      = Get-Date -Format 'yyyyMMdd_HHmmss'
$csvPath = Join-Path $patchOutRoot ("WMIC_QFE_{0}.csv" -f $ts)
$txtPath = Join-Path $patchOutRoot ("WMIC_QFE_{0}.txt" -f $ts)

# -----------------------------
# Try WMIC first (if available)
# -----------------------------
$wmicPaths = @(
    (Join-Path $env:SystemRoot 'System32\wbem\WMIC.exe'),
    (Join-Path $env:SystemRoot 'SysWOW64\wbem\WMIC.exe'),
    (Join-Path $env:SystemRoot 'Sysnative\wbem\WMIC.exe')
)
$wmic = $wmicPaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

if ($wmic) {
    Write-Host "Using WMIC for QFE enumeration..." -ForegroundColor Cyan

    $tempCsv = [System.IO.Path]::GetTempFileName()
    $tempTxt = [System.IO.Path]::GetTempFileName()

    $p1 = Start-Process -FilePath $wmic -ArgumentList 'qfe list full /format:csv' -NoNewWindow -RedirectStandardOutput $tempCsv -PassThru
    $null = $p1.WaitForExit()
    $p2 = Start-Process -FilePath $wmic -ArgumentList 'qfe list brief' -NoNewWindow -RedirectStandardOutput $tempTxt -PassThru
    $null = $p2.WaitForExit()

    try { $rawCsv = Get-Content -LiteralPath $tempCsv -Encoding Unicode } catch { $rawCsv = Get-Content -LiteralPath $tempCsv -Encoding Default }
    try { $rawTxt = Get-Content -LiteralPath $tempTxt -Encoding Unicode } catch { $rawTxt = Get-Content -LiteralPath $tempTxt -Encoding Default }

    Write-TextFile -Path $csvPath -Lines $rawCsv
    Write-TextFile -Path $txtPath -Lines $rawTxt
}
else {
    # -----------------------------
    # WMIC absent: use CIM + Get-HotFix
    # -----------------------------
    Write-Host "WMIC.exe not found; using CIM/Get-HotFix fallback..." -ForegroundColor Yellow

    # Get CIM QFE objects
    $qfe = @()
    try { $qfe = Get-CimInstance -ClassName Win32_QuickFixEngineering -ErrorAction Stop } catch { $qfe = @() }

    # Get-HotFix (sometimes has items not reflected in CIM)
    $ghf = @()
    try { $ghf = Get-HotFix -ErrorAction Stop } catch { $ghf = @() }

    # Normalize to a common object shape
    $fromCim = $qfe | ForEach-Object {
        [pscustomobject]@{
            Node         = $env:COMPUTERNAME
            HotFixID     = $_.HotFixID
            InstalledOn  = $_.InstalledOn
            Description  = $_.Description
            InstalledBy  = $_.InstalledBy
            FixComments  = $_.FixComments
            Caption      = $_.Caption
        }
    }

    $fromGhf = $ghf | ForEach-Object {
        [pscustomobject]@{
            Node         = $env:COMPUTERNAME
            HotFixID     = $_.HotFixID
            InstalledOn  = $_.InstalledOn
            Description  = $_.Description
            InstalledBy  = $null
            FixComments  = $null
            Caption      = $null
        }
    }

    # Merge + de-duplicate on HotFixID + InstalledOn (some machines report dupes)
    $all = @($fromCim + $fromGhf) | Where-Object { $_.HotFixID -and $_.HotFixID -ne "" }

    # Normalize InstalledOn as string yyyy-MM-dd when possible
    foreach ($r in $all) {
        if ($r.InstalledOn) {
            try {
                $dt = $r.InstalledOn
                if ($dt -isnot [datetime]) { $dt = [datetime]::Parse([string]$r.InstalledOn) }
                $r.InstalledOn = $dt.ToString('yyyy-MM-dd')
            } catch {
                # leave as-is if parse fails
            }
        }
    }

    $all = $all | Sort-Object HotFixID, InstalledOn -Unique

    # Write CSV
    $csv = $all | Select-Object Node, HotFixID, InstalledOn, Description, InstalledBy, FixComments, Caption
    $csv | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8

    # Write TXT "brief" similar to WMIC (no '??' operator; PS5.1 safe)
    $txtLines = @()
    foreach ($r in ($all | Sort-Object InstalledOn, HotFixID)) {
        $txtLines += ("{0}  {1}  {2}" -f (SafeStr $r.HotFixID), (SafeStr $r.InstalledOn), (SafeStr $r.Description))
    }
    Write-TextFile -Path $txtPath -Lines $txtLines
}

# -----------------------------
# Quick on-screen summary
# -----------------------------
try {
    $rows = Import-Csv -LiteralPath $csvPath
    if ($rows -and $rows.Count -gt 0) {
        # Cast InstalledOn for sorting if possible (PS5.1 safe)
        $rows | ForEach-Object {
            if ($_.InstalledOn) {
                try { $_.InstalledOn = ([datetime]$_.InstalledOn).ToString('yyyy-MM-dd') } catch {}
            }
        }
        $rows |
            Select-Object @{n='HotFixID';e={$_.HotFixID}},
                          @{n='InstalledOn';e={$_.InstalledOn}},
                          @{n='Description';e={$_.Description}},
                          @{n='InstalledBy';e={$_.InstalledBy}} |
            Sort-Object InstalledOn, HotFixID |
            Format-Table -AutoSize

        Write-Host ""
        Write-Host "Saved:" -ForegroundColor Green
        Write-Host "  CSV: $csvPath" -ForegroundColor Green
        Write-Host "  TXT: $txtPath" -ForegroundColor Green
        Write-Host ""
        Write-Host "Tip: CSV includes FixComments (when present)." -ForegroundColor DarkGray
    } else {
        Write-Host "Info: No QFE entries found." -ForegroundColor DarkCyan
        Write-Host "Files saved (may be empty):" -ForegroundColor DarkCyan
        Write-Host "  $csvPath" -ForegroundColor DarkCyan
        Write-Host "  $txtPath" -ForegroundColor DarkCyan
    }
} catch {
    Write-Host "WARN: Could not render on-screen table: $($_.Exception.Message)" -ForegroundColor Yellow
    Write-Host "Outputs saved to:" -ForegroundColor Yellow
    Write-Host "  $csvPath" -ForegroundColor Yellow
    Write-Host "  $txtPath" -ForegroundColor Yellow
}

Pause-Script "Press any key to return..."
return
