<# =======================================================================================
  OSQuery-WMIC-Patch-Audit.ps1

  Features:
    • Auto-creates required folders
    • Uses WMIC when available; falls back to CIM/Get-HotFix
    • Saves CSV + TXT to:
         C:\CS-Toolbox-TEMP\Collected-Info\Patches
    • On-screen table (non-ExportOnly):
         Columns: HotFixID, Description, Caption, InstalledOn
         Sorted by most recent InstalledOn (descending)
      Table is always rendered from the same CSV that is exported.

  SWITCHES:
    -ExportOnly     Run silently, no UI/headers/table/pause, but still exports results.

  Requirements:
    • Windows
    • PS 5.1
    • Admin rights
======================================================================================= #>

#requires -version 5.1
#Requires -RunAsAdministrator

[CmdletBinding()]
param(
    [switch]$ExportOnly
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

# -----------------------------
# Internal helpers
# -----------------------------
function _Ensure-Folder {
    param([Parameter(Mandatory)][string]$Path)
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            New-Item -Path $Path -ItemType Directory -Force -ErrorAction Stop | Out-Null
        }
        $true
    } catch {
        if ($script:ExportOnly) { return $false }
        Write-Host "ERROR: Unable to create/access folder: $Path`n$($_.Exception.Message)" -ForegroundColor Red
        $false
    }
}

function _Show-Header {
    param([string]$Title="Task")
    if ($script:ExportOnly) { return }
    $line = ('=' * [Math]::Max(20, $Title.Length + 8))
    Write-Host ""
    Write-Host $line -ForegroundColor DarkCyan
    Write-Host ("   $Title") -ForegroundColor Cyan
    Write-Host $line -ForegroundColor DarkCyan
    Write-Host ""
}

function _Pause-Here {
    param([string]$Message="Press Enter to return...")
    if ($script:ExportOnly) { return }
    try {
        if ($Host -and $Host.UI -and $Host.UI.RawUI) {
            Write-Host $Message -ForegroundColor DarkGray
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            return
        }
    } catch {}
    Read-Host $Message | Out-Null
}

function Write-TextFile([string]$Path, [string[]]$Lines) {
    if (Get-Command -Name Write-Utf8NoBom -ErrorAction SilentlyContinue) {
        Write-Utf8NoBom -Path $Path -Content ($Lines -join [Environment]::NewLine)
    } else {
        ($Lines -join [Environment]::NewLine) | Set-Content -LiteralPath $Path -Encoding UTF8
    }
}

function SafeStr([object]$v) { if ($null -eq $v) { '' } else { "$v" } }

# -----------------------------
# Main
# -----------------------------
try {
    # -------------------------------------------------
    # Load shared Functions-Common.ps1 if available
    # -------------------------------------------------
    $scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
    $commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

    if (Test-Path -LiteralPath $commonPath) {
        try {
            $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
            Invoke-Expression $code
        } catch {
            # silent in ExportOnly, warning in interactive
            if (-not $ExportOnly) {
                Write-Host "WARN: Failed to load Functions-Common.ps1; using internal fallbacks." -ForegroundColor Yellow
            }
        }
    }

    if (-not (Get-Command -Name Show-Header -ErrorAction SilentlyContinue)) {
        Set-Alias Show-Header _Show-Header -Scope Script
    }
    if (-not (Get-Command -Name Pause-Script -ErrorAction SilentlyContinue)) {
        Set-Alias Pause-Script _Pause-Here -Scope Script
    }

    # -----------------------------
    # Output folders
    # -----------------------------
    $exportRoot   = 'C:\CS-Toolbox-TEMP\Collected-Info'
    $patchOutRoot = Join-Path $exportRoot 'Patches'

    foreach ($folder in @($exportRoot, $patchOutRoot)) {
        if (-not (_Ensure-Folder -Path $folder)) {
            if ($ExportOnly) { exit 1 }
            Pause-Script "Press any key to exit..."
            return
        }
    }

    # -----------------------------
    # Header (skipped in ExportOnly)
    # -----------------------------
    Show-Header "Windows Patches (QFE Inventory)"

    # -----------------------------
    # Prepare output paths
    # -----------------------------
    $ts      = Get-Date -Format 'yyyyMMdd_HHmmss'
    $csvPath = Join-Path $patchOutRoot ("WMIC_QFE_{0}.csv" -f $ts)
    $txtPath = Join-Path $patchOutRoot ("WMIC_QFE_{0}.txt" -f $ts)

    # -----------------------------
    # WMIC detection
    # -----------------------------
    $wmicPaths = @(
        "$env:SystemRoot\System32\wbem\WMIC.exe",
        "$env:SystemRoot\SysWOW64\wbem\WMIC.exe",
        "$env:SystemRoot\Sysnative\wbem\WMIC.exe"
    )
    $wmic = $wmicPaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

    # -----------------------------
    # Collect data (WMIC or CIM/Get-HotFix)
    # -----------------------------
    if ($wmic) {

        if (-not $ExportOnly) {
            Write-Host "Using WMIC for QFE enumeration..." -ForegroundColor Cyan
        }

        $tempCsv = [System.IO.Path]::GetTempFileName()
        $tempTxt = [System.IO.Path]::GetTempFileName()

        $p1 = Start-Process -FilePath $wmic -ArgumentList 'qfe list full /format:csv' -NoNewWindow -RedirectStandardOutput $tempCsv -PassThru -ErrorAction Stop
        $p1.WaitForExit() | Out-Null

        $p2 = Start-Process -FilePath $wmic -ArgumentList 'qfe list brief' -NoNewWindow -RedirectStandardOutput $tempTxt -PassThru -ErrorAction Stop
        $p2.WaitForExit() | Out-Null

        try { $rawCsv = Get-Content -LiteralPath $tempCsv -Encoding Unicode } catch { $rawCsv = Get-Content -LiteralPath $tempCsv -Encoding Default }
        try { $rawTxt = Get-Content -LiteralPath $tempTxt -Encoding Unicode } catch { $rawTxt = Get-Content -LiteralPath $tempTxt -Encoding Default }

        # Save raw WMIC outputs
        Write-TextFile -Path $csvPath -Lines $rawCsv
        Write-TextFile -Path $txtPath -Lines $rawTxt
    }
    else {

        if (-not $ExportOnly) {
            Write-Host "WMIC.exe not found; using CIM/Get-HotFix fallback..." -ForegroundColor Yellow
        }

        # CIM objects
        try { $qfe = Get-CimInstance -ClassName Win32_QuickFixEngineering -ErrorAction Stop } catch { $qfe = @() }

        # Get-HotFix fallback
        try { $ghf = Get-HotFix -ErrorAction Stop } catch { $ghf = @() }

        # Normalize
        $fromCim = $qfe | ForEach-Object {
            [pscustomobject]@{
                Node         = $env:COMPUTERNAME
                HotFixID     = $_.HotFixID
                InstalledOn  = $_.InstalledOn
                Description  = $_.Description
                InstalledBy  = $_.InstalledBy
                FixComments  = $_.FixComments
                Caption      = $_.Caption
            }
        }

        $fromGhf = $ghf | ForEach-Object {
            [pscustomobject]@{
                Node         = $env:COMPUTERNAME
                HotFixID     = $_.HotFixID
                InstalledOn  = $_.InstalledOn
                Description  = $_.Description
                InstalledBy  = $null
                FixComments  = $null
                Caption      = $null
            }
        }

        # Combine + dedupe
        $all = (@($fromCim + $fromGhf) | Where-Object { $_.HotFixID -and $_.HotFixID -ne "" })

        foreach ($r in $all) {
            if ($r.InstalledOn) {
                try {
                    $dt = $r.InstalledOn
                    if ($dt -isnot [datetime]) { $dt = [datetime]::Parse("$dt") }
                    $r.InstalledOn = $dt.ToString('yyyy-MM-dd')
                } catch {}
            }
        }

        $all = $all | Sort-Object HotFixID, InstalledOn -Unique

        # Export CSV
        $all |
            Select-Object Node, HotFixID, InstalledOn, Description, InstalledBy, FixComments, Caption |
            Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8

        # Export brief TXT (to mirror what WMIC text gives you)
        $txtLines = @()
        foreach ($r in ($all | Sort-Object InstalledOn, HotFixID)) {
            $txtLines += ("{0}  {1}  {2}" -f (SafeStr $r.HotFixID), (SafeStr $r.InstalledOn), (SafeStr $r.Description))
        }
        Write-TextFile -Path $txtPath -Lines $txtLines
    }

    # -----------------------------
    # On-screen rendering from CSV (unless ExportOnly)
    # -----------------------------
    if (-not $ExportOnly) {
        try {
            $rows = Import-Csv -LiteralPath $csvPath

            if ($rows -and $rows.Count -gt 0) {

                $propNames = $rows[0].PSObject.Properties.Name
                $hasInstalledOn = $propNames -contains 'InstalledOn'

                foreach ($r in $rows) {
                    $sortDate = $null
                    if ($hasInstalledOn -and $r.InstalledOn) {
                        try { $sortDate = [datetime]$r.InstalledOn } catch { $sortDate = $null }
                    }
                    Add-Member -InputObject $r -NotePropertyName '_SortInstalledOn' -NotePropertyValue $sortDate -Force
                }

                $rows |
                    Sort-Object -Property _SortInstalledOn -Descending |
                    Select-Object HotFixID, Description, Caption, InstalledOn |
                    Format-Table -AutoSize

                Write-Host ""
                Write-Host "Saved CSV/TXT:" -ForegroundColor Green
                Write-Host "  $csvPath" -ForegroundColor Green
                Write-Host "  $txtPath" -ForegroundColor Green
                Write-Host ""
            }
            else {
                Write-Host "No QFE entries found." -ForegroundColor Cyan
                Write-Host "Files saved (may be empty):" -ForegroundColor Cyan
                Write-Host "  $csvPath"
                Write-Host "  $txtPath"
            }

        } catch {
            Write-Host "WARN: Could not render output table: $($_.Exception.Message)" -ForegroundColor Yellow
            Write-Host "Saved CSV/TXT:"
            Write-Host "  $csvPath"
            Write-Host "  $txtPath"
        }

        Pause-Script "Press any key to return..."
    }

    return
}
catch {
    if ($ExportOnly) { exit 1 }
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Pause-Script "Press any key to return..."
    return
}
```
