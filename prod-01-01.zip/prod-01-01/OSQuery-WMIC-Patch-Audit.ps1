# =======================================================================
# OSQuery + WMIC Patch Audit
# Menu slot: 3. OSQuery + WMIC Patch Audit
# Exports: C:\CS-Toolbox-TEMP\Collected-Info\Patches
# =======================================================================

# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# Local fallback for Write-Utf8NoBom if not present in Functions-Common
if (-not (Get-Command -Name Write-Utf8NoBom -ErrorAction SilentlyContinue)) {
    function Write-Utf8NoBom {
        [CmdletBinding()]
        param(
            [Parameter(ValueFromPipeline = $true)]
            [string] $InputObject,
            [Parameter(Mandatory)]
            [string] $Path
        )
        begin { $sb = New-Object System.Text.StringBuilder }
        process { if ($null -ne $InputObject) { [void]$sb.Append($InputObject) } }
        end {
            $enc = New-Object System.Text.UTF8Encoding($false) # no BOM
            [System.IO.File]::WriteAllText($Path, $sb.ToString(), $enc)
        }
    }
}

# =========================
# Script-level constants
# =========================
$HostName    = $env:COMPUTERNAME
$Stamp       = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$BaseExport  = "C:\CS-Toolbox-TEMP\Collected-Info"
$PatchDir    = Join-Path $BaseExport "Patches"
$OsqueryExe  = "C:\Program Files (x86)\CyberCNSAgent\osqueryi.exe"

if (-not (Test-Path $PatchDir)) {
    New-Item -ItemType Directory -Path $PatchDir -Force | Out-Null
}

function Write-Section([string]$Text) {
    Write-Host ""
    Write-Host ("{0}" -f ("=" * 70)) -ForegroundColor DarkCyan
    Write-Host ("  {0}" -f $Text) -ForegroundColor Cyan
    Write-Host ("{0}" -f ("=" * 70)) -ForegroundColor DarkCyan
}

function Save-Table {
    param(
        [Parameter(Mandatory)] [System.Collections.IEnumerable] $Objects,
        [Parameter(Mandatory)] [string] $CsvPath,
        [string] $JsonPath
    )
    try {
        $arr = @($Objects)
        if ($arr.Count -gt 0) {
            $arr | Export-Csv -Path $CsvPath -NoTypeInformation -Encoding UTF8
            if ($JsonPath) {
                $arr | ConvertTo-Json -Depth 6 | Write-Utf8NoBom -Path $JsonPath
            }
            Write-Host "Saved: $CsvPath" -ForegroundColor Green
            if ($JsonPath) { Write-Host "Saved: $JsonPath" -ForegroundColor Green }
        }
        else {
            Write-Host "No rows to save for: $CsvPath" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Host "Failed saving results ($CsvPath): $_" -ForegroundColor Red
    }
}

# -------------------------
# WMIC + Windows Update COM
# -------------------------
function Run-WmicPatchAudit {
    Write-Section "WMIC + Windows Update (COM) Patch Audit"
    $outWmicCsv = Join-Path $PatchDir ("Patches-WMIC_{0}_{1}.csv" -f $HostName,$Stamp)
    $outWuaCsv  = Join-Path $PatchDir ("Patches-WUA_{0}_{1}.csv" -f $HostName,$Stamp)
    $outWuaJson = Join-Path $PatchDir ("Patches-WUA_{0}_{1}.json" -f $HostName,$Stamp)

    $wmicKbs = @()
    try {
        # WMIC (deprecated but often present)
        $raw = (wmic qfe get HotfixID 2>$null) | Where-Object { $_ -and ($_ -notmatch 'HotFixID') } | ForEach-Object { $_.Trim() }
        $wmicKbs = $raw | Where-Object { $_ } | Sort-Object -Unique
    } catch { }

    if (-not $wmicKbs -or $wmicKbs.Count -eq 0) {
        # Fallback to Get-HotFix
        try {
            $wmicKbs = (Get-HotFix | Select-Object -ExpandProperty HotFixID) 2>$null | Sort-Object -Unique
        } catch {
            Write-Host "Neither WMIC nor Get-HotFix returned results." -ForegroundColor Yellow
        }
    }

    $wmicRows = $wmicKbs | Where-Object { $_ } | ForEach-Object {
        [pscustomobject]@{
            hotfix_id   = $_
            source      = 'WMIC/Get-HotFix'
            hostname    = $HostName
            collectedAt = (Get-Date)
        }
    }
    Save-Table -Objects $wmicRows -CsvPath $outWmicCsv

    # Windows Update Agent COM search (installed updates)
    $wuaRows = @()
    try {
        $UpdateSession  = New-Object -ComObject "Microsoft.Update.Session"
        $UpdateSearcher = $UpdateSession.CreateUpdateSearcher()
        $Results        = $UpdateSearcher.Search("IsInstalled=1")
        foreach ($update in $Results.Updates) {
            $kbList = @()
            foreach ($kb in $update.KBArticleIDs) {
                if ($kb) { $kbList += ("KB{0}" -f [string]$kb) }
            }
            if ($kbList.Count -eq 0) { $kbList = @('') }

            foreach ($kbId in $kbList) {
                $wuaRows += [pscustomobject]@{
                    hotfix_id    = $kbId
                    title        = [string]$update.Title
                    description  = [string]$update.Description
                    supportUrl   = [string]$update.SupportUrl
                    isHidden     = [bool]$update.IsHidden
                    msrcSeverity = [string]$update.MsrcSeverity
                    categories   = ($update.Categories | ForEach-Object Name) -join '; '
                    source       = 'WUA-COM'
                    hostname     = $HostName
                    collectedAt  = (Get-Date)
                }
            }
        }
    } catch {
        Write-Host "WUA COM query failed: $_" -ForegroundColor Red
    }

    Save-Table -Objects $wuaRows -CsvPath $outWuaCsv -JsonPath $outWuaJson

    # On-screen summary
    Write-Host ""
    Write-Host "WMIC/Get-HotFix count: $($wmicRows.Count)" -ForegroundColor Cyan
    Write-Host "WUA (COM) rows:        $($wuaRows.Count)" -ForegroundColor Cyan
    if ($wmicRows.Count -gt 0) {
        Write-Host ""
        Write-Host "Sample WMIC/Get-HotFix IDs:" -ForegroundColor DarkCyan
        $wmicRows | Select-Object -First 10 | Format-Table hotfix_id -AutoSize
    }
    if ($wuaRows.Count -gt 0) {
        Write-Host ""
        Write-Host "Sample WUA Titles:" -ForegroundColor DarkCyan
        $wuaRows | Select-Object -First 5 title,hotfix_id | Format-Table -AutoSize
    }

    Pause-Script "Press any key to continue..."
}

# -------------------------
# OSQuery Patch Audit
# -------------------------
function Invoke-OsqueryJson {
    param(
        [Parameter(Mandatory)] [string] $Query
    )
    if (-not (Test-Path $OsqueryExe)) {
        Write-Host "osqueryi.exe not found at: $OsqueryExe" -ForegroundColor Red
        return @()
    }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName               = $OsqueryExe
    $psi.Arguments              = "--json `"$Query`""
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute        = $false
    $psi.CreateNoWindow         = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    $null = $p.Start()
    $stdout = $p.StandardOutput.ReadToEnd()
    $stderr = $p.StandardError.ReadToEnd()
    $p.WaitForExit()

    if ($p.ExitCode -ne 0) {
        Write-Host "osqueryi exited with code $($p.ExitCode)" -ForegroundColor Red
        if ($stderr) { Write-Host $stderr -ForegroundColor DarkRed }
        return @()
    }

    try {
        $data = $stdout | ConvertFrom-Json
        if ($null -eq $data) { return @() }
        if ($data -isnot [System.Collections.IEnumerable]) { return ,$data }
        return $data
    } catch {
        Write-Host "Failed to parse osquery JSON: $_" -ForegroundColor Red
        return @()
    }
}

function Run-OsqueryPatchAudit {
    Write-Section "OSQuery Patch Audit"

    if (-not (Test-Path $OsqueryExe)) {
        Write-Host "osqueryi.exe not found at: $OsqueryExe" -ForegroundColor Red
        Write-Host "Navigate to: cd `"$([IO.Path]::GetDirectoryName($OsqueryExe))`"" -ForegroundColor Yellow
        Write-Host "Then run: .\osqueryi.exe" -ForegroundColor Yellow
        Pause-Script "Press any key to continue..."
        return
    }

    # Query 1: windows_update_history -> hotfix_id, description, install_date, ...
    $q1 = @'
select
  CONCAT('KB', replace(split(split(title,'KB',1),' ',0),')','')) as hotfix_id,
  description,
  datetime(date,'unixepoch') as install_date,
  '' as installed_by,
  '' as installed_on
from windows_update_history
where title like '%KB%'
group by split(split(title,'KB',1),' ',0);
'@

    # Query 2: patches table -> hotfix_id, description, installed_by, install_date, installed_on
    $q2 = @'
select hotfix_id, description, installed_by, install_date, installed_on
from patches
group by hotfix_id;
'@

    $outQ1Csv  = Join-Path $PatchDir ("Patches-OSQ-UpdateHistory_{0}_{1}.csv" -f $HostName,$Stamp)
    $outQ1Json = Join-Path $PatchDir ("Patches-OSQ-UpdateHistory_{0}_{1}.json" -f $HostName,$Stamp)
    $outQ2Csv  = Join-Path $PatchDir ("Patches-OSQ-PatchesTable_{0}_{1}.csv" -f $HostName,$Stamp)
    $outQ2Json = Join-Path $PatchDir ("Patches-OSQ-PatchesTable_{0}_{1}.json" -f $HostName,$Stamp)

    $rows1 = Invoke-OsqueryJson -Query $q1 | ForEach-Object {
        [pscustomobject]@{
            hotfix_id    = $_.hotfix_id
            description  = $_.description
            installed_by = $_.installed_by
            install_date = $_.install_date
            installed_on = $_.installed_on
            source       = 'osquery:windows_update_history'
            hostname     = $HostName
            collectedAt  = (Get-Date)
        }
    }

    $rows2 = Invoke-OsqueryJson -Query $q2 | ForEach-Object {
        [pscustomobject]@{
            hotfix_id    = $_.hotfix_id
            description  = $_.description
            installed_by = $_.installed_by
            install_date = $_.install_date
            installed_on = $_.installed_on
            source       = 'osquery:patches'
            hostname     = $HostName
            collectedAt  = (Get-Date)
        }
    }

    Save-Table -Objects $rows1 -CsvPath $outQ1Csv -JsonPath $outQ1Json
    Save-Table -Objects $rows2 -CsvPath $outQ2Csv -JsonPath $outQ2Json

    # On-screen summary
    Write-Host ""
    Write-Host "OSQuery windows_update_history rows: $($rows1.Count)" -ForegroundColor Cyan
    Write-Host "OSQuery patches table rows:          $($rows2.Count)" -ForegroundColor Cyan

    if ($rows1.Count -gt 0) {
        Write-Host ""
        Write-Host "Sample from windows_update_history:" -ForegroundColor DarkCyan
        $rows1 | Select-Object -First 10 hotfix_id,install_date,description | Format-Table -AutoSize
    }
    if ($rows2.Count -gt 0) {
        Write-Host ""
        Write-Host "Sample from patches table:" -ForegroundColor DarkCyan
        $rows2 | Select-Object -First 10 hotfix_id,installed_by,install_date | Format-Table -AutoSize
    }

    Pause-Script "Press any key to continue..."
}

function Run-All {
    Run-WmicPatchAudit
    Run-OsqueryPatchAudit
}

function Show-Menu {
    Clear-Host
    Show-Header "OSQuery + WMIC Patch Audit"
    Write-Host ""
    Write-Host " [1] WMIC + Windows Update (COM) Patch Audit" -ForegroundColor White
    Write-Host " [2] OSQuery Patch Audit" -ForegroundColor White
    Write-Host " [R] Run All" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Back to Main Menu (CS-Toolbox-Launcher.ps1)" -ForegroundColor Yellow
    Write-Host ""
}

# =========================
# Main loop
# =========================
do {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    switch ($choice.ToUpperInvariant()) {
        '1' { Run-WmicPatchAudit }
        '2' { Run-OsqueryPatchAudit }
        'R' { Run-All }
        'Q' {
            try { Launch-Tool "CS-Toolbox-Launcher.ps1" } catch {
                Write-Host "Could not relaunch main menu: $($_.Exception.Message)" -ForegroundColor Yellow
            }
            break
        }
        default {
            Write-Host "Invalid choice. Please select 1, 2, R, or Q." -ForegroundColor Yellow
            Start-Sleep -Seconds 1
        }
    }
} while ($true)
