<#
.SYNOPSIS
    ConnectSecure Agent Uninstall Tool (Quiet = single-line output, fully silent)

.DESCRIPTION
    - Default: interactive prompts, console messages, transcript log
    - -Quiet: no console output during run; prints only "Removed" or "Not removed" at the end
#>

[CmdletBinding()]
param(
    [switch]$Quiet
)

# ====================== Setup / Logging ======================
$hostname  = $env:COMPUTERNAME
$exportDir = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path -LiteralPath $exportDir)) {
    New-Item -Path $exportDir -ItemType Directory -Force | Out-Null
}

function New-UniquePath {
    param(
        [Parameter(Mandatory)] [string]$BasePath
    )
    # If BasePath does not exist, return it.
    if (-not (Test-Path -LiteralPath $BasePath)) { return $BasePath }

    # Otherwise add -001, -002, ... before extension.
    $dir  = [IO.Path]::GetDirectoryName($BasePath)
    $name = [IO.Path]::GetFileNameWithoutExtension($BasePath)
    $ext  = [IO.Path]::GetExtension($BasePath)
    for ($i=1; $i -le 999; $i++) {
        $candidate = Join-Path $dir ("{0}-{1:D3}{2}" -f $name, $i, $ext)
        if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }
    }
    throw "Unable to allocate a unique log path for $BasePath"
}

# Use seconds to reduce collisions; still call New-UniquePath for safety.
$stamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$baseLog      = Join-Path $exportDir "$hostname-AgentUninstall-$stamp.log"
$baseTranscript = Join-Path $exportDir "$hostname-AgentUninstall-$stamp.transcript.txt"

$logFile        = New-UniquePath -BasePath $baseLog
$transcriptFile = New-UniquePath -BasePath $baseTranscript

# Pre-create the custom log so it's ours (separate from transcript).
try { "" | Out-File -FilePath $logFile -Encoding UTF8 -Force } catch {}

# Quiet-mode: suppress *all* chatter from PowerShell and native processes
$prev = @{
  EAP  = $ErrorActionPreference
  W    = $WarningPreference
  V    = $VerbosePreference
  I    = $InformationPreference
  P    = $ProgressPreference
}
if ($Quiet) {
  $ErrorActionPreference   = 'SilentlyContinue'
  $WarningPreference       = 'SilentlyContinue'
  $VerbosePreference       = 'SilentlyContinue'
  $InformationPreference   = 'SilentlyContinue'
  $ProgressPreference      = 'SilentlyContinue'
} else {
  try { Start-Transcript -Path $transcriptFile -Append | Out-Null } catch {}
}

function Add-ContentSafe {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Value
    )
    # Small retry loop to handle transient file locks (e.g., AV scanners)
    for ($i=0; $i -lt 3; $i++) {
        try {
            Add-Content -LiteralPath $Path -Value $Value -Encoding UTF8
            return
        } catch {
            Start-Sleep -Milliseconds 200
            if ($i -eq 2) { throw }
        }
    }
}

function Write-Log {
  param([string]$m)
  $line = "{0} {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m
  try { Add-ContentSafe -Path $logFile -Value $line } catch {}
  if (-not $Quiet) { Write-Host $m }
}

# ====================== Constants ============================
$AgentDir         = "C:\Program Files (x86)\CyberCNSAgent"
$UninstallBatPath = Join-Path $AgentDir "uninstall.bat"

$RawUninstall = @'
@echo off
ping 127.0.0.1 -n 6 > nul
cd "C:\PROGRA~2"
sc stop ConnectSecureAgentMonitor >nul 2>&1
timeout /T 5 > nul
sc delete ConnectSecureAgentMonitor >nul 2>&1
timeout /T 5 > nul
sc stop CyberCNSAgent >nul 2>&1
timeout /T 5 > nul
sc delete CyberCNSAgent >nul 2>&1
ping 127.0.0.1 -n 6 > nul
taskkill /IM osqueryi.exe /F >nul 2>&1
taskkill /IM nmap.exe /F >nul 2>&1
taskkill /IM cyberutilities.exe /F >nul 2>&1
if exist "CyberCNSAgent\cybercnsagent.exe" CyberCNSAgent\cybercnsagent.exe --internalAssetArgument uninstallservice >nul 2>&1
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f >nul 2>&1
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f >nul 2>&1
rmdir "CyberCNSAgent" /s /q >nul 2>&1
'@

# ====================== Helpers ==============================
function Any-ServicePresent {
    $svc1 = Get-Service -Name 'CyberCNSAgent' -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name 'ConnectSecureAgentMonitor' -ErrorAction SilentlyContinue
    return ($svc1 -ne $null -or $svc2 -ne $null)
}

function Current-State {
    [PSCustomObject]@{
        ServicesPresent = Any-ServicePresent
        AgentDirExists  = Test-Path -LiteralPath $AgentDir
    }
}

function Invoke-Exe {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string[]]$Args = @()
    )
    if ($Quiet) {
        & $FilePath @Args > $null 2>&1
    } else {
        & $FilePath @Args
    }
}

function Run-Uninstall {
    Write-Log "[INFO] Starting uninstall process..."

    $agentExe = Join-Path $AgentDir 'cybercnsagent.exe'
    if (Test-Path -LiteralPath $agentExe) {
        Write-Log "[INFO] Triggering uninstall via cybercnsagent.exe -r"
        try { Invoke-Exe -FilePath $agentExe -Args @('-r') } catch { Write-Log "[WARN] cybercnsagent.exe -r failed: $($_.Exception.Message)" }
        Start-Sleep -Seconds 5
    } else {
        Write-Log "[INFO] Agent EXE not found, skipping -r"
    }

    $uninstallScript = $null
    if (Test-Path -LiteralPath $UninstallBatPath) {
        Write-Log "[INFO] Using local uninstall.bat"
        try { $uninstallScript = Get-Content -LiteralPath $UninstallBatPath -Raw -ErrorAction Stop } catch { $uninstallScript = $null }
    }
    if (-not $uninstallScript) {
        Write-Log "[WARN] uninstall.bat not found or unreadable, using built-in fallback"
        $uninstallScript = $RawUninstall
    }

    $tempBat = Join-Path $env:TEMP "_agent_uninstall.bat"
    try {
        $uninstallScript | Out-File -FilePath $tempBat -Encoding ASCII -Force

        Write-Log "[INFO] Executing uninstall script..."
        if ($Quiet) {
            # Hidden cmd window; fully redirected
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = $env:ComSpec
            $psi.Arguments = "/c `"$tempBat`""
            $psi.UseShellExecute = $false
            $psi.CreateNoWindow = $true
            $psi.RedirectStandardOutput = $true
            $psi.RedirectStandardError  = $true
            $p = [System.Diagnostics.Process]::Start($psi)
            $p.WaitForExit()
            # swallow outputs
            $null = $p.StandardOutput.ReadToEnd()
            $null = $p.StandardError.ReadToEnd()
        } else {
            & $env:ComSpec /c "`"$tempBat`""
        }
    } catch {
        Write-Log "[WARN] Failed to execute uninstall script: $($_.Exception.Message)"
    } finally {
        try { Remove-Item -LiteralPath $tempBat -Force -ErrorAction SilentlyContinue } catch {}
    }

    Write-Log "[OK] Uninstall process completed."
}

# ====================== Flow ================================
$exitCode = 0
try {
    $start = Current-State
    Write-Log "[INFO] Initial state: ServicesPresent=$($start.ServicesPresent) AgentDirExists=$($start.AgentDirExists)"

    $proceed = $true
    if (-not $Quiet) {
        if (-not ($start.ServicesPresent -or $start.AgentDirExists)) {
            Write-Log "[INFO] Nothing detected to uninstall."
        } else {
            $ans = Read-Host "Uninstall ConnectSecure now?  (Press Enter to start, or type N to cancel)"
            $proceed = ([string]::IsNullOrWhiteSpace($ans) -or $ans.Trim().ToUpperInvariant() -eq 'Y')
        }
    }

    $uninstallAttempted = $false
    if ($proceed -and ($start.ServicesPresent -or $start.AgentDirExists)) {
        $uninstallAttempted = $true
        Run-Uninstall
    } elseif (-not $Quiet) {
        Write-Log "[INFO] Uninstall cancelled by user."
    }

    $final = Current-State
    Write-Log "[INFO] Final state: ServicesPresent=$($final.ServicesPresent) AgentDirExists=$($final.AgentDirExists)"

    $removed = (-not $final.ServicesPresent) -and (-not $final.AgentDirExists)

    # ====================== Post-Uninstall Reminder ======================
    if (-not $Quiet -and $uninstallAttempted) {
        Write-Host ""
        Write-Host "ConnectSecure Agent removal is still required from the portal if agents are removed directly from endpoints. This is not required if you are reinstalling." -ForegroundColor Yellow
        [void](Read-Host "Press Enter to acknowledge")
    }
    # ====================================================================

    if ($Quiet) {
        if ($removed) { Write-Output "Removed" } else { Write-Output "Not removed" }
    } else {
        if ($removed) { Write-Host "[OK] Application removed." -ForegroundColor Green }
        else { Write-Host "[WARN] Application still present or partially removed." -ForegroundColor Yellow }
        Write-Host ("Custom log: {0}" -f $logFile) -ForegroundColor DarkGray
        Write-Host ("Transcript:  {0}" -f $transcriptFile) -ForegroundColor DarkGray
        Read-Host -Prompt "Press Enter to exit" | Out-Null
    }

    if (-not $removed) { $exitCode = 2 }
}
catch {
    $exitCode = 1
    if ($Quiet) {
        Write-Output "Not removed"
        try {
            Add-ContentSafe -Path $logFile -Value ("{0} [ERROR] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $_.Exception.Message)
        } catch {}
    } else {
        Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red
        Write-Host ("Custom log: {0}" -f $logFile) -ForegroundColor DarkGray
        Write-Host ("Transcript:  {0}" -f $transcriptFile) -ForegroundColor DarkGray
        Read-Host -Prompt "Press Enter to exit" | Out-Null
    }
}
finally {
    if (-not $Quiet) { try { Stop-Transcript | Out-Null } catch {} }
    # restore prefs
    $ErrorActionPreference = $prev.EAP
    $WarningPreference     = $prev.W
    $VerbosePreference     = $prev.V
    $InformationPreference = $prev.I
    $ProgressPreference    = $prev.P
    exit $exitCode
}
