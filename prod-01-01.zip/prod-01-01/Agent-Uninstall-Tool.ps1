<#
.SYNOPSIS
  ConnectSecure Agent Uninstall Tool + Deep Clean Scan (Merged) + HARD handle cleanup (logged)

  Fix in this version:
    - Handle folder cleanup runs and logs BEFORE any "Press Enter to exit" prompt.
    - You will ALWAYS see log lines beginning with: "HANDLE FINAL:"
#>

#requires -version 5.1
[CmdletBinding()]
param(
    [switch]$Quiet,
    [switch]$ExportOnly
)

Set-StrictMode -Version Latest
$ProgressPreference = 'SilentlyContinue'

# ====================== Setup / Logging ======================
$script:QuietMode = [bool]$Quiet

$hostname  = $env:COMPUTERNAME
$exportDir = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path -LiteralPath $exportDir)) {
    New-Item -Path $exportDir -ItemType Directory -Force | Out-Null
}

function New-UniquePath {
    param([Parameter(Mandatory)] [string]$BasePath)
    if (-not (Test-Path -LiteralPath $BasePath)) { return $BasePath }
    $dir  = [IO.Path]::GetDirectoryName($BasePath)
    $name = [IO.Path]::GetFileNameWithoutExtension($BasePath)
    $ext  = [IO.Path]::GetExtension($BasePath)
    for ($i=1; $i -le 999; $i++) {
        $candidate = Join-Path $dir ("{0}-{1:D3}{2}" -f $name, $i, $ext)
        if (-not (Test-Path -LiteralPath $candidate)) { return $candidate }
    }
    throw "Unable to allocate a unique log path for $BasePath"
}

$stamp = Get-Date -Format "yyyy-MM-dd_HHmmss"
$baseLog        = Join-Path $exportDir "$hostname-AgentUninstall-DeepClean-$stamp.log"
$baseTranscript = Join-Path $exportDir "$hostname-AgentUninstall-DeepClean-$stamp.transcript.txt"

$script:LogFile        = New-UniquePath -BasePath $baseLog
$script:TranscriptFile = New-UniquePath -BasePath $baseTranscript

try { "" | Out-File -FilePath $script:LogFile -Encoding UTF8 -Force } catch {}

$script:PrevPrefs = @{
  EAP  = $ErrorActionPreference
  W    = $WarningPreference
  V    = $VerbosePreference
  I    = $InformationPreference
  P    = $ProgressPreference
}

if ($script:QuietMode) {
  $ErrorActionPreference   = 'SilentlyContinue'
  $WarningPreference       = 'SilentlyContinue'
  $VerbosePreference       = 'SilentlyContinue'
  $InformationPreference   = 'SilentlyContinue'
  $ProgressPreference      = 'SilentlyContinue'
} else {
  $ErrorActionPreference = 'Stop'
  try { Start-Transcript -Path $script:TranscriptFile -Append | Out-Null } catch {}
}

function Add-ContentSafe {
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$Value)
    for ($i=0; $i -lt 3; $i++) {
        try { Add-Content -LiteralPath $Path -Value $Value -Encoding UTF8; return }
        catch { Start-Sleep -Milliseconds 200; if ($i -eq 2) { throw } }
    }
}

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    $line = "{0} [{1}] {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    try { Add-ContentSafe -Path $script:LogFile -Value $line } catch {}
    if (-not $script:QuietMode) { Write-Host $line }
}

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# ====================== Targets ======================
$script:AgentDir         = "C:\Program Files (x86)\CyberCNSAgent"
$script:UninstallBatPath = Join-Path $script:AgentDir "uninstall.bat"

$script:HandleZipUrl   = 'https://download.sysinternals.com/files/Handle.zip'
$script:HandleWorkRoot = 'C:\CS-Toolbox-TEMP\prod-01-01\handle'

$script:EmbeddedUninstallBat = @'
@echo off
ping 127.0.0.1 -n 6 > nul
cd "C:\PROGRA~2"
sc stop ConnectSecureAgentMonitor
timeout /T 5 > nul
sc delete ConnectSecureAgentMonitor
timeout /T 5 > nul
sc stop CyberCNSAgent
timeout /T 5 > nul
sc delete CyberCNSAgent
ping 127.0.0.1 -n 6 > nul
taskkill /IM osqueryi.exe /F
taskkill /IM nmap.exe /F
taskkill /IM cyberutilities.exe /F
CyberCNSAgent\cybercnsagent.exe --internalAssetArgument uninstallservice
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f
rmdir CyberCNSAgent /s /q
'@

# ====================== ExportOnly ======================
if ($ExportOnly) {
    $outPath = Join-Path $exportDir 'agent-uninstall-deepclean-export.json'
    [ordered]@{
        Script         = 'Agent-Uninstall-DeepClean-Merged.ps1'
        Timestamp      = (Get-Date).ToString('o')
        AgentDir       = $script:AgentDir
        HandleWorkRoot = $script:HandleWorkRoot
        LogFile        = $script:LogFile
        Transcript     = $script:TranscriptFile
    } | ConvertTo-Json -Depth 6 | Set-Content -Path $outPath -Encoding UTF8
    Write-Host "Exported: $outPath"
    exit 0
}

# ====================== State helpers ======================
function Any-ServicePresent {
    foreach ($n in @('CyberCNSAgent','CyberCNSAgentMonitor','ConnectSecureAgentMonitor')) {
        if (Get-Service -Name $n -ErrorAction SilentlyContinue) { return $true }
    }
    return $false
}

function Current-State {
    [PSCustomObject]@{
        ServicesPresent = (Any-ServicePresent)
        AgentDirExists  = (Test-Path -LiteralPath $script:AgentDir)
    }
}

function Ensure-Tls12 {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072 } catch {}
}

function Ensure-HandleExe {
    $staged = Join-Path $script:HandleWorkRoot 'handle.exe'
    if (Test-Path -LiteralPath $staged) { return $staged }

    $cmd = Get-Command handle.exe -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { return $cmd.Source }

    try {
        Ensure-Tls12
        New-Item -ItemType Directory -Path $script:HandleWorkRoot -Force | Out-Null

        $zipPath = Join-Path $script:HandleWorkRoot 'Handle.zip'
        $extractDir = Join-Path $script:HandleWorkRoot '_extract'

        Write-Log "handle.exe not found; downloading Handle.zip..." "WARN"
        Invoke-WebRequest -Uri $script:HandleZipUrl -OutFile $zipPath -UseBasicParsing -ErrorAction Stop

        if (Test-Path -LiteralPath $extractDir) {
            Remove-Item -LiteralPath $extractDir -Recurse -Force -ErrorAction SilentlyContinue
        }
        New-Item -ItemType Directory -Path $extractDir -Force | Out-Null
        Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force

        $extracted = Get-ChildItem -LiteralPath $extractDir -Recurse -Filter 'handle.exe' -ErrorAction SilentlyContinue |
                     Select-Object -First 1
        if (-not $extracted) { Write-Log "Downloaded Handle.zip but handle.exe not found inside." "ERROR"; return $null }

        Copy-Item -LiteralPath $extracted.FullName -Destination $staged -Force -ErrorAction Stop
        Write-Log "Downloaded and staged handle.exe at: $staged" "OK"
        return $staged
    } catch {
        Write-Log ("Failed to download/extract handle.exe: {0}" -f $_.Exception.Message) "WARN"
        return $null
    }
}

function Kill-LockingProcesses {
    param([Parameter(Mandatory)][string]$PathToUnlock)

    $handleExe = Ensure-HandleExe
    if (-not $handleExe) { Write-Log "handle.exe unavailable; cannot enumerate locking handles." "WARN"; return @() }

    Write-Log ("Scanning for locking handles: {0}" -f $PathToUnlock) "WARN"

    $pids = New-Object System.Collections.Generic.HashSet[int]
    try {
        $out = & $handleExe -accepteula -nobanner "$PathToUnlock" 2>$null
        foreach ($line in $out) {
            if ($line -match '\spid:\s*(\d+)\s') { [void]$pids.Add([int]$Matches[1]) }
        }
    } catch {
        Write-Log ("handle.exe scan failed: {0}" -f $_.Exception.Message) "WARN"
        return @()
    }

    if ($pids.Count -eq 0) { Write-Log "No locking PIDs reported (may be driver/EDR lock)." "WARN"; return @() }

    $pidList = ($pids | Sort-Object)
    Write-Log ("Locking PIDs: {0}" -f ($pidList -join ', ')) "WARN"

    foreach ($lockerPid in $pidList) {
        try { Stop-Process -Id $lockerPid -Force -ErrorAction SilentlyContinue } catch {}
    }

    Start-Sleep -Seconds 2
    return $pidList
}

function Force-Remove-ServiceHard {
    param([Parameter(Mandatory)][string]$ServiceName)
    Write-Log ("FORCE service removal: {0}" -f $ServiceName)
    try { sc.exe stop $ServiceName | Out-Null } catch {}
    try { sc.exe delete $ServiceName | Out-Null } catch {}
    $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"
    try { if (Test-Path -LiteralPath $svcKey) { Remove-Item -LiteralPath $svcKey -Recurse -Force -ErrorAction SilentlyContinue } } catch {}
}

function Force-DeleteFolderWithLockHunt {
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { return $true }

    try { cmd.exe /c "takeown /f `"$Path`" /r /d y" | Out-Null } catch {}
    try { cmd.exe /c "icacls `"$Path`" /grant *S-1-5-32-544:F /t /c" | Out-Null } catch {}

    for ($i=1; $i -le 5; $i++) {
        try {
            Write-Log ("Delete attempt {0}: hunting lockers..." -f $i) "WARN"
            Kill-LockingProcesses -PathToUnlock $Path | Out-Null
            Write-Log ("Delete attempt {0}: Remove-Item -Recurse -Force" -f $i) "WARN"
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            return $true
        } catch {
            Start-Sleep -Seconds 2
        }
    }
    return (-not (Test-Path -LiteralPath $Path))
}

function Run-Uninstall {
    Write-Log "Starting uninstall process..."

    $agentExe = Join-Path $script:AgentDir 'cybercnsagent.exe'
    if (Test-Path -LiteralPath $agentExe) {
        Write-Log "Triggering uninstall via cybercnsagent.exe -r"
        try { & $agentExe -r > $null 2>&1 } catch {}
        Start-Sleep -Seconds 5
    }

    $useLocal = $false
    if (Test-Path -LiteralPath $script:UninstallBatPath) {
        try { $null = Get-Content -LiteralPath $script:UninstallBatPath -Raw -ErrorAction Stop; $useLocal = $true } catch { $useLocal = $false }
    }

    $tempBat = Join-Path $env:TEMP "_agent_uninstall.bat"
    try {
        if ($useLocal) {
            Write-Log ("Using LOCAL uninstall.bat: {0}" -f $script:UninstallBatPath)
            & $env:ComSpec /c "`"$($script:UninstallBatPath)`"" | Out-Null
        } else {
            Write-Log "Local uninstall.bat missing/unreadable; using EMBEDDED uninstall.bat copy" "WARN"
            $script:EmbeddedUninstallBat | Out-File -FilePath $tempBat -Encoding ASCII -Force
            & $env:ComSpec /c "`"$tempBat`"" | Out-Null
        }
    } catch {
        Write-Log ("Failed to execute uninstall script: {0}" -f $_.Exception.Message) "WARN"
    } finally {
        try { Remove-Item -LiteralPath $tempBat -Force -ErrorAction SilentlyContinue } catch {}
    }

    Write-Log "Uninstall process completed." "OK"
}

function Run-DeepClean {
    Write-Log "Deep clean scan starting..." "WARN"
    foreach ($svc in @('CyberCNSAgent','CyberCNSAgentMonitor','ConnectSecureAgentMonitor')) {
        Force-Remove-ServiceHard -ServiceName $svc
    }
    if (Test-Path -LiteralPath $script:AgentDir) {
        [void](Force-DeleteFolderWithLockHunt -Path $script:AgentDir)
    }
    Write-Log "Deep clean scan completed." "OK"
}

# ====================== Handle folder cleanup (VISIBLE IN LOG) ======================
function Purge-HandleFolderNow {
    param([Parameter(Mandatory)][string]$Path)

    Write-Log ("HANDLE FINAL: attempting to remove {0}" -f $Path) "WARN"

    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Log "HANDLE FINAL: folder not present." "OK"
        return
    }

    # move away so we can delete
    try {
        Write-Log "HANDLE FINAL: Set-Location C:\Windows\System32" "WARN"
        Set-Location -Path $env:WINDIR\System32 -ErrorAction SilentlyContinue
    } catch {}

    # kill handle.exe
    try {
        Get-Process -Name 'handle' -ErrorAction SilentlyContinue | ForEach-Object {
            Write-Log ("HANDLE FINAL: killing handle.exe PID {0}" -f $_.Id) "WARN"
            try { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue } catch {}
        }
    } catch {}

    # takeown + icacls
    try { cmd.exe /c "takeown /f `"$Path`" /r /d y" | Out-Null } catch {}
    try { cmd.exe /c "icacls `"$Path`" /grant *S-1-5-32-544:F /t /c" | Out-Null } catch {}

    # delete known items then folder
    foreach ($t in @((Join-Path $Path '_extract'), (Join-Path $Path 'Handle.zip'), (Join-Path $Path 'handle.exe'))) {
        if (Test-Path -LiteralPath $t) {
            Write-Log ("HANDLE FINAL: removing {0}" -f $t) "WARN"
            try { Remove-Item -LiteralPath $t -Recurse -Force -ErrorAction SilentlyContinue } catch {}
        }
    }

    for ($i=1; $i -le 10; $i++) {
        Write-Log ("HANDLE FINAL: removing folder attempt {0}" -f $i) "WARN"
        try { Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue } catch {}
        try { cmd.exe /c "rd /s /q `"$Path`"" | Out-Null } catch {}
        if (-not (Test-Path -LiteralPath $Path)) {
            Write-Log "HANDLE FINAL: folder removed." "OK"
            return
        }
        Start-Sleep -Milliseconds 400
    }

    # RunOnce fallback
    if (Test-Path -LiteralPath $Path) {
        $stamp2 = Get-Date -Format 'yyyyMMdd_HHmmss'
        Write-Log "HANDLE FINAL: still present; staging RunOnce deletion." "WARN"
        try {
            $runOnceKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce'
            $cmd = "cmd.exe /c cd /d %windir%\system32 & taskkill /f /im handle.exe >nul 2>&1 & takeown /f `"$Path`" /r /d y & icacls `"$Path`" /grant *S-1-5-32-544:F /t /c & rd /s /q `"$Path`""
            New-Item -Path $runOnceKey -Force | Out-Null
            New-ItemProperty -Path $runOnceKey -Name ("ForceDelete_HandleFolder_$stamp2") -Value $cmd -PropertyType String -Force | Out-Null
        } catch {}
    }
}

# ====================== Main ======================
$exitCode = 0
$uiNeedsPauseAtEnd = $false

try {
    if (-not (Test-Admin)) { throw "This script must be run as Administrator." }

    $start = Current-State
    Write-Log ("TargetPath: {0}" -f $script:AgentDir)
    Write-Log ("Initial state: ServicesPresent={0} AgentDirExists={1}" -f $start.ServicesPresent, $start.AgentDirExists)

    $shouldRun = $true
    if (-not $script:QuietMode -and ($start.ServicesPresent -or $start.AgentDirExists)) {
        $ans = Read-Host "Uninstall ConnectSecure now?  (Press Enter to start, or type N to cancel)"
        $shouldRun = ([string]::IsNullOrWhiteSpace($ans) -or $ans.Trim().ToUpperInvariant() -eq 'Y')
        if (-not $shouldRun) { Write-Log "Uninstall cancelled by user." "WARN" }
    }

    if ($shouldRun -and ($start.ServicesPresent -or $start.AgentDirExists)) {
        Run-Uninstall
    } else {
        if (-not ($start.ServicesPresent -or $start.AgentDirExists)) {
            Write-Log "Nothing detected to uninstall."
        }
    }

    $mid = Current-State
    Write-Log ("Post-uninstall state: ServicesPresent={0} AgentDirExists={1}" -f $mid.ServicesPresent, $mid.AgentDirExists)

    if ($mid.ServicesPresent -or $mid.AgentDirExists) {
        Run-DeepClean
    }

    Write-Log "FINAL folder enforcement..." "WARN"
    [void](Force-DeleteFolderWithLockHunt -Path $script:AgentDir)

    $final = Current-State
    Write-Log ("Final state: ServicesPresent={0} AgentDirExists={1}" -f $final.ServicesPresent, $final.AgentDirExists)

    $removed = (-not $final.ServicesPresent) -and (-not $final.AgentDirExists)
    if (-not $removed) { $exitCode = 2 }

    if ($script:QuietMode) {
        if ($removed) { Write-Output "Removed" } else { Write-Output "Not removed" }
    } else {
        if ($removed) { Write-Host "[OK] Application removed." -ForegroundColor Green }
        else { Write-Host "[WARN] Application still present or partially removed. A reboot may be required." -ForegroundColor Yellow }
        Write-Host ("Custom log: {0}" -f $script:LogFile) -ForegroundColor DarkGray
        Write-Host ("Transcript:  {0}" -f $script:TranscriptFile) -ForegroundColor DarkGray
        $uiNeedsPauseAtEnd = $true
    }
}
catch {
    $exitCode = 1
    if ($script:QuietMode) {
        Write-Output "Not removed"
    } else {
        Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red
        $uiNeedsPauseAtEnd = $true
    }
}
finally {
    # ✅ ALWAYS attempt handle folder removal AND LOG IT
    try { Purge-HandleFolderNow -Path $script:HandleWorkRoot } catch {}

    if (-not $script:QuietMode) { try { Stop-Transcript | Out-Null } catch {} }

    $ErrorActionPreference   = $script:PrevPrefs.EAP
    $WarningPreference       = $script:PrevPrefs.W
    $VerbosePreference       = $script:PrevPrefs.V
    $InformationPreference   = $script:PrevPrefs.I
    $ProgressPreference      = $script:PrevPrefs.P

    # ✅ ONLY NOW do we pause for user (after handle purge)
    if ($uiNeedsPauseAtEnd -and -not $script:QuietMode) {
        Write-Host ""
        Write-Host "Cleanup complete (handle folder purge attempted). Press Enter to exit..." -ForegroundColor Yellow
        try { [void](Read-Host) } catch {}
    }

    exit $exitCode
}
