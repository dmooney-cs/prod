<#
.SYNOPSIS
    ConnectSecure Agent Uninstall Tool

.DESCRIPTION
    - Displays service status table for CyberCNSAgent and ConnectSecureAgentMonitor
    - Prompts to uninstall if detected
    - Runs uninstall via cybercnsagent.exe -r, local uninstall.bat, or cached fallback
    - Logs to C:\CS-Toolbox-TEMP\Collected-Info
#>

# ====================== Setup / Logging ======================
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$shortDate = Get-Date -Format "yyyy-MM-dd"
$shortTime = Get-Date -Format "HHmm"
$hostname  = $env:COMPUTERNAME

$exportDir = "C:\CS-Toolbox-TEMP\Collected-Info"
if (-not (Test-Path -LiteralPath $exportDir)) {
    New-Item -Path $exportDir -ItemType Directory -Force | Out-Null
}
$logFile = Join-Path $exportDir "$hostname-AgentUninstall-$shortDate-$shortTime.txt"
try { Start-Transcript -Path $logFile -Append | Out-Null } catch {}

# ====================== Constants ============================
$AgentDir         = "C:\Program Files (x86)\CyberCNSAgent"
$UninstallBatPath = Join-Path $AgentDir "uninstall.bat"

# Single-quoted here-string for safe literal CMD content (no interpolation)
$RawUninstall = @'
@echo off
ping 127.0.0.1 -n 6 > nul
cd "C:\PROGRA~2"
sc stop ConnectSecureAgentMonitor
timeout /T 5 > nul
sc delete ConnectSecureAgentMonitor
timeout /T 5 > nul
sc stop CyberCNSAgent
timeout /T 5 > nul
sc delete CyberCNSAgent
ping 127.0.0.1 -n 6 > nul
taskkill /IM osqueryi.exe /F
taskkill /IM nmap.exe /F
taskkill /IM cyberutilities.exe /F
if exist "CyberCNSAgent\cybercnsagent.exe" CyberCNSAgent\cybercnsagent.exe --internalAssetArgument uninstallservice
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f
rmdir "CyberCNSAgent" /s /q
'@

# ====================== Helpers ==============================
function Get-ServiceRow {
    param([Parameter(Mandatory=$true)][string]$Name)

    $svc = Get-Service -Name $Name -ErrorAction SilentlyContinue
    if ($null -eq $svc) {
        return [PSCustomObject]@{
            Service   = $Name
            Installed = 'No'
            Status    = 'Not Installed'
            StartType = 'N/A'
        }
    }

    $startMode = 'Unknown'
    try {
        $wmi = Get-WmiObject -Class Win32_Service -Filter ("Name='{0}'" -f $Name) -ErrorAction SilentlyContinue
        if ($wmi -and $wmi.StartMode) { $startMode = $wmi.StartMode }
    } catch {}

    return [PSCustomObject]@{
        Service   = $Name
        Installed = 'Yes'
        Status    = $svc.Status.ToString()
        StartType = $startMode
    }
}

function Show-ServicesTable {
    $rows = @(
        Get-ServiceRow -Name 'CyberCNSAgent'
        Get-ServiceRow -Name 'ConnectSecureAgentMonitor'
    )
    Write-Host ""
    Write-Host "=== ConnectSecure Services ===" -ForegroundColor Cyan
    $rows | Format-Table Service, Installed, Status, StartType -AutoSize | Out-Host
    return ,$rows
}

function Any-ServicePresent {
    $svc1 = Get-Service -Name 'CyberCNSAgent' -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name 'ConnectSecureAgentMonitor' -ErrorAction SilentlyContinue
    return ($svc1 -ne $null -or $svc2 -ne $null)
}

function Run-Uninstall {
    Write-Host ""
    Write-Host "[INFO] Starting uninstall process..." -ForegroundColor Yellow

    # 1) Try agent binary trigger
    $agentExe = Join-Path $AgentDir 'cybercnsagent.exe'
    if (Test-Path -LiteralPath $agentExe) {
        Write-Host "[INFO] Triggering uninstall via cybercnsagent.exe -r" -ForegroundColor Cyan
        try { & $agentExe -r } catch { Write-Host ("[WARN] cybercnsagent.exe -r failed: {0}" -f $_.Exception.Message) -ForegroundColor Yellow }
        Start-Sleep -Seconds 5
    }

    # 2) Load local uninstall.bat or 3) fallback
    $uninstallScript = $null
    if (Test-Path -LiteralPath $UninstallBatPath) {
        Write-Host "[INFO] Using local uninstall.bat" -ForegroundColor Green
        try { $uninstallScript = Get-Content -LiteralPath $UninstallBatPath -Raw -ErrorAction Stop } catch { $uninstallScript = $null }
    }
    if (-not $uninstallScript) {
        Write-Host "[WARN] uninstall.bat not found or unreadable, using built-in fallback" -ForegroundColor Yellow
        $uninstallScript = $RawUninstall
    }

    # Write to temp and execute with cmd
    $tempBat = Join-Path $env:TEMP "_agent_uninstall.bat"
    try {
        $uninstallScript | Out-File -FilePath $tempBat -Encoding ASCII -Force
        Write-Host "[INFO] Executing uninstall script..." -ForegroundColor Cyan
        cmd /c $tempBat
    } finally {
        Remove-Item -LiteralPath $tempBat -Force -ErrorAction SilentlyContinue
    }

    Write-Host "[OK] Uninstall process completed." -ForegroundColor Green
}

# ====================== Flow ================================
try {
    # 0) Show current services
    $rows = Show-ServicesTable

    if (Any-ServicePresent) {
        # Prompt to uninstall (Enter = proceed)
        $ans = Read-Host "Uninstall ConnectSecure now?  (Press Enter to start, or type N to cancel)"
        if ([string]::IsNullOrWhiteSpace($ans) -or $ans.Trim().ToUpperInvariant() -eq 'Y') {
            Run-Uninstall
            # Show final state
            $null = Show-ServicesTable
        } else {
            Write-Host "[INFO] Uninstall cancelled." -ForegroundColor Yellow
        }
    } else {
        Write-Host "[INFO] No ConnectSecure services detected, nothing to uninstall." -ForegroundColor Yellow
    }

    Read-Host -Prompt "Press Enter to exit"
}
catch {
    Write-Host ("[ERROR] {0}" -f $_.Exception.Message) -ForegroundColor Red
    Read-Host -Prompt "Press Enter to exit"
}
finally {
    try { Stop-Transcript | Out-Null } catch {}
    Write-Host ("Log file saved to: {0}" -f $logFile) -ForegroundColor DarkGray
}
