# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧹 CS Toolbox – Agent Uninstall Tool (Improved Version)     ║
# ╚═════════════════════════════════════════════════════════════╝

function Run-AgentUninstall {
    Show-Header "Uninstall CyberCNS Agent"

    $ts = Get-Date -Format "yyyyMMdd_HHmmss"
    $hn = $env:COMPUTERNAME
    $log = @()
    $baseName = "AgentUninstallLog_$ts`_$hn"
    $txtPath = "C:\CS-Toolbox-TEMP\Collected-Info\$baseName.txt"
    Start-Transcript -Path $txtPath -Append

    $batTarget = "C:\CS-Toolbox-TEMP\Collected-Info\uninstall.bat"
    $batLocalSource = "C:\Program Files (x86)\CyberCNSAgent\uninstall.bat"

    Write-Host "`n🧪 Step 1/3: Preparing uninstall batch..." -ForegroundColor Cyan

    if (Test-Path $batLocalSource) {
        Copy-Item $batLocalSource $batTarget -Force
        Write-Host "🗂️ uninstall.bat copied from agent folder." -ForegroundColor Yellow
        $log += [PSCustomObject]@{ Step = "Copy Local Uninstaller"; Status = "Copied"; Source = $batLocalSource; Time = (Get-Date) }
    } else {
        try {
            # Replace with real backup URL if hosted in future
            $backupUrl = "https://example.com/uninstall.bat"
            Invoke-WebRequest -Uri $backupUrl -OutFile $batTarget -UseBasicParsing -ErrorAction Stop
            Write-Host "🗂️ uninstall.bat downloaded from fallback URL." -ForegroundColor Yellow
            $log += [PSCustomObject]@{ Step = "Download Uninstaller"; Status = "Downloaded"; URL = $backupUrl; Time = (Get-Date) }
        } catch {
            Write-Host "⚠️  Failed to fetch from URL. Writing default uninstall.bat..." -ForegroundColor Yellow
            $batContent = @"
@echo off
ping 127.0.0.1 -n 6 > nul
cd "C:\PROGRA~2"
sc stop ConnectSecureAgentMonitor
timeout /T 5 > nul
sc delete ConnectSecureAgentMonitor
timeout /T 5 > nul
sc stop CyberCNSAgent
timeout /T 5 > nul
sc delete CyberCNSAgent
ping 127.0.0.1 -n 6 > nul
taskkill /IM osqueryi.exe /F
taskkill /IM nmap.exe /F
taskkill /IM cyberutilities.exe /F
CyberCNSAgent\cybercnsagent.exe --internalAssetArgument uninstallservice
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f
reg delete "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\ConnectSecure Agent" /f
rmdir CyberCNSAgent /s /q
"@
            $batContent | Out-File -FilePath $batTarget -Encoding ASCII -Force
            Write-Host "🗂️ uninstall.bat created from local backup." -ForegroundColor Yellow
            $log += [PSCustomObject]@{ Step = "Fallback Uninstaller"; Status = "Written from Cache"; Path = $batTarget; Time = (Get-Date) }
        }
    }

    # Step 2: Run the uninstall
    Write-Host "`n🚀 Step 2/3: Running uninstall script..." -ForegroundColor Cyan
    try {
        cmd.exe /c $batTarget
        Write-Host "✅ Uninstall executed." -ForegroundColor Green
        $log += [PSCustomObject]@{ Step = "Run Uninstaller"; Status = "Completed"; Time = (Get-Date) }
    } catch {
        Write-Host "❌ Error running uninstall script: $_" -ForegroundColor Red
        $log += [PSCustomObject]@{ Step = "Run Uninstaller"; Status = "Failed: $_"; Time = (Get-Date) }
    }

    # Step 3: Cleanup installer
    Write-Host "`n🧹 Step 3/3: Optional cleanup complete." -ForegroundColor Cyan
    Export-Data -Object $log -BaseName $baseName

    Write-Host "`n📄 Transcript saved to: $txtPath"
    Pause-Script "Uninstall process completed. Press any key to return."
    Stop-Transcript
}

Run-AgentUninstall
