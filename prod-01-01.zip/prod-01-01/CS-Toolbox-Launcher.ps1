<# =====================================================================
  ConnectSecure Technicians Toolbox - Launcher
  File: CS-Toolbox-Launcher.ps1
  Updated: 2025-08-12
  Notes:
   - Uses Functions-Common.ps1 (R6) for: Show-Header, Launch-Tool,
     Ensure-ExportFolder, Zip-Results, Email-Results, Write-SessionSummary,
     Invoke-FinalCleanupAndExit, Write-Log, Pause-Script, etc.
   - Menu updated per request:
       [3] Secondary Validation Tools – Patch Audit, VC++ Runtime, TLS/SSL Audit, Registry Uninstall Search
       [4] Windows Modern App Discovery – Enumerate & search Modern/Store apps
===================================================================== #>

# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host ("ERROR: Failed to load Functions-Common.ps1: {0}" -f $_.Exception.Message) -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

#---------------------------
# Hardcoded full paths to sub-tools
#---------------------------
$PathMap = [ordered]@{
    "1" = 'C:\CS-Toolbox-TEMP\prod-01-01\Osquery-Data-Collection.ps1'
    "2" = 'C:\CS-Toolbox-TEMP\prod-01-01\Nmap-Data-Collection.ps1'
    "3" = 'C:\CS-Toolbox-TEMP\prod-01-01\Secondary-Collection-Tool.ps1'          # Secondary bundle
    "4" = 'C:\CS-Toolbox-TEMP\prod-01-01\Windows-Modern-App-Discovery.ps1'       # New script
    "5" = 'C:\CS-Toolbox-TEMP\prod-01-01\ValidationTool-AD.ps1'
    "6" = 'C:\CS-Toolbox-TEMP\prod-01-01\SystemInfo-A.ps1'
    "7" = 'C:\CS-Toolbox-TEMP\prod-01-01\SystemInfo-B.ps1'
    "8" = 'C:\CS-Toolbox-TEMP\prod-01-01\Tools-Utilities.ps1'
    "9" = 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-Menu-Tool.ps1'
}

function Write-Menu {
    Clear-Host
    Show-Header -Title 'ConnectSecure Technicians Toolbox'

    Write-Host ''
    Write-Host ' [1] OSQuery Data Collection      - Apps, search, browser extensions'
    Write-Host ' [2] Nmap Data Collection         - Local network scan profiles'
    Write-Host ' [3] Secondary Validation Tools   - Patch Audit, VC++ Runtime, TLS/SSL Audit, Registry Uninstall Search'
    Write-Host ' [4] Windows Modern App Discovery - Enumerate & search Modern/Store apps'
    Write-Host ' [5] Active Directory Tools       - Users, Groups, OUs, GPOs'
    Write-Host ' [6] System Info A                - Firewall, Defender, Disk/SMART'
    Write-Host ' [7] System Info B                - Pending Reboot, App Logs, Startup'
    Write-Host ' [8] Utilities                    - Services, Disk Space'
    Write-Host ' [9] Agent Menu Tool              - Install, Reinstall, Uninstall'
    Write-Host ''
    Write-Host ' [Z] Zip and Email Results        - Compress results for support'
    Write-Host ' [C] Cleanup and Exit Toolbox'
    Write-Host ''
}

function Invoke-MenuAction {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Choice
    )

    switch -Regex ($Choice.Trim()) {
        '^[1-9]$' {
            $target = $PathMap[$Choice]
            if (-not (Test-Path -LiteralPath $target)) {
                Write-Host ("ERROR: Target script not found: {0}" -f $target) -ForegroundColor Red
                Pause-Script -Message 'Press any key to return to the menu...'
                return $false
            }

            try {
                & $target
            } catch {
                # NOTE: wrap $target to avoid "$target:" parsing
                Write-Host ("ERROR launching {0}: {1}" -f $target, $_.Exception.Message) -ForegroundColor Red
                Pause-Script -Message 'Press any key to return to the menu...'
            }
            return $false
        }

        '^(Z|z)$' {
            try {
                $zipPath = Zip-Results
                Email-Results -ZipPath $zipPath
            } catch {
                Write-Host ("ERROR during Zip/Email: {0}" -f $_.Exception.Message) -ForegroundColor Red
                Pause-Script -Message 'Press any key to return to the menu...'
            }
            return $false
        }

        '^(C|c)$' {
            try { Write-SessionSummary } catch {}
            Invoke-FinalCleanupAndExit
            return $true
        }

        default {
            Write-Host 'Please choose 1-9, Z, or C.' -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
            return $false
        }
    }
}

#---------------------------
# Main loop
#---------------------------
while ($true) {
    Write-Menu
    $choice = Read-Host 'Enter your choice'
    $exitNow = Invoke-MenuAction -Choice $choice
    if ($exitNow) { break }
}
