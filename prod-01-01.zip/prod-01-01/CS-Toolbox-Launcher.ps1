# CS Toolbox Main Launcher with error trap and pause on error
# Place this script in the same folder as all tool scripts and Functions-Common.ps1

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Load the common functions globally for [Z] and [C]
. "$scriptRoot\Functions-Common.ps1"

function Show-MainMenu {
    Clear-Host
    Write-Host ""
    Write-Host "====================================================="
    Write-Host "         ConnectSecure Technicians Toolbox"
    Write-Host "====================================================="
    Write-Host ""
    Write-Host " [1] Validation Tool A         - Office, Drivers, Roaming, Extensions"
    Write-Host " [2] Validation Tool B         - Patches, VC++ Runtime Scanner"
    Write-Host " [3] Validation Tool C         - SSL Ciphers, OSQuery Extensions"
    Write-Host ""
    Write-Host " [4] Network Tools             - TLS 1.0 Scan, Nmap, Validate SMB"
    Write-Host " [5] Active Directory Tools    - Users, Groups, OUs, GPOs"
    Write-Host ""
    Write-Host " [6] System Info A             - Firewall, Defender, Disk/SMART"
    Write-Host " [7] System Info B             - Pending Reboot, App Logs, Startup Audit"
    Write-Host ""
    Write-Host " [8] Utilities                 - Running Services, Disk Space"
    Write-Host ""
    Write-Host " [9] Agent Menu Tool           - Install, Uninstall, Status, Maintenance"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results     - Compress and prepare results for support"
    Write-Host " [C] Cleanup Toolbox Data      - Remove all temp and output files"
    Write-Host " [Q] Quit"
    Write-Host ""
}

trap {
    Write-Host "`n*** ERROR OCCURRED ***" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    break
}

try {
    do {
        Show-MainMenu
        $choice = Read-Host "Enter your choice"
        switch ($choice.ToUpper()) {
            '1' { . "$scriptRoot\ValidationTool-Collection A.ps1" }
            '2' { . "$scriptRoot\ValidationTool-Collection B.ps1" }
            '3' { . "$scriptRoot\ValidationTool-Collection C.ps1" }
            '4' { . "$scriptRoot\Network-Tools.ps1" }
            '5' { . "$scriptRoot\ValidationTool-AD.ps1" }
            '6' { . "$scriptRoot\SystemInfo-A.ps1" }
            '7' { . "$scriptRoot\SystemInfo-B.ps1" }
            '8' { . "$scriptRoot\Tools-Utilities.ps1" }
            '9' { . "$scriptRoot\Agent-Menu-Tool.ps1" }
            'Z' { Run-ZipAndEmailResults }
            'C' { Run-CleanupExportFolder }
            'Q' { 
                Write-Host "`nExiting CS Toolbox..."
                Pause-Script
                break 
            }
            default {
                Write-Host "Invalid selection. Try again."
                Pause-Script
            }
        }
    } while ($true)
}
catch {
    Write-Host "`n*** FATAL ERROR ***" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
