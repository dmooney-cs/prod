<# ========================================================================
  CS-Toolbox-Launcher.ps1  (All-in-One Menu Framework, Colored Header)
  Version: AAMenu-Short-v1.16 (2025-12-02, compact + console-size)
========================================================================= #>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------- Configurable Roots ----------------
if (-not (Get-Variable -Name CS_ToolRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_ToolRoot = Split-Path -Parent $PSCommandPath
}
if (-not (Get-Variable -Name CS_TempRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_TempRoot = Join-Path $env:SystemDrive 'CS-Toolbox-TEMP'
}
if (-not (Get-Variable -Name CS_ScriptSearchRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_ScriptSearchRoot = $script:CS_ToolRoot
}

# Mirror paths globally
$global:CS_ToolRoot         = $script:CS_ToolRoot
$global:CS_TempRoot         = $script:CS_TempRoot
$global:CS_ScriptSearchRoot = $script:CS_ScriptSearchRoot
$global:CSLauncherRoot      = $script:CS_ToolRoot

$script:ExitTool = $false

# ---------------- Script Name Registry ----------------
$ScriptNames = [ordered]@{
    AgentActions_MenuLabel         = 'ConnectSecure Agent Actions'
    LogTools_MenuLabel             = 'ConnectSecure Log Tools'
    NetworkValidation_MenuLabel    = 'Network Validation'
    PackageLogs_MenuLabel          = 'Package Logs and Collected Information'
    SoftwareValidation_MenuLabel   = 'Validate Installed Software'
    WindowsUtilities_MenuLabel     = 'Windows Machine Utilities'

    # Agent Tools
    Agent_InstallOrReinstall       = 'Agent-Install-Tool.ps1'
    Agent_Uninstall                = 'Agent-Uninstall-Tool.ps1'
    Agent_Update                   = 'Agent-Update-Tool.ps1'

    # Log Tools
    Agent_LogReview                = 'Agent-Log-Review.ps1'
    Agent_JobReview                = 'Agent-Job-Review.ps1'
    Agent_MessageCorrelator        = 'Agent-msg-Correlator.ps1'
    Agent_LogCorrelator            = 'Agent-Log-Correlator.ps1'

    # Network Validation
    NetworkValidation              = 'NMAP-Data-Collection.ps1'
    TLS_DataCollection             = 'tls-data-collection.ps1'

    # Software Validation
    Software_AppRegistrySearch     = 'Registry-Search.ps1'
    Software_BrowserExtensions     = 'Browser-Extensions-Details.ps1'
    Software_StaleProfileScan      = 'Windows-UserProfile-AppSweep.ps1'
    Software_ValidatedApps         = 'Osquery-Data-Collection.ps1'
    Software_StoreApps             = 'Windows-Modern-App-Discovery.ps1'
    Software_WindowsUpdate         = 'Windows-Update-Details.ps1'

    # Windows Utilities
    WinUtil_ADValidation           = 'Active-Directory-Tools.ps1'
    WinUtil_DependencyValidation   = 'Dependency-Validation-Tools.ps1'
    WinUtil_MachineUtilities       = 'Machine-Utilities.ps1'
    WinUtil_SystemInfoA            = 'SystemInfo-A.ps1'
    WinUtil_SystemInfoB            = 'SystemInfo-B.ps1'
    WinUtil_AppCleanup             = 'Application-Cleanup-Script.ps1'

    # Other
    ExitAndCleanup                 = 'Toolbox-Cleanup-SelfDestruct.ps1'
    PackageLogs                    = 'zip-encrypt-htmltemplate.ps1'
}

# ---------------- Helpers ----------------
function Ensure-ExportFolder {
    param([string]$Path)
    if (-not (Test-Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
    return (Resolve-Path $Path).Path
}

function Preflight-Unblock {
    param([string]$Root = $script:CS_ToolRoot)
    Get-ChildItem -LiteralPath $Root -Recurse -File |
        ForEach-Object { try { Unblock-File -LiteralPath $_.FullName } catch {} }
}

function Get-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        return (New-Object Security.Principal.WindowsPrincipal($id)).
            IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Set-ConsoleSize {
    <#
        Hard-coded console sizing tuned for your menu:
        Width: 110 columns
        Height: 34 rows
    #>
    try {
        if (-not $Host.UI -or -not $Host.UI.RawUI) { return }

        $raw  = $Host.UI.RawUI
        $buf  = $raw.BufferSize
        $win  = $raw.WindowSize

        $targetWidth  = 110
        $targetHeight = 34

        # Buffer must be >= window
        if ($buf.Width  -lt $targetWidth)  { $buf.Width  = $targetWidth }
        if ($buf.Height -lt 1000)          { $buf.Height = 1000 }
        $raw.BufferSize = $buf

        $win.Width  = $targetWidth
        $win.Height = $targetHeight
        $raw.WindowSize = $win
    }
    catch { }
}


function Show-TopHeader {
    param([string]$SectionTitle = $null)

    Clear-Host
    $hostName = $env:COMPUTERNAME
    $userName = ([Security.Principal.WindowsIdentity]::GetCurrent().Name)
    $isAdmin  = Get-IsAdmin
    $line     = ('=' * 58)

    Write-Host ""
    Write-Host " ConnectSecure Technicians Toolbox  - Launcher v1.16" -ForegroundColor Cyan
    Write-Host " $line" -ForegroundColor DarkGray
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, $isAdmin) -ForegroundColor Gray
    Write-Host (" Base: {0}" -f $script:CS_ToolRoot) -ForegroundColor Gray
    Write-Host " $line" -ForegroundColor DarkGray

    if ($SectionTitle) {
        Write-Host " $SectionTitle" -ForegroundColor White
        Write-Host ""
    }
}

function Footer-Prompt([string]$OptionsDisplay) {
    Write-Host ""
    Write-Host ("Press ({0}) to make your selection." -f $OptionsDisplay) -ForegroundColor DarkGray
}

function Write-Warn($m){ Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function Write-Info($m){ Write-Host "[INFO]  $m" -ForegroundColor Cyan }
function Write-ErrorMsg($m){ Write-Host "[ERROR] $m" -ForegroundColor Red }

function Resolve-ToolScript {
    param([string]$FileName)

    # Absolute path?
    if ([System.IO.Path]::IsPathRooted($FileName)) {
        if (Test-Path $FileName) {
            return Get-Item $FileName
        }
        Write-Warn "Absolute path not found: $FileName"
        return $null
    }

    # Search locally in toolbox folder
    $hit = Get-ChildItem -Path $script:CS_ScriptSearchRoot -Recurse -File -Filter $FileName -ErrorAction SilentlyContinue |
            Select-Object -First 1

    if (-not $hit) {
        $hit = Get-ChildItem -Path $script:CS_ScriptSearchRoot -Recurse -File |
               Where-Object { $_.Name -ieq $FileName } | Select-Object -First 1
    }

    if (-not $hit) {
        Write-Warn "Could not resolve '$FileName' under $script:CS_ScriptSearchRoot"
    }

    return $hit
}

function Launch-Tool {
    param(
        [string]$FileName,
        [string[]]$Args = @(),
        [switch]$PauseAfter
    )

    $scriptFile = Resolve-ToolScript $FileName
    if (-not $scriptFile) {
        Write-ErrorMsg "Tool not found: $FileName"
        Read-Host "Press Enter to return"
        return
    }

    Write-Info "Launching: $($scriptFile.FullName)"
    try {
        Unblock-File $scriptFile.FullName -ErrorAction SilentlyContinue
        & $scriptFile.FullName @Args
    }
    catch {
        Write-ErrorMsg $_.Exception.Message
        Read-Host "Press Enter to return"
    }

    if ($PauseAfter) {
        Read-Host "Press Enter to return"
    }
}

# ---------------- Menus ----------------

# 1) Agent Actions (compact)
function Show-AgentActionsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.AgentActions_MenuLabel
    Write-Host " You are in: ConnectSecure Agent Actions" -ForegroundColor Yellow
    Write-Host ""

    Write-Host " 1) Install or Reinstall Agent" -ForegroundColor White
    Write-Host "    Detects, downloads, installs, and verifies the agent." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Uninstall Agent (with Portal Reminder)" -ForegroundColor White
    Write-Host "    Clean removal of the agent with reminder to clean up in the portal." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Update Agent" -ForegroundColor White
    Write-Host "    Triggers an agent update using the ConnectSecure updater." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/3/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.Agent_InstallOrReinstall }
        '2' { Launch-Tool $ScriptNames.Agent_Uninstall }
        '3' { Launch-Tool $ScriptNames.Agent_Update -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

# 2) Log Tools (compact)
function Show-LogToolsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.LogTools_MenuLabel
    Write-Host " You are in: ConnectSecure Log Tools" -ForegroundColor Yellow
    Write-Host ""

    Write-Host " 1) Agent Error Review / Analyzer - Single-Agent" -ForegroundColor White
    Write-Host "    Parse agent logs for errors/warnings and export to HTML." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_LogReview) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Agent Job Review / Analyzer - Single-Agent" -ForegroundColor White
    Write-Host "    Group job runs, show last success/issue, and export summary." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_JobReview) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Agent Message Correlator - Single-Agent" -ForegroundColor White
    Write-Host "    Correlate message logs to find repeating patterns and issues." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_MessageCorrelator) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Agent Log Correlator / Analyzer - Multi-Agent" -ForegroundColor White
    Write-Host "    Multi-agent log correlation, grouped errors, and HTML export." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_LogCorrelator) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/3/4/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.Agent_LogReview }
        '2' { Launch-Tool $ScriptNames.Agent_JobReview }
        '3' { Launch-Tool $ScriptNames.Agent_MessageCorrelator -PauseAfter }
        '4' { Launch-Tool $ScriptNames.Agent_LogCorrelator -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

# 3) Exit & Cleanup (compact behavior)
function Invoke-ExitAndCleanup {
    Show-TopHeader -SectionTitle "Exit and Cleanup"
    Launch-Tool $ScriptNames.ExitAndCleanup
    $script:ExitTool = $true
}

# 4) Network Validation (compact)
function Show-NetworkValidationMenu {
    Show-TopHeader -SectionTitle $ScriptNames.NetworkValidation_MenuLabel

    Write-Host " 1) Scan Networks or Local Machine" -ForegroundColor White
    Write-Host "    Run NMAP-based scans against hosts or ranges." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.NetworkValidation) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) TLS/SSL Policy (Local Host)" -ForegroundColor White
    Write-Host "    Collect SCHANNEL/TLS configuration from the local machine." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.TLS_DataCollection) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.NetworkValidation }
        '2' { Launch-Tool $ScriptNames.TLS_DataCollection -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

# 5) Package Logs & Collected Info (compact)
function Show-PackageLogsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.PackageLogs_MenuLabel

    Write-Host " 1) Packager / Encrypt Helper" -ForegroundColor White
    Write-Host "    Zip and optionally encrypt toolbox logs/outputs." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.PackageLogs) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.PackageLogs }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

# 6) Validate Installed Software (compact + your requested change)
function Show-SoftwareValidationMenu {
    Show-TopHeader -SectionTitle $ScriptNames.SoftwareValidation_MenuLabel
    Write-Host " You are in: Validate Installed Software" -ForegroundColor Yellow
    Write-Host ""

    # 1 — Registry Search
    Write-Host " 1) Application Registry Search" -ForegroundColor White
    Write-Host "    Search uninstall registry hives (HKLM/HKCU) for apps and export results." -ForegroundColor DarkGray
    Write-Host ""

    # 2 — Browser Extension Details
    Write-Host " 2) Browser Extension Details" -ForegroundColor White
    Write-Host "    Enumerate installed browser extensions per user (Chrome/Edge/Firefox)." -ForegroundColor DarkGray
    Write-Host ""

    # 3 — Stale Profile Scan
    Write-Host " 3) Stale Profile Application Scan" -ForegroundColor White
    Write-Host "    Scan user profiles for large/old application data to target for cleanup." -ForegroundColor DarkGray
    Write-Host ""

    # 4 — Validate Installed Software (osquery)
    Write-Host " 4) Validate Installed Software (osquery)" -ForegroundColor White
    Write-Host "    Use osquery to inventory installed software in a normalized export." -ForegroundColor DarkGray
    Write-Host ""

    # 5 — Windows Store Apps
    Write-Host " 5) Windows Store Application Inventory" -ForegroundColor White
    Write-Host "    List UWP/AppX packages with name, version, and scope." -ForegroundColor DarkGray
    Write-Host ""

    # 6 — Windows Update Details
    Write-Host " 6) Windows Update Details" -ForegroundColor White
    Write-Host "    Show Windows Update history with KB, date, category, and status." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back to Main Menu" -ForegroundColor White
    Footer-Prompt "1/2/3/4/5/6/B"

    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.Software_AppRegistrySearch }
        '2' { Launch-Tool $ScriptNames.Software_BrowserExtensions }
        '3' { Launch-Tool $ScriptNames.Software_StaleProfileScan }
        '4' { Launch-Tool $ScriptNames.Software_ValidatedApps }
        '5' { Launch-Tool $ScriptNames.Software_StoreApps }
        '6' { Launch-Tool $ScriptNames.Software_WindowsUpdate }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

# 7) Windows Machine Utilities (compact)
function Show-WindowsUtilitiesMenu {
    Show-TopHeader -SectionTitle $ScriptNames.WindowsUtilities_MenuLabel

    Write-Host " 1) Active Directory Collection / Validation" -ForegroundColor White
    Write-Host "    Run AD data collectors for users, computers, OUs, and GPOs." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_ADValidation) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Dependency Validation Tools" -ForegroundColor White
    Write-Host "    Check runtimes, DLLs, and OS features required by ConnectSecure." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_DependencyValidation) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Machine Utilities - Services & Disk Space" -ForegroundColor White
    Write-Host "    Review key services and disk utilization for health issues." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_MachineUtilities) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) System Info A - Firewall, Defender, SMART" -ForegroundColor White
    Write-Host "    Collect basic protection and disk health information." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_SystemInfoA) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 5) System Info B - Reboot, Startup, Logs" -ForegroundColor White
    Write-Host "    Show reboot state, startup load, and key event log snippets." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_SystemInfoB) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 6) Windows Application - Cleanup S&D" -ForegroundColor White
    Write-Host "    Guided application removal and leftover cleanup with logging." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_AppCleanup) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/3/4/5/6/B"

    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.WinUtil_ADValidation }
        '2' { Launch-Tool $ScriptNames.WinUtil_DependencyValidation }
        '3' { Launch-Tool $ScriptNames.WinUtil_MachineUtilities }
        '4' { Launch-Tool $ScriptNames.WinUtil_SystemInfoA }
        '5' { Launch-Tool $ScriptNames.WinUtil_SystemInfoB }
        '6' { Launch-Tool $ScriptNames.WinUtil_AppCleanup }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

# ---------------- Main Menu ----------------
function Show-MainMenu {
    Show-TopHeader -SectionTitle "Main Menu"

    Write-Host " 1) ConnectSecure Agent Actions" -ForegroundColor White
    Write-Host "    Install / Update / Uninstall agent." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) ConnectSecure Log Tools" -ForegroundColor White
    Write-Host "    Single- and multi-agent log review and correlation." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Exit Toolbox and Cleanup Files" -ForegroundColor White
    Write-Host "    Run cleanup helper and exit the toolbox." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Network Validation" -ForegroundColor White
    Write-Host "    NMAP scan profiles and TLS/SSL policy collection." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 5) Package Logs and Collected Information" -ForegroundColor White
    Write-Host "    Zip/encrypt toolbox outputs and generate handoff info." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 6) Validate Installed Software" -ForegroundColor White
    Write-Host "    App registry, osquery inventory, Store apps, and updates." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 7) Windows Machine Utilities" -ForegroundColor White
    Write-Host "    System info, AD tools, dependencies, disk/services, cleanup." -ForegroundColor DarkGray
    Write-Host ""

    Footer-Prompt "1/2/3/4/5/6/7"
}

# ---------------- Main Loop ----------------
Ensure-ExportFolder $script:CS_TempRoot | Out-Null
Preflight-Unblock -Root $script:CS_ToolRoot

# Grow console so the menu fits
Set-ConsoleSize

while (-not $script:ExitTool) {
    Show-MainMenu
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Show-AgentActionsMenu }
        '2' { Show-LogToolsMenu }
        '3' { Invoke-ExitAndCleanup }
        '4' { Show-NetworkValidationMenu }
        '5' { Show-PackageLogsMenu }
        '6' { Show-SoftwareValidationMenu }
        '7' { Show-WindowsUtilitiesMenu }
        'Q' { $script:ExitTool = $true }
        default {
            Write-Warn "Invalid selection."
            Start-Sleep -Milliseconds 800
        }
    }
}
