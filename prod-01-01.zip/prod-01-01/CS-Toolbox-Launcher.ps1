# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ===============================
# ConnectSecure Technicians Toolbox - Launcher (PS 5.1)
# ===============================

# Root folder for this toolbox
$global:CSLauncherRoot = $scriptRoot

function Show-MainMenu {
    Write-Host ""
    Write-Host " ConnectSecure Technicians Toolbox"
    Write-Host "========================================================="
    Write-Host (" Host: {0,-18} User: {1,-10} Admin: {2}   Common: {3}" -f $env:COMPUTERNAME, $env:USERNAME, ([bool](whoami /groups | findstr /i 'S-1-5-32-544') -or ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)), (Get-Date -Format 'Common-yyyy-MM-dd HH:mm'))
    Write-Host ""
    Write-Host " [1] OSQuery Data Collection      - Apps, search, browser extensions"
    Write-Host " [2] Nmap Data Collection         - Local network scan profiles"
    Write-Host " [3] Secondary Validation Tools   - Collection A bundle"
    Write-Host " [5] Active Directory Tools       - Users, Groups, OUs, GPOs"
    Write-Host " [6] System Info A                - Firewall, Defender, Disk/SMART"
    Write-Host " [7] System Info B                - Pending Reboot, App Logs, Startup"
    Write-Host " [8] Utilities                    - Services, Disk Space"
    Write-Host " [9] Agent Menu Tool              - Install, Reinstall, Uninstall"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results        - Compress results for support"
    Write-Host " [C] Cleanup Toolbox and Exit Tool"
    Write-Host ""
}

function Run-Choice {
    param(
        [Parameter(Mandatory)]
        [string]$Choice
    )

    switch ($Choice.Trim().ToUpperInvariant()) {
        '1' {
            $path = Join-Path $global:CSLauncherRoot 'Osquery-Data-Collection.ps1'
            Launch-Tool -Path $path
            Pause-Script "Press any key to return to the menu..."
        }
        '2' {
            $path = Join-Path $global:CSLauncherRoot 'Nmap-Data-Collection.ps1'
            Launch-Tool -Path $path
            Pause-Script "Press any key to return to the menu..."
        }
        '3' {
            $path = Join-Path $global:CSLauncherRoot 'ValidationTool-Collection A.ps1'
            Launch-Tool -Path $path
            Pause-Script "Press any key to return to the menu..."
        }
        '5' {
            $path = Join-Path $global:CSLauncherRoot 'ValidationTool-AD.ps1'
            Launch-Tool -Path $path
            Pause-Script "Press any key to return to the menu..."
        }
        '6' {
            $path = Join-Path $global:CSLauncherRoot 'SystemInfo-A.ps1'
            Launch-Tool -Path $path
            Pause-Script "Press any key to return to the menu..."
        }
        '7' {
            $path = Join-Path $global:CSLauncherRoot 'SystemInfo-B.ps1'
            Launch-Tool -Path $path
            Pause-Script "Press any key to return to the menu..."
        }
        '8' {
            $path = Join-Path $global:CSLauncherRoot 'Tools-Utilities.ps1'
            Launch-Tool -Path $path
            Pause-Script "Press any key to return to the menu..."
        }
        '9' {
            $path = Join-Path $global:CSLauncherRoot 'Agent-Menu-Tool.ps1'
            Launch-Tool -Path $path
            Pause-Script "Press any key to return to the menu..."
        }
        'Z' {
            try {
                $zipPath = Zip-Results
                Write-Host ""
                Write-Host "Zip created: $zipPath"
                Email-Results -ZipPath $zipPath
            } catch {
                Write-Host ("❌ ERROR creating/emailing zip: {0}" -f $_.Exception.Message) -ForegroundColor Red
                Write-Log   ("ERROR: Zip/Email failed: {0}" -f $_.Exception.Message)
            }
            Pause-Script "Press any key to return to the menu..."
        }
        'C' {
            Invoke-FinalCleanupAndExit
        }
        Default {
            Write-Host "Invalid selection. Please choose a listed option." -ForegroundColor Yellow
            Pause-Script "Press any key to continue..."
        }
    }
}

# --- Main Loop ---
while ($true) {
    Clear-Host
    Show-Header "ConnectSecure Technicians Toolbox"
    Show-MainMenu
    $choice = Read-Host "Enter your choice"
    try {
        Run-Choice -Choice $choice
    } catch {
        Write-Host ("❌ ERROR running selection: {0}" -f $_.Exception.Message) -ForegroundColor Red
        Write-Log   ("ERROR: Selection failed: {0}" -f $_.Exception.Message)
        Pause-Script "Press any key to return to the menu..."
    }
}
