# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 ConnectSecure Technicians Toolbox – Main Launcher       ║
# ║ Version: 2.1 | 2025-08-07                                  ║
# ╚═════════════════════════════════════════════════════════════╝

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Load shared functions (still needed for Z and C)
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found. [Z] and [C] will not work." -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Launch-Tool {
    param ([string]$name)
    $path = Join-Path $scriptRoot $name
    if (Test-Path $path) {
        Write-SessionSummary "Launched: $name"
        & $path
    } else {
        Write-Host "❌ Script not found: $name" -ForegroundColor Red
        Pause-Script
    }
}

function Show-MainMenu {
    do {
        Clear-Host
        Show-Header "ConnectSecure Technicians Toolbox"

        Write-Host " [1] Validation Tool A         - Office, Drivers, Roaming, Extensions"
        Write-Host " [2] Validation Tool B         - Patches, VC++ Runtime Scanner"
        Write-Host " [3] Validation Tool C         - SSL Ciphers, OSQuery Extensions"
        Write-Host ""
        Write-Host " [4] Network Tools             - TLS 1.0 Scan, Nmap, Validate SMB"
        Write-Host " [5] Active Directory Tools    - Users, Groups, OUs, GPOs"
        Write-Host ""
        Write-Host " [6] System Info A             - Firewall, Defender, Disk/SMART"
        Write-Host " [7] System Info B             - Pending Reboot, App Logs, Startup Audit"
        Write-Host ""
        Write-Host " [8] Utilities                 - Running Services, Disk Space"
        Write-Host ""
        Write-Host " [9] Agent Menu Tool           - Install, Uninstall, Status, Maintenance"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results     - Compress and prepare results for support"
        Write-Host " [C] Cleanup Toolbox Data      - Remove all temp and output files"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Enter your choice"
        switch ($choice.ToUpper()) {
            "1" { Launch-Tool "ValidationTool-Collection A.ps1" }
            "2" { Launch-Tool "ValidationTool-Collection B.ps1" }
            "3" { Launch-Tool "ValidationTool-Collection C.ps1" }
            "4" { Launch-Tool "Network-Tools.ps1" }
            "5" { Launch-Tool "ActiveDirectory-Tools.ps1" }
            "6" { Launch-Tool "SystemInfo-A.ps1" }
            "7" { Launch-Tool "SystemInfo-B.ps1" }
            "8" { Launch-Tool "Tools-Utilities.ps1" }
            "9" { Launch-Tool "Agent-Menu-Tool.ps1" }
            "Z" { Invoke-ZipAndEmailResults }
            "C" { Cleanup-ExportFolder }
            "Q" { Pause-Script; return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

Show-MainMenu
