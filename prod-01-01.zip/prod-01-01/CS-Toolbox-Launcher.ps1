<# ========================================================================
  CS-Toolbox-Launcher.ps1  (All-in-One Menu Framework, Colored Header)
  Version: AAMenu-Short-v1.19 (Packager workflow restored)

  Audit Log:      C:\CS-Toolbox-TEMP\Collected-Info\Audit.log
  EULA State:     C:\CS-Toolbox-TEMP\Collected-Info\EulaAcceptedAt.txt  (ISO 8601 "o" format)

  EULA behavior (per request):
    - When EULA gate is needed, try to source from https://connectsecure.com/eula
    - If site cannot be reached, show message instructing tech to view the site,
      and STILL offer Y/N (Y proceeds, N runs self-destruct)
    - When site is reachable, show paragraph-by-paragraph with M until end anchor

  Change (2026-01-30):
    - Added Agent Actions menu item:
        4) Reload Agent Dependencies
      Hard-coded path:
        C:\CS-Toolbox-TEMP\prod-01-01\CS-Reload-Dependencies.ps1
========================================================================= #>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------- Configurable Roots ----------------
if (-not (Get-Variable -Name CS_ToolRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_ToolRoot = Split-Path -Parent $PSCommandPath
}
if (-not (Get-Variable -Name CS_TempRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_TempRoot = Join-Path $env:SystemDrive 'CS-Toolbox-TEMP'
}
if (-not (Get-Variable -Name CS_ScriptSearchRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_ScriptSearchRoot = $script:CS_ToolRoot
}

# Mirror paths globally
$global:CS_ToolRoot         = $script:CS_ToolRoot
$global:CS_TempRoot         = $script:CS_TempRoot
$global:CS_ScriptSearchRoot = $script:CS_ScriptSearchRoot
$global:CSLauncherRoot      = $script:CS_ToolRoot

$script:ExitTool = $false

# ---------------- Script Name Registry ----------------
$ScriptNames = [ordered]@{
    AgentActions_MenuLabel         = 'ConnectSecure Agent Actions'
    LogTools_MenuLabel             = 'ConnectSecure Log Tools'
    NetworkValidation_MenuLabel    = 'Network Validation'
    PackageLogs_MenuLabel          = 'Package Logs and Collected Information'
    SoftwareValidation_MenuLabel   = 'Validate Installed Software'
    WindowsUtilities_MenuLabel     = 'Windows Machine Utilities'

    # Agent Tools
    Agent_InstallOrReinstall       = 'Agent-Install-Tool.ps1'
    Agent_Uninstall                = 'Agent-Uninstall-Tool.ps1'
    Agent_Update                   = 'Agent-Update-Tool.ps1'

    # Added agent action (hard-coded path as requested)
    Agent_ReloadDependencies       = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Reload-Dependencies.ps1'

    # Log Tools
    Agent_LogReview                = 'Agent-Log-Review.ps1'
    Agent_JobReview                = 'Agent-Job-Review.ps1'
    Agent_MessageCorrelator        = 'Agent-msg-Correlator.ps1'
    Agent_LogCorrelator            = 'Agent-Log-Correlator.ps1'

    # Network Validation
    NetworkValidation              = 'NMAP-Data-Collection.ps1'
    TLS_DataCollection             = 'tls-data-collection.ps1'

    # Software Validation
    Software_AppRegistrySearch     = 'Registry-Search.ps1'
    Software_BrowserExtensions     = 'Browser-Extensions-Details.ps1'
    Software_StaleProfileScan      = 'Windows-UserProfile-AppSweep.ps1'
    Software_ValidatedApps         = 'Osquery-Data-Collection.ps1'
    Software_StoreApps             = 'Windows-Modern-App-Discovery.ps1'
    Software_WindowsUpdate         = 'Windows-Update-Details.ps1'

    # Windows Utilities
    WinUtil_ADValidation           = 'Active-Directory-Tools.ps1'
    WinUtil_DependencyValidation   = 'Dependency-Validation-Tools.ps1'
    WinUtil_MachineUtilities       = 'Machine-Utilities.ps1'
    WinUtil_SystemInfoA            = 'SystemInfo-A.ps1'
    WinUtil_SystemInfoB            = 'SystemInfo-B.ps1'
    WinUtil_AppCleanup             = 'Application-Cleanup-Script.ps1'

    # Other
    ExitAndCleanup                 = 'Toolbox-Cleanup-SelfDestruct.ps1'
    PackageLogs                    = 'zip-encrypt-htmltemplate.ps1'
}

# ---------------- Helpers ----------------
function Ensure-ExportFolder {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

function Preflight-Unblock {
    param([string]$Root = $script:CS_ToolRoot)
    Get-ChildItem -LiteralPath $Root -Recurse -File |
        ForEach-Object { try { Unblock-File -LiteralPath $_.FullName } catch {} }
}

function Get-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        return (New-Object Security.Principal.WindowsPrincipal($id)).
            IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Set-ConsoleSize {
    try {
        if (-not $Host.UI -or -not $Host.UI.RawUI) { return }
        $raw  = $Host.UI.RawUI
        $buf  = $raw.BufferSize
        $win  = $raw.WindowSize

        $targetWidth  = 110
        $targetHeight = 34

        if ($buf.Width  -lt $targetWidth)  { $buf.Width  = $targetWidth }
        if ($buf.Height -lt 1000)          { $buf.Height = 1000 }
        $raw.BufferSize = $buf

        $win.Width  = $targetWidth
        $win.Height = $targetHeight
        $raw.WindowSize = $win
    } catch { }
}

function Show-TopHeader {
    param([string]$SectionTitle = $null)

    Clear-Host
    $hostName = $env:COMPUTERNAME
    $userName = ([Security.Principal.WindowsIdentity]::GetCurrent().Name)
    $isAdmin  = Get-IsAdmin
    $line     = ('=' * 58)

    Write-Host ""
    Write-Host " ConnectSecure Technicians Toolbox  - Launcher v1.19" -ForegroundColor Cyan
    Write-Host " $line" -ForegroundColor DarkGray
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, $isAdmin) -ForegroundColor Gray
    Write-Host (" Base: {0}" -f $script:CS_ToolRoot) -ForegroundColor Gray
    Write-Host " $line" -ForegroundColor DarkGray

    if ($SectionTitle) {
        Write-Host " $SectionTitle" -ForegroundColor White
        Write-Host ""
    }
}

function Footer-Prompt([string]$OptionsDisplay) {
    Write-Host ""
    Write-Host ("Press ({0}) to make your selection." -f $OptionsDisplay) -ForegroundColor DarkGray
}

function Write-Warn($m){ Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function Write-Info($m){ Write-Host "[INFO]  $m" -ForegroundColor Cyan }
function Write-ErrorMsg($m){ Write-Host "[ERROR] $m" -ForegroundColor Red }

# ---------------- Audit Logging + EULA Persisted State ----------------
$script:CS_CollectedInfoRoot = Join-Path $script:CS_TempRoot 'Collected-Info'
$script:AuditLogPath         = Join-Path $script:CS_CollectedInfoRoot 'Audit.log'
$script:EulaStatePath        = Join-Path $script:CS_CollectedInfoRoot 'EulaAcceptedAt.txt'
$script:AuditFallbackPath    = Join-Path $env:TEMP 'CS-Toolbox-Audit-Fallback.log'

function Ensure-CollectedInfoFolder {
    try { [void][System.IO.Directory]::CreateDirectory($script:CS_CollectedInfoRoot) } catch {
        Write-Warn "Could not create audit folder: $script:CS_CollectedInfoRoot  ($($_.Exception.Message))"
    }
}

function Ensure-AuditFile {
    try {
        Ensure-CollectedInfoFolder
        if (-not (Test-Path -LiteralPath $script:AuditLogPath)) {
            [void][System.IO.File]::WriteAllText($script:AuditLogPath, "", [System.Text.Encoding]::UTF8)
        }
    } catch {
        Write-Warn "Could not create audit log: $script:AuditLogPath  ($($_.Exception.Message))"
    }
}

function Get-UserContextInfo {
    $dtLocal = Get-Date
    $dtIso   = $dtLocal.ToString('o')
    $id      = $null
    $sid     = ''
    try { $id  = [Security.Principal.WindowsIdentity]::GetCurrent(); $sid = $id.User.Value } catch { }
    $domUser = ''
    try { $domUser = $id.Name } catch { $domUser = '' }
    $admin = Get-IsAdmin

    return [pscustomobject]@{
        LocalTime   = $dtLocal.ToString('yyyy-MM-dd HH:mm:ss')
        IsoTime     = $dtIso
        Computer    = $env:COMPUTERNAME
        DomainUser  = $domUser
        UserDomain  = $env:USERDOMAIN
        UserName    = $env:USERNAME
        Sid         = $sid
        IsAdmin     = $admin
        ScriptPath  = $PSCommandPath
    }
}

function Write-AuditLog {
    param(
        [Parameter(Mandatory=$true)][string]$Event,
        [string]$Detail = ''
    )

    $ctx = Get-UserContextInfo
    $line = "[{0}] [ISO={1}] Host={2} User={3} UDOMAIN={4} UNAME={5} SID={6} Admin={7} Script={8} Event={9} Detail={10}" -f `
        $ctx.LocalTime, $ctx.IsoTime, $ctx.Computer, $ctx.DomainUser, $ctx.UserDomain, $ctx.UserName, $ctx.Sid, $ctx.IsAdmin, $ctx.ScriptPath, $Event, $Detail

    try {
        Ensure-AuditFile
        Add-Content -LiteralPath $script:AuditLogPath -Value $line -Encoding UTF8
    } catch {
        Write-Warn "AUDIT WRITE FAILED -> $script:AuditLogPath  ($($_.Exception.Message))"
        try { Add-Content -LiteralPath $script:AuditFallbackPath -Value $line -Encoding UTF8 } catch { }
    }
}

function Load-EulaAcceptedAt {
    try {
        Ensure-CollectedInfoFolder
        if (Test-Path -LiteralPath $script:EulaStatePath) {
            $raw = (Get-Content -LiteralPath $script:EulaStatePath -ErrorAction Stop | Select-Object -First 1).Trim()
            if ($raw) { return [datetime]::Parse($raw) }
        }
    } catch {
        Write-AuditLog -Event 'EulaStateReadFailed' -Detail $_.Exception.Message
    }
    return $null
}

function Save-EulaAcceptedAt([datetime]$dt) {
    try {
        Ensure-CollectedInfoFolder
        Set-Content -LiteralPath $script:EulaStatePath -Value $dt.ToString('o') -Encoding UTF8 -Force
    } catch {
        Write-AuditLog -Event 'EulaStateWriteFailed' -Detail $_.Exception.Message
    }
}

function Resolve-ToolScript {
    param([string]$FileName)

    if ([System.IO.Path]::IsPathRooted($FileName)) {
        if (Test-Path -LiteralPath $FileName) { return Get-Item -LiteralPath $FileName }
        Write-Warn "Absolute path not found: $FileName"
        return $null
    }

    $hit = Get-ChildItem -LiteralPath $script:CS_ScriptSearchRoot -Recurse -File -Filter $FileName -ErrorAction SilentlyContinue |
        Select-Object -First 1

    if (-not $hit) {
        $hit = Get-ChildItem -LiteralPath $script:CS_ScriptSearchRoot -Recurse -File |
            Where-Object { $_.Name -ieq $FileName } | Select-Object -First 1
    }

    if (-not $hit) { Write-Warn "Could not resolve '$FileName' under $script:CS_ScriptSearchRoot" }
    return $hit
}

function Get-SafeLastExitCode {
    try {
        if (Test-Path variable:global:LASTEXITCODE) { return $global:LASTEXITCODE }
        if (Test-Path variable:LASTEXITCODE) { return $LASTEXITCODE }
    } catch { }
    return $null
}

function Launch-Tool {
    param(
        [string]$FileName,
        [string[]]$Args = @(),
        [switch]$PauseAfter
    )

    $scriptFile = Resolve-ToolScript $FileName
    if (-not $scriptFile) {
        Write-ErrorMsg "Tool not found: $FileName"
        Read-Host "Press Enter to return"
        return
    }

    $argText = if ($Args -and $Args.Count -gt 0) { ($Args -join ' ') } else { '' }
    Write-Info ("Launching: {0}{1}" -f $scriptFile.FullName, $(if($argText){"  ARGS: $argText"}else{""}))
    Write-AuditLog -Event 'ToolLaunch' -Detail ("Tool={0} Args={1}" -f $scriptFile.FullName, $argText)

    try {
        Unblock-File -LiteralPath $scriptFile.FullName -ErrorAction SilentlyContinue
        try { if (Test-Path variable:global:LASTEXITCODE) { Remove-Variable -Name LASTEXITCODE -Scope Global -ErrorAction SilentlyContinue } } catch { }

        & $scriptFile.FullName @Args

        $exitCode = Get-SafeLastExitCode
        Write-AuditLog -Event 'ToolExit' -Detail ("Tool={0} ExitCode={1}" -f $scriptFile.FullName, $(if($null -eq $exitCode){'null'}else{$exitCode}))
    } catch {
        $msg = $_.Exception.Message
        Write-AuditLog -Event 'ToolException' -Detail ("Tool={0} Error={1}" -f $scriptFile.FullName, $msg)
        Write-ErrorMsg $msg
        Read-Host "Press Enter to return"
    }

    if ($PauseAfter) { Read-Host "Press Enter to return" }
}

# ---------------- EULA Gate ----------------
$script:EulaAcceptedAt      = $null
$script:EulaPromptWindowMin = 15
$script:EulaSelfDestruct    = "C:\CS-Toolbox-TEMP\prod-01-01\Toolbox-Cleanup-SelfDestruct.ps1"
$script:EulaSourceUrl       = 'https://connectsecure.com/eula'

function Test-EulaStillValid {
    $script:EulaAcceptedAt = Load-EulaAcceptedAt
    if (-not $script:EulaAcceptedAt) { return $false }
    $ageMin = (New-TimeSpan -Start $script:EulaAcceptedAt -End (Get-Date)).TotalMinutes
    return ($ageMin -lt [double]$script:EulaPromptWindowMin)
}

function Invoke-SelfDestructAndExit {
    Write-Host ""
    Write-Host "[WARN]  EULA declined. Starting cleanup/self-destruct..." -ForegroundColor Yellow

    if (Test-Path -LiteralPath $script:EulaSelfDestruct) {
        try {
            Unblock-File -LiteralPath $script:EulaSelfDestruct -ErrorAction SilentlyContinue
            Write-AuditLog -Event 'SelfDestructLaunched' -Detail 'Attempt'
            & $script:EulaSelfDestruct
            Write-AuditLog -Event 'SelfDestructLaunched' -Detail 'Success'
        } catch {
            Write-AuditLog -Event 'SelfDestructLaunched' -Detail ("Failed: {0}" -f $_.Exception.Message)
            Write-Host "[ERROR] Failed to run self-destruct: $($_.Exception.Message)" -ForegroundColor Red
        }
    } else {
        Write-AuditLog -Event 'SelfDestructMissing' -Detail $script:EulaSelfDestruct
        Write-Host "[ERROR] Self-destruct script not found: $script:EulaSelfDestruct" -ForegroundColor Red
    }

    $script:ExitTool = $true
}

function Convert-HtmlToText {
    param([Parameter(Mandatory=$true)][string]$Html)

    $t = $Html
    $t = [regex]::Replace($t, '<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>', ' ', 'IgnoreCase')
    $t = [regex]::Replace($t, '<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>', ' ', 'IgnoreCase')
    $t = [regex]::Replace($t, '<br\s*/?>', "`n", 'IgnoreCase')
    $t = [regex]::Replace($t, '</p\s*>', "`n`n", 'IgnoreCase')
    $t = [regex]::Replace($t, '<[^>]+>', ' ')
    try { $t = [System.Net.WebUtility]::HtmlDecode($t) } catch { }

    $t = $t -replace "`r", ''
    $t = [regex]::Replace($t, "[ \t]+", ' ')
    $t = [regex]::Replace($t, "\n{3,}", "`n`n")
    $t = $t.Trim()
    return $t
}

function Get-EulaFromWeb {
    $now = Get-Date
    $obj = [ordered]@{
        SourcedAtLocal = $now.ToString('yyyy-MM-dd HH:mm:ss')
        SourceUrl      = $script:EulaSourceUrl
        LastUpdated    = ''
        Paras          = @()
        EndIndex       = -1
        FetchOk        = $false
        FetchError     = ''
    }

    $footerStopInlineRegex = '(?im)\bContact\s+Us\b'
    $footerStopParaRegex   = '(?im)^\s*Contact\s+Us\s*$|^\s*Facebook\s*$|^\s*LinkedIn\s*$|^\s*YouTube\s*$|^\s*Platform\s*$|^\s*Vulnerability\s+Management\s*$|^\s*Compliance\s+Management\s*$|^\s*Premium\s+Features\s*$'
    $endAnchorRegex        = '(?is)\(b\)\s+the\s+word\s+["“]?including["”]?\s+means\s+["“]?including,\s+without\s+limitation["”]?\s*\.\s*'
    $startAnchorText       = 'ConnectSecure, LLC'
    $startAnchorRegex      = '(?is)ConnectSecure,\s*LLC\s*\(\s*["“]?we,["”]?\s*["“]?us\s+or\s+["“]?our["”]?\s*\)\s*makes\s+available'

    try {
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

        $resp = Invoke-WebRequest -Uri $script:EulaSourceUrl -UseBasicParsing -Method GET -TimeoutSec 25 -ErrorAction Stop
        $txtRaw = Convert-HtmlToText -Html $resp.Content
        $txtRaw = $txtRaw -replace ([char]0x00A0), ' '

        $lastUpdatedMatch = [regex]::Match($txtRaw, '(?im)\bLast\s+Updated\b[:\s-]*([^\r\n]{1,120})')
        if ($lastUpdatedMatch.Success) {
            $obj.LastUpdated = ("Last Updated " + $lastUpdatedMatch.Groups[1].Value.Trim())
        }

        $txt = $txtRaw
        $pos = $txt.IndexOf($startAnchorText, [System.StringComparison]::OrdinalIgnoreCase)
        if ($pos -ge 0) {
            $txt = $txt.Substring($pos)
        } else {
            $mStart = [regex]::Match($txt, $startAnchorRegex)
            if ($mStart.Success) { $txt = $txt.Substring($mStart.Index) }
        }

        $rawParas = @()
        foreach ($p in ($txt -split "\n\s*\n")) {
            $pp = $p.Trim()
            if ($pp) { $rawParas += $pp }
        }

        $paras = New-Object System.Collections.Generic.List[string]
        foreach ($p0 in $rawParas) {
            $p = $p0.Trim()

            $mInline = [regex]::Match($p, $footerStopInlineRegex)
            if ($mInline.Success) {
                $before = $p.Substring(0, $mInline.Index).Trim()
                if ($before) { $paras.Add($before) }
                break
            }
            if ([regex]::IsMatch($p, $footerStopParaRegex)) { break }

            $paras.Add($p)
        }

        $endIdx = -1
        for ($i = 0; $i -lt $paras.Count; $i++) {
            if ([regex]::IsMatch($paras[$i], $endAnchorRegex)) { $endIdx = $i; break }
        }
        if ($endIdx -ge 0) {
            $mEnd = [regex]::Match($paras[$endIdx], $endAnchorRegex)
            if ($mEnd.Success) {
                $paras[$endIdx] = $paras[$endIdx].Substring(0, $mEnd.Index + $mEnd.Length).Trim()
            }
            while ($paras.Count -gt ($endIdx + 1)) { [void]$paras.RemoveAt($paras.Count - 1) }
        }

        $obj.Paras = $paras.ToArray()
        $obj.EndIndex = if ($endIdx -ge 0) { $endIdx } elseif ($obj.Paras.Count -gt 0) { $obj.Paras.Count - 1 } else { -1 }
        $obj.FetchOk = ($obj.Paras.Count -gt 0)
    }
    catch {
        $obj.FetchOk = $false
        $obj.FetchError = $_.Exception.Message
    }

    return [pscustomobject]$obj
}

function Show-EulaGate {
    $eula = Get-EulaFromWeb
    Write-AuditLog -Event 'EulaFetched' -Detail ("FetchOk={0} Url={1} LastUpdated={2} Paras={3} EndIndex={4} Error={5}" -f `
        $eula.FetchOk, $eula.SourceUrl, $eula.LastUpdated, $eula.Paras.Count, $eula.EndIndex, $eula.FetchError)

    if (-not $eula.FetchOk) {
        Show-TopHeader -SectionTitle "End User License Agreement (EULA) - Required"

        Write-Host (" Sourced Date: {0}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) -ForegroundColor DarkGray
        Write-Host (" Source URL:   {0}" -f $script:EulaSourceUrl) -ForegroundColor DarkGray
        Write-Host ""

        Write-Host "[WARN]  This device could not retrieve the EULA from the website." -ForegroundColor Yellow
        Write-Host ("       Please view the EULA here: {0}" -f $script:EulaSourceUrl) -ForegroundColor Yellow
        Write-Host ("       Reason: {0}" -f $eula.FetchError) -ForegroundColor DarkGray
        Write-Host ""

        while ($true) {
            Write-Host "Do you accept this EULA?" -ForegroundColor White
            Write-Host "  Y) Yes - I accept and wish to continue" -ForegroundColor White
            Write-Host "  N) No  - Run cleanup/self-destruct and exit" -ForegroundColor White
            Write-Host ""
            $resp = (Read-Host "Selection (Y/N)").Trim().ToUpper()
            switch ($resp) {
                'Y' {
                    $script:EulaAcceptedAt = Get-Date
                    Save-EulaAcceptedAt $script:EulaAcceptedAt
                    Write-AuditLog -Event 'Accepted' -Detail ("AcceptedAt={0} Url={1} Note=SiteUnreachable" -f $script:EulaAcceptedAt.ToString('yyyy-MM-dd HH:mm:ss'), $script:EulaSourceUrl)
                    Start-Sleep -Milliseconds 200
                    return $true
                }
                'N' {
                    Write-AuditLog -Event 'Declined' -Detail ("SelfDestructPath={0} Url={1} Note=SiteUnreachable" -f $script:EulaSelfDestruct, $script:EulaSourceUrl)
                    Invoke-SelfDestructAndExit
                    return $false
                }
                default { Write-Host "[WARN]  Invalid selection. Please enter Y or N." -ForegroundColor Yellow }
            }
        }
    }

    $idx = 0
    $endIdx = if ($eula.EndIndex -ge 0) { $eula.EndIndex } else { ($eula.Paras.Count - 1) }

    while ($true) {
        Show-TopHeader -SectionTitle "End User License Agreement (EULA) - Required"

        Write-Host (" Sourced Date: {0}" -f $eula.SourcedAtLocal) -ForegroundColor DarkGray
        Write-Host (" Source URL:   {0}" -f $eula.SourceUrl) -ForegroundColor DarkGray
        if ($eula.LastUpdated) { Write-Host (" {0}" -f $eula.LastUpdated) -ForegroundColor DarkGray }
        if ($script:EulaAcceptedAt) {
            Write-Host (" Last accepted: {0}" -f $script:EulaAcceptedAt.ToString("yyyy-MM-dd HH:mm:ss")) -ForegroundColor DarkGray
        }
        Write-Host ""

        $isFinal = ($idx -ge $endIdx)

        $label = if ($isFinal) {
            " (Showing FINAL paragraph. You must select Y or N to continue.)"
        } elseif ($idx -eq 0) {
            " (Showing EULA opening paragraph. Press M to show the next paragraph.)"
        } else {
            " (Showing next paragraph #$idx. Press M to continue.)"
        }

        Write-Host $label -ForegroundColor DarkGray
        Write-Host ""
        Write-Host (" {0}" -f $eula.Paras[$idx]) -ForegroundColor Yellow
        Write-Host ""

        if ($isFinal) {
            while ($true) {
                Write-Host "Do you accept this EULA?" -ForegroundColor White
                Write-Host "  Y) Yes - I accept and wish to continue" -ForegroundColor White
                Write-Host "  N) No  - Run cleanup/self-destruct and exit" -ForegroundColor White
                Write-Host ""
                $resp = (Read-Host "Selection (Y/N)").Trim().ToUpper()
                switch ($resp) {
                    'Y' {
                        $script:EulaAcceptedAt = Get-Date
                        Save-EulaAcceptedAt $script:EulaAcceptedAt
                        Write-AuditLog -Event 'Accepted' -Detail ("AcceptedAt={0} Url={1} LastUpdated={2} EndIndex={3}" -f `
                            $script:EulaAcceptedAt.ToString('yyyy-MM-dd HH:mm:ss'), $eula.SourceUrl, $eula.LastUpdated, $endIdx)
                        Start-Sleep -Milliseconds 200
                        return $true
                    }
                    'N' {
                        Write-AuditLog -Event 'Declined' -Detail ("SelfDestructPath={0} Url={1} LastUpdated={2} EndIndex={3}" -f `
                            $script:EulaSelfDestruct, $eula.SourceUrl, $eula.LastUpdated, $endIdx)
                        Invoke-SelfDestructAndExit
                        return $false
                    }
                    default { Write-Host "[WARN]  Invalid selection. Please enter Y or N." -ForegroundColor Yellow }
                }
            }
        }

        Write-Host "Do you accept this EULA?" -ForegroundColor White
        Write-Host "  Y) Yes - I accept and wish to continue" -ForegroundColor White
        Write-Host "  N) No  - Run cleanup/self-destruct and exit" -ForegroundColor White
        Write-Host "  M) More - Show the next paragraph" -ForegroundColor White
        Write-Host ""

        $resp = (Read-Host "Selection (Y/N/M)").Trim().ToUpper()
        switch ($resp) {
            'Y' {
                $script:EulaAcceptedAt = Get-Date
                Save-EulaAcceptedAt $script:EulaAcceptedAt
                Write-AuditLog -Event 'Accepted' -Detail ("AcceptedAt={0} Url={1} LastUpdated={2} ViewedIndex={3} EndIndex={4}" -f `
                    $script:EulaAcceptedAt.ToString('yyyy-MM-dd HH:mm:ss'), $eula.SourceUrl, $eula.LastUpdated, $idx, $endIdx)
                Start-Sleep -Milliseconds 200
                return $true
            }
            'N' {
                Write-AuditLog -Event 'Declined' -Detail ("SelfDestructPath={0} Url={1} LastUpdated={2} ViewedIndex={3} EndIndex={4}" -f `
                    $script:EulaSelfDestruct, $eula.SourceUrl, $eula.LastUpdated, $idx, $endIdx)
                Invoke-SelfDestructAndExit
                return $false
            }
            'M' {
                if ($idx -lt $endIdx) { $idx++ }
            }
            default {
                Write-Host "[WARN]  Invalid selection. Please enter Y, N, or M." -ForegroundColor Yellow
                Start-Sleep -Milliseconds 350
            }
        }
    }
}

function Ensure-EulaGate {
    if (-not (Test-EulaStillValid)) { return (Show-EulaGate) }
    return $true
}

# ---------------- Menus ----------------
function Show-AgentActionsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.AgentActions_MenuLabel
    Write-Host " You are in: ConnectSecure Agent Actions" -ForegroundColor Yellow
    Write-Host ""

    Write-Host " 1) Install or Reinstall Agent" -ForegroundColor White
    Write-Host "    Detects, downloads, installs, and verifies the agent." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Uninstall Agent (with Portal Reminder)" -ForegroundColor White
    Write-Host "    Clean removal of the agent with reminder to clean up in the portal." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Update Agent" -ForegroundColor White
    Write-Host "    Triggers an agent update using the ConnectSecure updater." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Reload Agent Dependencies" -ForegroundColor White
    Write-Host "    Stop services -> delete dependency files -> start services (logged/exported by tool)." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_ReloadDependencies) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/3/4/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.Agent_InstallOrReinstall }
        '2' { Launch-Tool $ScriptNames.Agent_Uninstall }
        '3' { Launch-Tool $ScriptNames.Agent_Update -PauseAfter }
        '4' { Launch-Tool $ScriptNames.Agent_ReloadDependencies -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Show-LogToolsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.LogTools_MenuLabel
    Write-Host " You are in: ConnectSecure Log Tools" -ForegroundColor Yellow
    Write-Host ""

    Write-Host " 1) Agent Error Review / Analyzer - Single-Agent" -ForegroundColor White
    Write-Host "    Parse agent logs for errors/warnings and export to HTML." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_LogReview) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Agent Job Review / Analyzer - Single-Agent" -ForegroundColor White
    Write-Host "    Group job runs, show last success/issue, and export summary." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_JobReview) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Agent Message Correlator - Single-Agent" -ForegroundColor White
    Write-Host "    Correlate message logs to find repeating patterns and issues." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_MessageCorrelator) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Agent Log Correlator / Analyzer - Multi-Agent" -ForegroundColor White
    Write-Host "    Multi-agent log correlation, grouped errors, and HTML export." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_LogCorrelator) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/3/4/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.Agent_LogReview }
        '2' { Launch-Tool $ScriptNames.Agent_JobReview }
        '3' { Launch-Tool $ScriptNames.Agent_MessageCorrelator -PauseAfter }
        '4' { Launch-Tool $ScriptNames.Agent_LogCorrelator -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Invoke-ExitAndCleanup {
    Show-TopHeader -SectionTitle "Exit and Cleanup"
    Launch-Tool $ScriptNames.ExitAndCleanup
    $script:ExitTool = $true
}

function Show-NetworkValidationMenu {
    Show-TopHeader -SectionTitle $ScriptNames.NetworkValidation_MenuLabel

    Write-Host " 1) Scan Networks or Local Machine" -ForegroundColor White
    Write-Host "    Run NMAP-based scans against hosts or ranges." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.NetworkValidation) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) TLS/SSL Policy (Local Host)" -ForegroundColor White
    Write-Host "    Collect SCHANNEL/TLS configuration from the local machine." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.TLS_DataCollection) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.NetworkValidation }
        '2' { Launch-Tool $ScriptNames.TLS_DataCollection -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Show-PackageLogsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.PackageLogs_MenuLabel

    Write-Host " 1) Packager / Encrypt Helper" -ForegroundColor White
    Write-Host "    Zip and optionally encrypt toolbox logs/outputs." -ForegroundColor DarkGray
    Write-Host "    (Secure/Unsecure selection happens inside the packager.)" -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.PackageLogs) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.PackageLogs }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Show-SoftwareValidationMenu {
    Show-TopHeader -SectionTitle $ScriptNames.SoftwareValidation_MenuLabel
    Write-Host " You are in: Validate Installed Software" -ForegroundColor Yellow
    Write-Host ""

    Write-Host " 1) Application Registry Search" -ForegroundColor White
    Write-Host "    Search uninstall registry hives (HKLM/HKCU) for apps and export results." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Browser Extension Details" -ForegroundColor White
    Write-Host "    Enumerate installed browser extensions per user (Chrome/Edge/Firefox)." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Stale Profile Application Scan" -ForegroundColor White
    Write-Host "    Scan user profiles for large/old application data to target for cleanup." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Validate Installed Software (osquery)" -ForegroundColor White
    Write-Host "    Use osquery to inventory installed software in a normalized export." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 5) Windows Store Application Inventory" -ForegroundColor White
    Write-Host "    List UWP/AppX packages with name, version, and scope." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 6) Windows Update Details" -ForegroundColor White
    Write-Host "    Show Windows Update history with KB, date, category, and status." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back to Main Menu" -ForegroundColor White
    Footer-Prompt "1/2/3/4/5/6/B"

    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.Software_AppRegistrySearch }
        '2' { Launch-Tool $ScriptNames.Software_BrowserExtensions }
        '3' { Launch-Tool $ScriptNames.Software_StaleProfileScan }
        '4' { Launch-Tool $ScriptNames.Software_ValidatedApps }
        '5' { Launch-Tool $ScriptNames.Software_StoreApps }
        '6' { Launch-Tool $ScriptNames.Software_WindowsUpdate }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Show-WindowsUtilitiesMenu {
    Show-TopHeader -SectionTitle $ScriptNames.WindowsUtilities_MenuLabel

    Write-Host " 1) Active Directory Collection / Validation" -ForegroundColor White
    Write-Host "    Run AD data collectors for users, computers, OUs, and GPOs." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_ADValidation) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Dependency Validation Tools" -ForegroundColor White
    Write-Host "    Check runtimes, DLLs, and OS features required by ConnectSecure." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_DependencyValidation) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Machine Utilities - Services & Disk Space" -ForegroundColor White
    Write-Host "    Review key services and disk utilization for health issues." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_MachineUtilities) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) System Info A - Firewall, Defender, SMART" -ForegroundColor White
    Write-Host "    Collect basic protection and disk health information." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_SystemInfoA) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 5) System Info B - Reboot, Startup, Logs" -ForegroundColor White
    Write-Host "    Show reboot state, startup load, and key event log snippets." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_SystemInfoB) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 6) Windows Application - Cleanup S&D" -ForegroundColor White
    Write-Host "    Guided application removal and leftover cleanup with logging." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_AppCleanup) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/3/4/5/6/B"

    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.WinUtil_ADValidation }
        '2' { Launch-Tool $ScriptNames.WinUtil_DependencyValidation }
        '3' { Launch-Tool $ScriptNames.WinUtil_MachineUtilities }
        '4' { Launch-Tool $ScriptNames.WinUtil_SystemInfoA }
        '5' { Launch-Tool $ScriptNames.WinUtil_SystemInfoB }
        '6' { Launch-Tool $ScriptNames.WinUtil_AppCleanup }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

# ---------------- Main Menu ----------------
function Show-MainMenu {
    if (-not (Ensure-EulaGate)) { return }

    $acc = if ($script:EulaAcceptedAt) { $script:EulaAcceptedAt.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }
    Write-AuditLog -Event 'MainMenuShown' -Detail ("EulaAcceptedAt={0}" -f $acc)

    Show-TopHeader -SectionTitle "Main Menu"

    Write-Host " 1) ConnectSecure Agent Actions" -ForegroundColor White
    Write-Host "    Install / Update / Uninstall agent." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) ConnectSecure Log Tools" -ForegroundColor White
    Write-Host "    Single- and multi-agent log review and correlation." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Exit Toolbox and Cleanup Files" -ForegroundColor White
    Write-Host "    Run cleanup helper and exit the toolbox." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Network Validation" -ForegroundColor White
    Write-Host "    NMAP scan profiles and TLS/SSL policy collection." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 5) Package Logs and Collected Information" -ForegroundColor White
    Write-Host "    Zip/encrypt toolbox outputs and generate handoff info." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 6) Validate Installed Software" -ForegroundColor White
    Write-Host "    App registry, osquery inventory, Store apps, and updates." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 7) Windows Machine Utilities" -ForegroundColor White
    Write-Host "    System info, AD tools, dependencies, disk/services, cleanup." -ForegroundColor DarkGray
    Write-Host ""

    Footer-Prompt "1/2/3/4/5/6/7/Q"
}

# ---------------- Main Loop (STARTUP PAUSE ON ERROR) ----------------
try {
    Ensure-ExportFolder $script:CS_TempRoot | Out-Null
    Ensure-CollectedInfoFolder
    Ensure-AuditFile

    Preflight-Unblock -Root $script:CS_ToolRoot
    Write-AuditLog -Event 'LauncherStart' -Detail ("ToolRoot={0}" -f $script:CS_ToolRoot)

    Set-ConsoleSize
}
catch {
    $msg = $_.Exception.Message

    Write-Host ""
    Write-Host "================ STARTUP ERROR ================" -ForegroundColor Red
    Write-Host $msg -ForegroundColor Red
    Write-Host ""
    Write-Host "Full error:" -ForegroundColor Yellow
    Write-Host $_ -ForegroundColor Yellow
    Write-Host "===============================================" -ForegroundColor Red
    Write-Host ""

    try { Write-AuditLog -Event 'LauncherStartupException' -Detail $msg } catch { }

    Read-Host "Press Enter to close (fix the error and re-run)"
    exit 1
}

while (-not $script:ExitTool) {
    Show-MainMenu
    if ($script:ExitTool) { break }

    $sel = (Read-Host "Selection").Trim().ToUpper()
    Write-AuditLog -Event 'MenuSelection' -Detail ("Menu=Main Selection={0}" -f $sel)

    switch ($sel) {
        '1' { Show-AgentActionsMenu }
        '2' { Show-LogToolsMenu }
        '3' { Invoke-ExitAndCleanup }
        '4' { Show-NetworkValidationMenu }
        '5' { Show-PackageLogsMenu }
        '6' { Show-SoftwareValidationMenu }
        '7' { Show-WindowsUtilitiesMenu }
        'Q' { $script:ExitTool = $true }
        default { Write-Warn "Invalid selection."; Start-Sleep -Milliseconds 800 }
    }
}

Write-AuditLog -Event 'LauncherExit' -Detail 'Exiting main loop'
```
```powershell
<# ========================================================================
  CS-Toolbox-Launcher.ps1  (All-in-One Menu Framework, Colored Header)
  Version: AAMenu-Short-v1.19 (Packager workflow restored)

  Audit Log:      C:\CS-Toolbox-TEMP\Collected-Info\Audit.log
  EULA State:     C:\CS-Toolbox-TEMP\Collected-Info\EulaAcceptedAt.txt  (ISO 8601 "o" format)

  EULA behavior (per request):
    - When EULA gate is needed, try to source from https://connectsecure.com/eula
    - If site cannot be reached, show message instructing tech to view the site,
      and STILL offer Y/N (Y proceeds, N runs self-destruct)
    - When site is reachable, show paragraph-by-paragraph with M until end anchor

  Change (2026-01-30):
    - Added Agent Actions menu item:
        4) Reload Agent Dependencies
      Hard-coded path:
        C:\CS-Toolbox-TEMP\prod-01-01\CS-Reload-Dependencies.ps1
========================================================================= #>

#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------- Configurable Roots ----------------
if (-not (Get-Variable -Name CS_ToolRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_ToolRoot = Split-Path -Parent $PSCommandPath
}
if (-not (Get-Variable -Name CS_TempRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_TempRoot = Join-Path $env:SystemDrive 'CS-Toolbox-TEMP'
}
if (-not (Get-Variable -Name CS_ScriptSearchRoot -Scope Script -ErrorAction SilentlyContinue)) {
    $script:CS_ScriptSearchRoot = $script:CS_ToolRoot
}

# Mirror paths globally
$global:CS_ToolRoot         = $script:CS_ToolRoot
$global:CS_TempRoot         = $script:CS_TempRoot
$global:CS_ScriptSearchRoot = $script:CS_ScriptSearchRoot
$global:CSLauncherRoot      = $script:CS_ToolRoot

$script:ExitTool = $false

# ---------------- Script Name Registry ----------------
$ScriptNames = [ordered]@{
    AgentActions_MenuLabel         = 'ConnectSecure Agent Actions'
    LogTools_MenuLabel             = 'ConnectSecure Log Tools'
    NetworkValidation_MenuLabel    = 'Network Validation'
    PackageLogs_MenuLabel          = 'Package Logs and Collected Information'
    SoftwareValidation_MenuLabel   = 'Validate Installed Software'
    WindowsUtilities_MenuLabel     = 'Windows Machine Utilities'

    # Agent Tools
    Agent_InstallOrReinstall       = 'Agent-Install-Tool.ps1'
    Agent_Uninstall                = 'Agent-Uninstall-Tool.ps1'
    Agent_Update                   = 'Agent-Update-Tool.ps1'

    # Added agent action (hard-coded path as requested)
    Agent_ReloadDependencies       = 'C:\CS-Toolbox-TEMP\prod-01-01\CS-Reload-Dependencies.ps1'

    # Log Tools
    Agent_LogReview                = 'Agent-Log-Review.ps1'
    Agent_JobReview                = 'Agent-Job-Review.ps1'
    Agent_MessageCorrelator        = 'Agent-msg-Correlator.ps1'
    Agent_LogCorrelator            = 'Agent-Log-Correlator.ps1'

    # Network Validation
    NetworkValidation              = 'NMAP-Data-Collection.ps1'
    TLS_DataCollection             = 'tls-data-collection.ps1'

    # Software Validation
    Software_AppRegistrySearch     = 'Registry-Search.ps1'
    Software_BrowserExtensions     = 'Browser-Extensions-Details.ps1'
    Software_StaleProfileScan      = 'Windows-UserProfile-AppSweep.ps1'
    Software_ValidatedApps         = 'Osquery-Data-Collection.ps1'
    Software_StoreApps             = 'Windows-Modern-App-Discovery.ps1'
    Software_WindowsUpdate         = 'Windows-Update-Details.ps1'

    # Windows Utilities
    WinUtil_ADValidation           = 'Active-Directory-Tools.ps1'
    WinUtil_DependencyValidation   = 'Dependency-Validation-Tools.ps1'
    WinUtil_MachineUtilities       = 'Machine-Utilities.ps1'
    WinUtil_SystemInfoA            = 'SystemInfo-A.ps1'
    WinUtil_SystemInfoB            = 'SystemInfo-B.ps1'
    WinUtil_AppCleanup             = 'Application-Cleanup-Script.ps1'

    # Other
    ExitAndCleanup                 = 'Toolbox-Cleanup-SelfDestruct.ps1'
    PackageLogs                    = 'zip-encrypt-htmltemplate.ps1'
}

# ---------------- Helpers ----------------
function Ensure-ExportFolder {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
    return (Resolve-Path -LiteralPath $Path).Path
}

function Preflight-Unblock {
    param([string]$Root = $script:CS_ToolRoot)
    Get-ChildItem -LiteralPath $Root -Recurse -File |
        ForEach-Object { try { Unblock-File -LiteralPath $_.FullName } catch {} }
}

function Get-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        return (New-Object Security.Principal.WindowsPrincipal($id)).
            IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Set-ConsoleSize {
    try {
        if (-not $Host.UI -or -not $Host.UI.RawUI) { return }
        $raw  = $Host.UI.RawUI
        $buf  = $raw.BufferSize
        $win  = $raw.WindowSize

        $targetWidth  = 110
        $targetHeight = 34

        if ($buf.Width  -lt $targetWidth)  { $buf.Width  = $targetWidth }
        if ($buf.Height -lt 1000)          { $buf.Height = 1000 }
        $raw.BufferSize = $buf

        $win.Width  = $targetWidth
        $win.Height = $targetHeight
        $raw.WindowSize = $win
    } catch { }
}

function Show-TopHeader {
    param([string]$SectionTitle = $null)

    Clear-Host
    $hostName = $env:COMPUTERNAME
    $userName = ([Security.Principal.WindowsIdentity]::GetCurrent().Name)
    $isAdmin  = Get-IsAdmin
    $line     = ('=' * 58)

    Write-Host ""
    Write-Host " ConnectSecure Technicians Toolbox  - Launcher v1.19" -ForegroundColor Cyan
    Write-Host " $line" -ForegroundColor DarkGray
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, $isAdmin) -ForegroundColor Gray
    Write-Host (" Base: {0}" -f $script:CS_ToolRoot) -ForegroundColor Gray
    Write-Host " $line" -ForegroundColor DarkGray

    if ($SectionTitle) {
        Write-Host " $SectionTitle" -ForegroundColor White
        Write-Host ""
    }
}

function Footer-Prompt([string]$OptionsDisplay) {
    Write-Host ""
    Write-Host ("Press ({0}) to make your selection." -f $OptionsDisplay) -ForegroundColor DarkGray
}

function Write-Warn($m){ Write-Host "[WARN]  $m" -ForegroundColor Yellow }
function Write-Info($m){ Write-Host "[INFO]  $m" -ForegroundColor Cyan }
function Write-ErrorMsg($m){ Write-Host "[ERROR] $m" -ForegroundColor Red }

# ---------------- Audit Logging + EULA Persisted State ----------------
$script:CS_CollectedInfoRoot = Join-Path $script:CS_TempRoot 'Collected-Info'
$script:AuditLogPath         = Join-Path $script:CS_CollectedInfoRoot 'Audit.log'
$script:EulaStatePath        = Join-Path $script:CS_CollectedInfoRoot 'EulaAcceptedAt.txt'
$script:AuditFallbackPath    = Join-Path $env:TEMP 'CS-Toolbox-Audit-Fallback.log'

function Ensure-CollectedInfoFolder {
    try { [void][System.IO.Directory]::CreateDirectory($script:CS_CollectedInfoRoot) } catch {
        Write-Warn "Could not create audit folder: $script:CS_CollectedInfoRoot  ($($_.Exception.Message))"
    }
}

function Ensure-AuditFile {
    try {
        Ensure-CollectedInfoFolder
        if (-not (Test-Path -LiteralPath $script:AuditLogPath)) {
            [void][System.IO.File]::WriteAllText($script:AuditLogPath, "", [System.Text.Encoding]::UTF8)
        }
    } catch {
        Write-Warn "Could not create audit log: $script:AuditLogPath  ($($_.Exception.Message))"
    }
}

function Get-UserContextInfo {
    $dtLocal = Get-Date
    $dtIso   = $dtLocal.ToString('o')
    $id      = $null
    $sid     = ''
    try { $id  = [Security.Principal.WindowsIdentity]::GetCurrent(); $sid = $id.User.Value } catch { }
    $domUser = ''
    try { $domUser = $id.Name } catch { $domUser = '' }
    $admin = Get-IsAdmin

    return [pscustomobject]@{
        LocalTime   = $dtLocal.ToString('yyyy-MM-dd HH:mm:ss')
        IsoTime     = $dtIso
        Computer    = $env:COMPUTERNAME
        DomainUser  = $domUser
        UserDomain  = $env:USERDOMAIN
        UserName    = $env:USERNAME
        Sid         = $sid
        IsAdmin     = $admin
        ScriptPath  = $PSCommandPath
    }
}

function Write-AuditLog {
    param(
        [Parameter(Mandatory=$true)][string]$Event,
        [string]$Detail = ''
    )

    $ctx = Get-UserContextInfo
    $line = "[{0}] [ISO={1}] Host={2} User={3} UDOMAIN={4} UNAME={5} SID={6} Admin={7} Script={8} Event={9} Detail={10}" -f `
        $ctx.LocalTime, $ctx.IsoTime, $ctx.Computer, $ctx.DomainUser, $ctx.UserDomain, $ctx.UserName, $ctx.Sid, $ctx.IsAdmin, $ctx.ScriptPath, $Event, $Detail

    try {
        Ensure-AuditFile
        Add-Content -LiteralPath $script:AuditLogPath -Value $line -Encoding UTF8
    } catch {
        Write-Warn "AUDIT WRITE FAILED -> $script:AuditLogPath  ($($_.Exception.Message))"
        try { Add-Content -LiteralPath $script:AuditFallbackPath -Value $line -Encoding UTF8 } catch { }
    }
}

function Load-EulaAcceptedAt {
    try {
        Ensure-CollectedInfoFolder
        if (Test-Path -LiteralPath $script:EulaStatePath) {
            $raw = (Get-Content -LiteralPath $script:EulaStatePath -ErrorAction Stop | Select-Object -First 1).Trim()
            if ($raw) { return [datetime]::Parse($raw) }
        }
    } catch {
        Write-AuditLog -Event 'EulaStateReadFailed' -Detail $_.Exception.Message
    }
    return $null
}

function Save-EulaAcceptedAt([datetime]$dt) {
    try {
        Ensure-CollectedInfoFolder
        Set-Content -LiteralPath $script:EulaStatePath -Value $dt.ToString('o') -Encoding UTF8 -Force
    } catch {
        Write-AuditLog -Event 'EulaStateWriteFailed' -Detail $_.Exception.Message
    }
}

function Resolve-ToolScript {
    param([string]$FileName)

    if ([System.IO.Path]::IsPathRooted($FileName)) {
        if (Test-Path -LiteralPath $FileName) { return Get-Item -LiteralPath $FileName }
        Write-Warn "Absolute path not found: $FileName"
        return $null
    }

    $hit = Get-ChildItem -LiteralPath $script:CS_ScriptSearchRoot -Recurse -File -Filter $FileName -ErrorAction SilentlyContinue |
        Select-Object -First 1

    if (-not $hit) {
        $hit = Get-ChildItem -LiteralPath $script:CS_ScriptSearchRoot -Recurse -File |
            Where-Object { $_.Name -ieq $FileName } | Select-Object -First 1
    }

    if (-not $hit) { Write-Warn "Could not resolve '$FileName' under $script:CS_ScriptSearchRoot" }
    return $hit
}

function Get-SafeLastExitCode {
    try {
        if (Test-Path variable:global:LASTEXITCODE) { return $global:LASTEXITCODE }
        if (Test-Path variable:LASTEXITCODE) { return $LASTEXITCODE }
    } catch { }
    return $null
}

function Launch-Tool {
    param(
        [string]$FileName,
        [string[]]$Args = @(),
        [switch]$PauseAfter
    )

    $scriptFile = Resolve-ToolScript $FileName
    if (-not $scriptFile) {
        Write-ErrorMsg "Tool not found: $FileName"
        Read-Host "Press Enter to return"
        return
    }

    $argText = if ($Args -and $Args.Count -gt 0) { ($Args -join ' ') } else { '' }
    Write-Info ("Launching: {0}{1}" -f $scriptFile.FullName, $(if($argText){"  ARGS: $argText"}else{""}))
    Write-AuditLog -Event 'ToolLaunch' -Detail ("Tool={0} Args={1}" -f $scriptFile.FullName, $argText)

    try {
        Unblock-File -LiteralPath $scriptFile.FullName -ErrorAction SilentlyContinue
        try { if (Test-Path variable:global:LASTEXITCODE) { Remove-Variable -Name LASTEXITCODE -Scope Global -ErrorAction SilentlyContinue } } catch { }

        & $scriptFile.FullName @Args

        $exitCode = Get-SafeLastExitCode
        Write-AuditLog -Event 'ToolExit' -Detail ("Tool={0} ExitCode={1}" -f $scriptFile.FullName, $(if($null -eq $exitCode){'null'}else{$exitCode}))
    } catch {
        $msg = $_.Exception.Message
        Write-AuditLog -Event 'ToolException' -Detail ("Tool={0} Error={1}" -f $scriptFile.FullName, $msg)
        Write-ErrorMsg $msg
        Read-Host "Press Enter to return"
    }

    if ($PauseAfter) { Read-Host "Press Enter to return" }
}

# ---------------- EULA Gate ----------------
$script:EulaAcceptedAt      = $null
$script:EulaPromptWindowMin = 15
$script:EulaSelfDestruct    = "C:\CS-Toolbox-TEMP\prod-01-01\Toolbox-Cleanup-SelfDestruct.ps1"
$script:EulaSourceUrl       = 'https://connectsecure.com/eula'

function Test-EulaStillValid {
    $script:EulaAcceptedAt = Load-EulaAcceptedAt
    if (-not $script:EulaAcceptedAt) { return $false }
    $ageMin = (New-TimeSpan -Start $script:EulaAcceptedAt -End (Get-Date)).TotalMinutes
    return ($ageMin -lt [double]$script:EulaPromptWindowMin)
}

function Invoke-SelfDestructAndExit {
    Write-Host ""
    Write-Host "[WARN]  EULA declined. Starting cleanup/self-destruct..." -ForegroundColor Yellow

    if (Test-Path -LiteralPath $script:EulaSelfDestruct) {
        try {
            Unblock-File -LiteralPath $script:EulaSelfDestruct -ErrorAction SilentlyContinue
            Write-AuditLog -Event 'SelfDestructLaunched' -Detail 'Attempt'
            & $script:EulaSelfDestruct
            Write-AuditLog -Event 'SelfDestructLaunched' -Detail 'Success'
        } catch {
            Write-AuditLog -Event 'SelfDestructLaunched' -Detail ("Failed: {0}" -f $_.Exception.Message)
            Write-Host "[ERROR] Failed to run self-destruct: $($_.Exception.Message)" -ForegroundColor Red
        }
    } else {
        Write-AuditLog -Event 'SelfDestructMissing' -Detail $script:EulaSelfDestruct
        Write-Host "[ERROR] Self-destruct script not found: $script:EulaSelfDestruct" -ForegroundColor Red
    }

    $script:ExitTool = $true
}

function Convert-HtmlToText {
    param([Parameter(Mandatory=$true)][string]$Html)

    $t = $Html
    $t = [regex]::Replace($t, '<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>', ' ', 'IgnoreCase')
    $t = [regex]::Replace($t, '<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>', ' ', 'IgnoreCase')
    $t = [regex]::Replace($t, '<br\s*/?>', "`n", 'IgnoreCase')
    $t = [regex]::Replace($t, '</p\s*>', "`n`n", 'IgnoreCase')
    $t = [regex]::Replace($t, '<[^>]+>', ' ')
    try { $t = [System.Net.WebUtility]::HtmlDecode($t) } catch { }

    $t = $t -replace "`r", ''
    $t = [regex]::Replace($t, "[ \t]+", ' ')
    $t = [regex]::Replace($t, "\n{3,}", "`n`n")
    $t = $t.Trim()
    return $t
}

function Get-EulaFromWeb {
    $now = Get-Date
    $obj = [ordered]@{
        SourcedAtLocal = $now.ToString('yyyy-MM-dd HH:mm:ss')
        SourceUrl      = $script:EulaSourceUrl
        LastUpdated    = ''
        Paras          = @()
        EndIndex       = -1
        FetchOk        = $false
        FetchError     = ''
    }

    $footerStopInlineRegex = '(?im)\bContact\s+Us\b'
    $footerStopParaRegex   = '(?im)^\s*Contact\s+Us\s*$|^\s*Facebook\s*$|^\s*LinkedIn\s*$|^\s*YouTube\s*$|^\s*Platform\s*$|^\s*Vulnerability\s+Management\s*$|^\s*Compliance\s+Management\s*$|^\s*Premium\s+Features\s*$'
    $endAnchorRegex        = '(?is)\(b\)\s+the\s+word\s+["“]?including["”]?\s+means\s+["“]?including,\s+without\s+limitation["”]?\s*\.\s*'
    $startAnchorText       = 'ConnectSecure, LLC'
    $startAnchorRegex      = '(?is)ConnectSecure,\s*LLC\s*\(\s*["“]?we,["”]?\s*["“]?us\s+or\s+["“]?our["”]?\s*\)\s*makes\s+available'

    try {
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

        $resp = Invoke-WebRequest -Uri $script:EulaSourceUrl -UseBasicParsing -Method GET -TimeoutSec 25 -ErrorAction Stop
        $txtRaw = Convert-HtmlToText -Html $resp.Content
        $txtRaw = $txtRaw -replace ([char]0x00A0), ' '

        $lastUpdatedMatch = [regex]::Match($txtRaw, '(?im)\bLast\s+Updated\b[:\s-]*([^\r\n]{1,120})')
        if ($lastUpdatedMatch.Success) {
            $obj.LastUpdated = ("Last Updated " + $lastUpdatedMatch.Groups[1].Value.Trim())
        }

        $txt = $txtRaw
        $pos = $txt.IndexOf($startAnchorText, [System.StringComparison]::OrdinalIgnoreCase)
        if ($pos -ge 0) {
            $txt = $txt.Substring($pos)
        } else {
            $mStart = [regex]::Match($txt, $startAnchorRegex)
            if ($mStart.Success) { $txt = $txt.Substring($mStart.Index) }
        }

        $rawParas = @()
        foreach ($p in ($txt -split "\n\s*\n")) {
            $pp = $p.Trim()
            if ($pp) { $rawParas += $pp }
        }

        $paras = New-Object System.Collections.Generic.List[string]
        foreach ($p0 in $rawParas) {
            $p = $p0.Trim()

            $mInline = [regex]::Match($p, $footerStopInlineRegex)
            if ($mInline.Success) {
                $before = $p.Substring(0, $mInline.Index).Trim()
                if ($before) { $paras.Add($before) }
                break
            }
            if ([regex]::IsMatch($p, $footerStopParaRegex)) { break }

            $paras.Add($p)
        }

        $endIdx = -1
        for ($i = 0; $i -lt $paras.Count; $i++) {
            if ([regex]::IsMatch($paras[$i], $endAnchorRegex)) { $endIdx = $i; break }
        }
        if ($endIdx -ge 0) {
            $mEnd = [regex]::Match($paras[$endIdx], $endAnchorRegex)
            if ($mEnd.Success) {
                $paras[$endIdx] = $paras[$endIdx].Substring(0, $mEnd.Index + $mEnd.Length).Trim()
            }
            while ($paras.Count -gt ($endIdx + 1)) { [void]$paras.RemoveAt($paras.Count - 1) }
        }

        $obj.Paras = $paras.ToArray()
        $obj.EndIndex = if ($endIdx -ge 0) { $endIdx } elseif ($obj.Paras.Count -gt 0) { $obj.Paras.Count - 1 } else { -1 }
        $obj.FetchOk = ($obj.Paras.Count -gt 0)
    }
    catch {
        $obj.FetchOk = $false
        $obj.FetchError = $_.Exception.Message
    }

    return [pscustomobject]$obj
}

function Show-EulaGate {
    $eula = Get-EulaFromWeb
    Write-AuditLog -Event 'EulaFetched' -Detail ("FetchOk={0} Url={1} LastUpdated={2} Paras={3} EndIndex={4} Error={5}" -f `
        $eula.FetchOk, $eula.SourceUrl, $eula.LastUpdated, $eula.Paras.Count, $eula.EndIndex, $eula.FetchError)

    if (-not $eula.FetchOk) {
        Show-TopHeader -SectionTitle "End User License Agreement (EULA) - Required"

        Write-Host (" Sourced Date: {0}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) -ForegroundColor DarkGray
        Write-Host (" Source URL:   {0}" -f $script:EulaSourceUrl) -ForegroundColor DarkGray
        Write-Host ""

        Write-Host "[WARN]  This device could not retrieve the EULA from the website." -ForegroundColor Yellow
        Write-Host ("       Please view the EULA here: {0}" -f $script:EulaSourceUrl) -ForegroundColor Yellow
        Write-Host ("       Reason: {0}" -f $eula.FetchError) -ForegroundColor DarkGray
        Write-Host ""

        while ($true) {
            Write-Host "Do you accept this EULA?" -ForegroundColor White
            Write-Host "  Y) Yes - I accept and wish to continue" -ForegroundColor White
            Write-Host "  N) No  - Run cleanup/self-destruct and exit" -ForegroundColor White
            Write-Host ""
            $resp = (Read-Host "Selection (Y/N)").Trim().ToUpper()
            switch ($resp) {
                'Y' {
                    $script:EulaAcceptedAt = Get-Date
                    Save-EulaAcceptedAt $script:EulaAcceptedAt
                    Write-AuditLog -Event 'Accepted' -Detail ("AcceptedAt={0} Url={1} Note=SiteUnreachable" -f $script:EulaAcceptedAt.ToString('yyyy-MM-dd HH:mm:ss'), $script:EulaSourceUrl)
                    Start-Sleep -Milliseconds 200
                    return $true
                }
                'N' {
                    Write-AuditLog -Event 'Declined' -Detail ("SelfDestructPath={0} Url={1} Note=SiteUnreachable" -f $script:EulaSelfDestruct, $script:EulaSourceUrl)
                    Invoke-SelfDestructAndExit
                    return $false
                }
                default { Write-Host "[WARN]  Invalid selection. Please enter Y or N." -ForegroundColor Yellow }
            }
        }
    }

    $idx = 0
    $endIdx = if ($eula.EndIndex -ge 0) { $eula.EndIndex } else { ($eula.Paras.Count - 1) }

    while ($true) {
        Show-TopHeader -SectionTitle "End User License Agreement (EULA) - Required"

        Write-Host (" Sourced Date: {0}" -f $eula.SourcedAtLocal) -ForegroundColor DarkGray
        Write-Host (" Source URL:   {0}" -f $eula.SourceUrl) -ForegroundColor DarkGray
        if ($eula.LastUpdated) { Write-Host (" {0}" -f $eula.LastUpdated) -ForegroundColor DarkGray }
        if ($script:EulaAcceptedAt) {
            Write-Host (" Last accepted: {0}" -f $script:EulaAcceptedAt.ToString("yyyy-MM-dd HH:mm:ss")) -ForegroundColor DarkGray
        }
        Write-Host ""

        $isFinal = ($idx -ge $endIdx)

        $label = if ($isFinal) {
            " (Showing FINAL paragraph. You must select Y or N to continue.)"
        } elseif ($idx -eq 0) {
            " (Showing EULA opening paragraph. Press M to show the next paragraph.)"
        } else {
            " (Showing next paragraph #$idx. Press M to continue.)"
        }

        Write-Host $label -ForegroundColor DarkGray
        Write-Host ""
        Write-Host (" {0}" -f $eula.Paras[$idx]) -ForegroundColor Yellow
        Write-Host ""

        if ($isFinal) {
            while ($true) {
                Write-Host "Do you accept this EULA?" -ForegroundColor White
                Write-Host "  Y) Yes - I accept and wish to continue" -ForegroundColor White
                Write-Host "  N) No  - Run cleanup/self-destruct and exit" -ForegroundColor White
                Write-Host ""
                $resp = (Read-Host "Selection (Y/N)").Trim().ToUpper()
                switch ($resp) {
                    'Y' {
                        $script:EulaAcceptedAt = Get-Date
                        Save-EulaAcceptedAt $script:EulaAcceptedAt
                        Write-AuditLog -Event 'Accepted' -Detail ("AcceptedAt={0} Url={1} LastUpdated={2} EndIndex={3}" -f `
                            $script:EulaAcceptedAt.ToString('yyyy-MM-dd HH:mm:ss'), $eula.SourceUrl, $eula.LastUpdated, $endIdx)
                        Start-Sleep -Milliseconds 200
                        return $true
                    }
                    'N' {
                        Write-AuditLog -Event 'Declined' -Detail ("SelfDestructPath={0} Url={1} LastUpdated={2} EndIndex={3}" -f `
                            $script:EulaSelfDestruct, $eula.SourceUrl, $eula.LastUpdated, $endIdx)
                        Invoke-SelfDestructAndExit
                        return $false
                    }
                    default { Write-Host "[WARN]  Invalid selection. Please enter Y or N." -ForegroundColor Yellow }
                }
            }
        }

        Write-Host "Do you accept this EULA?" -ForegroundColor White
        Write-Host "  Y) Yes - I accept and wish to continue" -ForegroundColor White
        Write-Host "  N) No  - Run cleanup/self-destruct and exit" -ForegroundColor White
        Write-Host "  M) More - Show the next paragraph" -ForegroundColor White
        Write-Host ""

        $resp = (Read-Host "Selection (Y/N/M)").Trim().ToUpper()
        switch ($resp) {
            'Y' {
                $script:EulaAcceptedAt = Get-Date
                Save-EulaAcceptedAt $script:EulaAcceptedAt
                Write-AuditLog -Event 'Accepted' -Detail ("AcceptedAt={0} Url={1} LastUpdated={2} ViewedIndex={3} EndIndex={4}" -f `
                    $script:EulaAcceptedAt.ToString('yyyy-MM-dd HH:mm:ss'), $eula.SourceUrl, $eula.LastUpdated, $idx, $endIdx)
                Start-Sleep -Milliseconds 200
                return $true
            }
            'N' {
                Write-AuditLog -Event 'Declined' -Detail ("SelfDestructPath={0} Url={1} LastUpdated={2} ViewedIndex={3} EndIndex={4}" -f `
                    $script:EulaSelfDestruct, $eula.SourceUrl, $eula.LastUpdated, $idx, $endIdx)
                Invoke-SelfDestructAndExit
                return $false
            }
            'M' {
                if ($idx -lt $endIdx) { $idx++ }
            }
            default {
                Write-Host "[WARN]  Invalid selection. Please enter Y, N, or M." -ForegroundColor Yellow
                Start-Sleep -Milliseconds 350
            }
        }
    }
}

function Ensure-EulaGate {
    if (-not (Test-EulaStillValid)) { return (Show-EulaGate) }
    return $true
}

# ---------------- Menus ----------------
function Show-AgentActionsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.AgentActions_MenuLabel
    Write-Host " You are in: ConnectSecure Agent Actions" -ForegroundColor Yellow
    Write-Host ""

    Write-Host " 1) Install or Reinstall Agent" -ForegroundColor White
    Write-Host "    Detects, downloads, installs, and verifies the agent." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Uninstall Agent (with Portal Reminder)" -ForegroundColor White
    Write-Host "    Clean removal of the agent with reminder to clean up in the portal." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Update Agent" -ForegroundColor White
    Write-Host "    Triggers an agent update using the ConnectSecure updater." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Reload Agent Dependencies" -ForegroundColor White
    Write-Host "    Stop services -> delete dependency files -> start services (logged/exported by tool)." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_ReloadDependencies) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/3/4/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.Agent_InstallOrReinstall }
        '2' { Launch-Tool $ScriptNames.Agent_Uninstall }
        '3' { Launch-Tool $ScriptNames.Agent_Update -PauseAfter }
        '4' { Launch-Tool $ScriptNames.Agent_ReloadDependencies -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Show-LogToolsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.LogTools_MenuLabel
    Write-Host " You are in: ConnectSecure Log Tools" -ForegroundColor Yellow
    Write-Host ""

    Write-Host " 1) Agent Error Review / Analyzer - Single-Agent" -ForegroundColor White
    Write-Host "    Parse agent logs for errors/warnings and export to HTML." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_LogReview) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Agent Job Review / Analyzer - Single-Agent" -ForegroundColor White
    Write-Host "    Group job runs, show last success/issue, and export summary." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_JobReview) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Agent Message Correlator - Single-Agent" -ForegroundColor White
    Write-Host "    Correlate message logs to find repeating patterns and issues." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_MessageCorrelator) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Agent Log Correlator / Analyzer - Multi-Agent" -ForegroundColor White
    Write-Host "    Multi-agent log correlation, grouped errors, and HTML export." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.Agent_LogCorrelator) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/3/4/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.Agent_LogReview }
        '2' { Launch-Tool $ScriptNames.Agent_JobReview }
        '3' { Launch-Tool $ScriptNames.Agent_MessageCorrelator -PauseAfter }
        '4' { Launch-Tool $ScriptNames.Agent_LogCorrelator -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Invoke-ExitAndCleanup {
    Show-TopHeader -SectionTitle "Exit and Cleanup"
    Launch-Tool $ScriptNames.ExitAndCleanup
    $script:ExitTool = $true
}

function Show-NetworkValidationMenu {
    Show-TopHeader -SectionTitle $ScriptNames.NetworkValidation_MenuLabel

    Write-Host " 1) Scan Networks or Local Machine" -ForegroundColor White
    Write-Host "    Run NMAP-based scans against hosts or ranges." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.NetworkValidation) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) TLS/SSL Policy (Local Host)" -ForegroundColor White
    Write-Host "    Collect SCHANNEL/TLS configuration from the local machine." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.TLS_DataCollection) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.NetworkValidation }
        '2' { Launch-Tool $ScriptNames.TLS_DataCollection -PauseAfter }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Show-PackageLogsMenu {
    Show-TopHeader -SectionTitle $ScriptNames.PackageLogs_MenuLabel

    Write-Host " 1) Packager / Encrypt Helper" -ForegroundColor White
    Write-Host "    Zip and optionally encrypt toolbox logs/outputs." -ForegroundColor DarkGray
    Write-Host "    (Secure/Unsecure selection happens inside the packager.)" -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.PackageLogs) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/B"
    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.PackageLogs }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Show-SoftwareValidationMenu {
    Show-TopHeader -SectionTitle $ScriptNames.SoftwareValidation_MenuLabel
    Write-Host " You are in: Validate Installed Software" -ForegroundColor Yellow
    Write-Host ""

    Write-Host " 1) Application Registry Search" -ForegroundColor White
    Write-Host "    Search uninstall registry hives (HKLM/HKCU) for apps and export results." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Browser Extension Details" -ForegroundColor White
    Write-Host "    Enumerate installed browser extensions per user (Chrome/Edge/Firefox)." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Stale Profile Application Scan" -ForegroundColor White
    Write-Host "    Scan user profiles for large/old application data to target for cleanup." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Validate Installed Software (osquery)" -ForegroundColor White
    Write-Host "    Use osquery to inventory installed software in a normalized export." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 5) Windows Store Application Inventory" -ForegroundColor White
    Write-Host "    List UWP/AppX packages with name, version, and scope." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 6) Windows Update Details" -ForegroundColor White
    Write-Host "    Show Windows Update history with KB, date, category, and status." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back to Main Menu" -ForegroundColor White
    Footer-Prompt "1/2/3/4/5/6/B"

    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.Software_AppRegistrySearch }
        '2' { Launch-Tool $ScriptNames.Software_BrowserExtensions }
        '3' { Launch-Tool $ScriptNames.Software_StaleProfileScan }
        '4' { Launch-Tool $ScriptNames.Software_ValidatedApps }
        '5' { Launch-Tool $ScriptNames.Software_StoreApps }
        '6' { Launch-Tool $ScriptNames.Software_WindowsUpdate }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

function Show-WindowsUtilitiesMenu {
    Show-TopHeader -SectionTitle $ScriptNames.WindowsUtilities_MenuLabel

    Write-Host " 1) Active Directory Collection / Validation" -ForegroundColor White
    Write-Host "    Run AD data collectors for users, computers, OUs, and GPOs." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_ADValidation) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) Dependency Validation Tools" -ForegroundColor White
    Write-Host "    Check runtimes, DLLs, and OS features required by ConnectSecure." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_DependencyValidation) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Machine Utilities - Services & Disk Space" -ForegroundColor White
    Write-Host "    Review key services and disk utilization for health issues." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_MachineUtilities) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) System Info A - Firewall, Defender, SMART" -ForegroundColor White
    Write-Host "    Collect basic protection and disk health information." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_SystemInfoA) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 5) System Info B - Reboot, Startup, Logs" -ForegroundColor White
    Write-Host "    Show reboot state, startup load, and key event log snippets." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_SystemInfoB) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 6) Windows Application - Cleanup S&D" -ForegroundColor White
    Write-Host "    Guided application removal and leftover cleanup with logging." -ForegroundColor DarkGray
    Write-Host ("    Launch: {0}" -f $ScriptNames.WinUtil_AppCleanup) -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " B) Back" -ForegroundColor White
    Footer-Prompt "1/2/3/4/5/6/B"

    switch ((Read-Host "Selection").Trim().ToUpper()) {
        '1' { Launch-Tool $ScriptNames.WinUtil_ADValidation }
        '2' { Launch-Tool $ScriptNames.WinUtil_DependencyValidation }
        '3' { Launch-Tool $ScriptNames.WinUtil_MachineUtilities }
        '4' { Launch-Tool $ScriptNames.WinUtil_SystemInfoA }
        '5' { Launch-Tool $ScriptNames.WinUtil_SystemInfoB }
        '6' { Launch-Tool $ScriptNames.WinUtil_AppCleanup }
        'B' { return }
        default { Write-Warn "Invalid selection."; Start-Sleep 1 }
    }
}

# ---------------- Main Menu ----------------
function Show-MainMenu {
    if (-not (Ensure-EulaGate)) { return }

    $acc = if ($script:EulaAcceptedAt) { $script:EulaAcceptedAt.ToString('yyyy-MM-dd HH:mm:ss') } else { '' }
    Write-AuditLog -Event 'MainMenuShown' -Detail ("EulaAcceptedAt={0}" -f $acc)

    Show-TopHeader -SectionTitle "Main Menu"

    Write-Host " 1) ConnectSecure Agent Actions" -ForegroundColor White
    Write-Host "    Install / Update / Uninstall agent." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 2) ConnectSecure Log Tools" -ForegroundColor White
    Write-Host "    Single- and multi-agent log review and correlation." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 3) Exit Toolbox and Cleanup Files" -ForegroundColor White
    Write-Host "    Run cleanup helper and exit the toolbox." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 4) Network Validation" -ForegroundColor White
    Write-Host "    NMAP scan profiles and TLS/SSL policy collection." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 5) Package Logs and Collected Information" -ForegroundColor White
    Write-Host "    Zip/encrypt toolbox outputs and generate handoff info." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 6) Validate Installed Software" -ForegroundColor White
    Write-Host "    App registry, osquery inventory, Store apps, and updates." -ForegroundColor DarkGray
    Write-Host ""

    Write-Host " 7) Windows Machine Utilities" -ForegroundColor White
    Write-Host "    System info, AD tools, dependencies, disk/services, cleanup." -ForegroundColor DarkGray
    Write-Host ""

    Footer-Prompt "1/2/3/4/5/6/7/Q"
}

# ---------------- Main Loop (STARTUP PAUSE ON ERROR) ----------------
try {
    Ensure-ExportFolder $script:CS_TempRoot | Out-Null
    Ensure-CollectedInfoFolder
    Ensure-AuditFile

    Preflight-Unblock -Root $script:CS_ToolRoot
    Write-AuditLog -Event 'LauncherStart' -Detail ("ToolRoot={0}" -f $script:CS_ToolRoot)

    Set-ConsoleSize
}
catch {
    $msg = $_.Exception.Message

    Write-Host ""
    Write-Host "================ STARTUP ERROR ================" -ForegroundColor Red
    Write-Host $msg -ForegroundColor Red
    Write-Host ""
    Write-Host "Full error:" -ForegroundColor Yellow
    Write-Host $_ -ForegroundColor Yellow
    Write-Host "===============================================" -ForegroundColor Red
    Write-Host ""

    try { Write-AuditLog -Event 'LauncherStartupException' -Detail $msg } catch { }

    Read-Host "Press Enter to close (fix the error and re-run)"
    exit 1
}

while (-not $script:ExitTool) {
    Show-MainMenu
    if ($script:ExitTool) { break }

    $sel = (Read-Host "Selection").Trim().ToUpper()
    Write-AuditLog -Event 'MenuSelection' -Detail ("Menu=Main Selection={0}" -f $sel)

    switch ($sel) {
        '1' { Show-AgentActionsMenu }
        '2' { Show-LogToolsMenu }
        '3' { Invoke-ExitAndCleanup }
        '4' { Show-NetworkValidationMenu }
        '5' { Show-PackageLogsMenu }
        '6' { Show-SoftwareValidationMenu }
        '7' { Show-WindowsUtilitiesMenu }
        'Q' { $script:ExitTool = $true }
        default { Write-Warn "Invalid selection."; Start-Sleep -Milliseconds 800 }
    }
}

Write-AuditLog -Event 'LauncherExit' -Detail 'Exiting main loop'
```
