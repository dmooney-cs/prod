# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ╔═════════════════════════════════════════════════════════════════════════════╗
# ║ 🧰 ConnectSecure Technicians Toolbox – Main Launcher v2.4                  ║
# ║ Final | Includes pause on Z/C failure, shared loader enforced              ║
# ╚═════════════════════════════════════════════════════════════════════════════╝

function Launch-Tool {
    param ([string]$name)
    $path = Join-Path $scriptRoot $name
    if (Test-Path $path) {
        Write-SessionSummary "Launched: $name"
        & $path
    } else {
        Write-Host "❌ Script not found: $name" -ForegroundColor Red
        Pause-Script
    }
}

function Show-MainMenu {
    do {
        Clear-Host
        Show-Header "ConnectSecure Technicians Toolbox"

        Write-Host " [1] Validation Tool A         - Office, Drivers, Roaming, Extensions"
        Write-Host " [2] Validation Tool B         - Patches, VC++ Runtime Scanner"
        Write-Host " [3] Validation Tool C         - SSL Ciphers, OSQuery Extensions"
        Write-Host ""
        Write-Host " [4] Network Tools             - TLS 1.0 Scan, Nmap, Validate SMB"
        Write-Host " [5] Active Directory Tools    - Users, Groups, OUs, GPOs"
        Write-Host ""
        Write-Host " [6] System Info A             - Firewall, Defender, Disk/SMART"
        Write-Host " [7] System Info B             - Pending Reboot, App Logs, Startup Audit"
        Write-Host ""
        Write-Host " [8] Utilities                 - Running Services, Disk Space"
        Write-Host ""
        Write-Host " [9] Agent Menu Tool           - Install, Uninstall, Status, Maintenance"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results     - Compress and prepare results for support"
        Write-Host " [C] Cleanup Toolbox Data      - Remove all temp and output files"
        Write-Host " [Q] Quit"
        Write-Host ""

        $choice = Read-Host "Enter your choice"
        switch ($choice.ToUpper()) {
            "1" { Launch-Tool "ValidationTool-Collection A.ps1" }
            "2" { Launch-Tool "ValidationTool-Collection B.ps1" }
            "3" { Launch-Tool "ValidationTool-Collection C.ps1" }
            "4" { Launch-Tool "Network-Tools.ps1" }
            "5" { Launch-Tool "ValidationTool-AD.ps1" }
            "6" { Launch-Tool "SystemInfo-A.ps1" }
            "7" { Launch-Tool "SystemInfo-B.ps1" }
            "8" { Launch-Tool "Tools-Utilities.ps1" }
            "9" { Launch-Tool "Agent-Menu-Tool.ps1" }
            "Z" {
                try {
                    Invoke-ZipAndEmailResults
                } catch {
                    Write-Host "❌ ERROR during ZIP/email: $($_.Exception.Message)" -ForegroundColor Red
                    Pause-Script
                }
            }
            "C" {
                try {
                    Invoke-FinalCleanupAndExit
                } catch {
                    Write-Host "❌ ERROR during final cleanup: $($_.Exception.Message)" -ForegroundColor Red
                    Pause-Script
                }
            }
            "Q" {
                Pause-Script
                return
            }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Start-Sleep -Seconds 1
            }
        }
    } while ($true)
}

Show-MainMenu
