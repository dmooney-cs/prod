# ========================= CS-Toolbox-Launcher.ps1 =========================
# Launches sub-tools via hard-coded full paths in the SAME WINDOW.
# No dependency on a Launch-Tool wrapper; each choice calls & 'C:\...script.ps1'
# ===========================================================================

# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# ---- Hard-coded script paths (SAME WINDOW EXECUTION) ----
$P_OSQuery   = 'C:\CS-Toolbox-TEMP\prod-01-01\Osquery-Data-Collection.ps1'
$P_Nmap      = 'C:\CS-Toolbox-TEMP\prod-01-01\Nmap-Data-Collection.ps1'
$P_ValidA    = 'C:\CS-Toolbox-TEMP\prod-01-01\ValidationTool-Collection A.ps1'  # Secondary Validation Tools (3-in-1)
$P_ModernApp = 'C:\CS-Toolbox-TEMP\prod-01-01\Windows-ModernApp-Discovery.ps1' # If not present, message shown
$P_AD        = 'C:\CS-Toolbox-TEMP\prod-01-01\ValidationTool-AD.ps1'
$P_SysA      = 'C:\CS-Toolbox-TEMP\prod-01-01\SystemInfo-A.ps1'
$P_SysB      = 'C:\CS-Toolbox-TEMP\prod-01-01\SystemInfo-B.ps1'
$P_Utils     = 'C:\CS-Toolbox-TEMP\prod-01-01\Tools-Utilities.ps1'
$P_AgentMenu = 'C:\CS-Toolbox-TEMP\prod-01-01\Agent-Menu-Tool.ps1'

function Invoke-Hardcoded {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Label
    )
    if (-not (Test-Path -LiteralPath $Path)) {
        Write-Host "❌ ERROR launching ${Label}: file not found at ${Path}" -ForegroundColor Red
        Pause-Script
        return
    }
    try {
        # Call in the same window
        & $Path
    } catch {
        Write-Host "❌ ERROR launching ${Label} at ${Path}: $($_.Exception.Message)" -ForegroundColor Red
        Pause-Script
    }
}

function Show-MainMenu {
    Clear-Host
    Show-Header -Title "ConnectSecure Technicians Toolbox"

    Write-Host ""
    Write-Host " [1] OSQuery Data Collection      - Apps, search, browser extensions"
    Write-Host " [2] Nmap Data Collection         - Local network scan profiles"
    Write-Host " [3] Secondary Validation Tools   - Patch Audit, VC++ Runtime, TLS/SSL Audit, Registry Uninstall Search"
    Write-Host " [4] Windows Modern App Discovery - Enumerate & search Modern/Store apps"
    Write-Host " [5] Active Directory Tools       - Users, Groups, OUs, GPOs"
    Write-Host " [6] System Info A                - Firewall, Defender, Disk/SMART"
    Write-Host " [7] System Info B                - Pending Reboot, App Logs, Startup"
    Write-Host " [8] Utilities                    - Services, Disk Space"
    Write-Host " [9] Agent Menu Tool              - Install, Reinstall, Uninstall"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results        - Compress results for support"
    Write-Host " [C] Cleanup and Exit Toolbox"
    Write-Host ""
}

# Main loop (no [Q]; use [C] to cleanup/exit per project standard)
while ($true) {
    Show-MainMenu
    $choice = Read-Host "Enter your choice"

    switch ($choice.ToUpper()) {
        '1' { Invoke-Hardcoded -Path $P_OSQuery   -Label 'OSQuery Data Collection' }
        '2' { Invoke-Hardcoded -Path $P_Nmap      -Label 'Nmap Data Collection' }
        '3' { Invoke-Hardcoded -Path $P_ValidA    -Label 'Secondary Validation Tools (Collection A)' }
        '4' { Invoke-Hardcoded -Path $P_ModernApp -Label 'Windows Modern App Discovery' }
        '5' { Invoke-Hardcoded -Path $P_AD        -Label 'Active Directory Tools' }
        '6' { Invoke-Hardcoded -Path $P_SysA      -Label 'System Info A' }
        '7' { Invoke-Hardcoded -Path $P_SysB      -Label 'System Info B' }
        '8' { Invoke-Hardcoded -Path $P_Utils     -Label 'Utilities' }
        '9' { Invoke-Hardcoded -Path $P_AgentMenu -Label 'Agent Menu Tool' }

        'Z' {
            try {
                $zipPath = Zip-Results
                if ($zipPath) {
                    Email-Results -ZipPath $zipPath
                } else {
                    Write-Host "⚠ Zip-Results did not return a file path." -ForegroundColor Yellow
                    Pause-Script
                }
            } catch {
                Write-Host "❌ ERROR during Zip & Email: $($_.Exception.Message)" -ForegroundColor Red
                Pause-Script
            }
        }

        'C' {
            try {
                Invoke-FinalCleanupAndExit
            } catch {
                Write-Host "❌ ERROR during Cleanup: $($_.Exception.Message)" -ForegroundColor Red
                Write-Host "Press any key to exit..."
                $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
                exit
            }
        }

        default {
            Write-Host "Invalid choice. Please select a listed option." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
        }
    }
}
