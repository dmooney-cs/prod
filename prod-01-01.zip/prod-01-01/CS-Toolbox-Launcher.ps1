# ============================================
# CS-Toolbox-Launcher.ps1  (Main Menu)
# ============================================

# --- Load shared functions first (Show-Header, helpers, etc.) ---
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

# -------------------------------------------------------------------
# Local fallback: Invoke-FinalCleanupAndExit (if Common lacks it)
# (Your Functions-Common now includes an elevated, new-window version,
#  but this keeps the launcher resilient if an older Common is loaded.)
# -------------------------------------------------------------------
if (-not (Get-Command -Name Invoke-FinalCleanupAndExit -ErrorAction SilentlyContinue)) {
    function Invoke-FinalCleanupAndExit {
        [CmdletBinding()]
        param(
            [int]$CountdownSeconds = 3
        )
        $tempRoot = "C:\CS-Toolbox-TEMP"
        try {
            Write-Host ""
            Write-Host ("Cleanup will remove {0} and exit..." -f $tempRoot) -ForegroundColor Yellow
            for ($i=$CountdownSeconds; $i -ge 1; $i--) {
                Write-Host ("Deleting in {0}s..." -f $i)
                Start-Sleep -Seconds 1
            }
            if (Test-Path $tempRoot) {
                Get-ChildItem -Path $tempRoot -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
                    try { $_.Attributes = 'Normal' } catch {}
                }
                Remove-Item -Path $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
            }
        } catch {
            Write-Host ("ERROR during cleanup: {0}" -f $_.Exception.Message) -ForegroundColor Red
        }
    }
}
# -------------------------------------------------------------------

# =========================
#  CS Toolbox Main Launcher
# =========================
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Show-MainMenu {
    Clear-Host
    Show-Header "ConnectSecure Technicians Toolbox"

    Write-Host ""
    Write-Host " [1] OSQuery Data Collection    - Browser/Apps via osquery"
    Write-Host " [2] Nmap Data Collection       - Port/Service scan via nmap"
    Write-Host " [3] OSQuery + WMIC Patch Audit - Patch inventory via osquery/WMIC"
    Write-Host " [4] Secondary Validation Tools - Office, Drivers, Roaming, Extensions"
    Write-Host ""
    Write-Host " [5] Network Tools              - TLS 1.0 Scan, Validate SMB, misc"
    Write-Host " [6] Active Directory Tools     - Users, Groups, OUs, GPOs"
    Write-Host ""
    Write-Host " [7] System Info A              - Firewall, Defender, Disk/SMART"
    Write-Host " [8] System Info B              - Pending Reboot, App Logs, Startup Audit"
    Write-Host ""
    Write-Host " [9] Utilities                  - Running Services, Disk Space"
    Write-Host " [10] Agent Menu Tool           - Install, Uninstall, Status, Maintenance"
    Write-Host ""
    Write-Host " [Z] Zip and Email Results      - Compress results for support"
    Write-Host " [C] Cleanup Toolbox Data       - Remove temp/output and self-clean"
    Write-Host " [Q] Quit                       - Optional cleanup before exit"
    Write-Host ""
}

function Invoke-MenuAction {
    param([Parameter(Mandatory)][string]$Choice)

    $normalized = $Choice.Trim().ToUpperInvariant()

    switch ($normalized) {
        '1'  {
            try { Launch-Tool "Osquery-Data-Collection.ps1" }
            catch { Write-Host "ERROR launching Osquery-Data-Collection.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        '2'  {
            try { Launch-Tool "Nmap-Data-Collection.ps1" }
            catch { Write-Host "ERROR launching Nmap-Data-Collection.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        '3'  {
            try { Launch-Tool "OSQuery-WMIC-Patch-Audit.ps1" }
            catch { Write-Host "ERROR launching OSQuery-WMIC-Patch-Audit.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        '4'  {
            try { Launch-Tool "ValidationTool-Collection A.ps1" }  # former menu #3
            catch { Write-Host "ERROR launching ValidationTool-Collection A.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        '5'  {
            try { Launch-Tool "Network-Tools.ps1" }
            catch { Write-Host "ERROR launching Network-Tools.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        '6'  {
            try { Launch-Tool "ValidationTool-AD.ps1" }
            catch { Write-Host "ERROR launching ValidationTool-AD.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        '7'  {
            try { Launch-Tool "SystemInfo-A.ps1" }
            catch { Write-Host "ERROR launching SystemInfo-A.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        '8'  {
            try { Launch-Tool "SystemInfo-B.ps1" }
            catch { Write-Host "ERROR launching SystemInfo-B.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        '9'  {
            try { Launch-Tool "Tools-Utilities.ps1" }
            catch { Write-Host "ERROR launching Tools-Utilities.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        '10' {
            try { Launch-Tool "Agent-Menu-Tool.ps1" }
            catch { Write-Host "ERROR launching Agent-Menu-Tool.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script }
        }
        'Z'  {
            try {
                Zip-Results
                Pause-Script "Zip complete. Press any key to return to the main menu..."
            } catch {
                Write-Host "ERROR zipping results: $($_.Exception.Message)" -ForegroundColor Red
                Pause-Script
            }
        }
        'C'  {
            try {
                Invoke-FinalCleanupAndExit
            } catch {
                Write-Host "ERROR during cleanup: $($_.Exception.Message)" -ForegroundColor Red
                Pause-Script
            }
        }
        'Q'  {
            $response = Read-Host "Cleanup Toolbox Data before exit? (Y to cleanup, Enter to skip)"
            if ($response.Trim().ToUpperInvariant() -eq 'Y') {
                try {
                    Invoke-FinalCleanupAndExit
                } catch {
                    Write-Host "ERROR during cleanup: $($_.Exception.Message)" -ForegroundColor Red
                    Pause-Script
                }
            }
            return $true
        }
        Default {
            Write-Host "Unknown choice. Please try again." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 900
        }
    }

    return $false
}

# ======== Main Loop ========
while ($true) {
    Show-MainMenu
    $choice = Read-Host "Enter your choice"
    $shouldQuit = Invoke-MenuAction -Choice $choice
    if ($shouldQuit) { break }
}
