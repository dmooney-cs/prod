# ============================
# Agent-Maintenance.ps1  (ASCII-only, PS 5.1 safe)
# ============================

# Load shared functions
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'
if (-not (Test-Path $commonPath)) { Write-Host "[ERROR] Functions-Common.ps1 not found." -ForegroundColor Red; Pause-Script "Press any key..."; return }
try { . $commonPath } catch { Write-Host "[ERROR] Failed to load Functions-Common.ps1: $($_.Exception.Message)" -ForegroundColor Red; Pause-Script "Press any key..."; return }
Ensure-ExportFolder

$Hostname       = $env:COMPUTERNAME
$Stamp          = Get-Date -Format "yyyyMMdd_HHmmss"
$ExportRoot     = "C:\CS-Toolbox-TEMP\Collected-Info"
$TranscriptPath = Join-Path $ExportRoot ("{0}-AgentMaintenance-{1}.log" -f $Hostname,$Stamp)

$TranscriptStarted = $false
try { Start-Transcript -Path $TranscriptPath -Append -ErrorAction Stop | Out-Null; $TranscriptStarted=$true } catch {}

function Restart-AgentServices {
    Show-Header "Agent Maintenance"
    foreach ($n in @("CyberCNSAgent","ConnectSecureAgentMonitor")) {
        $svc = Get-Service -Name $n -ErrorAction SilentlyContinue
        if ($svc) {
            Write-Host ("Restarting {0} ..." -f $n) -ForegroundColor Cyan
            try {
                if ($svc.Status -eq 'Running') { Stop-Service -Name $n -Force -ErrorAction Stop; $svc.WaitForStatus('Stopped','00:00:20') }
                Start-Service -Name $n -ErrorAction Stop
                $svc.WaitForStatus('Running','00:00:25')
                Write-Host ("[OK] {0} is Running" -f $n) -ForegroundColor Green
            } catch {
                Write-Host ("[ERROR] Could not restart {0}: {1}" -f $n, $_.Exception.Message) -ForegroundColor Red
            }
        } else {
            Write-Host ("[INFO] Service {0} not found" -f $n) -ForegroundColor DarkGray
        }
    }
    Pause-Script "Press any key to return..."
}

try { Restart-AgentServices } finally {
    if($TranscriptStarted){ try { Stop-Transcript | Out-Null; Write-Host ("Log saved to: {0}" -f $TranscriptPath) -ForegroundColor DarkGray } catch {} }
}
