# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

# ╔═════════════════════════════════════════════════════════════╗
# ║ 🧰 CS Toolbox – Agent Maintenance Tool                     ║
# ║ Version: A.2 | SMB Check/Fix, Clear Jobs, Agent Status     ║
# ╚═════════════════════════════════════════════════════════════╝

# Load shared functions from the local extracted folder, with pause/error if missing
$commonPath = Join-Path $PSScriptRoot 'Functions-Common.ps1'
if (Test-Path $commonPath) {
    . $commonPath
} else {
    Write-Host "ERROR: Functions-Common.ps1 not found in $PSScriptRoot"
    Write-Host "This script cannot continue without common functions."
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

function Run-CheckAgentStatus {
    Show-Header "Agent Status Check"
    $svc1 = Get-Service -Name "CyberCNSAgent" -ErrorAction SilentlyContinue
    $svc2 = Get-Service -Name "CyberCNSAgentMonitor" -ErrorAction SilentlyContinue

    $result = @()
    if ($svc1) {
        $result += "CyberCNSAgent: $($svc1.Status)"
    } else {
        $result += "CyberCNSAgent: Not Installed"
    }
    if ($svc2) {
        $result += "CyberCNSAgentMonitor: $($svc2.Status)"
    } else {
        $result += "CyberCNSAgentMonitor: Not Installed"
    }

    Export-Data -Object $result -BaseName "AgentServiceStatus" -Ext "txt"
    Write-SessionSummary "Checked agent status: CyberCNSAgent = $($svc1?.Status), Monitor = $($svc2?.Status)"
    Pause-Script
}

function Run-ClearPendingJobs {
    Show-Header "Clear Agent Pending Jobs"
    $jobPath = "C:\Program Files (x86)\CyberCNSAgent\jobs"

    if (Test-Path $jobPath) {
        Remove-Item "$jobPath\*" -Force -Recurse -ErrorAction SilentlyContinue
        Write-Host "✅ Cleared all pending jobs." -ForegroundColor Green
        Write-SessionSummary "Cleared all pending agent jobs."
    } else {
        Write-Host "Job folder not found." -ForegroundColor Yellow
        Write-SessionSummary "⚠️ Agent job folder not found."
    }

    Pause-Script
}

function Run-SetSMB {
    Show-Header "Enable SMB (Registry + Firewall)"
    try {
        Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" SMB2 -Type DWORD -Value 1 -Force
        Set-NetFirewallRule -DisplayName "File And Printer Sharing (SMB-In)" -Enabled true -Profile Any
        Set-NetFirewallRule -DisplayName "File And Printer Sharing (NB-Session-In)" -Enabled true -Profile Any
        New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "LocalAccountTokenFilterPolicy" -PropertyType DWord -Value 1 -Force
        Write-Host "✅ SMB enabled and configured." -ForegroundColor Green
        Write-SessionSummary "SMB and firewall settings applied."
    } catch {
        Write-Host "❌ Error enabling SMB: $_" -ForegroundColor Red
        Write-SessionSummary "❌ Error enabling SMB: $($_.Exception.Message)"
    }
    Pause-Script
}

function Run-CheckSMB {
    Show-Header "Check SMB Configuration"

    $smbEnabled = Get-ItemPropertyValue -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "SMB2" -ErrorAction SilentlyContinue
    $firewallSMB = (Get-NetFirewallRule -DisplayName "File And Printer Sharing (SMB-In)").Enabled
    $tokenPolicy = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "LocalAccountTokenFilterPolicy" -ErrorAction SilentlyContinue

    $result = @(
        "SMB2 Enabled: $smbEnabled",
        "Firewall Rule SMB-In Enabled: $firewallSMB",
        "Token Filter Policy Set: $tokenPolicy"
    )

    Export-Data -Object $result -BaseName "SMBCheck" -Ext "txt"
    Write-SessionSummary "Checked SMB settings: SMB2=$smbEnabled, FW=$firewallSMB, TokenFilter=$tokenPolicy"
    Pause-Script
}

function Run-ZipAndEmailResults {
    Invoke-ZipAndEmailResults
}

function Run-CleanupExportFolder {
    Run-CleanupExportFolder
}

function Show-AgentMaintenanceMenu {
    do {
        Clear-Host
        Write-Host ""
        Write-Host "====================================================="
        Write-Host "         CS Toolbox – Agent Maintenance Tool"
        Write-Host "====================================================="
        Write-Host ""
        Write-Host " [1] Check Agent Service Status"
        Write-Host " [2] Clear Pending Agent Jobs"
        Write-Host " [3] Enable SMB (Registry + Firewall)"
        Write-Host " [4] Check SMB Configuration"
        Write-Host ""
        Write-Host " [Z] Zip and Email Results"
        Write-Host " [C] Cleanup Export Folder"
        Write-Host " [Q] Quit to Main Menu"
        Write-Host ""
        $choice = Read-Host "Select an option"

        switch ($choice.ToUpper()) {
            '1' { Run-CheckAgentStatus }
            '2' { Run-ClearPendingJobs }
            '3' { Run-SetSMB }
            '4' { Run-CheckSMB }
            'Z' { Run-ZipAndEmailResults }
            'C' { Run-CleanupExportFolder }
            'Q' { return }
            default {
                Write-Host "Invalid selection. Try again." -ForegroundColor Yellow
                Pause-Script
            }
        }
    } while ($true)
}

Show-AgentMaintenanceMenu
