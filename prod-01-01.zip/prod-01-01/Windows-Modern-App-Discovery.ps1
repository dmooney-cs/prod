# Windows Application Discovery (Appx/UWP) - Subscript
# Menu: [1] List All  [2] Search by Name  [Q] Return to Launcher
# Exports: C:\CS-Toolbox-TEMP\Collected-Info\WindowsApps

# =========================
# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder
# =========================

# ----- Paths / helpers (kept) -----
$ExportRoot = 'C:\CS-Toolbox-TEMP\Collected-Info\WindowsApps'
if (-not (Test-Path $ExportRoot)) { New-Item -ItemType Directory -Path $ExportRoot -Force | Out-Null }

function Sanitize-ForFileName {
    param([Parameter(Mandatory)][string]$Text)
    return ($Text -replace '[\\/:*?"<>|]+','_')
}

function Export-AppxData {
    param(
        [Parameter(Mandatory)][System.Collections.IEnumerable]$Data,
        [Parameter(Mandatory)][string]$BaseName
    )

    $timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $hostName  = $env:COMPUTERNAME
    $base      = Sanitize-ForFileName -Text $BaseName
    $csvPath   = Join-Path $ExportRoot "$($base)_$($hostName)_$($timestamp).csv"
    $jsonPath  = Join-Path $ExportRoot "$($base)_$($hostName)_$($timestamp).json"

    $Data | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath
    $Data | ConvertTo-Json -Depth 5 | Out-File -FilePath $jsonPath -Encoding UTF8

    return [PsCustomObject]@{
        Csv   = $csvPath
        Json  = $jsonPath
        Count = ($Data | Measure-Object).Count
    }
}

function Format-AppxProjection {
    param([Parameter(Mandatory)][System.Collections.IEnumerable]$Data)
    $Data | Select-Object `
        Name,
        PackageFullName,
        Version,
        Architecture,
        Publisher,
        NonRemovable,
        IsFramework,
        IsResourcePackage,
        InstallLocation
}

function Get-AllAppx {
    Get-AppxPackage -AllUsers
}

function Search-AppxByName {
    param([Parameter(Mandatory)][string]$Pattern)
    $like = if ($Pattern -match '\*|\?') { $Pattern } else { "*$Pattern*" }
    Get-AppxPackage -AllUsers | Where-Object { $_.Name -like $like }
}

# ----- Menu rendering (matched to Tools-Utilities style) -----
function Show-Menu {
    Clear-Host
    Show-Header "Windows Application Discovery"

    Write-Host ""
    Write-Host " [1] List All Apps              - Appx/UWP inventory (All Users)" -ForegroundColor White
    Write-Host " [2] Search for Specific App    - Name filter (wildcards OK)" -ForegroundColor White
    Write-Host ""
    Write-Host " [Q] Quit (return to Launcher)" -ForegroundColor Yellow
    Write-Host ""
}

# ----- Actions (kept) -----
function Do-ListAll {
    Show-Header "Windows Application Discovery - List All"
    try {
        Write-Host "[INFO] Collecting Appx packages for all users..." -ForegroundColor Cyan
        $raw = Get-AllAppx
        $data = Format-AppxProjection -Data $raw
        $export = Export-AppxData -Data $data -BaseName 'WindowsApps-AllUsers'

        $count = $export.Count
        Write-Host ""
        Write-Host ("Found {0} Appx packages." -f $count) -ForegroundColor Green
        if ($count -gt 0) {
            $preview = $data | Sort-Object Name | Select-Object Name, Version, Architecture, Publisher, InstallLocation -First 20
            $preview | Format-Table -AutoSize
            if ($count -gt 20) {
                Write-Host ("...and {0} more not shown." -f ($count - 20)) -ForegroundColor DarkGray
            }
        }

        Write-Host ""
        Write-Host "Exports saved to:" -ForegroundColor Yellow
        Write-Host " CSV : $($export.Csv)" -ForegroundColor Gray
        Write-Host " JSON: $($export.Json)" -ForegroundColor Gray

    } catch {
        Write-Host "❌ ERROR listing apps: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script "Press any key to return to the menu..."
}

function Do-Search {
    Show-Header "Windows Application Discovery - Search"
    try {
        $pattern = Read-Host "Enter full or partial app name (wildcards OK, e.g., *Viewer*)"
        if ([string]::IsNullOrWhiteSpace($pattern)) {
            Write-Host "No pattern entered. Returning to menu..." -ForegroundColor DarkYellow
            Pause-Script
            return
        }

        Write-Host ("[INFO] Searching for Appx with Name like: {0}" -f $pattern) -ForegroundColor Cyan
        $raw = Search-AppxByName -Pattern $pattern
        $data = Format-AppxProjection -Data $raw
        $base = "WindowsApps-Search-$((Sanitize-ForFileName $pattern))"
        $export = Export-AppxData -Data $data -BaseName $base

        $count = $export.Count
        Write-Host ""
        Write-Host ("Matches found: {0}" -f $count) -ForegroundColor Green
        if ($count -gt 0) {
            $data | Sort-Object Name | Select-Object Name, Version, Architecture, Publisher, InstallLocation | Format-Table -AutoSize
        } else {
            Write-Host "No Appx packages matched your search." -ForegroundColor DarkYellow
        }

        Write-Host ""
        Write-Host "Exports saved to:" -ForegroundColor Yellow
        Write-Host " CSV : $($export.Csv)" -ForegroundColor Gray
        Write-Host " JSON: $($export.Json)" -ForegroundColor Gray

    } catch {
        Write-Host "❌ ERROR searching apps: $($_.Exception.Message)" -ForegroundColor Red
    }
    Pause-Script "Press any key to return to the menu..."
}

# ----- Main loop (matched to Tools-Utilities quit flow) -----
while ($true) {
    Show-Menu
    $choice = Read-Host "Enter your choice"
    if (-not $choice) { continue }

    switch ($choice.ToUpper()) {
        '1' { Do-ListAll }
        '2' { Do-Search }
        'Q' {
            # Relaunch main CS Toolbox Launcher in the SAME window
            $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
            if (Test-Path $launcher) {
                & $launcher
            }
            return
        }
        default {
            Write-Host "Invalid selection." -ForegroundColor Yellow
            Start-Sleep -Milliseconds 800
        }
    }
}