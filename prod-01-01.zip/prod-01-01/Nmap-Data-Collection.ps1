#requires -version 5.1
<#
 Nmap-Data-Collection.ps1
 - Restores auto-download/auto-unzip of the ConnectSecure Nmap folder if not present
 - Lists adapters, suggests targets, runs Quick or Deep scans, and saves results
 - Exports to C:\CS-Toolbox-TEMP\Collected-Info\Network
#>

# =========================
# Load shared functions first – required for Show-Header and others
# (Per project requirement: this block must appear at the very top of every script)
# =========================
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $($_)" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

param(
    [switch]$ReturnToLauncher = $true
)

# =========================
# Config
# =========================
$NmapZipUrl   = 'https://github.com/dmooney-cs/prod/raw/refs/heads/main/nmap.zip'
$NmapFolder   = 'C:\Program Files (x86)\CyberCNSAgent\nmap'
$NmapExe      = Join-Path $NmapFolder 'nmap.exe'
$NmapDataDir  = $NmapFolder  # nmap scripts and data (optional --datadir)
$TempZipPath  = Join-Path $env:TEMP 'cs-nmap.zip'
$ExportRoot   = 'C:\CS-Toolbox-TEMP\Collected-Info\Network'

# =========================
# Helpers
# =========================
function Test-Admin {
    try { return ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) }
    catch { return $false }
}

function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-Tls12 {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
}

function Expand-Archive-Force {
    param(
        [Parameter(Mandatory)][string]$ZipPath,
        [Parameter(Mandatory)][string]$Destination
    )
    try {
        # PowerShell Expand-Archive sometimes trips over existing files; -Force helps.
        Expand-Archive -Path $ZipPath -DestinationPath $Destination -Force
        return $true
    } catch {
        Write-Host "❌ Extract failed: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

function Fix-NestedNmapFolder {
    # In earlier zips, content could end up in ...\nmap\nmap\ after extraction.
    $nested = Join-Path $NmapFolder 'nmap'
    $nestedExe = Join-Path $nested 'nmap.exe'
    if (Test-Path $nestedExe) {
        Write-Host "ℹ️ Detected nested nmap folder. Flattening..." -ForegroundColor Yellow
        Get-ChildItem -Path $nested -Force -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                Move-Item -Path $_.FullName -Destination $NmapFolder -Force
            } catch {
                Write-Host "WARN: Failed moving $($_.FullName): $($_.Exception.Message)" -ForegroundColor Yellow
            }
        }
        try { Remove-Item -Path $nested -Recurse -Force -ErrorAction SilentlyContinue } catch {}
    }
}

function Ensure-NmapAvailable {
    if (Test-Path -LiteralPath $NmapExe) { return $true }

    if (-not (Test-Admin)) {
        Write-Host "❌ Nmap not found and admin rights are required to install to `"$NmapFolder`"." -ForegroundColor Red
        Pause-Script "Press any key to exit..."
        exit 1
    }

    Write-Host ""
    Write-Host "ConnectSecure nmap not found at:" -ForegroundColor Yellow
    Write-Host "  $NmapExe" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "→ Downloading and installing ConnectSecure nmap components..." -ForegroundColor Cyan

    Ensure-Tls12
    Ensure-Directory -Path $NmapFolder

    try {
        Invoke-WebRequest -Uri $NmapZipUrl -OutFile $TempZipPath -UseBasicParsing -ErrorAction Stop
    } catch {
        Write-Host "❌ Download failed: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }

    if (-not (Test-Path -LiteralPath $TempZipPath)) {
        Write-Host "❌ Download appears to have failed: $TempZipPath not found." -ForegroundColor Red
        return $false
    }

    $ok = Expand-Archive-Force -ZipPath $TempZipPath -Destination $NmapFolder
    try { Remove-Item -Path $TempZipPath -Force -ErrorAction SilentlyContinue } catch {}

    if (-not $ok) { return $false }

    # Handle nested folder case
    Fix-NestedNmapFolder

    if (Test-Path -LiteralPath $NmapExe) {
        Write-Host "✅ Nmap installed at: $NmapExe" -ForegroundColor Green
        return $true
    } else {
        Write-Host "❌ nmap.exe still not found after extraction. Please verify the ZIP contents." -ForegroundColor Red
        return $false
    }
}

function Get-IPv4Info {
    # Collect basic IPv4 info from Get-NetIPConfiguration
    $results = @()
    try {
        $configs = Get-NetIPConfiguration -ErrorAction Stop
        foreach ($c in $configs) {
            foreach ($ip in ($c.IPv4Address | Where-Object { $_.IPAddress })) {
                $gw = ($c.IPv4DefaultGateway | Select-Object -First 1).NextHop
                $results += [pscustomobject]@{
                    Interface = $c.InterfaceAlias
                    IPv4      = $ip.IPAddress
                    Prefix    = [int]$ip.PrefixLength
                    Gateway   = $gw
                }
            }
        }
    } catch {
        # Fallback WMI if needed
        $adapters = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled=TRUE" -ErrorAction SilentlyContinue
        foreach ($a in $adapters) {
            if ($a.IPAddress) {
                for ($i=0; $i -lt $a.IPAddress.Count; $i++) {
                    if ($a.IPAddress[$i] -match '^\d{1,3}(\.\d{1,3}){3}$') {
                        $mask = $a.IPSubnet[$i]
                        $prefix = 24
                        if ($mask -match '^\d{1,2}$') { $prefix = [int]$mask }
                        $gw = ($a.DefaultIPGateway | Select-Object -First 1)
                        $results += [pscustomobject]@{
                            Interface = $a.Description
                            IPv4      = $a.IPAddress[$i]
                            Prefix    = $prefix
                            Gateway   = $gw
                        }
                    }
                }
            }
        }
    }
    return $results
}

function Get-NetworkAddress {
    param(
        [Parameter(Mandatory)][string]$IPv4,
        [Parameter(Mandatory)][int]$Prefix
    )
    try {
        $ipBytes = [System.Net.IPAddress]::Parse($IPv4).GetAddressBytes()
        [array]::Reverse($ipBytes)
        $ipInt = [BitConverter]::ToUInt32($ipBytes,0)
        $mask = [uint32]([uint32]0xFFFFFFFF -shl (32 - $Prefix))
        $net = $ipInt -band $mask
        $netBytes = [BitConverter]::GetBytes($net)
        [array]::Reverse($netBytes)
        return ([System.Net.IPAddress]::new($netBytes)).ToString()
    } catch { return $null }
}

function Suggest-Targets {
    param([Parameter(Mandatory)][object[]]$IPv4Info)
    $targets = New-Object System.Collections.Generic.HashSet[string]

    foreach ($row in $IPv4Info) {
        $host = "$($row.IPv4)/32"
        [void]$targets.Add($host)

        # Exact network from prefix (if sane)
        if ($row.Prefix -ge 8 -and $row.Prefix -le 30) {
            $net = Get-NetworkAddress -IPv4 $row.IPv4 -Prefix $row.Prefix
            if ($net) { [void]$targets.Add("$net/$($row.Prefix)") }
        }

        # Common wider ranges for quick selection
        $octets = $row.IPv4.Split('.')
        if ($octets.Count -eq 4) {
            $classC = "$($octets[0]).$($octets[1]).$($octets[2]).0/24"
            $classB = "$($octets[0]).$($octets[1]).0.0/16"
            [void]$targets.Add($classC)
            [void]$targets.Add($classB)
        }
    }

    return $targets.ToArray()
}

function Invoke-NmapScan {
    param(
        [Parameter(Mandatory)][string]$Mode,        # Quick|Deep
        [Parameter(Mandatory)][string]$Target,
        [Parameter(Mandatory)][string]$OutDir
    )

    Ensure-Directory -Path $OutDir
    $ts = Get-Date -Format 'yyyyMMdd_HHmmss'
    $label = if ($Mode -eq 'Quick') { 'Quick' } else { 'Deep' }
    $outTxt = Join-Path $OutDir "Nmap-Scan_${ts}_${label}.txt"
    $outXml = Join-Path $OutDir "Nmap-Scan_${ts}_${label}.xml"

    # Build args
    if ($Mode -eq 'Quick') {
        # Fast: service/version light, top ports
        $args = @(
            '--datadir', $NmapDataDir,
            '-sV','-T4','-F','--version-light',
            '-oN', $outTxt,
            '-oX', $outXml,
            $Target
        )
    } else {
        # Deep: more ports and retries; tuned but not extreme
        $args = @(
            '--datadir', $NmapDataDir,
            '-sV','-T3','--top-ports','3000','-Pn',
            '--max-retries','2',
            '-oN', $outTxt,
            '-oX', $outXml,
            $Target
        )
    }

    Write-Host ""
    Write-Host "[INFO] Running: `"$NmapExe`" $($args -join ' ')" -ForegroundColor DarkCyan
    Write-Host ""

    try {
        & $NmapExe @args
    } catch {
        Write-Host "❌ Nmap failed: $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }

    return [pscustomobject]@{ TextPath = $outTxt; XmlPath = $outXml }
}

# =========================
# UI + Flow
# =========================
Clear-Host
Show-Header "Nmap Data Collection - Local Network Overview"

# Ensure export folder (and Network subfolder)
Ensure-Directory -Path $ExportRoot

# Ensure Nmap is available or download+install it
if (-not (Ensure-NmapAvailable)) {
    Pause-Script "Press any key to exit..."
    exit 1
}

# Display adapter info
$ipv4Info = Get-IPv4Info
Write-Host "Detected IPv4 interfaces:" -ForegroundColor Cyan
if (-not $ipv4Info -or $ipv4Info.Count -eq 0) {
    Write-Host "No IPv4 interfaces detected. Using localhost." -ForegroundColor Yellow
    $ipv4Info = ,([pscustomobject]@{ Interface='Loopback'; IPv4='127.0.0.1'; Prefix=32; Gateway=$null })
}
$ipv4Info | Format-Table -AutoSize

# Suggested targets
$choices = Suggest-Targets -IPv4Info $ipv4Info
Write-Host ""
Write-Host "Suggested targets:" -ForegroundColor Cyan
$index = 0
foreach ($c in $choices) {
    $index++
    Write-Host (" [{0}] {1}" -f $index, $c)
}
Write-Host " [C] Custom target" -ForegroundColor Yellow
Write-Host ""

# Read target choice
$target = $null
while (-not $target) {
    $sel = Read-Host "Select 1-$index or 'C'"
    if ($sel -match '^[cC]$') {
        $t = Read-Host "Enter target or CIDR (e.g., 10.0.0.0/24 or host list)"
        if ($t) { $target = $t }
    } elseif ($sel -as [int] -and [int]$sel -ge 1 -and [int]$sel -le $index) {
        $target = $choices[[int]$sel - 1]
    }
}

# Scan mode
Write-Host ""
Write-Host "Scan mode:" -ForegroundColor Cyan
Write-Host " [1] Quick (top ports, fast, version light)"
Write-Host " [2] Deep  (more ports and detail)"
$modeSel = Read-Host "Choose scan mode (default 1)"
if ([string]::IsNullOrWhiteSpace($modeSel)) { $modeSel = '1' }
$mode = if ($modeSel -eq '2') { 'Deep' } else { 'Quick' }

# Run scan
$result = Invoke-NmapScan -Mode $mode -Target $target -OutDir $ExportRoot

Write-Host ""
if ($null -ne $result) {
    Write-Host "✅ Scan complete." -ForegroundColor Green
    Write-Host "Text output : $($result.TextPath)"
    Write-Host "XML output  : $($result.XmlPath)"
} else {
    Write-Host "❌ Scan failed or produced no output files." -ForegroundColor Red
}

Write-Host ""
Pause-Script "Press any key to return to the Launcher..."

# Return to launcher (same window) if present
$launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1'
if ($ReturnToLauncher -and (Test-Path $launcher)) {
    Clear-Host
    & $launcher
}