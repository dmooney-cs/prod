# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    return
}

Ensure-ExportFolder

<# 
.SYNOPSIS
  Nmap Data Collection with agent-aware defaults and selectable targets.

.NOTES
  Exports are written to C:\CS-Toolbox-TEMP\Collected-Info
  Requires nmap in "C:\Program Files (x86)\CyberCNSAgent\nmap\nmap.exe" or auto-restore from bundled ZIP if missing.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ----- Helpers -----
function _Ok   ($m) { Write-Host $m -ForegroundColor Green }
function _Info ($m) { Write-Host $m -ForegroundColor Cyan }
function _Warn ($m) { Write-Host $m -ForegroundColor Yellow }
function _Err  ($m) { Write-Host $m -ForegroundColor Red }

function Get-IPv4Adapters {
    try {
        $nics = Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $_.IPv4Address -and $_.NetAdapter.Status -eq 'Up' }
        $out = foreach ($n in $nics) {
            [pscustomobject]@{
                Interface = $n.InterfaceAlias
                IPv4      = $n.IPv4Address.IPAddress
                Prefix    = $n.IPv4Address.PrefixLength
                Gateway   = ($n.IPv4DefaultGateway.NextHop | Select-Object -First 1)
            }
        }
        return $out
    } catch {
        # Fallback for older hosts
        $cfg = Get-WmiObject Win32_NetworkAdapterConfiguration -ErrorAction SilentlyContinue | Where-Object { $_.IPEnabled -and $_.IPAddress }
        foreach ($c in $cfg) {
            $ipv4 = ($c.IPAddress | Where-Object { $_ -match '^\d{1,3}(\.\d{1,3}){3}$' })[0]
            if ($null -ne $ipv4) {
                [pscustomobject]@{
                    Interface = $c.Description
                    IPv4      = $ipv4
                    Prefix    = ($c.IPSubnet | Select-Object -First 1 | ForEach-Object {
                        # rough /24 default if WMI returns dotted mask
                        if ($_ -match '^\d+\.\d+\.\d+\.\d+$') { 
                            $mask = [System.Net.IPAddress]::Parse($_).GetAddressBytes()
                            ($mask | ForEach-Object { [Convert]::ToString($_,2).PadLeft(8,'0') } -join '').ToCharArray() | Where-Object { $_ -eq '1' } | Measure-Object | Select-Object -ExpandProperty Count
                        } else { $_ }
                    })
                    Gateway   = ($c.DefaultIPGateway | Select-Object -First 1)
                }
            }
        }
    }
}

function _BuildSuggestions($ipv4, $prefix) {
    # ipv4 like 10.0.0.242, prefix int
    if (-not $ipv4) { return @() }
    $parts = $ipv4.Split('.')
    if ($parts.Count -ne 4) { return @("$ipv4/32") }
    $net24 = "$($parts[0]).$($parts[1]).$($parts[2]).0/24"
    $net16 = "$($parts[0]).$($parts[1]).0.0/16"
    return @("$ipv4/32", $net24, $net16)
}

function Ensure-Nmap {
    $expected = "C:\Program Files (x86)\CyberCNSAgent\nmap\nmap.exe"
    if (Test-Path $expected) { return $expected }

    _Warn "ConnectSecure nmap not found at: $expected"
    # Try to restore from bundled nmap.zip if present next to this script
    $zipPath = Join-Path $scriptRoot 'nmap.zip'
    $destDir = Split-Path $expected -Parent
    try {
        if (Test-Path $zipPath) {
            _Info "Restoring nmap from bundled ZIP..."
            if (-not (Test-Path $destDir)) { New-Item -ItemType Directory -Path $destDir | Out-Null }
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $destDir, $true)
            if (Test-Path $expected) {
                _Ok "nmap restored to $destDir"
                return $expected
            }
        }
    } catch {
        _Err "Failed to restore nmap: $($_.Exception.Message)"
    }
    return $null
}

# ----- UI Header -----
Clear-Host
Show-Header "Nmap Data Collection - Local Network Overview"

Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $env:COMPUTERNAME, $env:USERNAME, ([bool](whoami /groups | findstr /I "S-1-16-12288") -or ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))) -ForegroundColor Gray
Write-Host ""

# ----- 1) Detect adapters -----
$adapters = @(Get-IPv4Adapters)
if ($adapters.Count -gt 0) {
    _Info "Detected IPv4 interfaces:"
    $adapters | Sort-Object Interface,IPv4 | Format-Table -AutoSize
    Write-Host ""
} else {
    _Warn "No active IPv4 adapters detected."
}

# ----- 2) Suggest targets or ask custom -----
$Target = $null
if ($adapters.Count -eq 0) {
    _Warn "No adapters. Enter a custom target."
    $Target = Read-Host "Target (e.g., 192.168.1.0/24)"
} else {
    $adapters | Sort-Object Interface,IPv4 | Format-Table -AutoSize | Out-String | Write-Host
    $suggestions = New-Object System.Collections.Generic.List[string]
    foreach ($r in $adapters) {
        foreach ($s in (_BuildSuggestions $r.IPv4 $r.Prefix)) { 
            if (-not $suggestions.Contains($s)) { $suggestions.Add($s) } 
        }
    }
    Write-Host ""
    Write-Host "Suggested targets:" -ForegroundColor Cyan
    for ($i=0; $i -lt $suggestions.Count; $i++) {
        Write-Host (" [{0}] {1}" -f ($i+1), $suggestions[$i])
    }
    Write-Host " [C] Custom target" -ForegroundColor Yellow
    Write-Host " [Q] Quit to Main Menu" -ForegroundColor Yellow
    $choice = Read-Host "Select 1-$($suggestions.Count), or 'C' or 'Q'"

    if ($choice -match '^[Qq]$') {
        try { Launch-Tool "CS-Toolbox-Launcher.ps1" } catch { Write-Host "⚠ Could not relaunch main menu: $($_.Exception.Message)" -ForegroundColor Yellow }
        return
    } elseif ($choice -match '^[Cc]$') {
        $Target = Read-Host "Enter custom target (IP/CIDR/range/hosts file)"
    } elseif ($choice -match '^\d+$' -and [int]$choice -ge 1 -and [int]$choice -le $suggestions.Count) {
        $Target = $suggestions[[int]$choice - 1]
    } else {
        _Warn "Invalid selection."
        $Target = Read-Host "Enter custom target (IP/CIDR/range/hosts file)"
    }
}

if ([string]::IsNullOrWhiteSpace($Target)) {
    _Err "No target specified. Exiting."
    Pause-Script -Seconds 5
    return
}

# ----- 3) Ensure nmap -----
$nmapExe = Ensure-Nmap
if (-not $nmapExe) {
    _Err "nmap.exe unavailable. Cannot continue."
    Pause-Script
    return
}

# ----- 4) Mode selection -----
$CliMode = $null
Write-Host ""
Write-Host "Scan Modes:" -ForegroundColor Cyan
Write-Host "  [1] Quick  - top 1000 ports, host discovery enabled (drop dead IPs early), FULL scripts"
Write-Host "  [2] Deep   - top 3000 ports, -Pn (treat all as up), FULL scripts"
$m = Read-Host "Choose 1 or 2"
if     ($m -eq '1') { $CliMode = 'Quick' }
elseif ($m -eq '2') { $CliMode = 'Deep'  }
else   { _Warn "Invalid mode; defaulting to Quick."; $CliMode = 'Quick' }

# ----- 5) Outputs -----
$ts     = Get-Date -Format "yyyyMMdd_HHmmss"
$comp   = $env:COMPUTERNAME
$base   = "Nmap-Scan-$comp-$ts-$CliMode"
$OutRoot = "C:\CS-Toolbox-TEMP\Collected-Info"
$outBase = Join-Path $OutRoot $base
$logPath = "$outBase.log"
$xmlPath = "$outBase.xml"
$gnmap   = "$outBase.gnmap"
$jsonOut = "$outBase.json"

# ----- 6) Build CLI by mode -----
$common = @(
    "--datadir", ("{0}" -f (Split-Path $nmapExe -Parent)),
    "--privileged",
    "--script-timeout", "1500000ms",
    "--host-timeout", "1900000ms",
    "--max-retries", "2",
    "--max-rtt-timeout", "2000ms",
    "-oX", $xmlPath,
    "-oG", $gnmap,
    "-oN", $logPath
)

if ($CliMode -eq 'Quick') {
    $args = @(
        "-T3",
        "--min-parallelism", "100",
        "--max-parallelism", "255",
        "--top-ports", "1000",
        "--min-hostgroup", "30",
        "--max-hostgroup", "64",
        "-sV"
    ) + $common + @($Target)
} else { # Deep
    $args = @(
        "-T3",
        "--min-parallelism", "100",
        "--max-parallelism", "255",
        "--top-ports", "3000",
        "--min-hostgroup", "30",
        "--max-hostgroup", "64",
        "-sV",
        "-Pn"
    ) + $common + @($Target)
}

# ----- 7) Execute -----
_Info "Starting nmap $CliMode scan on $Target ..."
try {
    & $nmapExe @args | Out-Null
    _Ok "Scan complete."
} catch {
    _Err "nmap failed: $($_.Exception.Message)"
    Pause-Script
    return
}

# ----- 8) Summarize -----
try {
    # light summary from gnmap
    $hostsUp = 0
    if (Test-Path $gnmap) {
        $hostsUp = (Select-String -Path $gnmap -Pattern "Status: Up").Count
    }
    Write-Host ""
    _Info ("Summary: Hosts Up = {0}" -f $hostsUp)
    _Info ("Outputs: `n  Log  : {0}`n  GNMAP: {1}`n  XML  : {2}" -f $logPath, $gnmap, $xmlPath)
} catch {
    _Warn "Could not compute summary: $($_.Exception.Message)"
}

Pause-Script "Press any key to return to the main menu..."
try { Launch-Tool "CS-Toolbox-Launcher.ps1" } catch { _Warn "Could not relaunch main menu: $($_.Exception.Message)" }
