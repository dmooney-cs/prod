# ===== CS Toolbox Bootstrap (idempotent) =====
# Establish script root & global paths
$script:CS_ScriptRoot = Split-Path -Parent $PSCommandPath
if (-not $global:CS_TempRoot)       { $global:CS_TempRoot = Join-Path $env:SystemDrive 'CS-Toolbox-TEMP' }
if (-not $global:CSLauncherRoot)    { $global:CSLauncherRoot = $script:CS_ScriptRoot }

# Dot-source Functions-Common.ps1 when available
$__common = Join-Path $script:CS_ScriptRoot 'Functions-Common.ps1'
if (Test-Path $__common) {
    . $__common
}

# Safe fallbacks if functions were not loaded
if (-not (Get-Command Ensure-ExportFolder -ErrorAction SilentlyContinue)) {
    function Ensure-ExportFolder {
        param([Parameter(Mandatory)][string]$Path)
        if (-not (Test-Path $Path)) { New-Item -Path $Path -ItemType Directory -Force | Out-Null }
        return (Resolve-Path $Path).Path
    }
}
if (-not (Get-Command Show-Header -ErrorAction SilentlyContinue)) {
    function Show-Header {
        param([Parameter(Mandatory)][string]$Title)
        $line = '=' * 58
        Write-Host " $Title`n$line"
    }
}
if (-not (Get-Command Write-SessionSummary -ErrorAction SilentlyContinue)) {
    function Write-SessionSummary {
        param(
            [string]$Title = "Session Summary",
            [string]$LogPath = "",
            [hashtable]$Meta = @{}
        )
        Write-Host ""
        Write-Host "== $Title =="
        if ($Meta) {
            $Meta.GetEnumerator() | Sort-Object Name | ForEach-Object {
                Write-Host ("{0,-16}: {1}" -f $_.Name, $_.Value)
            }
        }
        if ($LogPath) { Write-Host ("Log file".PadRight(16) + ": " + $LogPath) }
        Write-Host ""
    }
}
if (-not (Get-Command Return-To-Launcher -ErrorAction SilentlyContinue)) {
    function Return-To-Launcher {
        param(
            [string]$Launcher = $(Join-Path $global:CSLauncherRoot 'CS-Toolbox-Launcher.ps1')
        )
        if (Test-Path $Launcher) {
            try {
                # Pre-empt security prompts
                if (Get-Item -LiteralPath $Launcher -ErrorAction SilentlyContinue) {
                    Unblock-File -LiteralPath $Launcher -ErrorAction SilentlyContinue
                }
            } catch {}
            # Same-window transfer back to launcher
            . $Launcher
        } else {
            Write-Host "Launcher not found at: $Launcher"
        }
    }
}
# Unblock helper (idempotent)
if (-not (Get-Command Unblock-Tree -ErrorAction SilentlyContinue)) {
    function Unblock-Tree {
        param([Parameter(Mandatory)][string]$Root)
        if (Test-Path $Root) {
            Get-ChildItem -Path $Root -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
                try { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue } catch {}
            }
        }
    }
}
# ===== End Bootstrap =====

# -------------------------------------------------------------------------------------------------
# Constants & Paths
# -------------------------------------------------------------------------------------------------
$scriptRoot  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info'
$ExportPatch = Join-Path $ExportRoot 'Patch'
$ExportTLS   = Join-Path $ExportRoot 'TLS'
$ExportReg   = Join-Path $ExportRoot 'Registry'

# -------------------------------------------------------------------------------------------------
# Helpers (fully inlined)
# -------------------------------------------------------------------------------------------------
function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Ensure-ExportFolder {
    Ensure-Directory -Path (Split-Path -Parent $ExportRoot)
    Ensure-Directory -Path $ExportRoot
    Ensure-Directory -Path $ExportPatch
    Ensure-Directory -Path $ExportTLS
    Ensure-Directory -Path $ExportReg
}

function Get-IsAdmin {
    try {
        $id  = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $prp = New-Object System.Security.Principal.WindowsPrincipal($id)
        return $prp.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Pause-Script {
    try {
        Write-Host ""
        Write-Host "Press any key to continue..." -ForegroundColor DarkGray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    } catch {
        $null = Read-Host "Press ENTER to continue"
    }
}

function Show-Header {
    param([string]$Title = "Secondary Validation Tools")
    Clear-Host
    $isAdmin = Get-IsAdmin
    $hostName = $env:COMPUTERNAME
    $userName = "$env:USERDOMAIN\$env:USERNAME"

    Write-Host ("   ConnectSecure Technicians Toolbox".PadRight(80,' ')) -ForegroundColor Cyan
    Write-Host ("========================================================") -ForegroundColor Cyan
    Write-Host (" Host: {0}   User: {1}   Admin: {2}" -f $hostName, $userName, ($isAdmin -as [bool])) -ForegroundColor Gray
    Write-Host (" Tool: {0}" -f $Title) -ForegroundColor Gray
    Write-Host ""
}

# --------------------------
# Network download with retries (3 tries, 2s delay)
# --------------------------
function Invoke-DownloadWithRetry {
    param(
        [Parameter(Mandatory)][string]$Uri,
        [Parameter(Mandatory)][string]$OutFile,
        [int]$MaxAttempts = 3,
        [int]$DelaySeconds = 2
    )

    if (Test-Path -LiteralPath $OutFile) {
        Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
    }

    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        Write-Host ("Downloading... Attempt {0}/{1}" -f $attempt, $MaxAttempts) -ForegroundColor Cyan
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile -UseBasicParsing -ErrorAction Stop
            if ((Test-Path -LiteralPath $OutFile) -and ((Get-Item -LiteralPath $OutFile).Length -gt 0)) {
                Write-Host "Download successful." -ForegroundColor Green
                return $true
            } else {
                throw "Downloaded file is missing or empty."
            }
        } catch {
            if (Test-Path -LiteralPath $OutFile) {
                Remove-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue
            }
            if ($attempt -eq $MaxAttempts) {
                Write-Host ("ERROR: Download failed on attempt {0}/{1}: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Red
                return $false
            } else {
                Write-Host ("Attempt {0}/{1} failed: {2}" -f $attempt, $MaxAttempts, $_.Exception.Message) -ForegroundColor Yellow
                Write-Host ("   Retrying in {0} seconds..." -f $DelaySeconds) -ForegroundColor Yellow
                Start-Sleep -Seconds $DelaySeconds
            }
        }
    }

    return $false
}

# Load shared functions first – required for Show-Header and others
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$commonPath = Join-Path $scriptRoot 'Functions-Common.ps1'

if (-not (Test-Path $commonPath)) {
    Write-Host "❌ ERROR: Functions-Common.ps1 not found in $scriptRoot" -ForegroundColor Red
    Pause-Script
    return
}

try {
    $code = Get-Content -Path $commonPath -Encoding UTF8 -Raw
    Invoke-Expression $code
} catch {
    Write-Host "❌ ERROR: Failed to load Functions-Common.ps1: $_" -ForegroundColor Red
    Pause-Script
    return
}

Ensure-ExportFolder

# --- Auto-install Nmap into Program Files if missing/empty (PS 5.1-safe) ---
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
$__NmapInstallPath = "C:\Program Files (x86)\CyberCNSAgent\nmap"
$__NmapDownloadedThisRun = $false
if (-not (Test-Path $__NmapInstallPath)) { New-Item -Path $__NmapInstallPath -ItemType Directory -Force | Out-Null }
$__nmapExe = Join-Path $__NmapInstallPath 'nmap.exe'
$__needsInstall = -not (Test-Path $__nmapExe)
if ($__needsInstall) {
    Write-Host "Preparing Nmap in Program Files..." -ForegroundColor Yellow
    $zipUrl  = "https://github.com/dmooney-cs/prod/raw/refs/heads/main/nmap.zip"
    $zipPath = Join-Path $env:TEMP "nmap-portable.zip"

    $ok = Invoke-DownloadWithRetry -Uri $zipUrl -OutFile $zipPath -MaxAttempts 3 -DelaySeconds 2
    if ($ok) {
        try {
            Expand-Archive -Path $zipPath -DestinationPath $__NmapInstallPath -Force
            # Handle a nested 'nmap\' folder inside the ZIP
            $nestedExe = Join-Path $__NmapInstallPath "nmap\nmap.exe"
            if (Test-Path $nestedExe) {
                $nestedFolder = Split-Path $nestedExe -Parent
                Get-ChildItem -Path $nestedFolder -Force | Move-Item -Destination $__NmapInstallPath -Force
                Remove-Item -Path $nestedFolder -Recurse -Force -ErrorAction SilentlyContinue
            }
            # Unblock binaries to avoid SmartScreen prompts
            Get-ChildItem -Path $__NmapInstallPath -Recurse -File -Force | Unblock-File -ErrorAction SilentlyContinue
            $__NmapDownloadedThisRun = $true
        } catch {
            Write-Host "WARN: Failed to extract/install Nmap: $($_.Exception.Message)" -ForegroundColor Yellow
        } finally {
            try { Remove-Item -LiteralPath $zipPath -Force -ErrorAction SilentlyContinue } catch {}
        }
    } else {
        Write-Host "WARN: Nmap download did not succeed after 3 attempts." -ForegroundColor Yellow
    }
}
if ($__NmapDownloadedThisRun) {
    Write-Host "NOTE: A copy of Nmap was downloaded to '$__NmapInstallPath' for this session." -ForegroundColor Yellow
}
# --- End auto-install block ---

# =========================
#    Nmap Data Collection
# =========================
$NmapHome    = 'C:\Program Files (x86)\CyberCNSAgent\nmap'
$NmapExe     = Join-Path $NmapHome 'nmap.exe'
$ExportRoot  = 'C:\CS-Toolbox-TEMP\Collected-Info\Network'
$QuickArgs   = @('-sV','-T4','-F','--version-light')
$DeepArgs    = @('-sV','-T3','--top-ports','3000','-Pn')
$DefaultScan = '1'

function Restart-LauncherSameWindow {
    $launcher = $null
    if ($global:CSLauncherRoot -and (Test-Path $global:CSLauncherRoot)) {
        $launcher = Join-Path $global:CSLauncherRoot 'CS-Toolbox-Launcher.ps1'
    }
    if (-not $launcher) { $launcher = Join-Path $scriptRoot 'CS-Toolbox-Launcher.ps1' }
    if (Test-Path $launcher) { & $launcher }
}

function Ensure-NmapReady {
    $mirror = Join-Path $scriptRoot 'nmap-bin'
    if (-not (Test-Path $NmapHome)) { New-Item -Path $NmapHome -ItemType Directory -Force | Out-Null }
    if (Test-Path $mirror) {
        robocopy $mirror $NmapHome *.* /E /NFL /NDL /NJH /NJS /NC /NS | Out-Null
        Write-Host "[INFO] Mirrored files to $NmapHome"
    }
    if (-not (Test-Path $NmapExe)) { throw "Nmap not found at $NmapExe" }
    Write-Host "[INFO] Nmap ready: $NmapExe"
}

function Get-IPv4Interfaces {
    $results = @()
    try {
        foreach ($a in Get-NetIPConfiguration -ErrorAction Stop) {
            foreach ($ip in ($a.IPv4Address | Where-Object { $_ })) {
                if ($ip.PrefixLength -lt 0 -or $ip.PrefixLength -gt 32) { continue }
                $gw = $null
                if ($a.IPv4DefaultGateway) { $gw = ($a.IPv4DefaultGateway | Select-Object -First 1).NextHop }
                $results += [pscustomobject]@{
                    Name    = $a.InterfaceAlias
                    IPv4    = $ip.IPAddress
                    Prefix  = [int]$ip.PrefixLength
                    Gateway = $gw
                }
            }
        }
    } catch { }
    $results
}

function ConvertTo-NetworkCIDR {
    param([string]$Ip, [int]$Prefix)
    try {
        $ipBytes = [System.Net.IPAddress]::Parse($Ip).GetAddressBytes()
        [array]::Reverse($ipBytes)
        $ipInt = [BitConverter]::ToUInt32($ipBytes,0)
        $mask = 0
        if ($Prefix -gt 0) { $mask = [uint32]::MaxValue -shl (32 - $Prefix) }
        $net = $ipInt -band $mask
        $netBytes = [BitConverter]::GetBytes([uint32]$net)
        [array]::Reverse($netBytes)
        $netIp = [System.Net.IPAddress]::new($netBytes)
        return "$($netIp.IPAddressToString)/$Prefix"
    } catch { return $null }
}

function Choose-Targets {
    param([object[]]$Ifaces)

    Write-Host "`nDetected IPv4 interfaces:" -ForegroundColor Cyan
    foreach ($i in $Ifaces) {
        $cidrDisplay = ConvertTo-NetworkCIDR -Ip $i.IPv4 -Prefix $i.Prefix
        if (-not $cidrDisplay) { $cidrDisplay = '<n/a>' }
        $gwDisplay = if ($i.Gateway) { $i.Gateway } else { '<none>' }
        Write-Host (" - {0,-25} {1}/{2} (GW {3})  ->  {4}" -f $i.Name, $i.IPv4, $i.Prefix, $gwDisplay, $cidrDisplay)
    }

    $options = @()
    foreach ($i in $Ifaces) {
        $cidr = ConvertTo-NetworkCIDR -Ip $i.IPv4 -Prefix $i.Prefix
        if ($cidr) { $options += [pscustomobject]@{ Label = $cidr; Src = $i.Name } }
    }

    Write-Host "`nAvailable subnets to scan:" -ForegroundColor Cyan
    $idx = 1
    foreach ($o in $options) {
        Write-Host (" [{0}] {1,-18} ({2})" -f $idx, $o.Label, $o.Src)
        $idx++
    }

    $hostOnly = $Ifaces | Select-Object -First 1
    Write-Host (" [0]  This host only: {0}" -f $hostOnly.IPv4)
    Write-Host (" [C]  Custom target (IP / range / CIDR)")
    Write-Host (" [Q]  Exit to Toolbox Launcher")

    $choice = Read-Host ("Select target number(s) (comma-separated). Default $DefaultScan")
    if ([string]::IsNullOrWhiteSpace($choice)) { $choice = $DefaultScan }

    if ($choice -match '^[qQ]$') { return @{ ExitToLauncher = $true } }

    $targets = New-Object System.Collections.Generic.List[string]
    foreach ($p in ($choice -split '\s*,\s*')) {
        switch -Regex ($p) {
            '^[0]$' { $targets.Add($hostOnly.IPv4) }
            '^[cC]$' {
                $custom = Read-Host "Enter custom target (IP / range / CIDR)"
                if ($custom) { $targets.Add($custom) }
            }
            '^\d+$' {
                $n = [int]$p
                if ($n -ge 1 -and $n -le $options.Count) { $targets.Add($options[$n-1].Label) }
            }
        }
    }
    if ($targets.Count -eq 0) { $targets.Add($hostOnly.IPv4) }
    return @{ Targets = $targets }
}

function Choose-ScanMode {
    Write-Host "`nScan mode:" -ForegroundColor Cyan
    Write-Host " [1] Quick (top ports, fast, version light)"
    Write-Host " [2] Deep  (engineer-approved profile)"
    $mode = Read-Host "Choose scan mode (default 1)"
    if ([string]::IsNullOrWhiteSpace($mode)) { $mode = '1' }
    if ($mode -eq '2') { return @{ Name='Deep'; Args=$DeepArgs } }
    return @{ Name='Quick'; Args=$QuickArgs }
}

function Run-Nmap {
    param([string[]]$Targets, [string]$ProfileName, [array]$Args)

    if (-not (Test-Path $ExportRoot)) { New-Item -Path $ExportRoot -ItemType Directory -Force | Out-Null }
    $dateStamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $base = Join-Path $ExportRoot ("Nmap-Scan_{0}_{1}" -f $dateStamp, $ProfileName)
    $outN = "$base.txt"
    $outX = "$base.xml"

    $argList = @()
    if ($Args) { $argList += $Args }
    $argList += @('-oN', $outN, '-oX', $outX)
    $argList += $Targets

    $cmdPreview = "`"$NmapExe`" " + ($argList -join ' ')
    Write-Host "[INFO] Running: $cmdPreview"

    $proc = Start-Process -FilePath $NmapExe -ArgumentList $argList -NoNewWindow -Wait -PassThru
    $exit = if ($proc) { $proc.ExitCode } else { 1 }

    return [pscustomobject]@{
        OutText  = $outN
        OutXml   = $outX
        ExitCode = $exit
    }
}

# ---- Main loop ----
try {
    Ensure-NmapReady

    while ($true) {
        Show-Header "Nmap Data Collection - Local Network Overview"

        $ifaces = Get-IPv4Interfaces
        if (-not $ifaces) { $ifaces = @([pscustomobject]@{ Name='Localhost'; IPv4='127.0.0.1'; Prefix=32; Gateway=$null }) }

        $targetChoice = Choose-Targets -Ifaces $ifaces
        if ($targetChoice.ContainsKey('ExitToLauncher') -and $targetChoice.ExitToLauncher) {
            Restart-LauncherSameWindow
            break
        }

        $mode = Choose-ScanMode
        $res = Run-Nmap -Targets $targetChoice.Targets -ProfileName $mode.Name -Args $mode.Args

        Write-Host ""
        if ($res.ExitCode -ne 0) { Write-Host ("⚠️  Nmap exited with code {0}" -f $res.ExitCode) -ForegroundColor Yellow }
        Write-Host "Scan complete." -ForegroundColor Green
        Write-Host (" Targets : {0}" -f ($targetChoice.Targets -join ', '))
        Write-Host (" Profile : {0}" -f $mode.Name)
        Write-Host (" Output  :`n  - Text: {0}`n  - XML : {1}" -f $res.OutText, $res.OutXml)

        Write-SessionSummary
        Write-Host ""
        Write-Host "Returning to selection menu... (Press Q at the menu to exit to the Toolbox Launcher.)" -ForegroundColor DarkGray
        Start-Sleep -Seconds 1
    }
} catch {
    Write-Host "❌ ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-SessionSummary
    Pause-Script "Press any key to return to the Toolbox Launcher..."
    Restart-LauncherSameWindow
}
